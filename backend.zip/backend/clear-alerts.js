require('dotenv').config();
const mongoose = require('mongoose');
const CaseModel = require('./models/Case');
const fs = require('fs');
const path = require('path');

let AlertModel = null;
try {
  AlertModel = require('./models/Alert');
} catch (e) {}

const clearAlerts = async () => {
  try {
    const issuesFile = path.join(__dirname, 'data', 'issues.json');
    if (fs.existsSync(issuesFile)) {
      const data = JSON.parse(fs.readFileSync(issuesFile, 'utf8'));
      const filtered = data.filter(c => c.status === 'Resolved' || c.status === 'Closed' || (c.severity !== 'High' && c.severity !== 'Critical' && (c.riskPercentage || 0) <= 60));
      fs.writeFileSync(issuesFile, JSON.stringify(filtered, null, 2));
      console.log('Cleared active high-risk cases from JSON fallback.');
    }

    if (process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/animal-health') {
      await mongoose.connect(process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/animal-health');
      
      const res = await CaseModel.deleteMany({
        status: { $nin: ['Resolved', 'Closed'] },
        $or: [
          { severity: { $in: ['High', 'Critical'] } },
          { riskPercentage: { $gt: 60 } }
        ]
      });
      console.log(`Deleted ${res.deletedCount} active red alert cases from MongoDB.`);

      if (AlertModel) {
        await AlertModel.deleteMany({});
        console.log('Cleared all computed Alert documents.');
      }
      
      await mongoose.disconnect();
    }
    
    console.log('Cleanup complete. Active Red Alerts = 0.');
    process.exit(0);
  } catch (err) {
    console.error('Error clearing alerts:', err);
    process.exit(1);
  }
};

clearAlerts();
