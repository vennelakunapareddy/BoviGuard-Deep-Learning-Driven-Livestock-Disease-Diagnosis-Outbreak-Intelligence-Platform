/**
 * Epidemiological Database: Spreadable (Contagious / Epidemic Risk) vs. Non-Spreadable
 * Specialized for Water Buffalo Disease Surveillance (CommonJS Backend - 6 Core Visible Classes)
 */

const CLASS_NAMES = [
  "Foot_and_Mouth_Disease",
  "Healthy_Buffalo",
  "Lumpy_Skin_Disease",
  "Mastitis",
  "Multiple_Disease_Diagnosis"
];

const MANDATORY_ISOLATION_INSTRUCTION =
  "Isolate this buffalo immediately. Vacate the immediate shed area to prevent spreading to the rest of the herd. Do not share water or feed troughs.";

const FMD_HALLMARK_KEYWORDS = [
  "mouth",
  "tongue",
  "lip",
  "gum",
  "saliv",
  "drool",
  "hoof",
  "foot",
  "feet",
  "blister",
  "vesicle",
  "lame",
  "ulcer",
  "smack"
];

function checkFmdSymptomCorroboration(symptoms) {
  if (!symptoms) return false;
  let symList = [];
  if (Array.isArray(symptoms)) {
    symList = symptoms;
  } else if (typeof symptoms === 'string') {
    try {
      const parsed = JSON.parse(symptoms);
      if (Array.isArray(parsed)) symList = parsed;
      else symList = [symptoms];
    } catch {
      symList = symptoms.split(/[,;|]/).map(s => s.trim()).filter(Boolean);
    }
  }

  const combined = symList.join(' ').toLowerCase();
  return FMD_HALLMARK_KEYWORDS.some(kw => combined.includes(kw));
}

const CLINICAL_SAMPLE_DIRECTIVES = {
  Mastitis: {
    key: "Mastitis",
    title: "Milk Sample Submission Directive",
    instruction: "Please provide milk samples (from each affected quarter in sterile vials) to the concerned veterinarian for further testing (California Mastitis Test, bacterial culture, Somatic Cell Count, and antibiotic sensitivity) for targeted treatment."
  },
  Foot_and_Mouth_Disease: {
    key: "Foot_and_Mouth_Disease",
    title: "Vesicular / Saliva Sample Submission Directive",
    instruction: "Please provide vesicular fluid/swabs from unruptured blisters, oral epithelium, or saliva samples to the concerned veterinarian for confirmatory RT-PCR and ELISA testing."
  },
  Lumpy_Skin_Disease: {
    key: "Lumpy_Skin_Disease",
    title: "Skin Nodule & Blood Sample Submission Directive",
    instruction: "Please provide skin lesion biopsy, scabs, or EDTA whole blood/serum samples to the concerned veterinarian for PCR laboratory confirmation."
  },
  Multiple_Disease_Diagnosis: {
    key: "Multiple_Disease_Diagnosis",
    title: "Differential Laboratory Testing Panel Directive",
    instruction: "Please provide blood, serum, and lesion swab samples to the concerned veterinarian for differential panel testing (FMD, Vesicular Stomatitis, BVD, Foot Rot) to identify the exact pathogen."
  },
  Healthy_Buffalo: {
    key: "Healthy_Buffalo",
    title: "Routine Baseline Monitoring",
    instruction: "Routine baseline health profile — no immediate diagnostic sample required. Continue routine periodic health and milk quality checks."
  }
};

const DISEASE_AWARENESS = {
  Foot_and_Mouth_Disease: {
    stopSpread: "Immediately isolate affected buffalo in a separate quarantine shed. Halt all animal movement and milk transport from farm premises. Wash mouth lesions and hooves with 1% potassium permanganate or 4% sodium carbonate. Disinfect barn floors and footwear before entering or leaving.",
    preventFuture: "Administer bi-annual FMD vaccination to the entire herd prior to monsoon and winter seasons. Maintain a strict 21-day quarantine protocol for all newly purchased livestock. Provide separate feeding and watering troughs."
  },
  Lumpy_Skin_Disease: {
    stopSpread: "House affected buffalo under mosquito/fly netting to prevent vector transmission (flies, mosquitoes, ticks) to healthy stock. Spray shed premises daily with neem oil or cypermethrin. Apply antiseptic sprays to open skin lesions.",
    preventFuture: "Vaccinate all cattle and buffaloes annually with goat pox or homologous LSD vaccine before summer/monsoon. Eliminate standing water, drain stagnant pools, and clear manure heaps around the barn to suppress insect breeding."
  },
  Mastitis: {
    stopSpread: "Always milk infected buffalo quarters last into a separate container and discard contaminated milk safely. Never let mastitic milk spill on bedding. Wash and disinfect hands and milking utensils thoroughly before and after milking each animal.",
    preventFuture: "Implement post-milking teat dipping in 0.5% povidone-iodine solution. Keep animal bedding dry, clean, and free of manure accumulation. Conduct monthly California Mastitis Test (CMT) screenings and apply dry cow therapy during lactation cessation."
  },
  Multiple_Disease_Diagnosis: {
    stopSpread: "Enforce strict isolation in a quarantine stall pending veterinary laboratory confirmation. Disinfect all footwear, troughs, and shed surfaces with broad-spectrum virucidal and bactericidal solutions.",
    preventFuture: "Enforce comprehensive biosecurity protocols, adhere to routine vaccination schedules (FMD, HS, BQ), verify health certificates for all new livestock, and maintain optimal herd nutrition and sanitary housing."
  },
  Healthy_Buffalo: {
    stopSpread: "Maintain standard shed hygiene, daily washing, and separate quarantine stalls for incoming animals.",
    preventFuture: "Maintain balanced green and dry fodder with essential mineral mixtures, ensure unrestricted access to clean drinking water, adhere to bi-annual FMD vaccinations, and perform regular deworming."
  }
};

const DISEASE_EPIDEMIOLOGY = {
  // --- SPREADABLE (EPIDEMIC RISK) ---
  Foot_and_Mouth_Disease: {
    key: "Foot_and_Mouth_Disease",
    displayName: "Foot-and-Mouth Disease (FMD)",
    isSpreadable: true,
    category: "Spreadable (Epidemic Risk)",
    severity: "Critical",
    transmission: "Highly contagious viral (aerosol, contact, milk).",
    precaution: "Strict quarantine, halt animal movement.",
    additionalPrecautions: [
      "Halt all animal movement and milk transport from premises.",
      "Use potassium permanganate (1% KMnO4) foot and mouth washes.",
      "Separate milking utensils and boil milk before disposal.",
      "Disinfect sheds with 4% sodium carbonate or citric acid."
    ]
  },
  Lumpy_Skin_Disease: {
    key: "Lumpy_Skin_Disease",
    displayName: "Lumpy Skin Disease (LSD)",
    isSpreadable: true,
    category: "Spreadable (Epidemic Risk)",
    severity: "High",
    transmission: "Contagious via biting flies, mosquitoes, and ticks.",
    precaution: "Mosquito/fly control, complete isolation.",
    additionalPrecautions: [
      "Rigorous insect and vector control using neem oil or cypermethrin sprays.",
      "Keep infected buffalo under mosquito-proof netting if possible.",
      "Apply topical antiseptic/iodine to ruptured nodules to avoid fly strike.",
      "Provide soft digestible greens and electrolyte water."
    ]
  },
  Multiple_Disease_Diagnosis: {
    key: "Multiple_Disease_Diagnosis",
    displayName: "Multiple Disease Diagnosis (Differential Assessment Required)",
    isSpreadable: true,
    category: "Multiple / Differential Risk",
    severity: "High",
    transmission: "Potential multi-pathogen / vesicular / systemic risk.",
    precaution: "Strict isolation pending veterinary differential laboratory tests.",
    additionalPrecautions: [
      "Isolate the buffalo immediately from healthy herd members.",
      "Provide blood, serum, and lesion swabs to the veterinarian for differential testing (FMD vs VSV vs BVD).",
      "Sanitize feed troughs, waterers, and shed floors with broad-spectrum disinfectant.",
      "Closely monitor other herd animals for similar symptoms."
    ]
  },

  // --- NON-SPREADABLE (LOCALIZED / ENVIRONMENTAL) ---
  Mastitis: {
    key: "Mastitis",
    displayName: "Clinical Mastitis",
    isSpreadable: false,
    category: "Non-Spreadable (Localized/Environmental)",
    severity: "Medium",
    transmission: "Hygiene-based bacterial infection of udder quarters.",
    precaution: "Milk infected buffalo last, sanitize milking area.",
    additionalPrecautions: [
      "Provide milk samples to the veterinarian for CMT and antibiotic sensitivity.",
      "Follow clean milking technique and strip-cup testing.",
      "Post-milking teat dipping in disinfectant iodine solution.",
      "Ensure dry, clean bedding free of manure.",
      "Discard milk from infected quarters; do not feed to calves raw."
    ]
  },
  Healthy_Buffalo: {
    key: "Healthy_Buffalo",
    displayName: "Healthy Buffalo",
    isSpreadable: false,
    category: "Non-Spreadable (Healthy Baseline)",
    severity: "Low",
    transmission: "N/A",
    precaution: "N/A",
    additionalPrecautions: [
      "Maintain balanced green and dry fodder with essential mineral mixture.",
      "Ensure clean drinking water freely available.",
      "Keep up-to-date with routine vaccinations (FMD bi-annually)."
    ]
  }
};

function normalizeDiseaseKey(input) {
  if (!input) return "Healthy_Buffalo";
  const str = String(input).trim().toLowerCase();

  if (str.includes("multiple") || str.includes("differential")) return "Multiple_Disease_Diagnosis";
  if (str.includes("brucell")) return "Mastitis";
  if (str.includes("wound") || str.includes("cutaneous") || str.includes("trauma")) return "Multiple_Disease_Diagnosis";
  if (str.includes("foot") || str.includes("fmd") || str.includes("mouth")) return "Foot_and_Mouth_Disease";
  if (str.includes("lumpy") || str.includes("lsd")) return "Lumpy_Skin_Disease";
  if (str.includes("mastitis") || str.includes("udder") || str.includes("milk")) return "Mastitis";
  if (str.includes("health")) return "Healthy_Buffalo";

  return "Healthy_Buffalo";
}

function getDiseaseInfo(diseaseName) {
  const canonicalKey = normalizeDiseaseKey(diseaseName);
  return DISEASE_EPIDEMIOLOGY[canonicalKey] || DISEASE_EPIDEMIOLOGY.Healthy_Buffalo;
}

function isSpreadableDisease(diseaseName) {
  const info = getDiseaseInfo(diseaseName);
  return Boolean(info && info.isSpreadable);
}

module.exports = {
  CLASS_NAMES,
  MANDATORY_ISOLATION_INSTRUCTION,
  FMD_HALLMARK_KEYWORDS,
  checkFmdSymptomCorroboration,
  CLINICAL_SAMPLE_DIRECTIVES,
  DISEASE_AWARENESS,
  DISEASE_EPIDEMIOLOGY,
  normalizeDiseaseKey,
  getDiseaseInfo,
  isSpreadableDisease
};
