const mongoose = require('mongoose');

const healthRecordSchema = new mongoose.Schema({
  animalId: { type: mongoose.Schema.Types.ObjectId, ref: 'Animal', required: true },
  recordType: { type: String, enum: ['AI Analysis', 'Symptom Reported', 'Diagnosis', 'Treatment', 'Medication', 'Vaccination', 'Note'], required: true },
  description: { type: String, required: true },
  date: { type: Date, default: Date.now },
  veterinarianId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  caseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Case' }, // Optional link to a specific case
});

module.exports = mongoose.model('HealthRecord', healthRecordSchema);
