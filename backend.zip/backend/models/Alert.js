const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema({
  disease: { type: String, required: true },
  animalType: { type: String, required: true, enum: ['Buffalo'], default: 'Buffalo' },
  area: { type: String, required: true },
  totalCases: { type: Number, required: true, default: 0 },
  caseCount: { type: Number, required: true, default: 0 },
  severityScore: { type: Number, min: 0, max: 100, default: 0 },
  radius: { type: Number, default: 5000 },
  alertLevel: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'], default: 'Low' },
  severityTrend: { type: String, default: 'Stable' },
  coordinates: {
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
  },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Alert', alertSchema);
