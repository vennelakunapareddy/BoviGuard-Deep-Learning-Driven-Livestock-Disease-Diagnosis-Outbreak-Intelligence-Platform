const mongoose = require('mongoose');

const animalSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true }, // e.g. Tag number or name
  species: { type: String, required: true, enum: ['Buffalo'], default: 'Buffalo' },
  breed: { type: String, trim: true },
  age: { type: Number }, // in months or years
  sex: { type: String, enum: ['Male', 'Female', 'Unknown'], default: 'Unknown' },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  location: {
    area: { type: String, required: true },
    latitude: { type: Number },
    longitude: { type: Number },
  },
  status: { type: String, enum: ['Healthy', 'At Risk', 'Under Treatment', 'Recovered', 'Critical'], default: 'Healthy' },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Animal', animalSchema);
