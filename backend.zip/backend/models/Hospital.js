const mongoose = require('mongoose');

const hospitalSchema = new mongoose.Schema({
  name: { type: String, required: true },
  hospitalName: { type: String },
  category: { type: String },
  facilityType: { type: String },
  city: { type: String },
  distanceText: { type: String },
  rating: { type: Number, default: 4.5 },
  userRatingsTotal: { type: Number, default: 100 },
  isOpenNow: { type: Boolean, default: true },
  timings: { type: String },
  phone: { type: String, required: true },
  bestFor: { type: String },
  address: { type: String, required: true },
  latitude: { type: Number, required: true },
  longitude: { type: Number, required: true },
  emergencyAvailable: { type: Boolean, default: true },
  googleMapsUrl: { type: String },
  directionsUrl: { type: String },
  source: { type: String },
  createdAt: { type: Date, default: Date.now },
}, { strict: false });

module.exports = mongoose.model('Hospital', hospitalSchema);
