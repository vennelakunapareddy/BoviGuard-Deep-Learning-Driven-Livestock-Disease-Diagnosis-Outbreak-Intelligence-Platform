const mongoose = require('mongoose');

const caseSchema = new mongoose.Schema({
  caseId: { type: String, unique: true, required: true, trim: true },
  animalId: { type: mongoose.Schema.Types.ObjectId, ref: 'Animal' },
  animalType: { type: String, enum: ['Buffalo'], required: true, default: 'Buffalo' },
  tagNumber: { type: String, required: true, trim: true },
  buffaloName: { type: String, trim: true },
  age: { type: Number, required: true },
  gender: { type: String, enum: ['Female', 'Male'], default: 'Female' },
  breed: { type: String, required: true, default: 'Murrah' },
  affectedCount: { type: Number, default: 1 },
  ownerName: { type: String, required: true, trim: true },
  
  // Location
  area: { type: String, required: true, trim: true },
  streetName: { type: String, required: true, trim: true },
  pincode: { type: String, required: true, trim: true },
  locationSource: { type: String, enum: ['detected', 'manual'], default: 'manual' },
  latitude: { type: Number, required: true },
  longitude: { type: Number, required: true },

  // Health & Symptoms
  symptoms: [{ type: String, required: true }],
  diseaseDescription: { type: String, trim: true },
  symptomsStartDate: { type: Date },
  temperature: { type: String, trim: true },
  medicalHistory: { type: String, trim: true },
  currentTreatment: { type: String, trim: true },
  veterinarianName: { type: String, trim: true },

  // Image & AI Analysis
  image: { type: String },
  images: [{ type: String }],
  diseasePrediction: { type: String, required: true, default: 'Pending Diagnosis' },
  confidenceScore: { type: Number, required: true, default: 85, min: 0, max: 100 },
  severity: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'], default: 'Low' },
  riskPercentage: { type: Number, min: 0, max: 100 },
  recommendations: [{ type: String }],
  precautions: [{ type: String }],
  immediateAction: { type: String },
  vetAttentionRecommended: { type: Boolean, default: true },

  // Status & Notes
  status: { type: String, enum: ['Open', 'Under Treatment', 'Recovered', 'Closed', 'Emergency'], default: 'Open' },
  treatmentInfo: { type: String, trim: true },
  veterinaryNotes: { type: String, trim: true },
  followUpNotes: { type: String, trim: true },

  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  veterinarianId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  
  history: [{
    action: { type: String, required: true },
    changedBy: { type: String },
    timestamp: { type: Date, default: Date.now },
    details: { type: String }
  }],

  emergency: { type: Boolean, default: false },
  alertLevel: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'], default: 'Low' },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

caseSchema.index({ caseId: 1 });
caseSchema.index({ tagNumber: 1 });
caseSchema.index({ area: 1, pincode: 1 });
caseSchema.index({ longitude: 1, latitude: 1 });

module.exports = mongoose.model('Case', caseSchema);
