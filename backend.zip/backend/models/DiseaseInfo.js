const mongoose = require('mongoose');

const diseaseInfoSchema = new mongoose.Schema({
  disease_name: { type: String, required: true, unique: true },
  description: { type: String },
  common_symptoms: [{ type: String }],
  severity: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'] },
  precautions: [{ type: String }],
  recommended_action: { type: String },
  emergency_level: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'] },
  prevention: [{ type: String }],
});

module.exports = mongoose.model('DiseaseInfo', diseaseInfoSchema);
