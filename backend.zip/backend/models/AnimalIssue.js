﻿const mongoose = require('mongoose');

const animalIssueSchema = new mongoose.Schema({
  animalType: { type: String, enum: ['Dog', 'Hen', 'Buffalo', 'Goat'], required: true },
  animalImage: { type: String },
  symptoms: { type: String, required: true },
  diseaseType: { type: String, required: true },
  areaName: { type: String, required: true },
  pincode: { type: String, required: true },
  coordinates: {
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
  },
  imageUrl: { type: String },
  diagnosis: { type: String, default: 'Unknown' },
  severity: { type: String, enum: ['low', 'moderate', 'critical'], default: 'low' },
  emergency: { type: Boolean, default: false },
  alertLevel: { type: String, enum: ['GREEN', 'YELLOW', 'RED'], default: 'GREEN' },
  reportedBy: { type: String },
  userRole: { type: String, enum: ['veterinarian', 'volunteer', 'owner'] },
  createdAt: { type: Date, default: Date.now },
});

const AnimalIssue = mongoose.model('AnimalIssue', animalIssueSchema);
module.exports = AnimalIssue;
