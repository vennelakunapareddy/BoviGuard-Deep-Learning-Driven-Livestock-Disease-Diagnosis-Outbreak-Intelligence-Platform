const mongoose = require('mongoose');

const volunteerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true },
  area: { type: String, required: true },
  district: { type: String, default: 'Krishna' },
  mandal: { type: String, default: '' },
  role: { type: String, default: 'Para-Veterinarian' },
  latitude: { type: Number, required: true },
  longitude: { type: Number, required: true },
  availabilityStatus: { 
    type: String, 
    enum: ['available', 'unavailable', 'on-call'], 
    default: 'available' 
  },
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], required: true },
  },
  createdAt: { type: Date, default: Date.now },
});

volunteerSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('Volunteer', volunteerSchema);
