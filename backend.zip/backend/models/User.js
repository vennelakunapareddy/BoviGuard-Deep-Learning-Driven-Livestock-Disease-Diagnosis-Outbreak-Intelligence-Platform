const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String },
  googleId: { type: String },
  avatar: { type: String },
  role: { 
    type: String, 
    required: true, 
    enum: ['Buffalo Owner', 'Animal Owner', 'Volunteer', 'Veterinarian', 'NGO', 'Admin', 'System Admin', 'buffalo_owner', 'animal_owner', 'volunteer', 'veterinarian', 'ngo', 'admin', 'system_admin'],
    default: 'Buffalo Owner' 
  },
  phone: { type: String, trim: true },
  emergencyContactConsent: { type: Boolean, default: false },
  area: { type: String, trim: true },
  streetName: { type: String, trim: true },
  pincode: { type: String, trim: true },
  latitude: { type: Number, min: -90, max: 90 },
  longitude: { type: Number, min: -180, max: 180 },
  availabilityStatus: { type: String, enum: ['Available', 'Unavailable', 'available', 'unavailable'], default: 'Available' },
  organization: { type: String, trim: true },
  notificationPreferences: {
    smsAlerts: { type: Boolean, default: font => true },
    emailAlerts: { type: Boolean, default: true },
    redZoneAlerts: { type: Boolean, default: true }
  },
  verified: { type: Boolean, default: false },
  resetPasswordToken: { type: String },
  resetPasswordOtp: { type: String },
  resetPasswordExpires: { type: Date },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('User', userSchema);
