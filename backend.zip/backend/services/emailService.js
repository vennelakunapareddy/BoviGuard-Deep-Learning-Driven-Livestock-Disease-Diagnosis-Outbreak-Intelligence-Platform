const nodemailer = require('nodemailer');

let cachedTransporter = null;

async function getTransporter() {
  if (cachedTransporter) return cachedTransporter;

  const emailUser = process.env.EMAIL_USER || process.env.SMTP_USER;
  const emailPass = process.env.EMAIL_PASS || process.env.SMTP_PASS;

  if (emailUser && emailPass) {
    const isGmail = (process.env.EMAIL_SERVICE === 'gmail') || emailUser.toLowerCase().includes('@gmail.com');
    if (isGmail) {
      cachedTransporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: emailUser,
          pass: emailPass
        }
      });
      console.log(`[EmailService] Configured Gmail SMTP transporter with user: ${emailUser}`);
    } else {
      cachedTransporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: Number(process.env.SMTP_PORT) || 587,
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: emailUser,
          pass: emailPass
        }
      });
      console.log(`[EmailService] Configured custom SMTP transporter (${process.env.SMTP_HOST}:${process.env.SMTP_PORT}) with user: ${emailUser}`);
    }
    return cachedTransporter;
  }

  // Fallback: Automatic Ethereal test inbox for development/testing if no credentials in .env
  try {
    const testAccount = await nodemailer.createTestAccount();
    cachedTransporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass
      }
    });
    console.log(`[EmailService] No SMTP credentials in .env; generated Ethereal test account: ${testAccount.user}`);
    return cachedTransporter;
  } catch (err) {
    console.warn('[EmailService] Could not generate test account, using json/console transport fallback:', err.message);
    cachedTransporter = nodemailer.createTransport({
      jsonTransport: true
    });
    return cachedTransporter;
  }
}

/**
 * Send Password Reset Email with 6-digit verification code & reset link
 */
async function sendPasswordResetEmail(recipientEmail, userName, resetCode, resetToken) {
  try {
    const transporter = await getTransporter();
    const fromAddress = process.env.EMAIL_FROM || process.env.EMAIL_USER || '"Buffalo Health AI" <no-reply@buffalohealth.org>';

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Buffalo Health - Password Recovery</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0f172a; margin: 0; padding: 32px 16px;">
  <div style="max-width: 560px; margin: 0 auto; background: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.3);">
    
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #059669 0%, #047857 50%, #064e3b 100%); padding: 32px; text-align: center; color: #ffffff;">
      <div style="font-size: 36px; margin-bottom: 8px;">🐃</div>
      <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">Buffalo Health</h1>
      <p style="margin: 6px 0 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #a7f3d0;">Risk & AI Intelligence</p>
    </div>

    <!-- Body -->
    <div style="padding: 36px 32px; color: #1e293b;">
      <h2 style="margin: 0 0 12px; font-size: 20px; font-weight: 800; color: #0f172a;">Password Recovery Request</h2>
      <p style="margin: 0 0 16px; font-size: 14px; color: #475569; line-height: 1.6;">
        Hello <strong>${userName || 'Valued Member'}</strong>,
      </p>
      <p style="margin: 0 0 24px; font-size: 14px; color: #475569; line-height: 1.6;">
        We received a request to reset the password for your Buffalo Health surveillance account (<strong>${recipientEmail}</strong>). Please enter the 6-digit security code below to set your new password:
      </p>

      <!-- 6-Digit Code Box -->
      <div style="background: #f0fdf4; border: 2px dashed #10b981; border-radius: 16px; padding: 20px; text-align: center; margin: 28px 0;">
        <span style="display: block; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #047857; margin-bottom: 6px;">Your 6-Digit Verification Code</span>
        <span style="font-family: Consolas, 'Courier New', monospace; font-size: 36px; font-weight: 900; letter-spacing: 8px; color: #065f46;">${resetCode}</span>
      </div>

      <div style="background: #f8fafc; border-left: 4px solid #10b981; padding: 12px 16px; border-radius: 8px; margin-bottom: 24px;">
        <p style="margin: 0; font-size: 12px; color: #475569; line-height: 1.5;">
          ⏱️ <strong>Validity:</strong> This security code will expire in <strong>15 minutes</strong>.
        </p>
      </div>

      <p style="margin: 0 0 8px; font-size: 13px; color: #64748b; line-height: 1.5;">
        If you did not request a password reset, please ignore this email. Your current password remains safe and unchanged.
      </p>

      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 28px 0 20px;" />

      <!-- Footer Info -->
      <p style="margin: 0; font-size: 11px; color: #94a3b8; text-align: center; line-height: 1.6;">
        Buffalo Health Surveillance Platform • Animal Husbandry & Veterinary Support<br>
        Vijayawada, Andhra Pradesh • Emergency Livestock Helpline: <strong>1962</strong>
      </p>
    </div>
  </div>
</body>
</html>
`;

    const textContent = `
Buffalo Health - Password Recovery
==================================

Hello ${userName || 'Valued Member'},

We received a request to reset your password for your Buffalo Health account (${recipientEmail}).

Your 6-Digit Verification Code: ${resetCode}

This code will expire in 15 minutes.

If you did not request this password reset, please ignore this email.

Emergency Livestock Helpline: 1962
Buffalo Health Surveillance Platform
`;

    const mailOptions = {
      from: fromAddress,
      to: recipientEmail,
      subject: `Buffalo Health - Password Recovery Code: ${resetCode}`,
      text: textContent,
      html: htmlContent
    };

    const info = await transporter.sendMail(mailOptions);
    const previewUrl = nodemailer.getTestMessageUrl(info) || null;

    console.log(`[EmailService] Password reset email dispatched to ${recipientEmail}. MessageId: ${info.messageId || 'sent'}`);
    if (previewUrl) {
      console.log(`[EmailService] Ethereal Web Email Preview: ${previewUrl}`);
    }

    return {
      success: true,
      messageId: info.messageId,
      previewUrl,
      resetCode
    };
  } catch (error) {
    console.error(`[EmailService] Error dispatching password reset email to ${recipientEmail}:`, error);
    throw error;
  }
}

module.exports = {
  sendPasswordResetEmail,
  getTransporter
};
