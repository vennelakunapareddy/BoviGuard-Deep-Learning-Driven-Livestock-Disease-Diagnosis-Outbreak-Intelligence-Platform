const { analyzeImageBuffer } = require('./imageAnalysis');
const { 
  getDiseaseInfo, 
  normalizeDiseaseKey, 
  checkFmdSymptomCorroboration,
  CLINICAL_SAMPLE_DIRECTIVES,
  DISEASE_AWARENESS,
  MANDATORY_ISOLATION_INSTRUCTION 
} = require('../constants/diseaseInfo');

const DISEASE_DETAILS = {
  "Foot-and-Mouth Disease (FMD)": {
    severity: "Critical",
    symptoms: ["Vesicles & blisters on tongue, lips, gums, and hooves", "Profuse stringy salivation", "Severe lameness", "Fever"],
    precautions: [
      "Strictly quarantine affected buffaloes to prevent airborne spread",
      "Apply potassium permanganate (1:1000) solution or mild antiseptic to mouth and hoof lesions",
      "Restrict movement of personnel, vehicles, and feed between farms",
      "Maintain strict foot-bath disinfection at farm entrances"
    ],
    immediate_action: "Report potential FMD outbreak to municipal livestock officer and isolate all exposed animals."
  },
  "Healthy Buffalo": {
    severity: "Low",
    symptoms: ["Normal appetite", "Clear eyes & wet muzzle", "Smooth skin coat", "Active chewing of cud"],
    precautions: [
      "Maintain routine FMD vaccination schedule",
      "Ensure continuous access to clean drinking water and green fodder",
      "Perform periodic deworming every 3-4 months"
    ],
    immediate_action: "No emergency intervention required. Continue standard daily herd care."
  },
  "Lumpy Skin Disease (LSD)": {
    severity: "High",
    symptoms: ["Firm, raised nodular skin bumps (2-5cm)", "Fever", "Swollen leg lymph nodes", "Nasal discharge & lachrymation"],
    precautions: [
      "Use fly, mosquito, and tick repellents (neem oil or cypermethrin sprays)",
      "Isolate infected buffaloes in vector-proof netting areas",
      "Apply topical antiseptic / wound spray on burst nodules to prevent secondary fly strike",
      "Feed soft green grass and supply electrolyte-enriched drinking water"
    ],
    immediate_action: "Isolate buffalo to halt insect vector transmission and request veterinary supportive therapy."
  },
  "Clinical Mastitis": {
    severity: "Medium",
    symptoms: ["Swollen, hard, hot or painful udder quarters", "Abnormal milk (clots, flakes, watery yellow whey)", "Fever"],
    precautions: [
      "Maintain strict hygienic milking techniques (strip cup testing)",
      "Wash teats with warm disinfectant solution before and after milking",
      "Ensure clean, dry bedding free of manure accumulation",
      "Milk affected quarters last and discard contaminated milk safely"
    ],
    immediate_action: "Perform California Mastitis Test (CMT) and consult vet for targeted intramammary antibiotic infusion."
  },
  "Multiple Disease Diagnosis": {
    severity: "High",
    symptoms: ["Overlapping vesicular, mucosal, or systemic clinical signs requiring differential laboratory analysis"],
    precautions: [
      "Enforce strict herd isolation pending veterinary laboratory tests",
      "Sanitize barn floors, waterers, and feed troughs with virucidal disinfectant",
      "Provide blood, serum, and lesion swabs to the veterinarian for differential testing"
    ],
    immediate_action: "Isolate buffalo and request differential veterinary laboratory assessment (FMD vs VSV vs BVD)."
  }
};

async function analyzeCase({ animalType = 'Buffalo', symptoms = [], imageUploaded = false, imagePath = null, imageBuffer = null, requestId = null }) {
  const reqId = requestId || `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  if (!imageUploaded || (!imagePath && !imageBuffer)) {
    return {
      requestId: reqId,
      isBuffalo: false,
      diseasePrediction: 'Verification Required',
      confidenceScore: 0,
      severity: 'Unknown',
      symptoms: [],
      precautions: ['Upload a clear photograph of a buffalo to receive an AI disease analysis.'],
      immediateAction: 'Upload a photo of the buffalo to proceed.',
      isBuffaloDetected: false
    };
  }

  let cnnPrediction = await analyzeImageBuffer(imageBuffer, imagePath, symptoms, reqId);

  if (!cnnPrediction) {
    return {
      requestId: reqId,
      isBuffalo: false,
      diseasePrediction: null,
      confidenceScore: 0,
      severity: 'N/A',
      symptoms: [],
      message: 'ML prediction microservice is unavailable. Please check that the Python FastAPI server is running.',
      precautions: ['Ensure the ML prediction microservice is active.'],
      immediateAction: 'Retry after verifying microservice status.',
      vetAttentionRecommended: false
    };
  }

  if (cnnPrediction.isBuffalo === false) {
    return {
      requestId: cnnPrediction.requestId || reqId,
      isBuffalo: false,
      status: cnnPrediction.status || 'rejected',
      entityType: cnnPrediction.entityType || 'Non-Buffalo Subject',
      predictedSubject: cnnPrediction.predictedSubject || 'Non-Buffalo Image',
      detectedEntityIcon: cnnPrediction.detectedEntityIcon || '⚠️',
      message: cnnPrediction.message || 'Image quality is insufficient for reliable prediction. Please upload a clearer buffalo image.',
      diseasePrediction: null,
      confidenceScore: cnnPrediction.confidenceScore || 0,
      image_quality: cnnPrediction.image_quality || null,
      model_version: cnnPrediction.model_version || '4.0-Trained-4Class-CNN',
      severity: 'N/A',
      symptoms: [],
      precautions: ['Please upload a clear photo showing a buffalo (body, skin, hooves, or udder).'],
      immediateAction: 'Ensure the image clearly features a buffalo before running disease analysis.',
      vetAttentionRecommended: false
    };
  }

  let rawDiseaseName = cnnPrediction.diseasePrediction || cnnPrediction.prediction || 'Healthy Buffalo';
  let canonicalKey = normalizeDiseaseKey(rawDiseaseName);
  let isMultipleMismatch = false;

  // Symptom corroboration note
  const isCorroborated = canonicalKey === 'Foot_and_Mouth_Disease' ? checkFmdSymptomCorroboration(symptoms) : true;

  const epi = getDiseaseInfo(canonicalKey);
  const sampleDirective = CLINICAL_SAMPLE_DIRECTIVES[epi.key] || CLINICAL_SAMPLE_DIRECTIVES.Healthy_Buffalo;
  const awareness = DISEASE_AWARENESS[epi.key] || DISEASE_AWARENESS.Healthy_Buffalo;

  const details = DISEASE_DETAILS[rawDiseaseName] || DISEASE_DETAILS[epi.displayName] || {
    severity: epi.severity || 'Medium',
    symptoms: ['General lethargy', 'Skin or mucosal lesions'],
    precautions: epi.additionalPrecautions || ['Isolate animal', 'Ensure fresh water and clean feed'],
    immediate_action: 'Consult a qualified veterinarian for professional diagnosis.'
  };

  const safeConfidence = Number(cnnPrediction.confidenceScore || cnnPrediction.confidence || 0);

  return {
    requestId: cnnPrediction.requestId || reqId,
    isBuffalo: true,
    status: cnnPrediction.status || (safeConfidence >= 50 ? 'confident' : 'uncertain'),
    message: isMultipleMismatch 
      ? 'Differential diagnosis required: Image features show vesicular signs, but entered symptoms do not corroborate hallmark FMD signs.'
      : (cnnPrediction.message || (safeConfidence >= 50 ? 'Buffalo disease prediction complete.' : 'Prediction uncertain. Please upload a clearer image or consult a veterinarian.')),
    predicted_index: cnnPrediction.predicted_index,
    predicted_class: epi.key,
    prediction: epi.displayName,
    diseasePrediction: epi.displayName,
    canonicalDisease: epi.key,
    isMultipleDiseaseDiagnosis: isMultipleMismatch,
    mismatchNotice: isMultipleMismatch ? "Image features indicated possible vesicular/mucosal pathology, but entered symptoms do not corroborate hallmark Foot-and-Mouth Disease (FMD) signs. Diagnosed as Multiple Disease Diagnosis requiring differential veterinary testing." : null,
    confidence: safeConfidence,
    confidenceScore: safeConfidence,
    raw_logits: cnnPrediction.raw_logits || [],
    probabilities: cnnPrediction.probabilities || {},
    image_quality: cnnPrediction.image_quality || null,
    model_version: cnnPrediction.model_version || '4.0-Trained-4Class-CNN',
    severity: details.severity,
    symptoms: details.symptoms,
    precautions: epi.precaution !== 'N/A' ? [epi.precaution, ...(details.precautions || [])] : details.precautions,
    immediateAction: epi.isSpreadable ? MANDATORY_ISOLATION_INSTRUCTION : details.immediate_action,
    vetAttentionRecommended: details.severity !== 'Low',
    isSpreadable: epi.isSpreadable,
    category: epi.category,
    transmission: epi.transmission,
    precaution: epi.precaution,
    sampleDirective: sampleDirective.instruction,
    awarenessStopSpread: awareness.stopSpread,
    awarenessPreventFuture: awareness.preventFuture,
    veterinaryGuidance: "This result is an AI-assisted screening result and should not be considered a final veterinary diagnosis. Please consult a qualified veterinarian for confirmation and treatment.",
    mandatoryInstruction: epi.isSpreadable ? MANDATORY_ISOLATION_INSTRUCTION : null,
    top3: cnnPrediction.top3 || [],
    allProbabilities: cnnPrediction.allProbabilities || []
  };
}

module.exports = { analyzeCase };

