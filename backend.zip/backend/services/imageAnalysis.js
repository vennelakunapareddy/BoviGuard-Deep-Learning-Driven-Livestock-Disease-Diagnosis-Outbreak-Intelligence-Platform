const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

const ML_SERVICE_URL = process.env.ML_SERVICE_URL || 'http://127.0.0.1:5000';

function toScore(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.round(n * 100) / 100));
}

async function analyzeImageBuffer(buffer, filePath = null, symptoms = [], requestId = null) {
  if (!Buffer.isBuffer(buffer) && !filePath) return null;

  const reqId = requestId || `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const formData = new FormData();
  formData.append('requestId', reqId);
  if (filePath) {
    formData.append('image', fs.createReadStream(filePath));
  } else {
    formData.append('image', buffer, 'upload.jpg');
  }
  if (symptoms && Array.isArray(symptoms) && symptoms.length > 0) {
    formData.append('symptoms', symptoms.join(', '));
  } else if (typeof symptoms === 'string' && symptoms.trim()) {
    formData.append('symptoms', symptoms.trim());
  }

  let response;
  try {
    response = await axios.post(`${ML_SERVICE_URL}/predict`, formData, {
      headers: { ...formData.getHeaders() },
      timeout: 60000,
    });
  } catch (error) {
    if (!error.response) {
      console.warn(`CNN service unavailable at ${ML_SERVICE_URL}.`);
      return null;
    }
    throw error;
  }

  if (!response.data) {
    throw new Error('Empty response from CNN service.');
  }

  if (response.data.isBuffalo === false) {
    return {
      requestId: response.data.requestId || reqId,
      isBuffalo: false,
      status: response.data.status || 'rejected',
      entityType: response.data.entityType || 'Non-Buffalo Subject',
      predictedSubject: response.data.predictedSubject || 'Non-Buffalo Image',
      detectedEntityIcon: response.data.detectedEntityIcon || '⚠️',
      message: response.data.message || 'Prediction failed: No buffalo detected in the image.',
      diseasePrediction: null,
      confidenceScore: toScore(response.data.confidenceScore),
      image_quality: response.data.image_quality || null,
      model_version: response.data.model_version || '4.0-Trained-4Class-CNN',
      severity: 'N/A',
      symptoms: [],
      precautions: ['Please upload a clear photograph of a water buffalo.'],
      immediateAction: 'Ensure the image clearly shows a buffalo before running AI analysis.',
      vetAttentionRecommended: false
    };
  }

  const allProbs = Array.isArray(response.data.allProbabilities)
    ? response.data.allProbabilities.map((t) => ({
        class_index: t.class_index,
        disease_key: t.disease_key,
        disease: t.disease,
        probability: Number(t.probability ?? (toScore(t.confidence) / 100)),
        confidence: toScore(t.confidence),
      })).sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0))
    : [];

  const top3List = Array.isArray(response.data.top3) && response.data.top3.length > 0
    ? response.data.top3.map((t) => ({
        disease_key: t.disease_key,
        disease: t.disease,
        confidence: toScore(t.confidence),
      })).sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0))
    : allProbs.slice(0, 3);

  return {
    requestId: response.data.requestId || reqId,
    isBuffalo: true,
    status: response.data.status || 'confident',
    message: response.data.message || 'Buffalo health analysis complete.',
    model: response.data.model_version || '4.0-Trained-4Class-CNN',
    model_version: response.data.model_version || '4.0-Trained-4Class-CNN',
    predicted_index: response.data.predicted_index,
    predicted_class: response.data.predicted_class || response.data.disease_key,
    prediction: response.data.diseasePrediction || response.data.prediction || 'Healthy Buffalo',
    diseasePrediction: response.data.diseasePrediction || response.data.prediction || 'Healthy Buffalo',
    confidence: toScore(response.data.confidenceScore || response.data.confidence),
    confidenceScore: toScore(response.data.confidenceScore || response.data.confidence),
    raw_logits: response.data.raw_logits || [],
    probabilities: response.data.probabilities || {},
    image_quality: response.data.image_quality || null,
    severity: response.data.severity || 'Low',
    symptoms: response.data.symptoms || [],
    precautions: response.data.precautions || [],
    immediateAction: response.data.immediateAction || '',
    vetAttentionRecommended: response.data.vetAttentionRecommended ?? true,
    findings: allProbs.map((t) => `${t.disease} (${t.confidence}%)`),
    top3: top3List,
    allProbabilities: allProbs,
  };
}

module.exports = { analyzeImageBuffer };
