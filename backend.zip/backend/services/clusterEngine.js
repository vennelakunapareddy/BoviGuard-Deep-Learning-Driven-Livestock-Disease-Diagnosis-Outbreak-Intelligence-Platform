const fs = require('fs');
const path = require('path');
const dataIssuesFile = path.join(__dirname, '..', 'data', 'issues.json');
const { isSpreadableDisease } = require('../constants/diseaseInfo');

const CLUSTER_THRESHOLD = parseInt(process.env.CLUSTER_THRESHOLD || process.env.RED_ALERT_CASE_THRESHOLD || '3', 10);
const CLUSTER_DAYS = parseInt(process.env.CLUSTER_DAYS || '30', 10);
const CLUSTER_RADIUS_KM = Number(process.env.CLUSTER_RADIUS_KM || process.env.RED_ALERT_RADIUS_KM || 1.0);

function normalizeDisease(value) {
  return String(value || '').trim();
}

function toCoords(item) {
  const lat = Number(item?.latitude ?? item?.coordinates?.latitude ?? item?.location?.latitude);
  const lng = Number(item?.longitude ?? item?.coordinates?.longitude ?? item?.location?.longitude);
  if (Number.isFinite(lat) && Number.isFinite(lng) && lat !== 0 && lng !== 0) {
    return { latitude: lat, longitude: lng };
  }
  const area = String(item?.area || '').trim();
  const manualCoords = {
    'MG Road': [16.5115, 80.6441],
    'Benz Circle': [16.5238, 80.6408],
    'Governorpet': [16.5033, 80.6434],
    'Labbipet': [16.5085, 80.6321],
    'Kondapalli': [16.5584, 80.8163],
  };
  const fallback = manualCoords[area];
  if (fallback && fallback.length === 2) {
    return { latitude: Number(fallback[0]), longitude: Number(fallback[1]) };
  }
  return null;
}

function distanceKm(first, second) {
  if (!first || !second) return Number.POSITIVE_INFINITY;
  const dLat = (second.latitude - first.latitude) * Math.PI / 180;
  const dLng = (second.longitude - first.longitude) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(first.latitude * Math.PI / 180) * Math.cos(second.latitude * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

async function checkClusters(newCase, io) {
  if (!newCase || !newCase.diseasePrediction) return;

  const disease = normalizeDisease(newCase.diseasePrediction);
  const area = newCase.area || 'Unknown Area';

  if (newCase.severity === 'High' || newCase.severity === 'Critical') {
    if (io) {
      io.emit('emergency_assistance', {
        caseId: newCase._id,
        area,
        disease,
        message: `EMERGENCY ASSISTANCE NEEDED: Severe individual case of ${disease} in ${area}.`,
        disclaimer: 'Only authorized/verified veterinarians, NGOs, and volunteers should respond. Ensure animal welfare is prioritized. Culling or forced removal is strictly prohibited.',
        timestamp: new Date().toISOString()
      });
    }
  }

  if (disease === 'Healthy / No Visible Disease' || disease === 'Healthy' || disease === 'Healthy Buffalo' || disease === 'Verification Required') return;
  if (!isSpreadableDisease(disease)) {
    console.log(`[cluster-engine] Skipping red alert check for non-spreadable disease: ${disease}`);
    return;
  }

  const clusterWindow = new Date();
  clusterWindow.setDate(clusterWindow.getDate() - CLUSTER_DAYS);

  let recentCases = [];
  try {
    const Case = require('../models/Case');
    if (Case && require('mongoose').connection.readyState === 1) {
      recentCases = await Case.find({
        diseasePrediction: disease,
        status: { $nin: ['Closed', 'Recovered'] },
        createdAt: { $gte: clusterWindow }
      }).lean();
    } else {
      throw new Error('DB offline');
    }
  } catch (err) {
    if (fs.existsSync(dataIssuesFile)) {
      const issues = JSON.parse(fs.readFileSync(dataIssuesFile));
      recentCases = issues.filter(item => 
        normalizeDisease(item.diseasePrediction || item.diseaseType) === disease && 
        item.status !== 'Closed' && 
        item.status !== 'Recovered' && 
        new Date(item.createdAt || item.reportedAt) >= clusterWindow
      );
    }
  }

  const baseCoords = toCoords(newCase) || { latitude: 16.5062, longitude: 80.648 };
  const clusterCandidates = recentCases.filter(item => {
    const itemCoords = toCoords(item);
    if (!itemCoords) return false;
    const sameArea = String(item.area || '').toLowerCase() === String(area || '').toLowerCase();
    const near = distanceKm(baseCoords, itemCoords) <= CLUSTER_RADIUS_KM;
    return sameArea || near;
  });

  console.log('[red-alert-diagnostics]', {
    disease,
    area,
    clusterWindow: clusterWindow.toISOString(),
    baseCoords,
    totalRecentCases: recentCases.length,
    clusterCandidates: clusterCandidates.length,
    threshold: CLUSTER_THRESHOLD,
    radiusKm: CLUSTER_RADIUS_KM,
    manualFallback: !toCoords(newCase) ? 'used-default-centroid' : 'coords-present'
  });

  if (clusterCandidates.length >= CLUSTER_THRESHOLD) {
    const alertMsg = `RED ALERT: Potential disease-risk cluster of ${disease} in ${area}. ${clusterCandidates.length} active cases reported within ${CLUSTER_RADIUS_KM} km (1km region). Immediate quarantine recommended.`;
    console.log(alertMsg);

    if (io) {
      io.emit('red_alert', {
        area,
        disease,
        count: clusterCandidates.length,
        message: alertMsg,
        welfareDisclaimer: 'Never recommend killing, culling, slaughtering, meat export, or forced removal of animals.',
        timestamp: new Date().toISOString()
      });
    }
  }
}

module.exports = { checkClusters };

