const axios = require('axios');

async function resolveAccuratePincode(nominatimData, areaName, cityName, districtName) {
  // 1. Try extracting clean 6-digit pincode from Nominatim postcode
  if (nominatimData && nominatimData.address && nominatimData.address.postcode) {
    const clean = String(nominatimData.address.postcode).replace(/\D/g, '');
    if (/^[1-9]\d{5}$/.test(clean)) {
      return clean;
    }
  }

  // 2. Try regex extraction from display_name string
  if (nominatimData && nominatimData.display_name) {
    const match = nominatimData.display_name.match(/\b[1-9]\d{5}\b/);
    if (match && match[0]) {
      return match[0];
    }
  }

  // 3. Query India Post API via area / city / district
  const candidates = [areaName, cityName, districtName].filter(Boolean);
  for (const name of candidates) {
    try {
      const firstWord = name.split(/[\s,]+/)[0];
      if (firstWord.length < 3) continue;
      const res = await axios.get(`https://api.postalpincode.in/postoffice/${encodeURIComponent(firstWord)}`, { timeout: 4000 });
      if (res.data && res.data[0] && res.data[0].Status === 'Success' && Array.isArray(res.data[0].PostOffice) && res.data[0].PostOffice.length > 0) {
        const pin = res.data[0].PostOffice[0].Pincode;
        if (/^[1-9]\d{5}$/.test(pin)) {
          return pin;
        }
      }
    } catch (e) {
      // Ignore API errors
    }
  }

  return '';
}

async function geocodeLocation(area, streetName, pincode) {
  const queryParts = [];
  if (streetName) queryParts.push(streetName.trim());
  if (area) queryParts.push(area.trim());
  if (pincode) queryParts.push(pincode.trim());
  queryParts.push('India');

  const query = queryParts.filter(Boolean).join(', ');

  try {
    const response = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: {
        q: query,
        format: 'json',
        addressdetails: 1,
        limit: 1,
      },
      headers: {
        'User-Agent': 'BuffaloHealthMonitor/2.0 (contact@buffalohealth.org)',
      },
      timeout: 8000
    });

    const item = response.data && response.data[0];
    if (!item) {
      const fallbackQuery = [area, pincode, 'India'].filter(Boolean).join(', ');
      const fbRes = await axios.get('https://nominatim.openstreetmap.org/search', {
        params: { q: fallbackQuery, format: 'json', addressdetails: 1, limit: 1 },
        headers: { 'User-Agent': 'BuffaloHealthMonitor/2.0' },
        timeout: 8000
      });
      const fbItem = fbRes.data && fbRes.data[0];
      if (fbItem) {
        const exactPincode = await resolveAccuratePincode(fbItem, area, '', '');
        return {
          valid: true,
          latitude: Number(fbItem.lat),
          longitude: Number(fbItem.lon),
          pincode: exactPincode || pincode || '',
          displayName: fbItem.display_name,
        };
      }
      return { valid: false, message: 'Unable to geocode the provided location.' };
    }

    const exactPincode = await resolveAccuratePincode(item, area, '', '');
    return {
      valid: true,
      latitude: Number(item.lat),
      longitude: Number(item.lon),
      pincode: exactPincode || pincode || '',
      displayName: item.display_name,
    };
  } catch (error) {
    console.warn('Geocoding service error:', error.message);
    return { valid: false, message: 'Geocoding service is currently unavailable.' };
  }
}

async function reverseGeocode(lat, lon) {
  try {
    const response = await axios.get('https://nominatim.openstreetmap.org/reverse', {
      params: {
        lat: lat,
        lon: lon,
        format: 'json',
        addressdetails: 1,
      },
      headers: {
        'User-Agent': 'BuffaloHealthMonitor/2.0 (contact@buffalohealth.org)',
      },
      timeout: 8000
    });

    const item = response.data;
    if (!item || item.error) {
      return { valid: false, message: 'Unable to reverse geocode.' };
    }

    const address = item.address || {};
    const areaName = address.suburb || address.neighbourhood || address.village || address.town || address.city_district || address.county || '';
    const cityName = address.city || address.town || address.village || '';
    const districtName = address.state_district || address.county || address.district || '';

    const exactPincode = await resolveAccuratePincode(item, areaName, cityName, districtName);

    return {
      valid: true,
      latitude: Number(item.lat),
      longitude: Number(item.lon),
      area: areaName,
      streetName: address.road || address.pedestrian || address.suburb || '',
      pincode: exactPincode,
      city: cityName,
      district: districtName,
      state: address.state || '',
      country: address.country || '',
      displayName: item.display_name,
    };
  } catch (error) {
    console.warn('Reverse geocoding error:', error.message);
    return { valid: false, message: 'Reverse geocoding service is unavailable.' };
  }
}

module.exports = { geocodeLocation, reverseGeocode };
