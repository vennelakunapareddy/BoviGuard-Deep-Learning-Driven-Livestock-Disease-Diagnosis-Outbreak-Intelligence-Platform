const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

const jwtSecret = process.env.JWT_SECRET || 'animal_health_secret';

async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || req.headers.Authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token missing.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, jwtSecret);
    // If mongoose is connected use DB, otherwise read from fallback users file
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const User = require('../models/User');
      const user = await User.findById(decoded.id).select('-password');
      if (!user) return res.status(401).json({ message: 'Invalid token.' });
      req.user = user;
      return next();
    }

    const usersFile = path.join(__dirname, '..', 'data', 'users.json');
    let users = [];
    if (fs.existsSync(usersFile)) users = JSON.parse(fs.readFileSync(usersFile));
    const found = users.find((u) => String(u.id) === String(decoded.id));
    if (!found) return res.status(401).json({ message: 'Invalid token.' });
    // emulate mongoose user object minimally
    req.user = { _id: found.id, id: found.id, name: found.name, email: found.email, role: found.role, phone: found.phone, emergencyContactConsent: found.emergencyContactConsent || false, area: found.area, latitude: found.latitude, longitude: found.longitude, availabilityStatus: found.availabilityStatus || 'available' };
    return next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired token.' });
  }
}

async function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization || req.headers.Authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, jwtSecret);
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const User = require('../models/User');
      const user = await User.findById(decoded.id).select('-password');
      if (user) req.user = user;
      return next();
    }

    const usersFile = path.join(__dirname, '..', 'data', 'users.json');
    let users = [];
    if (fs.existsSync(usersFile)) users = JSON.parse(fs.readFileSync(usersFile, 'utf8'));
    const found = users.find((u) => String(u.id) === String(decoded.id));
    if (found) {
      req.user = { _id: found.id, id: found.id, name: found.name, email: found.email, role: found.role, phone: found.phone, emergencyContactConsent: found.emergencyContactConsent || false, area: found.area, latitude: found.latitude, longitude: found.longitude, availabilityStatus: found.availabilityStatus || 'available' };
    }
  } catch (error) {
    // Ignore invalid or expired token for optional auth
  }
  return next();
}

function requireRole(roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Access denied.' });
    }
    next();
  };
}

module.exports = { requireAuth, optionalAuth, requireRole, jwtSecret };

