'use strict';

const fs = require('fs');
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const uploadsDir = path.join(__dirname, 'uploads');
const frontendDir = fs.existsSync(path.join(__dirname, '..', 'frontend', 'dist'))
  ? path.join(__dirname, '..', 'frontend', 'dist')
  : path.join(__dirname, '..', 'frontend-v2', 'dist');

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use('/uploads', express.static(uploadsDir));
app.use(express.static(frontendDir));
app.use('/assets', express.static(path.join(frontendDir, 'assets')));
app.use((req, res, next) => {
  if (req.url && req.url.includes('/assets/')) {
    const assetPath = req.url.substring(req.url.indexOf('/assets/'));
    req.url = assetPath;
    return express.static(frontendDir)(req, res, next);
  }
  next();
});

const http = require('http');
const { Server } = require('socket.io');

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Make io accessible in routes
app.use((req, res, next) => {
  req.io = io;
  next();
});

io.on('connection', (socket) => {
  console.log('A user connected via WebSocket');
  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

const multer = require('multer');
const axios = require('axios');
const FormData = require('form-data');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 30 * 1024 * 1024 }
});

const uploadMiddleware = upload.fields([
  { name: 'image', maxCount: 1 },
  { name: 'file', maxCount: 1 }
]);

const { 
  checkFmdSymptomCorroboration, 
  getDiseaseInfo, 
  normalizeDiseaseKey,
  CLINICAL_SAMPLE_DIRECTIVES, 
  DISEASE_AWARENESS 
} = require('./constants/diseaseInfo');

// ============================================================================
// HYBRID EDGE-CLOUD INFERENCE PIPELINE (PyTorch Edge + Gemini Cloud Fallback)
// ============================================================================
const ML_SERVICE_URL = process.env.ML_SERVICE_URL || 'http://127.0.0.1:5000';

const UNBIASED_PRIOR_DISTRIBUTION = {
  Foot_and_Mouth_Disease: 25.0,
  Healthy_Buffalo: 25.0,
  Lumpy_Skin_Disease: 25.0,
  Mastitis: 25.0
};

async function handlePredictionPipeline(req, res) {
  try {
    let imageBuffer = null;
    let mimeType = 'image/jpeg';
    let filename = 'upload.jpg';

    const uploadedFile = req.files?.image?.[0] || req.files?.file?.[0] || req.file;

    if (uploadedFile) {
      imageBuffer = uploadedFile.buffer;
      mimeType = uploadedFile.mimetype || 'image/jpeg';
      filename = uploadedFile.originalname || 'upload.jpg';
    } else if (req.body.imageBase64) {
      const b64 = req.body.imageBase64;
      const mimeMatch = b64.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,/);
      if (mimeMatch) mimeType = mimeMatch[1];
      const cleaned = b64.replace(/^data:image\/\w+;base64,/, '');
      imageBuffer = Buffer.from(cleaned, 'base64');
    }

    if (!imageBuffer || imageBuffer.length === 0) {
      return res.status(400).json({
        success: false,
        isBuffalo: false,
        message: 'No image provided. Please upload an image file using "image" or "file" field, or send imageBase64.',
        confidenceScore: 0
      });
    }

    // Symptoms are optional supplementary observation (Image drives the primary AI diagnosis)
    const symptoms = req.body.symptoms || '';

    // Forward directly to 4-Class Trained ML Service (port 5000)
    const formData = new FormData();
    formData.append('file', imageBuffer, { filename, contentType: mimeType });
    formData.append('image', imageBuffer, { filename, contentType: mimeType });
    if (req.body.animalType) formData.append('animalType', req.body.animalType);
    if (symptoms) formData.append('symptoms', typeof symptoms === 'object' ? JSON.stringify(symptoms) : symptoms);

    const pyResponse = await axios.post(`${ML_SERVICE_URL}/predict`, formData, {
      headers: { ...formData.getHeaders() },
      timeout: 30000,
    });

    const pytorchData = pyResponse.data;

    // Handle non-buffalo rejection
    if (pytorchData.isBuffalo === false || pytorchData.is_buffalo === false) {
      return res.json({
        ...pytorchData,
        isBuffalo: false,
        is_buffalo: false,
        status: pytorchData.status || 'rejected',
        message: pytorchData.message || 'Prediction failed: No buffalo detected in the image.'
      });
    }

    // Direct Image-Based Prediction from Trained Model
    const rawPredicted = pytorchData.diseasePrediction || pytorchData.prediction || pytorchData.predicted_class || '';
    const normPred = normalizeDiseaseKey(rawPredicted);
    const finalDiseaseKey = normPred;
    const isFmd = normPred === 'Foot_and_Mouth_Disease';
    const isCorroborated = isFmd ? checkFmdSymptomCorroboration(symptoms) : true;

    const epi = getDiseaseInfo(finalDiseaseKey);
    const sampleDirective = CLINICAL_SAMPLE_DIRECTIVES[epi.key] || CLINICAL_SAMPLE_DIRECTIVES.Healthy_Buffalo;
    const awareness = DISEASE_AWARENESS[epi.key] || DISEASE_AWARENESS.Healthy_Buffalo;

    // Return full corroborated output
    return res.json({
      ...pytorchData,
      diseasePrediction: epi.displayName,
      prediction: epi.displayName,
      predicted_class: epi.key,
      disease_key: epi.key,
      canonicalDisease: epi.key,
      isMultipleDiseaseDiagnosis: false,
      mismatchNotice: null,
      isSpreadable: epi.isSpreadable,
      category: epi.category,
      severity: epi.severity,
      precaution: epi.precaution,
      precautions: epi.additionalPrecautions,
      sampleDirective: sampleDirective.instruction,
      awarenessStopSpread: awareness.stopSpread,
      awarenessPreventFuture: awareness.preventFuture,
      isBuffalo: true,
      is_buffalo: true,
      status: pytorchData.status || 'confident',
      isUnbiased: true,
      baselinePriorPerClass: 25.0,
      priorDistribution: UNBIASED_PRIOR_DISTRIBUTION
    });

  } catch (err) {
    console.error('Prediction pipeline error:', err.message);
    if (err.code === 'ECONNREFUSED' || err.message?.includes('connect ECONNREFUSED')) {
      return res.status(503).json({
        success: false,
        isBuffalo: false,
        message: 'ML prediction microservice is unavailable. Please check that the Python FastAPI server is running on port 5000.',
        confidenceScore: 0
      });
    }
    res.status(500).json({
      success: false,
      isBuffalo: false,
      message: err.message || 'Prediction failed',
      confidenceScore: 0
    });
  }
}

const authRouter = require('./routes/auth');
const casesRouter = require('./routes/cases');
const usersRouter = require('./routes/users');
const volunteersRouter = require('./routes/volunteers');
const hospitalsRouter = require('./routes/hospitals');
const alertsRouter = require('./routes/alerts');
const dashboardRouter = require('./routes/dashboard');
const animalsRouter = require('./routes/animals');
const healthRecordsRouter = require('./routes/healthRecords');
const assistantRoutes = require('./routes/assistant');
const reviewsRouter = require('./routes/reviews');

// Hybrid Prediction Route Endpoints (Edge PyTorch + Cloud Gemini Fallback)
app.post('/api/cases/predict', uploadMiddleware, handlePredictionPipeline);
app.post('/predict', uploadMiddleware, handlePredictionPipeline);

app.use('/api/auth', authRouter);
app.use('/api/cases', casesRouter);
app.use('/api/users', usersRouter);
app.use('/api/assistant', assistantRoutes);
app.use('/api/volunteers', volunteersRouter);
app.use('/api/hospitals', hospitalsRouter);
app.use('/api/alerts', alertsRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/animals', animalsRouter);
app.use('/api/health-records', healthRecordsRouter);
app.use('/api/reviews', reviewsRouter);

app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy', service: 'express-backend', port });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/animal-health';

mongoose.set('strictQuery', false);
mongoose.connection.on('error', (err) => {
  console.warn('MongoDB connection error:', err && err.message ? err.message : err);
});
mongoose.connection.on('disconnected', () => {
  console.warn('MongoDB disconnected. The app will continue in fallback mode.');
});

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(async () => {
    console.log('MongoDB connected');
  })
  .catch(err => {
    console.error('MongoDB connection error:', err && err.message ? err.message : err);
    console.warn('Running in fallback mode without MongoDB.');
  });

process.on('unhandledRejection', (reason) => {
  console.warn('Unhandled Promise Rejection:', reason && reason.message ? reason.message : reason);
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Server is running on port ${port} with Socket.IO`);
});
