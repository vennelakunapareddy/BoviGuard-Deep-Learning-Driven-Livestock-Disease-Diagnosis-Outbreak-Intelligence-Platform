const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');

const Case = require('../models/Case');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { analyzeCase } = require('../services/prediction');
const { geocodeLocation, reverseGeocode } = require('../services/geocode');
const { 
  getDiseaseInfo, 
  isSpreadableDisease, 
  normalizeDiseaseKey, 
  checkFmdSymptomCorroboration,
  CLINICAL_SAMPLE_DIRECTIVES,
  DISEASE_AWARENESS,
  MANDATORY_ISOLATION_INSTRUCTION 
} = require('../constants/diseaseInfo');

// Multer Config
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'buffalo-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext && mime) {
      return cb(null, true);
    }
    cb(new Error('Only JPG, JPEG, PNG, and WEBP image files are allowed.'));
  }
});

// Fallback JSON persistence helper
const dataDir = path.join(__dirname, '..', 'data');
const dataIssuesFile = path.join(dataDir, 'issues.json');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function readFallbackCases() {
  if (!fs.existsSync(dataIssuesFile)) return [];
  try {
    const content = fs.readFileSync(dataIssuesFile, 'utf8');
    return JSON.parse(content) || [];
  } catch (err) {
    console.error('Error reading fallback cases:', err);
    return [];
  }
}

function writeFallbackCases(cases) {
  try {
    fs.writeFileSync(dataIssuesFile, JSON.stringify(cases, null, 2), 'utf8');
  } catch (err) {
    console.error('Error writing fallback cases:', err);
  }
}

// Distance helper (Haversine formula in km)
function distanceKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 99999;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Helper to generate Case ID (e.g., BUF-2026-0001) without DB blocking
async function generateUniqueCaseId() {
  const year = new Date().getFullYear();
  const existingIds = new Set();

  const fallbackCases = readFallbackCases();
  fallbackCases.forEach(c => {
    if (c.caseId) existingIds.add(String(c.caseId).trim());
  });

  if (mongoose.connection && mongoose.connection.readyState === 1) {
    try {
      const dbCases = await Case.find({}, 'caseId').lean();
      dbCases.forEach(c => {
        if (c.caseId) existingIds.add(String(c.caseId).trim());
      });
    } catch (e) {
      console.warn('DB caseId query error:', e.message);
    }
  }

  let count = existingIds.size;
  let candidate = `BUF-${year}-${String(count + 1).padStart(4, '0')}`;
  let iter = 1;
  while (existingIds.has(candidate)) {
    candidate = `BUF-${year}-${String(count + 1 + iter).padStart(4, '0')}`;
    iter++;
  }
  return candidate;
}

// Helper to enrich a case object with disease epidemiological metadata
function enrichCase(c) {
  const doc = (c && typeof c.toObject === 'function') ? c.toObject() : { ...c };
  const meta = getDiseaseInfo(doc.diseasePrediction);
  const sampleDirective = CLINICAL_SAMPLE_DIRECTIVES[meta.key] || CLINICAL_SAMPLE_DIRECTIVES.Healthy_Buffalo;
  const awareness = DISEASE_AWARENESS[meta.key] || DISEASE_AWARENESS.Healthy_Buffalo;
  return {
    ...doc,
    canonicalDisease: meta.key,
    diseaseDisplayName: meta.displayName,
    isSpreadable: meta.isSpreadable,
    spreadableStatus: meta.isSpreadable ? 'Spreadable (Epidemic Risk)' : 'Non-Spreadable',
    precaution: meta.precaution,
    additionalPrecautions: meta.additionalPrecautions,
    transmission: meta.transmission,
    sampleDirective: sampleDirective.instruction,
    sampleTitle: sampleDirective.title,
    awarenessStopSpread: awareness.stopSpread,
    awarenessPreventFuture: awareness.preventFuture,
    veterinaryGuidance: "This result is an AI-assisted screening result and should not be considered a final veterinary diagnosis. Please consult a qualified veterinarian for confirmation and treatment."
  };
}

// POST Disease Prediction Route (/api/cases/predict)
router.post('/predict', upload.single('image'), async (req, res) => {
  try {
    let imageBuffer = null;
    let imagePath = null;

    if (req.file) {
      imagePath = req.file.path;
      imageBuffer = fs.readFileSync(req.file.path);
    } else if (req.body.imageBase64) {
      const base64Data = req.body.imageBase64.replace(/^data:image\/\w+;base64,/, '');
      imageBuffer = Buffer.from(base64Data, 'base64');
    }

    const { animalType, symptoms, requestId } = req.body;
    let parsedSymptoms = [];
    if (typeof symptoms === 'string') {
      try { parsedSymptoms = JSON.parse(symptoms); }
      catch { parsedSymptoms = symptoms.split(',').map(s => s.trim()).filter(Boolean); }
    } else if (Array.isArray(symptoms)) {
      parsedSymptoms = symptoms;
    }

    // If symptoms are not provided during quick scan, proceed with visual analysis
    if (!parsedSymptoms) {
      parsedSymptoms = [];
    }

    const prediction = await analyzeCase({
      animalType: animalType || 'Buffalo',
      symptoms: parsedSymptoms,
      imageUploaded: Boolean(imageBuffer || imagePath),
      imagePath,
      imageBuffer,
      requestId
    });

    res.json(prediction);
  } catch (err) {
    console.error('Error during prediction:', err);
    res.status(500).json({
      isBuffalo: false,
      message: err.message || 'Disease prediction failed. Please try again with a clear buffalo image.'
    });
  }
});

// Reverse Geocoding Endpoint (/api/cases/geocode/reverse)
router.get('/geocode/reverse', async (req, res) => {
  try {
    const { lat, lon } = req.query;
    if (!lat || !lon) return res.status(400).json({ message: 'Latitude and Longitude are required.' });
    const data = await reverseGeocode(Number(lat), Number(lon));
    res.json(data);
  } catch (err) {
    console.error('Reverse geocoding error:', err);
    res.status(500).json({ message: 'Reverse geocoding failed.' });
  }
});

// Search Geocoding Endpoint (/api/cases/geocode/search)
router.get('/geocode/search', async (req, res) => {
  try {
    const { area, streetName, pincode } = req.query;
    const data = await geocodeLocation(area, streetName, pincode);
    res.json(data);
  } catch (err) {
    console.error('Geocoding search error:', err);
    res.status(500).json({ message: 'Geocoding search failed.' });
  }
});

// GET all cases - with graceful offline JSON fallback & optional auth
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { status, severity, area, disease, search } = req.query;

    let cases = [];
    let usedDb = false;

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const filter = {};
        if (status && status !== 'All') filter.status = status;
        if (severity && severity !== 'All') filter.severity = severity;
        if (area && area !== 'All') filter.area = new RegExp(area, 'i');
        if (disease && disease !== 'All') filter.diseasePrediction = new RegExp(disease, 'i');

        if (search) {
          const searchRegex = new RegExp(search, 'i');
          filter.$or = [
            { caseId: searchRegex },
            { tagNumber: searchRegex },
            { buffaloName: searchRegex },
            { ownerName: searchRegex },
            { area: searchRegex },
            { pincode: searchRegex },
            { diseasePrediction: searchRegex }
          ];
        }

        cases = await Case.find(filter).sort({ createdAt: -1 });
        usedDb = true;
      } catch (dbErr) {
        console.warn('DB cases fetch failed, using fallback:', dbErr.message);
        cases = [];
      }
    }

    if (!usedDb || cases.length === 0) {
      let rawCases = readFallbackCases();
      if (status && status !== 'All') {
        rawCases = rawCases.filter(c => c.status === status);
      }
      if (severity && severity !== 'All') {
        rawCases = rawCases.filter(c => c.severity === severity);
      }
      if (area && area !== 'All') {
        const aRegex = new RegExp(area, 'i');
        rawCases = rawCases.filter(c => aRegex.test(c.area || ''));
      }
      if (disease && disease !== 'All') {
        const dRegex = new RegExp(disease, 'i');
        rawCases = rawCases.filter(c => dRegex.test(c.diseasePrediction || ''));
      }
      if (search) {
        const s = search.toLowerCase();
        rawCases = rawCases.filter(c => 
          (c.caseId && c.caseId.toLowerCase().includes(s)) ||
          (c.tagNumber && c.tagNumber.toLowerCase().includes(s)) ||
          (c.buffaloName && c.buffaloName.toLowerCase().includes(s)) ||
          (c.ownerName && c.ownerName.toLowerCase().includes(s)) ||
          (c.area && c.area.toLowerCase().includes(s)) ||
          (c.pincode && c.pincode.includes(s)) ||
          (c.diseasePrediction && c.diseasePrediction.toLowerCase().includes(s))
        );
      }

      rawCases.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      cases = rawCases;
    }

    // Filter by ownership if mine=true requested
    if (req.query.mine === 'true') {
      if (req.user) {
        const uId = String(req.user._id || req.user.id);
        const uEmail = (req.user.email || '').toLowerCase().trim();
        const uName = (req.user.name || '').toLowerCase().trim();
        cases = cases.filter(c => {
          const cUid = c.userId ? String(c.userId) : '';
          const cEmail = (c.registeredByEmail || '').toLowerCase().trim();
          const cOwner = (c.ownerName || '').toLowerCase().trim();
          const cRegBy = (c.registeredBy || '').toLowerCase().trim();
          return (cUid && cUid === uId) || (cEmail && cEmail === uEmail) || (cOwner && cOwner === uName) || (cRegBy && cRegBy === uName);
        });
      } else {
        cases = [];
      }
    }

    const enriched = cases.map(enrichCase);
    res.json(enriched);
  } catch (err) {
    console.error('Error fetching cases:', err);
    res.status(500).json({ message: 'Server error fetching cases.' });
  }
});

// GET Red Alert Zones (/api/cases/red-alerts)
router.get('/red-alerts', optionalAuth, async (req, res) => {
  try {
    const RED_ALERT_THRESHOLD = Number(process.env.RED_ALERT_THRESHOLD || process.env.RED_ALERT_CASE_THRESHOLD || 3);
    const RED_ALERT_RADIUS_KM = Number(process.env.RED_ALERT_RADIUS_KM || 1.0);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    let recentCases = [];

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        recentCases = await Case.find({
          createdAt: { $gte: thirtyDaysAgo },
          diseasePrediction: { $ne: 'Healthy Buffalo' },
          status: { $nin: ['Closed', 'Recovered'] }
        }).lean();
      } catch (e) {
        console.warn('DB red-alerts query warning:', e.message);
      }
    }

    if (!recentCases.length) {
      const allFallback = readFallbackCases();
      recentCases = allFallback.filter(c => {
        const d = normalizeDiseaseKey(c.diseasePrediction);
        const dt = new Date(c.createdAt || c.reportedAt || Date.now());
        const active = c.status !== 'Closed' && c.status !== 'Recovered';
        return d !== 'Healthy_Buffalo' && dt >= thirtyDaysAgo && active;
      });
    }

    const clusters = {};
    recentCases.forEach(c => {
      const canonical = normalizeDiseaseKey(c.diseasePrediction);
      const areaKey = (c.area || c.pincode || 'Unknown Area').trim().toLowerCase();
      const key = `${areaKey}:::${canonical}`;

      if (!clusters[key]) {
        clusters[key] = {
          area: c.area || c.pincode || 'Unknown Area',
          pincode: c.pincode,
          canonicalDisease: canonical,
          disease: c.diseasePrediction,
          cases: [],
          latitudes: [],
          longitudes: [],
          maxSeverity: c.severity || 'Medium'
        };
      }
      clusters[key].cases.push(c);
      const lat = Number(c.latitude ?? c.coordinates?.latitude);
      const lng = Number(c.longitude ?? c.coordinates?.longitude);
      if (Number.isFinite(lat) && lat !== 0) clusters[key].latitudes.push(lat);
      if (Number.isFinite(lng) && lng !== 0) clusters[key].longitudes.push(lng);

      const severityRanks = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
      if ((severityRanks[c.severity] || 1) > (severityRanks[clusters[key].maxSeverity] || 1)) {
        clusters[key].maxSeverity = c.severity;
      }
    });

    const redAlertZones = [];
    Object.values(clusters).forEach(cluster => {
      const isSpreadable = isSpreadableDisease(cluster.canonicalDisease);
      // Strictly enforce business rule: >= 3 cases of a SPREADABLE disease trigger Red Alert Emergency Zone
      if (cluster.cases.length >= RED_ALERT_THRESHOLD && isSpreadable) {
        const avgLat = cluster.latitudes.length ? cluster.latitudes.reduce((a, b) => a + b, 0) / cluster.latitudes.length : 16.5062;
        const avgLng = cluster.longitudes.length ? cluster.longitudes.reduce((a, b) => a + b, 0) / cluster.longitudes.length : 80.6480;
        const diseaseMeta = getDiseaseInfo(cluster.canonicalDisease);

        redAlertZones.push({
          id: `ALERT-${cluster.area}-${cluster.canonicalDisease}`.replace(/\s+/g, '-'),
          area: cluster.area,
          pincode: cluster.pincode,
          disease: cluster.disease,
          canonicalDisease: cluster.canonicalDisease,
          diseaseDisplayName: diseaseMeta.displayName,
          caseCount: cluster.cases.length,
          totalCases: cluster.cases.length,
          severity: cluster.maxSeverity,
          latitude: Number(avgLat.toFixed(6)),
          longitude: Number(avgLng.toFixed(6)),
          radiusMeters: 1000, // 1km alert region
          radiusKm: RED_ALERT_RADIUS_KM,
          status: 'ACTIVE_RED_ALERT',
          isSpreadable: true,
          isEmergencyZone: true,
          precaution: diseaseMeta.precaution,
          transmission: diseaseMeta.transmission,
          mandatoryInstruction: MANDATORY_ISOLATION_INSTRUCTION,
          message: `RED ALERT EMERGENCY ZONE: ${cluster.cases.length} active cases of ${diseaseMeta.displayName} (Spreadable Epidemic Risk) detected in ${cluster.area} within 1km radius. Immediate herd quarantine required!`,
          cases: cluster.cases.map(c => ({ caseId: c.caseId, tagNumber: c.tagNumber, date: c.createdAt }))
        });
      }
    });

    res.json({
      threshold: RED_ALERT_THRESHOLD,
      radiusMeters: 1000,
      radiusKm: RED_ALERT_RADIUS_KM,
      activeAlertsCount: redAlertZones.length,
      redAlertZones
    });
  } catch (err) {
    console.error('Error computing red alert zones:', err);
    res.status(500).json({ message: 'Failed to calculate Red Alert zones.' });
  }
});

// GET single case by ID or caseId
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const id = req.params.id;
    let found = null;

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const query = mongoose.Types.ObjectId.isValid(id)
          ? { $or: [{ _id: id }, { caseId: id }] }
          : { caseId: id };
        found = await Case.findOne(query);
      } catch (e) {
        console.warn('DB case findOne error:', e.message);
      }
    }

    if (!found) {
      const fallbackCases = readFallbackCases();
      found = fallbackCases.find(c => 
        String(c.caseId) === String(id) || 
        String(c._id) === String(id) || 
        String(c.id) === String(id)
      );
    }

    if (!found) {
      return res.status(404).json({ message: 'Case record not found.' });
    }

    res.json(enrichCase(found));
  } catch (err) {
    console.error('Error fetching case details:', err);
    res.status(500).json({ message: 'Failed to fetch case details.' });
  }
});

// POST Create new case
router.post('/', optionalAuth, upload.single('image'), async (req, res) => {
  try {
    const {
      tagNumber,
      buffaloName,
      age,
      gender,
      breed,
      affectedCount,
      ownerName,
      area,
      streetName,
      pincode,
      symptoms,
      diseaseDescription,
      symptomsStartDate,
      temperature,
      medicalHistory,
      currentTreatment,
      veterinarianName,
      diseasePrediction,
      confidenceScore,
      severity,
      recommendations,
      precautions,
      immediateAction,
      latitude,
      longitude,
      imageBase64
    } = req.body;

    if (!tagNumber || !tagNumber.trim()) return res.status(400).json({ message: 'Buffalo Tag ID is required.' });
    if (!area || !area.trim()) return res.status(400).json({ message: 'Area is required.' });
    if (!streetName || !streetName.trim()) return res.status(400).json({ message: 'Street Name is required.' });
    if (!pincode || !/^\d{6}$/.test(pincode.trim())) return res.status(400).json({ message: 'A valid 6-digit Pincode is required.' });

    let parsedSymptoms = [];
    if (typeof symptoms === 'string') {
      try { parsedSymptoms = JSON.parse(symptoms); }
      catch { parsedSymptoms = symptoms.split(',').map(s => s.trim()).filter(Boolean); }
    } else if (Array.isArray(symptoms)) {
      parsedSymptoms = symptoms;
    }
    if (!parsedSymptoms.length) return res.status(400).json({ message: 'At least one symptom is required.' });

    let imagePath = '';
    if (req.file) {
      imagePath = `/uploads/${req.file.filename}`;
    } else if (imageBase64) {
      imagePath = imageBase64;
    }

    const caseId = await generateUniqueCaseId();

    let finalLat = Number(latitude);
    let finalLng = Number(longitude);
    let finalPincode = pincode.trim();

    // Geocode OpenStreetMap coordinates if not explicitly provided or if default Vijayawada
    if (!finalLat || !finalLng || (finalLat === 16.5062 && finalLng === 80.6480)) {
      try {
        const geoResult = await geocodeLocation(area, streetName, pincode);
        if (geoResult.valid && geoResult.latitude && geoResult.longitude) {
          finalLat = geoResult.latitude;
          finalLng = geoResult.longitude;
          if (geoResult.pincode && /^[1-9]\d{5}$/.test(geoResult.pincode)) {
            finalPincode = geoResult.pincode;
          }
        } else {
          const locationKey = `${area.trim()}_${pincode.trim()}_${tagNumber.trim()}_${Date.now()}`;
          const hash = locationKey.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
          const latOffset = (((hash * 17) % 120) - 60) * 0.0018;
          const lngOffset = (((hash * 31) % 120) - 60) * 0.0018;
          finalLat = Number((16.5062 + latOffset).toFixed(6));
          finalLng = Number((80.6480 + lngOffset).toFixed(6));
        }
      } catch (geoErr) {
        finalLat = 16.5062;
        finalLng = 80.6480;
      }
    }

    const userName = req.user ? req.user.name : (ownerName ? ownerName.trim() : 'Buffalo Owner');
    const userEmail = req.user ? req.user.email : '';
    const userRole = req.user ? req.user.role : 'Buffalo Owner';
    const userId = req.user ? String(req.user._id || req.user.id) : ('user_' + Date.now());

    const caseRecord = {
      _id: 'case_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8),
      caseId,
      animalType: 'Buffalo',
      tagNumber: tagNumber.trim(),
      buffaloName: buffaloName ? buffaloName.trim() : 'Buffalo',
      age: Number(age) || 4,
      gender: gender || 'Female',
      breed: breed || 'Murrah',
      affectedCount: Number(affectedCount) || 1,
      ownerName: ownerName ? ownerName.trim() : userName,
      registeredBy: userName,
      registeredByEmail: userEmail,
      registeredByRole: userRole,
      area: area.trim(),
      streetName: streetName.trim(),
      pincode: finalPincode,
      latitude: finalLat,
      longitude: finalLng,
      coordinates: { latitude: finalLat, longitude: finalLng },
      symptoms: parsedSymptoms,
      diseaseDescription: diseaseDescription ? diseaseDescription.trim() : '',
      symptomsStartDate: symptomsStartDate ? new Date(symptomsStartDate).toISOString() : new Date().toISOString(),
      temperature: temperature ? temperature.trim() : '',
      medicalHistory: medicalHistory ? medicalHistory.trim() : '',
      currentTreatment: currentTreatment ? currentTreatment.trim() : '',
      veterinarianName: veterinarianName ? veterinarianName.trim() : '',
      image: imagePath,
      diseasePrediction: diseasePrediction || 'Healthy_Buffalo',
      confidenceScore: Number(confidenceScore) || 85,
      severity: severity || 'Low',
      riskPercentage: severity === 'Critical' || severity === 'High' ? 85 : severity === 'Medium' ? 55 : 20,
      recommendations: Array.isArray(recommendations) ? recommendations : [],
      precautions: Array.isArray(precautions) ? precautions : [],
      immediateAction: immediateAction || 'Isolate affected buffalo and consult a qualified veterinarian.',
      status: 'Open',
      userId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: [{
        action: 'Case Created',
        changedBy: userName,
        timestamp: new Date().toISOString(),
        details: `Created case ${caseId} for Buffalo Tag ID ${tagNumber}`
      }]
    };

    let saved = caseRecord;

    // Save to MongoDB if connected
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const newCase = new Case({
          ...caseRecord,
          userId: mongoose.Types.ObjectId.isValid(userId) ? userId : new mongoose.Types.ObjectId()
        });
        const dbSaved = await newCase.save();
        saved = dbSaved.toObject();
      } catch (dbErr) {
        console.warn('MongoDB save failed, continuing with fallback:', dbErr.message);
      }
    }

    // Always update fallback issues.json so fallback mode and alert clustering are fully synchronized
    const existingFallback = readFallbackCases();
    existingFallback.unshift(saved);
    writeFallbackCases(existingFallback);

    // Emit real-time notification to all connected clients
    const io = req.io || (req.app && req.app.get('socketio'));
    if (io) {
      io.emit('new-case', saved);
      io.emit('new_case', saved);
    }

    res.status(201).json({
      message: 'Case submitted successfully.',
      case: enrichCase(saved)
    });
  } catch (err) {
    console.error('Error submitting case:', err);
    res.status(500).json({ message: err.message || 'Failed to submit case.' });
  }
});

// PUT Update case - strictly permits only the registered creator or system admin
router.put('/:id', optionalAuth, async (req, res) => {
  try {
    const { status, treatmentInfo, veterinaryNotes, followUpNotes } = req.body;
    const id = req.params.id;

    // 1. Fetch existing case to check ownership
    let existingCase = null;
    let dbCaseDoc = null;

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const query = mongoose.Types.ObjectId.isValid(id)
          ? { $or: [{ _id: id }, { caseId: id }] }
          : { caseId: id };
        dbCaseDoc = await Case.findOne(query);
        if (dbCaseDoc) existingCase = dbCaseDoc.toObject();
      } catch (e) {
        console.warn('DB case lookup warning:', e.message);
      }
    }

    const fallbackCases = readFallbackCases();
    const fallbackIdx = fallbackCases.findIndex(c => 
      String(c.caseId) === String(id) || 
      String(c._id) === String(id) || 
      String(c.id) === String(id)
    );

    if (!existingCase && fallbackIdx !== -1) {
      existingCase = fallbackCases[fallbackIdx];
    }

    if (!existingCase) {
      return res.status(404).json({ message: 'Case not found.' });
    }

    // 2. Strict Ownership Permission Verification
    const reqUserId = req.user ? String(req.user._id || req.user.id) : null;
    const reqUserEmail = req.user && req.user.email ? req.user.email.toLowerCase().trim() : null;
    const reqUserName = req.user && req.user.name ? req.user.name.toLowerCase().trim() : null;
    const isAdmin = Boolean(
      req.user && (
        req.user.role === 'System Admin' || 
        req.user.role === 'system_admin' || 
        req.user.role === 'Admin' ||
        (req.user.role || '').toLowerCase().includes('admin')
      )
    );

    const isCaseOwner = Boolean(
      req.user && (
        (existingCase.userId && String(existingCase.userId) === reqUserId) ||
        (existingCase.registeredByEmail && reqUserEmail && existingCase.registeredByEmail.toLowerCase().trim() === reqUserEmail) ||
        (existingCase.ownerName && reqUserName && existingCase.ownerName.toLowerCase().trim() === reqUserName) ||
        (existingCase.registeredBy && reqUserName && existingCase.registeredBy.toLowerCase().trim() === reqUserName)
      )
    );

    if (!isAdmin && !isCaseOwner) {
      return res.status(403).json({ 
        message: 'Permission denied. Only the particular member who registered this case (or system admin) can update its status.' 
      });
    }

    let updated = null;

    // 3. Save updates in MongoDB if present
    if (dbCaseDoc) {
      if (status) dbCaseDoc.status = status;
      if (treatmentInfo) dbCaseDoc.treatmentInfo = treatmentInfo;
      if (veterinaryNotes) dbCaseDoc.veterinaryNotes = veterinaryNotes;
      if (followUpNotes) dbCaseDoc.followUpNotes = followUpNotes;

      dbCaseDoc.history.push({
        action: 'Case Updated',
        changedBy: req.user ? req.user.name : 'Authorized User',
        timestamp: new Date(),
        details: `Status updated to ${dbCaseDoc.status}`
      });

      const dbRes = await dbCaseDoc.save();
      updated = dbRes.toObject();
    }

    // 4. Save updates in fallback issues.json
    if (fallbackIdx !== -1) {
      if (status) fallbackCases[fallbackIdx].status = status;
      if (treatmentInfo) fallbackCases[fallbackIdx].treatmentInfo = treatmentInfo;
      if (veterinaryNotes) fallbackCases[fallbackIdx].veterinaryNotes = veterinaryNotes;
      if (followUpNotes) fallbackCases[fallbackIdx].followUpNotes = followUpNotes;
      fallbackCases[fallbackIdx].updatedAt = new Date().toISOString();
      if (!Array.isArray(fallbackCases[fallbackIdx].history)) fallbackCases[fallbackIdx].history = [];
      fallbackCases[fallbackIdx].history.push({
        action: 'Case Updated',
        changedBy: req.user ? req.user.name : 'Authorized User',
        timestamp: new Date().toISOString(),
        details: `Status updated to ${fallbackCases[fallbackIdx].status}`
      });
      writeFallbackCases(fallbackCases);
      if (!updated) updated = fallbackCases[fallbackIdx];
    }

    if (!updated) updated = existingCase;

    res.json({ message: 'Case updated successfully.', case: enrichCase(updated) });
  } catch (err) {
    console.error('Error updating case:', err);
    res.status(500).json({ message: 'Failed to update case.' });
  }
});

// DELETE Case - strictly permits only the registered creator or system admin
router.delete('/:id', optionalAuth, async (req, res) => {
  try {
    const id = req.params.id;

    // 1. Fetch existing case to check ownership
    let existingCase = null;
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const query = mongoose.Types.ObjectId.isValid(id)
          ? { $or: [{ _id: id }, { caseId: id }] }
          : { caseId: id };
        existingCase = await Case.findOne(query);
      } catch (e) {
        console.warn('DB case lookup warning:', e.message);
      }
    }

    const fallbackCases = readFallbackCases();
    const fallbackCase = fallbackCases.find(c => 
      String(c.caseId) === String(id) || 
      String(c._id) === String(id) || 
      String(c.id) === String(id)
    );

    if (!existingCase && fallbackCase) {
      existingCase = fallbackCase;
    }

    if (!existingCase) {
      return res.status(404).json({ message: 'Case record not found.' });
    }

    // 2. Strict Ownership Permission Verification
    const reqUserId = req.user ? String(req.user._id || req.user.id) : null;
    const reqUserEmail = req.user && req.user.email ? req.user.email.toLowerCase().trim() : null;
    const reqUserName = req.user && req.user.name ? req.user.name.toLowerCase().trim() : null;
    const isAdmin = Boolean(
      req.user && (
        req.user.role === 'System Admin' || 
        req.user.role === 'system_admin' || 
        req.user.role === 'Admin' ||
        (req.user.role || '').toLowerCase().includes('admin')
      )
    );

    const isCaseOwner = Boolean(
      req.user && (
        (existingCase.userId && String(existingCase.userId) === reqUserId) ||
        (existingCase.registeredByEmail && reqUserEmail && existingCase.registeredByEmail.toLowerCase().trim() === reqUserEmail) ||
        (existingCase.ownerName && reqUserName && existingCase.ownerName.toLowerCase().trim() === reqUserName) ||
        (existingCase.registeredBy && reqUserName && existingCase.registeredBy.toLowerCase().trim() === reqUserName)
      )
    );

    if (!isAdmin && !isCaseOwner) {
      return res.status(403).json({ 
        message: 'Permission denied. Only the particular member who registered this case (or system admin) can delete it.' 
      });
    }

    // 3. Perform Deletion
    let deletedId = id;
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const query = mongoose.Types.ObjectId.isValid(id)
          ? { $or: [{ _id: id }, { caseId: id }] }
          : { caseId: id };
        const deleted = await Case.findOneAndDelete(query);
        if (deleted) deletedId = deleted.caseId || deleted._id;
      } catch (e) {
        console.warn('DB delete warning:', e.message);
      }
    }

    const newCases = fallbackCases.filter(c => 
      String(c.caseId) !== String(id) && 
      String(c._id) !== String(id) && 
      String(c.id) !== String(id)
    );
    writeFallbackCases(newCases);

    res.json({ message: 'Case record deleted successfully.', caseId: deletedId });
  } catch (err) {
    console.error('Error deleting case:', err);
    res.status(500).json({ message: 'Failed to delete case record.' });
  }
});

module.exports = router;
