const express = require('express');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const Alert = require('../models/Alert');
const CaseModel = require('../models/Case');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { 
  getDiseaseInfo, 
  isSpreadableDisease, 
  normalizeDiseaseKey,
  MANDATORY_ISOLATION_INSTRUCTION 
} = require('../constants/diseaseInfo');

const router = express.Router();
const dataIssuesFile = path.join(__dirname, '..', 'data', 'issues.json');
const caseThreshold = Number(process.env.RED_ALERT_CASE_THRESHOLD || 3);
const radiusKm = Number(process.env.RED_ALERT_RADIUS_KM || 1.0); // 1.0 km (1000m region)
const windowDays = Number(process.env.RED_ALERT_WINDOW_DAYS || 30);

function readIssues() {
  if (!fs.existsSync(dataIssuesFile)) return [];
  try { return JSON.parse(fs.readFileSync(dataIssuesFile, 'utf8')) || []; } catch { return []; }
}

function coordinatesOf(item) {
  const latitude = Number(item.latitude ?? item.coordinates?.latitude);
  const longitude = Number(item.longitude ?? item.coordinates?.longitude);
  return Number.isFinite(latitude) && Number.isFinite(longitude) && latitude !== 0 && longitude !== 0 ? { latitude, longitude } : null;
}

// Exact Haversine formula
function distanceKm(first, second) {
  const dLat = (second.latitude - first.latitude) * Math.PI / 180;
  const dLng = (second.longitude - first.longitude) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(first.latitude * Math.PI / 180) * Math.cos(second.latitude * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function severityValue(value) {
  return { Low: 20, Medium: 50, High: 80, Critical: 100 }[value] || 20;
}

function alertLevel(score) {
  if (score >= 75) return 'Critical';
  if (score >= 50) return 'High';
  if (score >= 25) return 'Medium';
  return 'Low';
}

function clusterScore(items) {
  const averageSeverity = items.reduce((sum, item) => sum + severityValue(item.severity), 0) / items.length;
  const averageConfidence = items.reduce((sum, item) => sum + Math.max(0, Math.min(100, Number(item.confidenceScore) || 0)), 0) / items.length;
  const recentRatio = items.filter(item => Date.now() - new Date(item.createdAt || item.reportedAt).getTime() <= 7 * 86400000).length / items.length;
  const density = Math.min(100, (items.length / caseThreshold) * 100);
  return Math.round(Math.min(100, density * 0.4 + averageSeverity * 0.3 + averageConfidence * 0.2 + recentRatio * 10));
}

function buildClusters(items) {
  const cutoff = Date.now() - windowDays * 86400000;
  const groups = [];

  items
    .filter(item => {
      if (!item.diseasePrediction) return false;
      const reportedTime = new Date(item.createdAt || item.reportedAt).getTime();
      if (reportedTime < cutoff) return false;
      if (!coordinatesOf(item)) return false;
      // Only active cases contribute to Red Alert Outbreak Clusters
      const status = String(item.status || '').trim();
      if (status === 'Closed' || status === 'Recovered') return false;
      return true;
    })
    .forEach(item => {
      const coordinates = coordinatesOf(item);
      const canonical = normalizeDiseaseKey(item.diseasePrediction);
      const meta = getDiseaseInfo(item.diseasePrediction);
      const itemArea = (item.area || item.areaName || '').trim().toLowerCase();

      // Group by canonical disease and either same area or geographic proximity within 1km (radiusKm)
      let group = groups.find(candidate => {
        if (candidate.canonicalDisease !== canonical) return false;
        if (candidate.animalType !== (item.animalType || 'Buffalo')) return false;
        const candArea = (candidate.area || '').trim().toLowerCase();
        const sameArea = Boolean(itemArea && candArea && itemArea === candArea);
        const near = distanceKm(candidate.coordinates, coordinates) <= radiusKm;
        return sameArea || near;
      });

      if (!group) {
        group = { 
          canonicalDisease: canonical,
          disease: meta.displayName || item.diseasePrediction, 
          animalType: item.animalType || 'Buffalo', 
          area: item.area || item.areaName || 'Unknown', 
          coordinates, 
          items: [] 
        };
        groups.push(group);
      }

      group.items.push(item);
      // Recalculate cluster centroid
      group.coordinates = {
        latitude: group.items.reduce((sum, current) => sum + coordinatesOf(current).latitude, 0) / group.items.length,
        longitude: group.items.reduce((sum, current) => sum + coordinatesOf(current).longitude, 0) / group.items.length,
      };
    });

  return groups.map(group => {
    const score = clusterScore(group.items);
    const latitude = Number(group.coordinates.latitude.toFixed(6));
    const longitude = Number(group.coordinates.longitude.toFixed(6));
    const diseaseMeta = getDiseaseInfo(group.disease);
    const isSpreadable = Boolean(diseaseMeta.isSpreadable);
    const isEmergencyZone = isSpreadable && group.items.length >= caseThreshold;

    return {
      disease: group.disease,
      diseaseDisplayName: diseaseMeta.displayName,
      animalType: group.animalType,
      area: group.area,
      caseCount: group.items.length,
      totalCases: group.items.length,
      severityScore: score,
      alertLevel: isEmergencyZone ? 'Critical' : alertLevel(score),
      severityTrend: group.items.filter(item => ['High', 'Critical'].includes(item.severity)).length > group.items.length / 2 ? 'Increasing' : 'Stable',
      latitude,
      longitude,
      coordinates: { latitude, longitude },
      radius: radiusKm * 1000, // 1000 meters (1km)
      radiusMeters: radiusKm * 1000,
      radiusKm: radiusKm,
      contributingCaseIds: group.items.map(item => String(item._id || item.id || item.caseId)),
      
      // Epidemiological rule tags
      isSpreadable,
      isEmergencyZone,
      transmission: diseaseMeta.transmission,
      precaution: diseaseMeta.precaution,
      category: diseaseMeta.category,
      mandatoryInstruction: isSpreadable ? MANDATORY_ISOLATION_INSTRUCTION : null,
      cases: group.items.map(it => ({
        caseId: it.caseId || it._id,
        tagNumber: it.tagNumber,
        area: it.area,
        severity: it.severity,
        latitude: coordinatesOf(it)?.latitude,
        longitude: coordinatesOf(it)?.longitude,
        createdAt: it.createdAt || it.reportedAt
      }))
    };
  });
}

async function calculateAlerts() {
  let items = [];
  if (CaseModel && mongoose.connection.readyState === 1) {
    try {
      items = await CaseModel.find().lean();
    } catch (e) {
      console.warn('DB alert query error:', e.message);
    }
  }
  if (!items || items.length === 0) {
    items = readIssues();
  }
  const clusters = buildClusters(items);
  if (Alert && mongoose.connection.readyState === 1) {
    try {
      await Alert.deleteMany({});
      if (clusters.length) {
        // Only insert standard Alert schema fields
        const schemaAlerts = clusters.map(c => ({
          disease: c.disease,
          animalType: c.animalType,
          area: c.area,
          totalCases: c.totalCases,
          caseCount: c.caseCount,
          severityScore: c.severityScore,
          radius: c.radius,
          alertLevel: c.alertLevel,
          severityTrend: c.severityTrend,
          coordinates: c.coordinates,
          createdAt: new Date()
        }));
        await Alert.insertMany(schemaAlerts);
      }
    } catch (e) {
      console.warn('Alert DB sync warning:', e.message);
    }
  }
  return clusters;
}

// GET all alert clusters with epidemiological profiles
router.get('/', optionalAuth, async (req, res) => {
  try { 
    return res.json(await calculateAlerts()); 
  } catch (error) { 
    console.error('Fetch alerts error:', error); 
    return res.status(500).json({ message: 'Unable to fetch alerts.' }); 
  }
});

// GET Red Alert Emergency Outbreak Zones (Only Spreadable diseases with >= 3 active cases in 1km region)
router.get('/red-zones', optionalAuth, async (req, res) => {
  try {
    const allClusters = await calculateAlerts();
    // Strict business rule: >= 3 active cases of a SPREADABLE disease within 1km region
    const redZones = allClusters.filter(cluster => cluster.isEmergencyZone);
    return res.json({ 
      alerts: redZones, 
      allClusters,
      threshold: caseThreshold, 
      radius: radiusKm * 1000, 
      radiusMeters: radiusKm * 1000,
      radiusKm,
      windowDays 
    });
  } catch (error) { 
    console.error('Fetch red zones error:', error); 
    return res.status(500).json({ message: 'Unable to compute red zones.' }); 
  }
});

router.post('/check', optionalAuth, async (req, res) => {
  try { 
    return res.json(await calculateAlerts()); 
  } catch (error) { 
    console.error('Check alerts error:', error); 
    return res.status(500).json({ message: 'Unable to compute alerts.' }); 
  }
});

module.exports = router;
