const express = require('express');
const mongoose = require('mongoose');
const HealthRecord = require('../models/HealthRecord');
const Animal = require('../models/Animal');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Get health records for an animal
router.get('/:animalId', requireAuth, async (req, res) => {
  try {
    const animal = await Animal.findById(req.params.animalId);
    if (!animal) return res.status(404).json({ message: 'Animal not found.' });

    if (req.user.role !== 'veterinarian' && String(animal.owner) !== String(req.user._id)) {
      return res.status(403).json({ message: 'Forbidden.' });
    }

    const records = await HealthRecord.find({ animalId: req.params.animalId })
      .sort({ date: -1 })
      .populate('veterinarianId', 'name role');
      
    res.json(records);
  } catch (error) {
    console.error('Fetch records error:', error);
    res.status(500).json({ message: 'Unable to fetch health records.' });
  }
});

// Create new health record
router.post('/', requireAuth, async (req, res) => {
  try {
    const { animalId, recordType, description, caseId } = req.body;
    if (!animalId || !recordType || !description) {
      return res.status(400).json({ message: 'Missing required fields.' });
    }

    const animal = await Animal.findById(animalId);
    if (!animal) return res.status(404).json({ message: 'Animal not found.' });

    // Only owners can add certain records, vets can add others
    if (req.user.role !== 'veterinarian' && String(animal.owner) !== String(req.user._id)) {
      return res.status(403).json({ message: 'Forbidden.' });
    }

    const record = await HealthRecord.create({
      animalId,
      recordType,
      description: description.trim(),
      veterinarianId: req.user.role === 'veterinarian' ? req.user._id : null,
      caseId: caseId || null,
    });

    res.status(201).json(record);
  } catch (error) {
    console.error('Create record error:', error);
    res.status(500).json({ message: 'Unable to create health record.' });
  }
});

module.exports = router;
