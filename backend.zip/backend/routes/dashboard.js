const express = require('express');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const CaseModel = (() => { try { return require('../models/Case'); } catch { return null; } })();
const Alert = (() => { try { return require('../models/Alert'); } catch { return null; } })();

const router = express.Router();
const dataIssuesFile = path.join(__dirname, '..', 'data', 'issues.json');

router.get('/stats', async (req, res) => {
  try {
    if (CaseModel && mongoose.connection && mongoose.connection.readyState === 1) {
      const totalCases = await CaseModel.countDocuments();
      const activeCases = await CaseModel.countDocuments({ status: { $in: ['Open', 'Under Treatment', 'Emergency', 'Reported', 'Under Observation', 'In Progress'] } });
      const criticalCases = await CaseModel.countDocuments({ severity: { $in: ['High', 'Critical'] } });
      const recoveredCases = await CaseModel.countDocuments({ status: { $in: ['Recovered', 'Closed', 'Resolved'] } });
      const redAlertAreas = Alert ? await Alert.countDocuments({ alertLevel: { $in: ['High', 'Critical', 'RED'] } }) : 0;

      const recentCases = await CaseModel.find()
        .sort({ createdAt: -1 })
        .limit(6)
        .populate('userId', 'name role')
        .lean();

      const recentEmergencyCases = await CaseModel.find({ severity: { $in: ['High', 'Critical'] } })
        .sort({ createdAt: -1 })
        .limit(5)
        .lean();

      const diseaseDistribution = await CaseModel.aggregate([
        { $group: { _id: '$diseasePrediction', count: { $sum: 1 } } },
      ]);
      const severityDistribution = await CaseModel.aggregate([
        { $group: { _id: '$severity', count: { $sum: 1 } } },
      ]);

      return res.json({
        success: true,
        totalCases,
        activeCases,
        criticalCases,
        recoveredCases,
        redAlertAreas,
        recentCases: recentCases.map((item) => ({
          _id: item._id,
          id: item._id,
          diseasePrediction: item.diseasePrediction,
          area: item.area,
          severity: item.severity,
          status: item.status,
          confidenceScore: item.confidenceScore,
          createdAt: item.createdAt,
          reportedBy: item.userId ? item.userId.name : 'System User'
        })),
        recentEmergencyCases: recentEmergencyCases.map(item => ({
          _id: item._id,
          diseasePrediction: item.diseasePrediction,
          area: item.area,
          severity: item.severity,
          status: item.status,
          createdAt: item.createdAt
        })),
        diseaseDistribution: diseaseDistribution.map((item) => ({ disease: item._id, count: item.count })),
        severityDistribution: severityDistribution.map((item) => ({ severity: item._id, count: item.count })),
      });
    }

    // Fallback JSON aggregation
    let issues = [];
    if (fs.existsSync(dataIssuesFile)) issues = JSON.parse(fs.readFileSync(dataIssuesFile));

    const totalCases = issues.length;
    const activeCases = issues.filter(i => ['Open', 'Under Treatment', 'Emergency', 'Reported'].includes(i.status)).length;
    const criticalCases = issues.filter(i => ['High', 'Critical'].includes(i.severity)).length;
    const recoveredCases = issues.filter(i => ['Recovered', 'Closed', 'Resolved'].includes(i.status)).length;
    const redAlertAreas = issues.filter(i => ['High', 'Critical', 'RED'].includes(i.alertLevel)).length;

    const diseaseMap = {};
    const severityMap = {};
    issues.forEach(i => {
      const d = i.diseasePrediction || 'Unknown';
      diseaseMap[d] = (diseaseMap[d] || 0) + 1;
      const s = i.severity || 'Low';
      severityMap[s] = (severityMap[s] || 0) + 1;
    });

    const diseaseDistribution = Object.entries(diseaseMap).map(([disease, count]) => ({ disease, count }));
    const severityDistribution = Object.entries(severityMap).map(([severity, count]) => ({ severity, count }));

    return res.json({
      success: true,
      totalCases,
      activeCases,
      criticalCases,
      recoveredCases,
      redAlertAreas,
      recentCases: issues.slice(0, 6),
      recentEmergencyCases: issues.filter(i => ['High', 'Critical'].includes(i.severity)).slice(0, 5),
      diseaseDistribution,
      severityDistribution,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ success: false, message: 'Unable to generate dashboard stats.' });
  }
});

module.exports = router;
