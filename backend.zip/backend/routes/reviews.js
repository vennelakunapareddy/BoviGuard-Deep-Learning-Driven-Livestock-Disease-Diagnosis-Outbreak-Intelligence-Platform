const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const { requireAuth } = require('../middleware/auth');

// Get all feedback & reviews
router.get('/', async (req, res) => {
  try {
    const reviews = await Review.find().sort({ createdAt: -1 });
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Submit a new review
router.post('/', requireAuth, async (req, res) => {
  try {
    const { rating, reviewText } = req.body;
    if (!rating || !reviewText) {
      return res.status(400).json({ success: false, message: 'Rating and review text are required.' });
    }
    if (rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: 'Rating must be between 1 and 5 stars.' });
    }

    const review = new Review({
      userId: req.user.id,
      userName: req.user.name || 'Anonymous User',
      userRole: req.user.role || 'Animal Owner',
      userAvatar: req.user.avatar || '',
      rating: Number(rating),
      reviewText: reviewText.trim(),
    });

    await review.save();

    if (req.io) {
      req.io.emit('new_review', review);
    }

    res.status(201).json({ success: true, review, message: 'Thank you for your feedback!' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Update own review
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ success: false, message: 'Review not found.' });
    }
    if (review.userId.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized to edit this review.' });
    }

    const { rating, reviewText } = req.body;
    if (rating) review.rating = Number(rating);
    if (reviewText) review.reviewText = reviewText.trim();
    review.updatedAt = new Date();

    await review.save();

    if (req.io) {
      req.io.emit('update_review', review);
    }

    res.json({ success: true, review, message: 'Review updated successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Delete own review
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ success: false, message: 'Review not found.' });
    }
    if (review.userId.toString() !== req.user.id && req.user.role !== 'admin' && req.user.role !== 'Admin') {
      return res.status(403).json({ success: false, message: 'Unauthorized to delete this review.' });
    }

    await Review.findByIdAndDelete(req.params.id);

    if (req.io) {
      req.io.emit('delete_review', req.params.id);
    }

    res.json({ success: true, message: 'Review deleted successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
