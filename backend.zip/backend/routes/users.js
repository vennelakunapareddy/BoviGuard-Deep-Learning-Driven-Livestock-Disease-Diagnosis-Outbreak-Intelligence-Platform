const express = require('express');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const User = (() => { try { return require('../models/User'); } catch { return null; } })();
const Volunteer = (() => { try { return require('../models/Volunteer'); } catch { return null; } })();
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const fallbackUsersFile = path.join(__dirname, '..', 'data', 'users.json');

function readFallbackUsers() {
  if (!fs.existsSync(fallbackUsersFile)) return [];
  try {
    return JSON.parse(fs.readFileSync(fallbackUsersFile, 'utf8')) || [];
  } catch {
    return [];
  }
}

function writeFallbackUsers(users) {
  fs.writeFileSync(fallbackUsersFile, JSON.stringify(users, null, 2));
}

// GET User Profile
router.get('/profile', requireAuth, async (req, res) => {
  try {
    const user = req.user;
    if (User && mongoose.connection && mongoose.connection.readyState === 1) {
      const dbUser = await User.findById(user._id).select('-password');
      if (!dbUser) return res.status(404).json({ message: 'User profile not found.' });

      const totalCases = await require('../models/Case').countDocuments({ userId: user._id });
      const activeCases = await require('../models/Case').countDocuments({ userId: user._id, status: { $nin: ['Closed', 'Recovered'] } });
      const resolvedCases = await require('../models/Case').countDocuments({ userId: user._id, status: 'Recovered' });

      return res.json({
        id: dbUser._id,
        name: dbUser.name,
        email: dbUser.email,
        phone: dbUser.phone || '',
        role: dbUser.role || 'Animal Owner',
        avatar: dbUser.avatar || '',
        area: dbUser.area || '',
        streetName: dbUser.streetName || '',
        pincode: dbUser.pincode || '',
        emergencyContactConsent: Boolean(dbUser.emergencyContactConsent),
        notificationPreferences: dbUser.notificationPreferences || { smsAlerts: true, emailAlerts: true, redZoneAlerts: true },
        createdAt: dbUser.createdAt,
        totalCases,
        activeCases,
        resolvedCases,
      });
    }

    const users = readFallbackUsers();
    const found = users.find((u) => String(u.id) === String(user._id));
    if (!found) return res.status(404).json({ message: 'User not found.' });

    res.json({
      id: found.id,
      name: found.name,
      email: found.email,
      phone: found.phone || '',
      role: found.role || 'Animal Owner',
      avatar: found.avatar || '',
      area: found.area || '',
      streetName: found.streetName || '',
      pincode: found.pincode || '',
      emergencyContactConsent: Boolean(found.emergencyContactConsent),
      notificationPreferences: found.notificationPreferences || { smsAlerts: true, emailAlerts: true, redZoneAlerts: true },
      createdAt: found.createdAt,
      totalCases: 0,
      activeCases: 0,
      resolvedCases: 0,
    });
  } catch (err) {
    console.error('Fetch profile error:', err);
    res.status(500).json({ message: 'Failed to fetch user profile.' });
  }
});

// PUT Update User Profile
router.put('/profile', requireAuth, async (req, res) => {
  const {
    name,
    phone,
    role,
    avatar,
    area,
    streetName,
    pincode,
    emergencyContactConsent,
    notificationPreferences
  } = req.body;

  const updates = {};
  if (name && name.trim()) updates.name = name.trim();
  if (typeof phone === 'string') updates.phone = phone.trim();
  if (role && ['Animal Owner', 'Volunteer', 'Veterinarian', 'NGO', 'Admin', 'System Admin', 'animal_owner', 'volunteer', 'veterinarian', 'ngo', 'admin', 'system_admin'].includes(role)) {
    updates.role = role;
  }
  if (typeof avatar === 'string') updates.avatar = avatar;
  if (typeof area === 'string') updates.area = area.trim();
  if (typeof streetName === 'string') updates.streetName = streetName.trim();
  if (typeof pincode === 'string') updates.pincode = pincode.trim();
  if (typeof emergencyContactConsent === 'boolean') updates.emergencyContactConsent = emergencyContactConsent;
  if (notificationPreferences && typeof notificationPreferences === 'object') {
    updates.notificationPreferences = notificationPreferences;
  }

  try {
    if (User && mongoose.connection && mongoose.connection.readyState === 1) {
      const updatedUser = await User.findByIdAndUpdate(req.user._id, updates, { new: true }).select('-password');
      if (!updatedUser) return res.status(404).json({ message: 'User not found.' });

      return res.json({
        success: true,
        message: 'Profile updated successfully.',
        user: updatedUser
      });
    }

    const users = readFallbackUsers();
    const index = users.findIndex((u) => String(u.id) === String(req.user._id));
    if (index === -1) {
      return res.status(404).json({ message: 'User not found.' });
    }
    users[index] = { ...users[index], ...updates };
    writeFallbackUsers(users);

    return res.json({
      success: true,
      message: 'Profile updated successfully.',
      user: users[index]
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Unable to update profile.' });
  }
});

function isAuthenticContact(contact) {
  if (!contact || !contact.phone) return false;
  const rawPhone = String(contact.phone).trim();
  const digits = rawPhone.replace(/\D/g, '');
  if (digits.length < 10) return false;

  // Exclude demo IDs or mock accounts
  const id = String(contact.id || contact._id || '');
  if (id.startsWith('demo-')) return false;

  const email = String(contact.email || '').toLowerCase();
  if (email.endsWith('@buffalohealth.org')) return false;

  // Exclude sequential or dummy test numbers
  if (digits.includes('12345') || digits.includes('54321') || digits.includes('9876543210') || digits === '9876543210' || digits === '9123456789') {
    return false;
  }

  return true;
}

// GET Emergency Contacts Directory (Only real registered volunteers & consented users)
router.get('/emergency-contacts', async (req, res) => {
  try {
    let contacts = [];
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      if (User) {
        const userContacts = await User.find({
          emergencyContactConsent: true,
          phone: { $exists: true, $ne: '' }
        })
        .select('name role phone area streetName pincode organization availabilityStatus createdAt')
        .sort({ createdAt: -1 })
        .lean();
        contacts.push(...userContacts);
      }

      if (Volunteer) {
        const volContacts = await Volunteer.find({
          phone: { $exists: true, $ne: '' }
        })
        .select('name role phone area district mandal availabilityStatus createdAt')
        .sort({ createdAt: -1 })
        .lean();

        // Merge real registered volunteers without duplicate phone numbers
        const existingPhones = new Set(contacts.map(c => c.phone ? c.phone.replace(/[\s+-]/g, '') : ''));
        for (const vol of volContacts) {
          const cleanPhone = (vol.phone || '').replace(/[\s+-]/g, '');
          if (cleanPhone && !existingPhones.has(cleanPhone)) {
            contacts.push(vol);
            existingPhones.add(cleanPhone);
          }
        }
      }
    }

    if (contacts.length === 0) {
      contacts = readFallbackUsers().filter((u) =>
        Boolean(u.emergencyContactConsent) === true &&
        u.phone &&
        u.phone.trim() !== ''
      );
    }

    // Strictly filter to ensure only authentic original and real registered contacts
    contacts = contacts.filter(isAuthenticContact);

    res.json(contacts);
  } catch (error) {
    console.error('Emergency contacts error:', error);
    res.status(500).json({ message: 'Unable to fetch emergency contacts.' });
  }
});

module.exports = router;
