const express = require('express');
const mongoose = require('mongoose');
const Volunteer = (() => { try { return require('../models/Volunteer'); } catch { return null; } })();

const router = express.Router();

// In-memory array for volunteers registered when DB offline (starts empty, only real registered details)
let inMemoryVolunteers = [];

// POST /api/volunteers/register: Register a new volunteer
router.post('/register', async (req, res) => {
  const { name, phone, area, district, mandal, role, latitude, longitude, availabilityStatus } = req.body;

  if (!name || !phone || !area) {
    return res.status(400).json({ 
      success: false, 
      message: 'Name, phone number, and area are required for volunteer registration.' 
    });
  }

  const lat = Number(latitude) || 16.5062;
  const lng = Number(longitude) || 80.6480;
  const status = availabilityStatus || 'available';

  try {
    if (Volunteer && mongoose.connection && mongoose.connection.readyState === 1) {
      const newVolunteer = await Volunteer.create({
        name: name.trim(),
        phone: phone.trim(),
        area: area.trim(),
        district: district ? district.trim() : 'Krishna',
        mandal: mandal ? mandal.trim() : '',
        role: role ? role.trim() : 'Para-Veterinarian',
        latitude: lat,
        longitude: lng,
        availabilityStatus: status,
        location: {
          type: 'Point',
          coordinates: [lng, lat]
        }
      });

      return res.status(201).json({
        success: true,
        message: 'Volunteer successfully registered in Emergency Registry.',
        volunteer: newVolunteer
      });
    }

    // In-memory fallback
    const mockVolunteer = {
      _id: `VOL-${Date.now()}`,
      name: name.trim(),
      phone: phone.trim(),
      area: area.trim(),
      district: district ? district.trim() : 'Krishna',
      mandal: mandal ? mandal.trim() : '',
      role: role ? role.trim() : 'Para-Veterinarian',
      latitude: lat,
      longitude: lng,
      availabilityStatus: status,
      createdAt: new Date().toISOString()
    };
    inMemoryVolunteers.unshift(mockVolunteer);

    return res.status(201).json({
      success: true,
      message: 'Volunteer successfully registered in Emergency Registry.',
      volunteer: mockVolunteer
    });

  } catch (error) {
    console.error('Volunteer registration error:', error);
    res.status(500).json({ success: false, message: 'Failed to register volunteer.' });
  }
});

// GET /api/volunteers: Query active volunteers nearby or by district
router.get('/', async (req, res) => {
  const { district, mandal, status, query, lat, lng } = req.query;

  try {
    if (Volunteer && mongoose.connection && mongoose.connection.readyState === 1) {
      let filter = {};
      if (status && status !== 'all') {
        filter.availabilityStatus = status;
      }
      if (district && district !== 'all') {
        filter.district = new RegExp(district, 'i');
      }
      if (mandal) {
        filter.mandal = new RegExp(mandal, 'i');
      }
      if (query) {
        filter.$or = [
          { name: new RegExp(query, 'i') },
          { area: new RegExp(query, 'i') },
          { role: new RegExp(query, 'i') },
          { district: new RegExp(query, 'i') }
        ];
      }

      const volunteers = await Volunteer.find(filter).sort({ createdAt: -1 });

      return res.json({
        success: true,
        count: volunteers.length,
        volunteers
      });
    }

    // In-memory filter
    let results = inMemoryVolunteers;
    if (status && status !== 'all') {
      results = results.filter(v => v.availabilityStatus === status);
    }
    if (district && district !== 'all') {
      results = results.filter(v => v.district.toLowerCase() === district.toLowerCase());
    }
    if (query) {
      const q = query.toLowerCase();
      results = results.filter(v => 
        v.name.toLowerCase().includes(q) || 
        v.area.toLowerCase().includes(q) || 
        v.role.toLowerCase().includes(q) || 
        (v.district && v.district.toLowerCase().includes(q))
      );
    }

    return res.json({
      success: true,
      count: results.length,
      volunteers: results
    });

  } catch (error) {
    console.error('Fetch volunteers error:', error);
    res.status(500).json({ success: false, message: 'Unable to retrieve volunteers list.' });
  }
});

// GET /api/volunteers/nearby
router.get('/nearby', async (req, res) => {
  const { lat, lng, limit = 10 } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ message: 'lat and lng are required.' });
  }

  try {
    if (Volunteer && mongoose.connection && mongoose.connection.readyState === 1) {
      const volunteers = await Volunteer.find({
        availabilityStatus: 'available',
        location: {
          $near: {
            $geometry: { type: 'Point', coordinates: [Number(lng), Number(lat)] },
            $maxDistance: 25000,
          },
        },
      }).limit(Number(limit));
      if (volunteers.length > 0) {
        return res.json(volunteers);
      }
    }

    // Haversine fallback
    const userLat = Number(lat);
    const userLng = Number(lng);
    const sorted = [...inMemoryVolunteers]
      .filter(v => v.availabilityStatus === 'available')
      .map(v => {
        const dLat = (v.latitude - userLat) * (Math.PI / 180);
        const dLon = (v.longitude - userLng) * (Math.PI / 180);
        const a = Math.sin(dLat / 2) ** 2 + Math.cos(userLat * Math.PI / 180) * Math.cos(v.latitude * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
        const dKm = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return { ...v, distanceKm: Math.round(dKm * 10) / 10 };
      })
      .sort((a, b) => a.distanceKm - b.distanceKm)
      .slice(0, Number(limit));

    return res.json(sorted);
  } catch (error) {
    console.error('Nearby volunteers error:', error);
    res.status(500).json({ message: 'Unable to fetch nearby volunteers.' });
  }
});

module.exports = router;
