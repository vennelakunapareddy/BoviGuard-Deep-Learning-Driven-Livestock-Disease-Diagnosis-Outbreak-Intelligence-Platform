const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const AnimalIssue = require('../models/AnimalIssue');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    cb(null, `${timestamp}-${safeName}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
});

const localDataPath = path.join(__dirname, '..', 'data', 'issues.json');

const vijayawadaAreaMap = {
  'MG Road': [16.5115, 80.6441],
  'Benz Circle': [16.5238, 80.6408],
  'Governorpet': [16.5033, 80.6434],
  'Labbipet': [16.5085, 80.6321],
  'One Town': [16.5201, 80.6205],
  'Auto Nagar': [16.5197, 80.6687],
  'Gannavaram': [16.4360, 80.6217],
  'Satyanarayanapuram': [16.5020, 80.6522],
  'Kondapalli': [16.5584, 80.8163],
  'Eluru Road': [16.5200, 80.6320],
  'Tadepalli': [16.4780, 80.6244],
};

const allowedPincodes = ['520001', '520002', '520003', '520004', '520008', '520013', '520014', '520016', '520017', '520018'];

const animalImageMap = {
  Dog: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Golden_retriever_eating_pigs_foot.jpg/320px-Golden_retriever_eating_pigs_foot.jpg',
  Hen: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Chicken_in_farm.jpg/320px-Chicken_in_farm.jpg',
  Buffalo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Indian_water_buffalo.jpg/320px-Indian_water_buffalo.jpg',
  Goat: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Goat_with_horn%2C_Croatian_highlands.jpg/320px-Goat_with_horn%2C_Croatian_highlands.jpg',
};

function ensureLocalDataFile() {
  const dir = path.dirname(localDataPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(localDataPath)) {
    fs.writeFileSync(localDataPath, '[]', 'utf8');
  }
}

async function readLocalIssues() {
  ensureLocalDataFile();
  const raw = await fs.promises.readFile(localDataPath, 'utf8');
  try {
    return JSON.parse(raw || '[]');
  } catch {
    return [];
  }
}

async function writeLocalIssues(issues) {
  ensureLocalDataFile();
  await fs.promises.writeFile(localDataPath, JSON.stringify(issues, null, 2), 'utf8');
}

function isDatabaseConnected() {
  return AnimalIssue.db && AnimalIssue.db.readyState === 1;
}

function isValidPincode(pincode) {
  return allowedPincodes.includes(pincode);
}

function classifyDisease({ animalType, symptoms, imagePresent }) {
  const lower = symptoms.toLowerCase();
  let diseaseType = 'General illness';
  let severity = 'low';
  let diagnosis = 'Unable to determine the exact condition from symptoms alone.';
  let emergency = false;
  let alertLevel = 'GREEN';

  const criticalWords = ['bleeding', 'seizure', 'unconscious', 'collapse', 'trauma', 'unable to stand', 'not breathing', 'severe', 'shock'];
  const respiratoryWords = ['cough', 'sneezing', 'nasal', 'wheezing', 'breath', 'breathing', 'congestion', 'gasping'];
  const gastroWords = ['diarrhea', 'vomiting', 'dysentery', 'stomach', 'bloat', 'constipation', 'loss of appetite'];
  const skinWords = ['skin', 'rash', 'lesion', 'ulcer', 'swelling', 'scab', 'pustule', 'hair loss', 'crust'];
  const parasiteWords = ['parasite', 'tick', 'mange', 'worm', 'lice', 'flystrike'];
  const footWords = ['foot', 'hoof', 'lame', 'limp', 'blister', 'mouth', 'hoof rot'];
  const neurologicalWords = ['seizure', 'tremor', 'shaking', 'staggering', 'head tilt'];
  const injuryWords = ['fracture', 'broken', 'injury', 'wound', 'cut', 'bleed'];

  if (criticalWords.some((word) => lower.includes(word)) || neurologicalWords.some((word) => lower.includes(word))) {
    severity = 'critical';
    emergency = true;
    alertLevel = 'RED';
    diagnosis = 'Immediate veterinary attention is required.';
    diseaseType = 'Critical condition';
  } else if (respiratoryWords.some((word) => lower.includes(word))) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'Respiratory disease is suspected. Evaluate breathing and nasal discharge.';
    diseaseType = animalType === 'Hen' ? 'Avian respiratory illness' : 'Respiratory illness';
  } else if (gastroWords.some((word) => lower.includes(word))) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'Signs point to a gastrointestinal problem such as infection or poisoning.';
    diseaseType = 'Gastrointestinal disease';
  } else if (footWords.some((word) => lower.includes(word))) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'Foot or mouth lesions are likely. Check for sores, swelling, or limping.';
    diseaseType = 'Foot and mouth disease';
  } else if (parasiteWords.some((word) => lower.includes(word))) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'Parasitic infestation is suspected. Inspect for ticks, mites, or worms.';
    diseaseType = 'Parasitic disease';
  } else if (skinWords.some((word) => lower.includes(word))) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'A skin infection or dermatitis is likely. Look for lesions, swelling, or alopecia.';
    diseaseType = 'Skin infection';
  } else if (injuryWords.some((word) => lower.includes(word))) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'Trauma or injury is suspected. Assess wounds and mobility.';
    diseaseType = 'Trauma / injury';
  }

  if (diseaseType === 'General illness' && imagePresent) {
    severity = 'moderate';
    alertLevel = 'YELLOW';
    diagnosis = 'Photo suggests a visual review is needed to identify the disease type.';
    diseaseType = 'Photo-based diagnosis recommended';
  }

  if (diseaseType === 'General illness' && lower.includes('bird')) {
    diseaseType = 'Avian disease';
    diagnosis = 'Symptoms may point to an avian illness. A vet should inspect the bird.';
  }

  if (imagePresent && skinWords.some((word) => lower.includes(word))) {
    diseaseType = 'Skin infection';
  }

  return { diseaseType, severity, diagnosis, emergency, alertLevel };
}

router.post('/issues', upload.single('image'), async (req, res) => {
  const { animalType, symptoms, pincode, areaName, reportedBy, userRole } = req.body;
  const normalizedPincode = String(pincode || '').trim();

  if (!animalType || !symptoms || !normalizedPincode || !areaName) {
    return res.status(400).json({ message: 'animalType, symptoms, pincode and areaName are required' });
  }

  if (!['Dog', 'Hen', 'Buffalo', 'Goat'].includes(animalType)) {
    return res.status(400).json({ message: 'Invalid animal type.' });
  }

  if (!isValidPincode(normalizedPincode)) {
    return res.status(400).json({ message: 'Only Vijayawada pincodes are allowed.' });
  }

  if (!vijayawadaAreaMap[areaName]) {
    return res.status(400).json({ message: 'Please select a valid Vijayawada area name.' });
  }

  const coordinatesArray = vijayawadaAreaMap[areaName];
  const coordinates = { latitude: coordinatesArray[0], longitude: coordinatesArray[1] };
  const analysis = classifyDisease({ animalType, symptoms, imagePresent: Boolean(req.file) });
  const imageUrl = req.file ? `/uploads/${req.file.filename}` : undefined;

  try {
    const existingIssues = isDatabaseConnected() ? await AnimalIssue.find() : await readLocalIssues();
    const sameDiseaseCount = existingIssues.filter((issue) => {
      return issue.pincode === normalizedPincode && issue.diseaseType === analysis.diseaseType;
    }).length + 1;

    if (sameDiseaseCount >= 3) {
      analysis.alertLevel = 'RED';
      analysis.severity = 'critical';
      analysis.emergency = true;
    }

    const issueData = {
      id: Date.now().toString(),
      animalType,
      animalImage: animalImageMap[animalType],
      symptoms,
      diseaseType: analysis.diseaseType,
      areaName,
      pincode: normalizedPincode,
      coordinates,
      imageUrl,
      diagnosis: analysis.diagnosis,
      severity: analysis.severity,
      emergency: analysis.emergency,
      alertLevel: analysis.alertLevel,
      reportedBy: reportedBy || 'Anonymous',
      userRole: ['veterinarian', 'volunteer', 'owner'].includes(userRole) ? userRole : 'owner',
      createdAt: new Date(),
    };

    if (isDatabaseConnected()) {
      const issue = new AnimalIssue(issueData);
      const savedIssue = await issue.save();
      return res.status(201).json(savedIssue);
    }

    const issues = await readLocalIssues();
    issues.unshift(issueData);
    await writeLocalIssues(issues);
    return res.status(201).json(issueData);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Unable to save issue', error: error.message });
  }
});

router.get('/issues', async (req, res) => {
  try {
    const issues = isDatabaseConnected() ? await AnimalIssue.find().sort({ createdAt: -1 }) : await readLocalIssues();
    const sorted = issues.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(sorted);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Unable to retrieve issues', error: error.message });
  }
});

router.get('/analysis/regions', async (req, res) => {
  try {
    const issues = isDatabaseConnected() ? await AnimalIssue.find() : await readLocalIssues();
    const regions = {};
    const diseaseCounts = {};

    issues.forEach((issue) => {
      const key = `${issue.pincode}:${issue.areaName}:${issue.diseaseType}`;
      if (!regions[key]) {
        regions[key] = {
          areaName: issue.areaName,
          pincode: issue.pincode,
          coordinates: issue.coordinates,
          diseaseType: issue.diseaseType,
          count: 0,
          alertLevel: 'GREEN',
        };
      }
      regions[key].count += 1;
      if (issue.alertLevel === 'RED') {
        regions[key].alertLevel = 'RED';
      } else if (issue.alertLevel === 'YELLOW' && regions[key].alertLevel !== 'RED') {
        regions[key].alertLevel = 'YELLOW';
      }
      diseaseCounts[issue.diseaseType] = (diseaseCounts[issue.diseaseType] || 0) + 1;
    });

    const regionList = Object.values(regions).map((region) => ({
      ...region,
      risk: region.count >= 3 ? 'High' : region.count === 2 ? 'Moderate' : 'Normal',
    }));

    const redAlertAreas = regionList.filter((region) => region.count >= 3 || region.alertLevel === 'RED');
    const diseaseSummary = Object.entries(diseaseCounts).map(([diseaseType, count]) => ({ diseaseType, count }));

    res.json({
      city: 'Vijayawada',
      regions: regionList,
      redAlertAreas,
      diseaseSummary,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Unable to compute region analysis', error: error.message });
  }
});

module.exports = router;
