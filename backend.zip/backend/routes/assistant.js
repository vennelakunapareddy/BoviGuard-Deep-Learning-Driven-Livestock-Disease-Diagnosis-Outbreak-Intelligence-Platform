const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const Case = require('../models/Case');
const { jwtSecret } = require('../middleware/auth');

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.0-flash';

// Multilingual Disclaimers
const DISCLAIMERS = {
  'te': "\n\n⚠️ గమనిక: ఇది ఏఐ ప్రాథమిక సూచన మాత్రమే. ఖచ్చితమైన చికిత్స మరియు మందుల మోతాదు కొరకు వెంటనే అర్హతగల పశువైద్యుడిని (1962) సంప్రదించండి.",
  'hi': "\n\n⚠️ अस्वीकरण: यह मार्गदर्शन केवल सामान्य जानकारी के लिए है। सटीक उपचार और दवा के लिए तुरंत पशु चिकित्सक (1962) से परामर्श लें।",
  'en': "\n\n⚠️ Disclaimer: AI-generated guidance is for informational purposes only and does not replace professional veterinary diagnosis or treatment. Consult a licensed field veterinarian (Call 1962)."
};

function getDisclaimer(lang) {
  return DISCLAIMERS[lang] || DISCLAIMERS.en;
}

function detectLanguage(text, defaultLang = 'en-IN') {
  if (!text) return defaultLang.startsWith('te') ? 'te' : defaultLang.startsWith('hi') ? 'hi' : 'en';
  // Check Telugu Unicode range (0C00 - 0C7F)
  if (/[\u0C00-\u0C7F]/.test(text)) return 'te';
  // Check Devanagari Hindi Unicode range (0900 - 097F)
  if (/[\u0900-\u097F]/.test(text)) return 'hi';
  
  if (defaultLang.startsWith('te')) return 'te';
  if (defaultLang.startsWith('hi')) return 'hi';
  return 'en';
}

// ============================================================================
// COMPREHENSIVE VETERINARY KNOWLEDGE GRAPH (ChatGPT / Gemini Quality)
// ============================================================================

const KNOWLEDGE_BASE = {
  // --------------------------------------------------------------------------
  // DIAGNOSTIC TESTS
  // --------------------------------------------------------------------------
  tests: {
    cmt: {
      en: {
        title: "🔬 California Mastitis Test (CMT) - Complete Guide",
        content: `**Purpose**: Rapid cow/buffalo-side test to detect subclinical and clinical mastitis before visible abnormalities appear in milk.

**How to Perform**:
1. Strip out initial 2 streams of foremilk into a strip cup.
2. Draw approximately 2 ml of milk from each of the 4 teats into corresponding shallow cups of the four-compartment CMT paddle (A, B, C, D).
3. Tilt paddle to roughly 45° to drain excess milk to the indicator line.
4. Add an equal volume (~2 ml) of CMT reagent (alkyl aryl sulfonate + bromocresol purple indicator).
5. Gently swirl the paddle in horizontal circular motions for 15–20 seconds and observe reaction immediately.

**Interpreting Results**:
• **Negative (-)**: Mixture remains liquid with no slime. Somatic Cell Count (SCC) < 200,000 cells/ml. Udder quarter is healthy.
• **Trace (T)**: Slight slime visible when swirling, disappears quickly. SCC 150,000–500,000 cells/ml.
• **Weak Positive (1+)**: Distinct slime formation, no gel centering. SCC 400,000–1,500,000 cells/ml.
• **Distinct Positive (2+)**: Immediate thickening with gel centering at the middle of the cup. SCC 1,200,000–5,000,000 cells/ml.
• **Strong Positive (3+)**: Convex jelly-like clot formation with elevated central peak. SCC > 5,000,000 cells/ml. Urgent veterinary treatment required.

**Clinical Action**:
Submit milk samples from positive quarters in sterile vials for bacterial culture & antibiotic sensitivity testing (ABST) to avoid antibiotic resistance.`
      },
      te: {
        title: "🔬 కాలిఫోర్నియా మాస్టిటిస్ టెస్ట్ (CMT) - పొదుగు వాపు నిర్ధారణ పరీక్ష",
        content: `**ఉద్దేశ్యం**: పాలల్లో మార్పులు కనిపించక ముందే పొదుగు వాపు (Mastitis) వ్యాధిని గుర్తించడానికి చేసే త్వరిత క్షేత్రస్థాయి పరీక్ష.

**పరీక్ష చేసే విధానం**:
1. మొదట వచ్చే రెండు పాల ధారలను స్ట్రిప్ కప్‌లోకి పితకండి.
2. నాలుగు గదుల CMT తెడ్డు (Paddle) లోని సంబంధిత గదులలోకి నాలుగు చనుల నుండి సుమారు 2 మి.లీ పాలను తీసుకోండి.
3. తెడ్డును 45 డిగ్రీల కోణంలో వంచి అదనపు పాలను బయటకు పోనివ్వండి.
4. పాల పరిమాణానికి సమానంగా (~2 మి.లీ) CMT రియాజెంట్ ద్రావణాన్ని కలపండి.
5. తెడ్డును క్షితిజ సమాంతరంగా గుండ్రంగా 15-20 సెకన్ల పాటు తిప్పుతూ వెంటనే మార్పును గమనించండి.

**ఫలితాల విశ్లేషణ**:
• **నెగెటివ్ (-)**: పాలు పలచగానే ఉంటాయి, ఎటువంటి జిగురు రాదు. కణం సంఖ్య (SCC) < 2 లక్షలు. పొదుగు ఆరోగ్యంగా ఉంది.
• **ట్రేస్ (T)**: స్వల్ప జిగురు ఏర్పడి వెంటనే కరిగిపోతుంది. SCC 1.5 - 5 లక్షలు.
• **పాజిటివ్ 1 (+)**: స్పష్టమైన జిగురు ఏర్పడుతుంది. SCC 4 - 15 లక్షలు.
• **పాజిటివ్ 2 (++)**: పాలు చిక్కటి జెల్ వలె మారి మధ్యలోకి చేరుతాయి. SCC 12 - 50 లక్షలు.
• **తీవ్ర పాజిటివ్ 3 (+++)**: గట్టి జెల్లీ ముద్ద ఏర్పడి కదలదు. SCC > 50 లక్షలు. వెంటనే చికిత్స అవసరం.

**తదుపరి చర్య**:
పాజిటివ్ వచ్చిన చనుల పాలను శుభ్రమైన స్టెరైల్ వైల్స్‌లో సేకరించి బ్యాక్టీరియల్ కల్చర్ మరియు యాంటీబయాటిక్ సెన్సిటివిటీ టెస్ట్ (ABST) కొరకు వెటర్నరీ ల్యాబ్‌కు పంపించండి.`
      },
      hi: {
        title: "🔬 कैलिफोर्निया मैस्टाइटिस टेस्ट (CMT) - थनैला जांच गाइड",
        content: `**उद्देश्य**: दूध में बाहरी बदलाव दिखने से पहले ही थनैला (Mastitis) रोग की पहचान करने हेतु त्वरित फील्ड टेस्ट।

**जांच की विधि**:
1. पहली दो धारों को स्ट्रिप कप में निकालें।
2. चार खानों वाली CMT पैडल में प्रत्येक थन से लगभग 2 मिली दूध लें।
3. पैडल को 45 डिग्री झुकाकर अतिरिक्त दूध निकालें ताकि बराबर मात्रा रहे।
4. बराबर मात्रा (2 मिली) में CMT रीजेंट मिलाएं।
5. पैडल को 15-20 सेकंड तक गोल-गोल घुमाएं और जेल बनने की प्रक्रिया देखें।

**परिणाम का विश्लेषण**:
• **नेगेटिव (-)**: कोई गाढ़ापन नहीं। सोमैटिक सेल काउंट (SCC) < 2 लाख। थन स्वस्थ है।
• **ट्रेस (T)**: हल्का गाढ़ापन जो तुरंत गायब हो जाए। SCC 1.5 - 5 लाख।
• **पॉजिटिव 1 (+)**: स्पष्ट जेल या चिपचिपापन बनना। SCC 4 - 15 लाख।
• **पॉजिटिव 2 (++)**: गाढ़ा जेल जो पैडल के बीच में इकट्ठा हो। SCC 12 - 50 लाख।
• **गंभीर पॉजिटिव 3 (+++)**: जेली की तरह सख्त थक्का बनना। SCC > 50 लाख। तत्काल उपचार जरूरी।

**उपचार सलाह**:
पॉजिटिव थनों के दूध का नमूना जीवाणु संवर्धन (Bacterial Culture) और एंटीबायोटिक संवेदनशीलता जांच (ABST) हेतु लैब भेजें।`
      }
    },
    rtpcr: {
      en: {
        title: "🧬 RT-PCR & Molecular Tests for Buffaloes",
        content: `**Primary Diseases Tested**: Foot-and-Mouth Disease (FMD) and Lumpy Skin Disease (LSD).

**Sampling Protocol**:
• **For FMD**: Unruptured vesicular blister fluid (1-2 ml), tongue/mouth epithelial tags collected in 50% phosphate buffered glycerol (PBG, pH 7.2–7.6), or oral swabs on ice.
• **For LSD**: Skin nodule biopsies, dry scabs, or whole blood in EDTA tubes (purple top) during febrile stage.

**Why RT-PCR is Gold Standard**:
Detects viral nucleic acid within hours with >98% sensitivity, differentiating field viral strains from vaccinal strains.`
      },
      te: {
        title: "🧬 గేదెలకు RT-PCR & మాలిక్యులర్ ల్యాబ్ పరీక్షలు",
        content: `**పరీక్షించే వ్యాధులు**: గాలికుంటు వ్యాధి (FMD) మరియు లంపీ స్కిన్ వ్యాధి (LSD).

**నమూనాలు సేకరించే విధానం**:
• **గాలికుంటు (FMD) కొరకు**: పగలని బొబ్బల ద్రవం, నాలుక/నోటి చర్మ పొరలు (ఎపిథీలియం) ను 50% గ్లిజరాల్ బఫర్ ద్రావణంలో ఐస్ బాక్స్‌లో పెట్టి పంపాలి.
• **లంపీ స్కిన్ (LSD) కొరకు**: చర్మంపై ఏర్పడిన గడ్డల ముక్కలు (బయాప్సీ), ఎండిన పొలుసులు లేదా EDTA రక్తపు నమూనాలు.

**ల్యాబ్ ప్రయోజనం**:
వైరస్ జన్యువును అత్యంత వేగంగా మరియు 98% కంటే ఎక్కువ ఖచ్చితత్వంతో నిర్ధారిస్తుంది.`
      },
      hi: {
        title: "🧬 भैंसों के लिए RT-PCR एवं आणविक लैब परीक्षण",
        content: `**प्रमुख रोग**: खुरपका-मुंहपका (FMD) और लम्पी स्किन डिजीज (LSD)।

**नमूना संग्रह प्रक्रिया**:
• **FMD के लिए**: बिना फूटे छालों का द्रव (1-2 मिली), जीभ व मसूड़ों के छिलके (50% फॉस्फेट बफर्ड ग्लिसरॉल में), या लार का फाहा बर्फ में रखकर भेजें।
• **लम्पी के लिए**: त्वचा की गांठों का बायोप्सी टुकड़ा, खुरंड (Scabs), या EDTA रक्त का नमूना।

**महत्व**:
यह परीक्षण वायरस के जीनोम की सटीक पहचान करता है और टीकाकरण तथा वास्तविक संक्रमण में भेद बताता है।`
      }
    },
    elisa: {
      en: {
        title: "🧪 ELISA & Serological Antibody Testing",
        content: `**Key Diagnostic Tests**:
1. **3ABC Non-Structural Protein (NSP) ELISA**: Critical for FMD surveillance. Differentiates infected animals from vaccinated animals (DIVA principle).
2. **Rose Bengal Plate Test (RBPT)**: Rapid screening test for Bovine Brucellosis antibodies.
3. **Milk Ring Test (MRT)**: Herd-level bulk tank milk screening for Brucella.

**Sample Requirements**:
5–10 ml plain clotted blood (red top tube) for serum separation. Centrifuge at 3000 RPM for 10 minutes and store serum at -20°C.`
      },
      te: {
        title: "🧪 ఎలైసా (ELISA) & రక్త సీరం యాంటీబాడీ పరీక్షలు",
        content: `**ముఖ్యమైన పరీక్షలు**:
1. **3ABC NSP ELISA (గాలికుంటు)**: వ్యాక్సిన్ వేయడం వల్ల వచ్చిన యాంటీబాడీలు మరియు నిజమైన వైరస్ సోకిన గేదెలను గుర్తించే ఖచ్చితమైన పరీక్ష.
2. **రోజ్ బెంగాల్ ప్లేట్ టెస్ట్ (RBPT)**: బ్రూసెల్లోసిస్ వ్యాధి యాంటీబాడీల స్క్రీనింగ్.
3. **మిల్క్ రింగ్ టెస్ట్ (MRT)**: మొత్తం మందలో బ్రూసెల్లా ఉందో లేదో పాల ద్వారా తెలుసుకునే పరీక్ష.

**నమూనా**:
5-10 మి.లీ రక్తాన్ని సాధారణ ట్యూబ్‌లో సేకరించి సీరం తీసి పరీక్షకు పంపాలి.`
      },
      hi: {
        title: "🧪 एलाइजा (ELISA) एवं सीरोलॉजिकल टेस्ट",
        content: `**मुख्य परीक्षण**:
1. **3ABC NSP ELISA**: खुरपका-मुंहपका (FMD) में संक्रमित और टीका लगे पशुओं में अंतर (DIVA प्रणाली) करने हेतु।
2. **रोज बंगाल प्लेट टेस्ट (RBPT)**: ब्रुसेलोसिस रोग की जांच।
3. **मिल्क रिंग टेस्ट (MRT)**: दूध के नमूने से ब्रुसेला संक्रमण की सामूहिक जांच।

**नमूना**:
5-10 मिली रक्त से सीरम अलग करके सुरक्षित रखें।`
      }
    },
    bloodsmear: {
      en: {
        title: "🩸 Blood Smear Staining & Hemoprotozoan Tests",
        content: `**Target Pathogens**:
• **Surra (Trypanosoma evansi)**: Flagellated protozoan seen swimming between red cells.
• **Hemorrhagic Septicemia (Pasteurella multocida)**: Characteristic bipolar-staining coccobacilli (safety-pin appearance) on Leishman or methylene blue stain.
• **Theileriosis (Theileria annulata)** & **Babesiosis**: Tick-borne intra-erythrocytic piroplasms.

**How to Prepare**:
Collect peripheral blood from ear tip vein. Prepare thin feathered-edge smear and thick smear immediately. Air dry and fix with absolute methanol for 3 minutes before Giemsa staining.`
      },
      te: {
        title: "🩸 రక్తపు పూత (Blood Smear) & సూక్ష్మజీవుల పరీక్షలు",
        content: `**గుర్తించే రోగాలు**:
• **సర్రా వ్యాధి (Trypanosomiasis)**: రక్త కణాల మధ్య తిరిగే పరాన్నజీవులను గుర్తిస్తుంది.
• **గొంతువాపు (HS - Pasteurella)**: లిష్మాన్ స్టెయినింగ్ ద్వారా సేఫ్టీ పిన్ ఆకారంలో ఉండే బ్యాక్టీరియాను గుర్తిస్తుంది.
• **రక్తం మూత్రం పడే వ్యాధులు (Theileria, Babesia)**: పేల ద్వారా సంక్రమించే రక్త కణాల పరాన్నజీవులు.

**నమూనా సేకరణ**:
చెవి కొన సిర నుండి తాజా రక్తాన్ని సేకరించి స్లైడ్‌పై పల్చని పూత తీసి మిథనాల్‌తో ఫిక్స్ చేసి ల్యాబ్‌కు పంపాలి.`
      },
      hi: {
        title: "🩸 ब्लड स्मीयर (रक्त की जांच) एवं प्रोटोजोआ टेस्ट",
        content: `**पहचाने जाने वाले रोग**:
• **सर्रा (Trypanosoma evansi)**: रक्त में तैरते हुए परजीवी।
• **गलघोंटू (HS - Pasteurella multocida)**: सेफ्टी-पिन के आकार के द्विध्रुवीय (Bipolar) जीवाणु।
• **बबेसिओसिस एवं थाइलेरिया**: चीचड़ जनित लाल रक्त कणिकाओं के परजीवी।

**तैयारी**:
कान की नस से ताजा रक्त लेकर कांच की स्लाइड पर पतली परत बनाएं और जांच हेतु भेजें।`
      }
    }
  },

  // --------------------------------------------------------------------------
  // DISEASES & MANAGEMENT
  // --------------------------------------------------------------------------
  diseases: {
    fmd: {
      en: {
        name: "Foot-and-Mouth Disease (FMD)",
        severity: "Critical / Highly Contagious",
        transmission: "Airborne aerosols, direct contact, contaminated feed/water troughs, milk, and footwear.",
        symptoms: [
          "High fever (104–106°F / 40–41°C) with shivering",
          "Painful blisters/vesicles on tongue, dental pad, gums, cheeks, and muzzle",
          "Profuse, stringy, ropy salivation (drooling) and smacking of lips",
          "Painful vesicles in interdigital space of hooves and coronary band causing severe lameness",
          "Teat vesicles leading to secondary clinical mastitis",
          "Sudden drop in milk yield (up to 80%)"
        ],
        diagnosticTests: "Vesicular fluid RT-PCR, 3ABC non-structural protein ELISA, Antigen-detection ELISA.",
        precautions: [
          "Strict quarantine: Isolate affected buffaloes in a separate quarantine shed at least 50 meters away.",
          "Halt all animal movements, trade, and farm entry.",
          "Wash mouth and hoof lesions with 1% Potassium Permanganate (KMnO4) or 2% Sodium Bicarbonate twice daily.",
          "Apply Boroglycerine paste to oral ulcers to facilitate feeding soft green fodder.",
          "Disinfect shed floors and equipment with 4% Sodium Carbonate (washing soda) or 1% Citric Acid.",
          "Milkers must sanitize hands and dip boots in disinfectant before and after handling animals."
        ],
        vaccination: "Bi-annual vaccination with Polyvalent Oil-adjuvanted FMD vaccine (before summer/monsoon and winter).",
        helpline: "Immediate outbreak reporting to toll-free 1962 (AP Mobile Ambulance)."
      },
      te: {
        name: "గాలికుంటు వ్యాధి (Foot & Mouth Disease / FMD)",
        severity: "అత్యంత ప్రమాదకరం / త్వరిత వ్యాప్తి",
        transmission: "గాలి ద్వారా, పశువుల స్పర్శ, కలుషితమైన మేత, నీరు, మరియు పాల ద్వారా సులభంగా వ్యాపిస్తుంది.",
        symptoms: [
          "తీవ్రమైన జ్వరం (104–106°F)",
          "నాలుక, పెదవులు, చిగుళ్ళు మరియు మూతిపై బాధాకరమైన నీటి బొబ్బలు",
          "నోటి నుండి నిరంతరం తీగలు తీగలుగా సొంగ కారడం మరియు పెదవుల చప్పుడు (Lip smacking)",
          "గిట్టల సందుల్లో తీవ్రమైన పుండ్లు రావడం వల్ల తీవ్రంగా కుంటడం",
          "చనులపై బొబ్బలు వచ్చి పాలు ఆగిపోవడం",
          "పాలలో 70-80% వరకు భారీ తగ్గుదల"
        ],
        diagnosticTests: "పగలని బొబ్బల ద్రవంతో RT-PCR మరియు 3ABC ELISA యాంటీబాడీ పరీక్ష.",
        precautions: [
          "తక్షణ ఐసోలేషన్: సోకిన గేదెను ఇతర పశువుల నుండి వెంటనే వేరుగా ఉంచండి.",
          "నోటిలోని మరియు కాళ్ళ గాయాలను రోజుకు 2 సార్లు 1% పొటాషియం పర్మాంగనేట్ (గులాబీ రంగు నీరు) లేదా సోడా నీటితో కడగండి.",
          "నోటి పుండ్లపై బోరోగ్లిజరిన్ పేస్ట్ రాయండి, మెత్తని పచ్చిగడ్డి, గంజి మాత్రమే ఇవ్వండి.",
          "పశువుల కొట్టాన్ని 4% సోడా ద్రావణం (వాషింగ్ సోడా) తో రోజూ శుభ్రం చేయండి.",
          "వ్యాధి సోకిన పశువుల పాలను దూడలకు తాగించవద్దు, కాచి పారబోయండి."
        ],
        vaccination: "ప్రతి 6 నెలలకు ఒకసారి (వర్షాకాలం మరియు శీతాకాలం ముందు) గాలికుంటు టీకా తప్పనిసరిగా వేయించాలి.",
        helpline: "అత్యవసర చికిత్సకు వెంటనే 1962 టోల్ ఫ్రీ నంబర్‌కు కాల్ చేయండి."
      },
      hi: {
        name: "खुरपका-मुंहपका रोग (Foot-and-Mouth Disease / FMD)",
        severity: "अत्यधिक गंभीर / संक्रामक",
        transmission: "हवा, लार, दूषित चारे, पानी और पैरों के संपर्क से तेजी से फैलता है।",
        symptoms: [
          "तेज बुखार (104–106°F) और कंपकंपी",
          "जीभ, मसूड़ों और मुंह के अंदर दर्दनाक छाले",
          "मुंह से रस्सी जैसी गाढ़ी लार टपकना",
          "खुरों के बीच छाले व घाव होने से गंभीर लंगड़ापन",
          "थनों पर छाले और दूध उत्पादन में भारी गिरावट"
        ],
        diagnosticTests: "RT-PCR और 3ABC ELISA सीरोलॉजिकल टेस्ट।",
        precautions: [
          "संक्रमित भैंस को तुरंत बाकी पशुओं से अलग बाड़े में रखें।",
          "मुंह और खुरों के छालों को 1% पोटाश (लाल दवा) के पानी से धोएं।",
          "मुंह के छालों पर बोरो-ग्लिसरीन लगाएं और सुपाच्य दलिया व हरा चारा दें।",
          "बाड़े के फर्श को 4% सोडियम कार्बोनेट (धोने का सोडा) से विसंक्रमित करें।",
          "संक्रमित पशु के दूध को उबालकर नष्ट करें।"
        ],
        vaccination: "हर 6 महीने में तेल-युक्त FMD टीका अवश्य लगवाएं।",
        helpline: "तुरंत पशु एम्बुलेंस हेल्पलाइन 1962 पर कॉल करें।"
      }
    },

    lsd: {
      en: {
        name: "Lumpy Skin Disease (LSD)",
        severity: "High / Contagious Viral Pox",
        transmission: "Biting insects (Stomoxys biting flies, mosquitoes, ticks), contaminated equipment, and direct contact.",
        symptoms: [
          "High fever (104–105°F) lasting 3–5 days",
          "Eruption of firm, circumscribed nodules (2–5 cm) all over body, head, neck, and udder",
          "Enlarged superficial lymph nodes (prescapular & prefemoral)",
          "Edema/swelling of brisket, dewlap, and legs (causing stiffness)",
          "Watery to purulent nasal and ocular discharge",
          "Deep skin ulcers / 'sit-fast' lesions prone to secondary bacterial infection and maggot wounds"
        ],
        diagnosticTests: "Real-time PCR on skin scab/biopsy, blood EDTA PCR during febrile stage.",
        precautions: [
          "Strict vector control: Spray shed and buffalo with 2% Neem oil or Deltamethrin/Cypermethrin spray to kill biting flies.",
          "Keep infected animals under mosquito/fly netting if possible.",
          "Clean ulcerated nodules daily with antiseptic povidone-iodine spray and fly-repellent ointments to prevent maggot infestation.",
          "Provide electrolyte water, multivitamin/mineral supplements, and liver tonics.",
          "Administer antipyretic (Meloxicam/Paracetamol) and secondary antibiotic protection under vet guidance."
        ],
        vaccination: "Annual vaccination with Heterologous Goat Pox vaccine (Uttarkashi strain, 3 ml SC) before insect breeding season.",
        helpline: "Call 1962 for veterinary clinical support."
      },
      te: {
        name: "లంపీ స్కిన్ వ్యాధి (Lumpy Skin Disease / LSD)",
        severity: "అధికం / వైరల్ కీటక వ్యాప్తి",
        transmission: "గోమార్లు, పేలు, దోమలు, మరియు రక్త పిపాసి ఈగల కాటు ద్వారా వేగంగా వ్యాపిస్తుంది.",
        symptoms: [
          "తీవ్ర జ్వరం (104–105°F)",
          "శరీరం, మెడ, పొదుగుపై 2 నుండి 5 సెం.మీ గుండ్రని గట్టి కణుతులు/గడ్డలు",
          "కాళ్ళు, గొంతు కింద తీవ్రమైన నీరు చేరి వాపు రావడం",
          "ముక్కు, కళ్ళ నుండి నీరు లేదా చీము కారడం",
          "గడ్డలు పగిలి పుండ్లుగా మారడం మరియు పురుగులు (మాగట్స్) పడే ప్రమాదం",
          "పాలు గణనీయంగా తగ్గిపోవడం"
        ],
        diagnosticTests: "చర్మపు పొలుసులపై RT-PCR మరియు బయాప్సీ పరీక్ష.",
        precautions: [
          "ఈగలు, దోమలు, పేల నివారణకు కొట్టం చుట్టూ వేపనూనె లేదా క్రిమిసంహారక స్ప్రేలు చల్లండి.",
          "పగిలిన గడ్డలపై పోవిడోన్-అయోడిన్ మందు మరియు పురుగులు పట్టకుండా ఉండే ఆయింట్‌మెంట్లు పూయండి.",
          "పశువుకు శక్తి కోసం బెల్లం, ఎలక్ట్రోలైట్ నీరు, విటమిన్ టానిక్ ఇవ్వండి.",
          "వ్యాధిగ్రస్తుడైన పశువును దోమ తెర కింద లేదా ప్రత్యేక కొట్టంలో ఉంచండి."
        ],
        vaccination: "ఏటా వేసవి కాలానికి ముందే గోట్ పాక్స్ (Goat Pox) వ్యాక్సిన్ వేయించండి.",
        helpline: "వైద్య సాయం కొరకు వెంటనే 1962 నంబర్‌ను సంప్రదించండి."
      },
      hi: {
        name: "लम्पी स्किन रोग (Lumpy Skin Disease / LSD)",
        severity: "उच्च / संक्रामक पॉक्स वायरस",
        transmission: "खून चूसने वाली मक्खियों, मच्छरों और चीचड़ों द्वारा फैलता है।",
        symptoms: [
          "तेज बुखार (104–105°F)",
          "शरीर, गर्दन और थन पर 2 से 5 सेमी की कठोर गांठें",
          "पैरों और गले में भारी सूजन व जकड़न",
          "आंखों व नाक से पानी या मवाद बहना",
          "गांठें फूटने पर घाव होना और कीड़े (मैलट्स) पड़ने का खतरा"
        ],
        diagnosticTests: "त्वचा की पपड़ी का RT-PCR परीक्षण।",
        precautions: [
          "मक्खी और मच्छरों से बचाव के लिए नीम के तेल या साइपरमेथ्रिन का छिड़काव करें।",
          "फूटी हुई गांठों पर बीटाडीन (पोवीडोन आयोडीन) और कीड़े भगाने वाला स्प्रे लगाएं।",
          "बुखार कम करने के लिए दर्द निवारक दवा और इलेक्ट्रोलाइट्स दें।",
          "पशु को मच्छरदानी में या अलग छायादार बाड़े में रखें।"
        ],
        vaccination: "हर साल गोट पॉक्स वैक्सीन (3 मिली) अवश्य लगवाएं।",
        helpline: "तुरंत 1962 पशु एम्बुलेंस सेवा से संपर्क करें।"
      }
    },

    mastitis: {
      en: {
        name: "Clinical Mastitis",
        severity: "Moderate to High / Economic Threat",
        transmission: "Environmental & contagious bacteria (Staph aureus, Strep agalactiae, E. coli, Klebsiella) entering through relaxed teat canal.",
        symptoms: [
          "Swollen, hard, hot, intensely painful udder quarter(s)",
          "Discolored milk: Clots, flakes, watery whey-like consistency, or blood streaks",
          "Buffalo resists milking or calf suckling (kicks or steps around)",
          "Systemic toxemia in coliform mastitis: High fever, sunken eyes, loss of appetite, recumbency",
          "Permanent loss of milk quarter (blind quarter) if left untreated"
        ],
        diagnosticTests: "California Mastitis Test (CMT), Milk Somatic Cell Count (SCC > 200,000 cells/ml), Milk Bacterial Culture and Antibiotic Sensitivity Testing (ABST).",
        precautions: [
          "Milk affected quarters LAST into a separate bucket and safely discard the milk.",
          "Perform California Mastitis Test (CMT) monthly across all lactating animals.",
          "Post-milking teat dip: Immediately dip teats in 0.5% Povidone-Iodine or Chlorhexidine solution for 30 seconds.",
          "Keep buffalo standing for at least 30–45 minutes post-milking by providing fresh fodder (allows teat sphincter to close).",
          "Ensure clean, dry bedding free of damp mud and manure accumulation.",
          "Complete intramammary antibiotic infusion strictly under sterile conditions following veterinarian guidance.",
          "Use dry cow antibiotic therapy at the end of each lactation cycle."
        ],
        vaccination: "Good milking hygiene, teat dipping, and dry cow therapy are primary prevention methods.",
        helpline: "Consult your field veterinarian or call 1962 for intramammary infusion and culture."
      },
      te: {
        name: "పొదుగు వాపు వ్యాధి (Clinical Mastitis)",
        severity: "మధ్యస్థం నుండి తీవ్రం / పాల నష్టం",
        transmission: "అపరిశుభ్రమైన కొట్టం నేల, పేడ మరియు మురికి చేతుల నుండి బ్యాక్టీరియా చనుల ద్వారం ద్వారా లోపలికి ప్రవేశిస్తుంది.",
        symptoms: [
          "పొదుగు గట్టిగా, రాతిలా మారి ఎర్రబడి వేడెక్కడం",
          "పాలల్లో మార్పు: రక్తం రావడం, పసుపు రంగు చీము, నీళ్లలా లేదా గడ్డలుగా పాలు రావడం",
          "పాలు పితకనివ్వకపోవడం మరియు నొప్పి వల్ల దూడను తాగనివ్వకపోవడం",
          "తీవ్రమైన స్థితిలో అధిక జ్వరం మరియు పశువు కింద కూలబడిపోవడం"
        ],
        diagnosticTests: "కాలిఫోర్నియా మాస్టిటిస్ టెస్ట్ (CMT), సోమాటిక్ సెల్ కౌంట్ (SCC), మరియు ల్యాబ్ కల్చర్ & ABST పరీక్ష.",
        precautions: [
          "పాలు పితకడానికి ముందు, తర్వాత చనులను 0.5% పోవిడోన్ అయోడిన్ ద్రావణంలో ముంచండి (Teat Dipping).",
          "వ్యాధి సోకిన చను పాలను అందరికంటే చివరగా పితకండి మరియు ఆ పాలను సురక్షితంగా పారబోయండి.",
          "పాలు పితికిన తర్వాత చను ద్వారం మూసుకునే వరకు కనీసం 30-45 నిమిషాల పాటు గేదె కింద పడుకోకుండా పచ్చిమేత వేసి నిలబెట్టండి.",
          "కొట్టం నేలను ఎల్లప్పుడూ పొడిగా, పేడ లేకుండా శుభ్రంగా ఉంచండి.",
          "పొదుగులో ఎక్కించే ఇంట్రా-మామరీ ట్యూబ్‌లను వెటర్నరీ డాక్టర్ సలహాతో మాత్రమే వేయండి."
        ],
        vaccination: "పరిశుభ్రమైన పాలు పితికే పద్ధతులు మరియు డ్రై కౌ థెరపీ ద్వారా నివారించవచ్చు.",
        helpline: "తక్షణ చికిత్స కొరకు 1962 టోల్ ఫ్రీ నంబర్‌ను సంప్రదించండి."
      },
      hi: {
        name: "क्लिनिकल थनैला रोग (Clinical Mastitis)",
        severity: "मध्यम से गंभीर / दूध का भारी नुकसान",
        transmission: "गंदे बाड़े, कीचड़ व गोबर से जीवाणु (बैक्टीरिया) थन के रास्ते अंदर प्रवेश करते हैं।",
        symptoms: [
          "थन में सूजन, अत्यधिक गर्मी, कड़ापन व दर्द",
          "दूध में खून, मवाद, पानी जैसा पतला दूध या सफेद थक्के आना",
          "भैंस का दूध न दुहने देना और लात मारना",
          "दूध उत्पादन में भारी गिरावट व तेज बुखार"
        ],
        diagnosticTests: "कैलिफोर्निया मैस्टाइटिस टेस्ट (CMT), सोमैटिक सेल काउंट (SCC), और कल्चर ABST जांच।",
        precautions: [
          "दूध दुहने के बाद थनों को 0.5% पोवीडोन आयोडीन घोल में 30 सेकंड तक डुबोएं (टीट डिपिंग)।",
          "संक्रमित थन का दूध सबसे अंत में दुहें और अलग नष्ट करें।",
          "दूध निकालने के बाद 45 मिनट तक भैंस को बैठने न दें, उसे हरा चारा खाने दें।",
          "बाड़े के फर्श को सूखा, हवादार व साफ रखें।",
          "पशु चिकित्सक की सलाह से ही थन में एंटीबायोटिक ट्यूब चढ़ाएं।"
        ],
        vaccination: "स्वच्छ दूध उत्पादन व ड्राई काउ थेरेपी ही मुख्य बचाव है।",
        helpline: "तुरंत पशु अस्पताल या 1962 पर संपर्क करें।"
      }
    },

    hs: {
      en: {
        name: "Hemorrhagic Septicemia (HS / गलघोंटू / గొంతువాపు)",
        severity: "Critical / Highly Fatal (Deadly within 24-48 hrs)",
        transmission: "Pasteurella multocida (B:2) ingested or inhaled via contaminated feed/water, triggered by monsoon stress, exhaustion, or sudden chilling.",
        symptoms: [
          "Peracute high fever (105–107°F / 40.5–41.5°C)",
          "Hot, painful, warm subcutaneous swelling in throat, submandibular space, dewlap, and neck",
          "Severe respiratory distress: Loud snoring/stertorous breathing, open-mouth panting, extended tongue",
          "Profuse salivation and ocular discharge",
          "Rapid collapse and death due to asphyxiation and endotoxemia within 12–36 hours if untreated"
        ],
        diagnosticTests: "Blood smear staining (bipolar staining coccobacilli with Leishman/Giemsa), PCR, bacterial culture.",
        precautions: [
          "Emergency veterinary treatment is imperative in first 6 hours: High-dose Sulfonamides or 3rd gen Cephalosporins (Ceftiofur) and NSAIDs (Flunixin/Meloxicam).",
          "Immediate quarantine of affected buffalo.",
          "Administer prophylactic antibiotics to in-contact herd members under vet guidance.",
          "Prevent exposure to stagnant flood waters and cold night winds."
        ],
        vaccination: "Annual vaccination with Alum-precipitated or Oil-adjuvanted HS vaccine in May–June (strictly BEFORE monsoon onset).",
        helpline: "CRITICAL EMERGENCY: Call 1962 mobile ambulance immediately."
      },
      te: {
        name: "గొంతువాపు వ్యాధి (Hemorrhagic Septicemia / HS)",
        severity: "అత్యంత ప్రమాదకరం / ప్రాణాంతకం (24 గంటల్లో మరణించే ప్రమాదం)",
        transmission: "వర్షాకాలంలో కలుషిత నీరు, మేత మరియు చలి గాలి వల్ల పాశ్చరెల్లా బ్యాక్టీరియా ద్వారా వేగంగా వ్యాపిస్తుంది.",
        symptoms: [
          "తీవ్రమైన జ్వరం (105–107°F)",
          "గొంతు కింద, దవడల కింద, మరియు మెడ భాగంలో వేడిగా ఉండే తీవ్రమైన వాపు",
          "తీవ్రమైన ఊపిరితిత్తుల సమస్య: గురక శబ్దంతో కూడిన శ్వాస, నాలుక బయటపెట్టి ఆయాసపడటం",
          "నోటి నుండి తీవ్రంగా సొంగ కారడం",
          "సకాలంలో వైద్యం అందకపోతే ఊపిరాడక 24-36 గంటల్లో పశువు మరణించే ప్రమాదం"
        ],
        diagnosticTests: "రక్త పూత (Blood Smear) పరీక్ష ద్వారా బైపోలార్ బ్యాక్టీరియా గుర్తింపు.",
        precautions: [
          "లక్షణాలు కనిపించిన మొదటి 6 గంటల్లోనే వెటర్నరీ డాక్టర్‌తో యాంటీబయాటిక్ ఇంజెక్షన్లు ఇప్పించాలి.",
          "వర్షాకాలంలో నిల్వ ఉన్న మురుగు నీటిని పశువులు తాగకుండా చూడండి.",
          "మందలోని ఇతర పశువులకు వెంటనే నివారణ మందులు వేయించాలి."
        ],
        vaccination: "ప్రతి సంవత్సరం వర్షాకాలానికి ముందే (మే - జూన్ నెలల్లో) గొంతువాపు టీకా (HS Vaccine) తప్పనిసరిగా వేయించాలి.",
        helpline: "తక్షణ అత్యవసర సహాయం కొరకు 1962 నంబర్‌కు వెంటనే కాల్ చేయండి."
      },
      hi: {
        name: "गलघोंटू रोग (Hemorrhagic Septicemia / HS)",
        severity: "अत्यधिक गंभीर / जानलेवा (24 घंटे में मृत्यु का खतरा)",
        transmission: "वर्षा ऋतु में दूषित चारे-पानी और तनाव के कारण पाश्चुरेला जीवाणु से फैलता है।",
        symptoms: [
          "अत्यधिक तेज बुखार (105–107°F)",
          "गले, जबड़े और गलकंबल में गर्म व दर्दनाक सूजन",
          "सांस लेने में भारी घरघराहट की आवाज, जीभ बाहर निकलना और हांफना",
          "मुंह से अत्यधिक लार टपकना",
          "इलाज न मिलने पर दम घुटने से 24 से 36 घंटे में मृत्यु"
        ],
        diagnosticTests: "ब्लड स्मीयर जांच द्वारा बाईपोलर जीवाणु की पहचान।",
        precautions: [
          "शुरुआती 6 घंटे में तत्काल उच्च श्रेणी की एंटीबायोटिक दवाएं पशु चिकित्सक से दिलवाएं।",
          "संक्रमित पशु को तुरंत अलग करें और बाकी झुंड का तापमान नापें।",
          "बरसात के गंदे पानी में पशुओं को न जाने दें।"
        ],
        vaccination: "मानसून से पहले (मई-जून में) हर वर्ष गलघोंटू का टीका अवश्य लगवाएं।",
        helpline: "आपातकालीन एम्बुलेंस 1962 पर तत्काल कॉल करें।"
      }
    },

    bq: {
      en: {
        name: "Black Quarter (BQ / జబ్బవాపు / लंगड़ा बुखार)",
        severity: "Critical / Highly Fatal",
        transmission: "Clostridium chauvoei spores ingested from soil or entering deep puncture wounds.",
        symptoms: [
          "Acute onset of high fever (104–106°F) and depression",
          "Severe lameness in one hindquarter or forequarter",
          "Hot, painful swelling in heavy muscle masses (thigh, shoulder, rump) that turns cold, painless, and crepitant (crackling sound on palpation due to subcutaneous gas)",
          "Skin over swelling becomes dry, dark, and parchment-like",
          "Rapid toxemia, hypothermia, and death within 24–48 hours"
        ],
        diagnosticTests: "Muscle aspirate Gram stain (Gram-positive rods with spores), fluorescent antibody test.",
        precautions: [
          "Immediate high-dose Penicillin and NSAIDs under veterinary guidance.",
          "Do NOT make incisions into crepitant swelling without strict veterinary guidance (spores contaminate soil for years).",
          "Carcasses of dead animals must be deeply buried with quicklime or incinerated."
        ],
        vaccination: "Annual vaccination with BQ vaccine in young stock (6 months to 2 years) prior to monsoon season.",
        helpline: "Emergency vet call required (1962)."
      },
      te: {
        name: "జబ్బవాపు వ్యాధి (Black Quarter / BQ)",
        severity: "అత్యంత ప్రమాదకరం / ప్రాణాంతకం",
        transmission: "మట్టిలోని క్లాస్ట్రీడియం బ్యాక్టీరియా విత్తనాల (spores) ద్వారా మేతతో పాటు లోపలికి ప్రవేశిస్తుంది.",
        symptoms: [
          "తీవ్రమైన జ్వరం (104–106°F)",
          "ముందు లేదా వెనుక కాలు వాచి విపరీతమైన కుంటితనం రావడం",
          "భుజం లేదా తొడ కండరాలపై వేడిగా ఉండే వాపు రావడం, దానిని తాకినప్పుడు లోపల గ్యాస్ వల్ల 'కిరకిర' శబ్దం రావడం (Crepitation)",
          "తరువాత వాచిన చర్మం నల్లబడి చల్లగా మారడం",
          "24-48 గంటల్లో విషం రక్తం లోకి చేరి పశువు మరణించడం"
        ],
        diagnosticTests: "కండరాల ద్రవంతో గ్రామ్ స్టెయిన్ పరీక్ష.",
        precautions: [
          "ప్రారంభ దశలోనే భారీ మోతాదులో పెన్సిలిన్ యాంటీబయాటిక్స్ ఇవ్వాలి.",
          "వాపును కోయరాదు, ఎందుకంటే బ్యాక్టీరియా నేలలో ఏళ్ల తరబడి నిల్వ ఉంటుంది.",
          "మరణించిన పశువును లోతైన గుంతలో సున్నం వేసి పూడ్చాలి."
        ],
        vaccination: "ప్రతి సంవత్సరం వర్షాకాలం ముందు 6 నెలల నుండి 2 ఏళ్ల వయసు గల గేదెలకు జబ్బవాపు టీకా వేయించాలి.",
        helpline: "తక్షణ వైద్య సాయం కొరకు 1962 నంబర్‌ను సంప్రదించండి."
      },
      hi: {
        name: "लंगड़ा बुखार / काला बावा (Black Quarter / BQ)",
        severity: "अत्यधिक गंभीर / जानलेवा",
        transmission: "मिट्टी में मौजूद जीवाणु के बीजाणु चारे के साथ शरीर में प्रवेश करते हैं।",
        symptoms: [
          "तेज बुखार और अचानक एक पैर में गंभीर लंगड़ापन",
          "कंधे या जांघ की भारी मांसपेशियों में सूजन",
          "सूजन को दबाने पर गैस के कारण 'चर्र-चर्र' की आवाज आना (क्रेपिटेशन)",
          "बाद में सूजन वाली त्वचा ठंडी और काली पड़ जाना",
          "24 से 48 घंटे में मृत्यु का खतरा"
        ],
        diagnosticTests: "मांसपेशियों के द्रव की लैब जांच।",
        precautions: [
          "तत्काल पेनिसिलिन एंटीबायोटिक पशु चिकित्सक से लगवाएं।",
          "सूजन पर चीरा न लगाएं ताकि मिट्टी दूषित न हो।",
          "मृत पशु को चूना डालकर गहरा दफनाएं।"
        ],
        vaccination: "हर वर्ष बरसात से पहले BQ का टीका अवश्य लगवाएं।",
        helpline: "1962 हेल्पलाइन पर तुरंत संपर्क करें।"
      }
    },

    bloat: {
      en: {
        name: "Ruminal Tympany / Bloat (కడుపుబ్బరం / अफरा)",
        severity: "Urgent Medical Emergency",
        transmission: "Non-infectious metabolic disorder: Excessive trapped gas in rumen from lush legumes (berseem, lucerne) or sudden carbohydrate gorging.",
        symptoms: [
          "Massive drum-like distension of the LEFT flank (paralumbar fossa)",
          "Restlessness, kicking at belly, frequent urination, anxiety",
          "Severe respiratory distress: Open-mouth panting, grunting, extended neck",
          "Cyanosis (bluish tongue and mucous membranes) due to diaphragm compression",
          "Sudden death from suffocation if ruminal pressure is not promptly relieved"
        ],
        diagnosticTests: "Clinical palpation and percussion of left flank (drum sound).",
        precautions: [
          "Keep buffalo standing with front feet elevated on a mound/slope to relieve diaphragm pressure.",
          "Place a wooden bit crosswise in mouth tied behind ears to stimulate chewing and eructation (belching).",
          "Administer anti-foaming carminative: 200–300 ml mustard oil / vegetable oil or Turpentine oil (30 ml in 250 ml edible oil) or Simethicone oral suspension.",
          "Do NOT drench a lying animal to avoid fatal aspiration pneumonia.",
          "In acute life-threatening bloat with suffocation, a veterinarian must puncture the left flank with a Trocar and Cannula or wide-bore needle."
        ],
        vaccination: "Avoid giving wet, dewy green legumes in excess; always mix dry straw with lush greens.",
        helpline: "Emergency trocarization requires field veterinarian (Call 1962 immediately)."
      },
      te: {
        name: "కడుపుబ్బరం / బ్లోట్ (Ruminal Tympany / Bloat)",
        severity: "అత్యవసర ప్రాణాపాయ పరిస్థితి",
        transmission: "పచ్చి పప్పుజాతి మేత (ల్యూసర్న్, బెర్సీమ్) ఎక్కువగా తిన్నప్పుడు లేదా ఆహారం అకస్మాత్తుగా మారినప్పుడు కడుపులో వాయువులు నిండిపోతాయి.",
        symptoms: [
          "గేదె ఎడమ వైపు కడుపు డప్పులా బాగా ఉబ్బిపోవడం",
          "తీవ్రమైన ఆందోళన, పదే పదే మూత్రం పోయడం, కడుపును కాళ్ళతో తన్నుకోవడం",
          "ఊపిరి అందక నోరు తెరిచి ఆయాసపడటం",
          "సకాలంలో గాలి బయటకు పోకపోతే గుండె మరియు ఊపిరితిత్తులపై ఒత్తిడి పెరిగి మరణించడం"
        ],
        diagnosticTests: "ఎడమ వైపు కడుపుపై తట్టినప్పుడు డప్పు శబ్దం రావడం.",
        precautions: [
          "గేదె ముందు కాళ్లను ఎత్తైన ప్రదేశంలో ఉంచి నిలబెట్టండి (ఊపిరి బాగా ఆడుతుంది).",
          "నోటిలో అడ్డంగా ఒక కర్రను కట్టి ఉంచితే నెమరువేసి తేన్పులు రావడం ద్వారా గాలి పోతుంది.",
          "ప్రథమ చికిత్సగా 200-300 మి.లీ వేరుశెనగ నూనె లేదా ఆవనూనె తాగించండి.",
          "పడిపోయిన గేదెకు బలవంతంగా మందులు తాగించవద్దు (ఊపిరితిత్తుల్లోకి వెళ్లే ప్రమాదం ఉంది).",
          "తీవ్రమైన పరిస్థితిలో వెటర్నరీ డాక్టర్ ట్రోకార్ మరియు కాన్యులా ద్వారా ఎడమ వైపు కడుపుకు రంధ్రం చేసి గాలి తీయాలి."
        ],
        vaccination: "తేమగా ఉన్న పచ్చిమేతను నేరుగా వేయకుండా, ఎండుగడ్డితో కలిపి వేయాలి.",
        helpline: "వెంటనే 1962 టోల్ ఫ్రీ నంబర్‌కు కాల్ చేసి అంబులెన్స్‌ను రప్పించండి."
      },
      hi: {
        name: "अफरा रोग / ब्लोट (Ruminal Tympany / Bloat)",
        severity: "आपातकालीन स्थिति",
        transmission: "अधिक रसीला हरा चारा या अनाज खाने से पेट में गैस भर जाती है।",
        symptoms: [
          "बाईं कोख (Left Flank) का ढोल की तरह फूल जाना",
          "बेचैनी, पेट पर लात मारना, जीभ बाहर निकालकर हांफना",
          "सांस लेने में भारी तकलीफ और दम घुटना"
        ],
        diagnosticTests: "बाईं कोख को थपथपाने पर ढोल जैसी आवाज आना।",
        precautions: [
          "भैंस को आगे से ऊंचे स्थान पर खड़ा रखें।",
          "मुंह में लकड़ी की खपच्ची बांधें ताकि जुगाली से डकार आए।",
          "प्राथमिक उपचार में 200-300 मिली सरसों या मीठा तेल पिलाएं।",
          "लेटे हुए पशु को जबरदस्ती दवा न पिलाएं।",
          "गंभीर स्थिति में पशु चिकित्सक द्वारा ट्रोकार एवं कैन्युला से बाईं कोख में सुराख कर गैस निकाली जाती है।"
        ],
        vaccination: "हरे चारे के साथ सूखा भूसा मिलाकर दें।",
        helpline: "आपातकाल में तुरंत 1962 पर कॉल करें।"
      }
    },

    surra: {
      en: {
        name: "Surra / Trypanosomiasis (सर्रा / ట్రిపనోసోమియాసిస్)",
        severity: "High / Chronic Wasting & Acute Episodes",
        transmission: "Trypanosoma evansi protozoa transmitted by biting horseflies (Tabanus) and stable flies (Stomoxys).",
        symptoms: [
          "Intermittent fluctuating fever spikes (103–105°F)",
          "Progressive severe anemia (pale mucous membranes) and rapid weight loss",
          "Edema of lower abdomen, brisket, sheath, and legs",
          "Petechial hemorrhages on third eyelid and conjunctiva",
          "Nervous signs in acute buffalo cases: Circling, head pressing, blindness, bellowing, convulsions"
        ],
        diagnosticTests: "Wet blood film (motile flagellates) and Giemsa-stained peripheral blood smear.",
        precautions: [
          "Treat with Quinapyramine sulfate/chloride or Diminazene aceturate strictly under veterinary supervision.",
          "Rigorous biting fly control around sheds using fly repellents and nets.",
          "Supportive hematinics (iron, copper, cobalt, vitamins) to combat anemia."
        ],
        vaccination: "Vector control and prophylactic Quinapyramine prosalt before fly season.",
        helpline: "Contact vet hospital (1962)."
      },
      te: {
        name: "సర్రా వ్యాధి (Surra / Trypanosomiasis)",
        severity: "అధికం / తీవ్ర క్షీణత",
        transmission: "పెద్ద గుఱ్ఱపు ఈగలు (Tabanus flies) కుట్టడం ద్వారా రక్తం లోకి పరాన్నజీవులు ప్రవేశిస్తాయి.",
        symptoms: [
          "వచ్చిపోయే జ్వరం (విడివిడిగా వచ్చే తీవ్ర జ్వరం)",
          "రక్తహీనత, కళ్ళు పాలిపోవడం, మరియు పశువు బక్కచిక్కిపోవడం",
          "కాళ్ళు, పొత్తికడుపు మరియు గొంతు కింద నీరు చేరి వాపు రావడం",
          "తీవ్రమైన స్థితిలో పిచ్చిపట్టినట్లు గుండ్రంగా తిరగడం, గోడలకు తల బాదుకోవడం, కళ్ళు కనిపించకపోవడం"
        ],
        diagnosticTests: "తాజా రక్తపు పూత (Blood smear) పరీక్ష ద్వారా పరాన్నజీవులను గుర్తించడం.",
        precautions: [
          "వెటర్నరీ డాక్టర్ పర్యవేక్షణలో క్వినాపైరమైన్ లేదా డైమినాజీన్ ఇంజెక్షన్లు ఇప్పించాలి.",
          "ఈగలు కుట్టకుండా కొట్టంలో వేపనూనె లేదా క్రిమిసంహారక స్ప్రేలు వాడాలి.",
          "రక్తం పెరగడానికి ఐరన్ మరియు విటమిన్ టానిక్లు ఇవ్వాలి."
        ],
        vaccination: "ఈగల నియంత్రణే ముఖ్య రక్షణ.",
        helpline: "1962 హెల్ప్‌లైన్‌ను సంప్రదించండి."
      },
      hi: {
        name: "सर्रा रोग (Surra / Trypanosomiasis)",
        severity: "उच्च / दीर्घकालिक कमजोरी",
        transmission: "बड़ी डास (मक्खियों) के काटने से रक्त में परजीवी फैलता है।",
        symptoms: [
          "रुक-रुक कर तेज बुखार आना",
          "गंभीर खून की कमी (पीलापन) और तेजी से वजन घटना",
          "पैरों और पेट के निचले हिस्से में पानी की सूजन",
          "गंभीर मामलों में चक्कर काटना, दीवारों से सिर टकराना व अंधापन"
        ],
        diagnosticTests: "ब्लड स्मीयर जांच।",
        precautions: [
          "पशु चिकित्सक की देखरेख में क्विनापिरामीन इंजेक्शन लगवाएं।",
          "मक्खियों की रोकथाम हेतु कीटनाशक का छिड़काव करें।",
          "आयरन और लिवर टॉनिक दें।"
        ],
        vaccination: "मक्खी नियंत्रण मुख्य बचाव है।",
        helpline: "1962 पर कॉल करें।"
      }
    },

    healthy: {
      en: {
        name: "Healthy Buffalo Assessment & Baseline Management",
        severity: "Healthy Baseline (Optimal Condition)",
        transmission: "N/A",
        symptoms: [
          "Normal rectal temperature: 100.0–102.0°F (37.8–38.9°C)",
          "Resting heart rate: 40–60 beats per minute",
          "Respiratory rate: 16–30 breaths per minute",
          "Rumen contractions: 2–3 per 2 minutes (audible in left paralumbar fossa)",
          "Active rumination: 40–60 chews per cud bolus, 6–8 hours daily",
          "Bright alert eyes, cool moist muzzle with water droplets, smooth shiny hair coat",
          "Firm, well-formed manure and clear straw-colored urine"
        ],
        diagnosticTests: "Routine bi-annual fecal examination for parasites, monthly California Mastitis Test (CMT).",
        precautions: [
          "Feeding Ration: 30–40 kg green fodder (Napier, SSG, Maize), 4–6 kg dry straw, 2–3 kg concentrate mixture.",
          "Add 50 g chelated mineral mixture and 30 g common salt daily.",
          "Provide 75–100 liters of clean, fresh drinking water daily.",
          "Wallowing or water splashing twice daily during hot summer months to prevent heat stress.",
          "Deworming schedule: Administer broad-spectrum anthelmintics (Albendazole, Fenbendazole, Oxyclozanide) every 3–4 months.",
          "Vaccination calendar: FMD every 6 months, HS & BQ annually before monsoon (May–June)."
        ],
        vaccination: "Adhere to the national livestock vaccination schedule.",
        helpline: "Maintain routine wellness checkups with your local veterinary dispensary."
      },
      te: {
        name: "ఆరోగ్యకరమైన గేదె లక్షణాలు & సంరక్షణ సూత్రాలు",
        severity: "ఆరోగ్యకరమైన స్థితి (సాధారణం)",
        transmission: "వర్తించదు",
        symptoms: [
          "సాధారణ శరీర ఉష్ణోగ్రత: 100.0 - 102.0°F",
          "గుండె వేగం: నిమిషానికి 40 - 60 సార్లు",
          "శ్వాస వేగం: నిమిషానికి 16 - 30 సార్లు",
          "నెమరువేత: రోజుకు 6-8 గంటలు, ముద్దకు 40-60 నమలడం",
          "చురుకైన కళ్ళు, తడిగా ఉండే చల్లని ముక్కు, మరియు మెరిసే చర్మం",
          "సరైన పేడ మరియు తేటగా ఉండే మూత్రం"
        ],
        diagnosticTests: "ప్రతి 3-4 నెలలకు మల పరీక్ష (పేడ పరీక్ష) మరియు నెలనెలా CMT పొదుగు పరీక్ష.",
        precautions: [
          "ఆహార ప్రణాళిక: 30-40 కిలోల పచ్చిగడ్డి, 4-6 కిలోల ఎండుగడ్డి, 2-3 కిలోల దాణా.",
          "రోజూ 50 గ్రాముల ఖనిజ లవణాల మిశ్రమం (Mineral Mixture) మరియు 30 గ్రాముల ఉప్పు తప్పనిసరిగా ఇవ్వండి.",
          "రోజుకు 80-100 లీటర్ల స్వచ్ఛమైన త్రాగునీరు అందించండి.",
          "ఎండాకాలంలో వేడి తగలకుండా రోజుకు 2 సార్లు నీటితో కడగండి లేదా ఈత కొట్టించండి.",
          "ప్రతి 3-4 నెలలకు నట్టల మందు (Deworming) తప్పనిసరిగా త్రాగించండి.",
          "టీకాలు: గాలికుంటు (FMD) ప్రతి 6 నెలలకు, గొంతువాపు (HS) వర్షాకాలం ముందు వేయించండి."
        ],
        vaccination: "సకాలంలో అన్ని రకాల వ్యాక్సిన్లను వేయించండి.",
        helpline: "సాధారణ సలహాల కొరకు స్థానిక పశువైద్యశాలను సంప్రదించండి."
      },
      hi: {
        name: "स्वस्थ भैंस के लक्षण एवं दैनिक देखभाल",
        severity: "सामान्य / स्वस्थ स्थिति",
        transmission: "लागू नहीं",
        symptoms: [
          "सामान्य शारीरिक तापमान: 100.0–102.0°F",
          "श्वसन दर: 16–30 बार प्रति मिनट",
          "नियमित जुगाली: दिन में 6-8 घंटे सक्रिय जुगाली",
          "सक्रिय आंखें, नम व ठंडी थूथन और चमकदार त्वचा",
          "सामान्य गोबर और पेशाब"
        ],
        diagnosticTests: "हर 3-4 माह में गोबर जांच और नियमित CMT टेस्ट।",
        precautions: [
          "दैनिक आहार: 30-40 किग्रा हरा चारा, 4-6 किग्रा सूखा भूसा, 2-3 किग्रा संतुलित दाना।",
          "रोजाना 50 ग्राम मिनरल मिक्सचर और 30 ग्राम सादा नमक अवश्य दें।",
          "प्रतिदिन 80-100 लीटर स्वच्छ ताजा पानी उपलब्ध कराएं।",
          "गर्मियों में लू से बचाव के लिए दिन में दो बार पानी से नहलाएं।",
          "हर 3-4 माह में पेट के कीड़ों की दवा (डिवर्मिंग) दें।",
          "समय पर नियमित टीकाकरण (FMD, HS, BQ) करवाएं।"
        ],
        vaccination: "टीकाकरण समय सारिणी का पालन करें।",
        helpline: "स्थानीय पशु चिकित्सालय से संपर्क बनाए रखें।"
      }
    },

    differential: {
      en: {
        name: "Multiple Disease Diagnosis (Differential Assessment Required)",
        severity: "High / Diagnostic Uncertainty",
        transmission: "Mixed or overlapping contagious/environmental pathogens.",
        symptoms: [
          "Conflicting symptoms (e.g. skin lesions combined with severe oral drooling, or lameness with respiratory signs)",
          "Possible co-infection (e.g. FMD complicated with secondary Mastitis or Blood Parasites)",
          "Requires immediate differential laboratory workup to distinguish FMD, Vesicular Stomatitis, LSD, HS, or Bovine Viral Diarrhea"
        ],
        diagnosticTests: "Comprehensive Panel: Blood EDTA for PCR & CBC, Serum for ELISA, Lesion Swabs for viral isolation, Milk CMT & Culture.",
        precautions: [
          "Strict isolation in quarantine stall pending diagnostic laboratory results.",
          "Disinfect all premises with broad-spectrum virucidal and bactericidal solutions.",
          "Isolate from all other livestock species on the farm.",
          "Record daily rectal temperature twice daily (morning and evening)."
        ],
        vaccination: "Follow targeted vaccination once specific pathogen is confirmed.",
        helpline: "Immediate laboratory differential panel via 1962 mobile ambulance."
      },
      te: {
        name: "బహుళ వ్యాధి నిర్ధారణ (Multiple Disease Diagnosis)",
        severity: "అధికం / ప్రత్యేక ల్యాబ్ పరీక్షల అవసరం",
        transmission: "వివిధ రకాల వ్యాధి కారకాలు ఒకేసారి సోకడం లేదా లక్షణాలు పరస్పరం కలిసి ఉండటం.",
        symptoms: [
          "వివిధ వ్యాధుల లక్షణాలు కలిసి కనిపించడం (ఉదాహరణకు నోటిలో బొబ్బలతో పాటు తీవ్ర గొంతు వాపు, లేదా చర్మంపై గడ్డలతో పాటు పొదుగు వాపు)",
          "గాలికుంటు, లంపీ స్కిన్, లేదా బ్లడ్ పారాసైట్ వ్యాధుల మధ్య తేడాను గుర్తించడానికి ప్రత్యేక పరీక్షలు అవసరం"
        ],
        diagnosticTests: "రక్త పరీక్ష, సీరం ఎలైసా, పుండ్ల నమూనాల RT-PCR, మరియు పాల కల్చర్ పరీక్ష.",
        precautions: [
          "ఖచ్చితమైన రోగ నిర్ధారణ జరిగే వరకు పశువును ప్రత్యేక క్వారంటైన్‌లో ఉంచండి.",
          "మేత తొట్లు మరియు కొట్టాన్ని క్రిమిసంహారకాలతో శుభ్రం చేయండి.",
          "రోజూ ఉదయం, సాయంత్రం జ్వరాన్ని కొలవండి."
        ],
        vaccination: "ల్యాబ్ రిపోర్ట్ వచ్చిన తర్వాత నిర్దిష్ట వ్యాక్సిన్ వేయించాలి.",
        helpline: "వెంటనే 1962 మొబైల్ వెటర్నరీ ల్యాబ్‌ను రప్పించండి."
      },
      hi: {
        name: "एकाधिक विभेदक रोग निदान (Multiple Disease Diagnosis)",
        severity: "उच्च / विस्तृत जांच आवश्यक",
        transmission: "मिश्रित संक्रमण या परस्पर विरोधी लक्षण।",
        symptoms: [
          "एक से अधिक रोगों के लक्षण एक साथ दिखना (जैसे मुंह में छाले के साथ गले की सूजन, या त्वचा पर गांठों के साथ थनैला)",
          "सटीक पहचान हेतु प्रयोगशाला विभेदक पैनल की आवश्यकता"
        ],
        diagnosticTests: "रक्त पीसीआर, सीरम एलाइजा, घाव के फाहे की जांच व दूध कल्चर।",
        precautions: [
          "पशु को तुरंत अलग बाड़े में रखें जब तक जांच रिपोर्ट न आ जाए।",
          "बाड़े को कीटाणुनाशक से साफ करें।",
          "सुबह-शाम तापमान रिकॉर्ड करें।"
        ],
        vaccination: "रोग की पुष्टि होने पर लक्षित टीका लगवाएं।",
        helpline: "तुरंत 1962 पर कॉल करें।"
      }
    }
  },

  // --------------------------------------------------------------------------
  // TOPIC MATCHER INTEL: PRECAUTIONS, VACCINATIONS, NUTRITION, EMERGENCY
  // --------------------------------------------------------------------------
  general: {
    precautions: {
      en: {
        title: "🛡️ Comprehensive Buffalo Biosecurity & Precautionary Protocols",
        content: `**1. Chemical Disinfection Standards**:
• **FMD Prevention**: 4% Sodium Carbonate (washing soda, 400g in 10L water) or 1% Citric Acid for walls, floors, and equipment.
• **Wound & Mouth Care**: 1% Potassium Permanganate (KMnO4 / pink water) wash for foot and mouth blisters.
• **Teat Disinfection**: 0.5% Povidone-Iodine solution post-milking teat dip for 30 seconds.
• **Hoof Rot / Footbaths**: 5–10% Copper Sulfate solution footbath at shed entrance.

**2. Strict Quarantine Measures**:
• Isolate newly purchased animals for a minimum of 21 days before herd introduction.
• Isolate sick animals at least 50 meters downwind from healthy animals.

**3. Vector & Insect Control (LSD & Surra Prevention)**:
• Spray sheds with 2% Neem oil or 0.1% Cypermethrin spray twice weekly.
• Eliminate stagnant water puddles and manure heaps around the barn to destroy fly and mosquito breeding sites.

**4. Milking Hygiene**:
• Always milk healthy cows first, and mastitic/infected quarters strictly LAST.
• Keep animals standing for 45 minutes after milking.`
      },
      te: {
        title: "🛡️ గేదెల సంరక్షణ & పూర్తి బయో-సెక్యూరిటీ జాగ్రత్తలు",
        content: `**1. క్రిమిసంహారక రసాయనాల వాడకం**:
• **గాలికుంటు నివారణ**: 4% సోడా ద్రావణం (10 లీటర్ల నీటిలో 400 గ్రాముల వాషింగ్ సోడా) తో కొట్టం నేలలు, గోడలు కడగాలి.
• **గాయాలు & నోటి శుభ్రత**: 1% పొటాషియం పర్మాంగనేట్ (గులాబీ రంగు నీరు) తో నోటి, కాళ్ళ పుండ్లను కడగాలి.
• **పొదుగు శుభ్రత**: పాలు పితికాక 0.5% పోవిడోన్-అయోడిన్ ద్రావణంలో చనులను ముంచాలి (Teat Dip).
• **గిట్టల పుండ్లు**: 5% మైలుతుత్తం (కాపర్ సల్ఫేట్) నీటిలో నడిపించాలి.

**2. క్వారంటైన్ నిబంధనలు**:
• కొత్తగా కొన్న పశువులను కనీసం 21 రోజుల పాటు వేరుగా ఉంచి పరిశీలించాలి.
• జబ్బు పడిన పశువును వెంటనే ఇతర పశువుల నుండి 50 మీటర్ల దూరంలో ఉంచాలి.

**3. ఈగలు, దోమల నివారణ (లంపీ & సర్రా రక్షణ)**:
• వేపనూనె లేదా క్రిమిసంహారక స్ప్రేలను వారానికి 2 సార్లు కొట్టం చుట్టూ పిచికారీ చేయాలి.
• పశువుల పాక చుట్టూ మురుగు నీరు, పెంటకుప్పలు నిల్వ ఉండకుండా చూడాలి.

**4. పాలు పితికే జాగ్రత్తలు**:
• ఎల్లప్పుడూ ఆరోగ్యకరమైన గేదెలను మొదట పితికి, జబ్బు పడిన చనులను చివరగా పితకాలి.`
      },
      hi: {
        title: "🛡️ भैंस पालन जैव-सुरक्षा एवं सावधानियां",
        content: `**1. रासायनिक विसंक्रमण**:
• **FMD से बचाव**: 4% कपड़े धोने का सोडा (10 लीटर पानी में 400 ग्राम) फर्श और दीवारों पर डालें।
• **घाव व छाले**: 1% लाल दवा (पोटाश) के पानी से धोएं।
• **थनैला से बचाव**: दूध दुहने के बाद 0.5% पोवीडोन आयोडीन में थन डुबोएं।
• **खुरों के घाव**: 5% नीला थोथा (कॉपर सल्फेट) के घोल का फुटबाथ दें।

**2. क्वारंटीन**:
• नए पशु को 21 दिनों तक अलग रखें।
• बीमार पशु को तुरंत स्वस्थ झुंड से दूर करें।

**3. कीट नियंत्रण**:
• नीम के तेल या साइपरमेथ्रिन का छिड़काव करके मक्खी-मच्छर भगाएं।
• गोबर के ढेर और गंदा पानी बाड़े से दूर रखें।

**4. दुग्ध स्वच्छता**:
• स्वस्थ पशुओं का दूध पहले और बीमार थन का दूध अंत में दुहें।`
      }
    },

    vaccination: {
      en: {
        title: "💉 Master Livestock Vaccination Schedule for Buffaloes",
        content: `| Disease | Recommended Vaccine | Primary Age | Booster / Frequency | Ideal Timing |
| :--- | :--- | :--- | :--- | :--- |
| **Foot-and-Mouth (FMD)** | Inactivated Polyvalent | 3–4 months | Bi-annually (Every 6 months) | March–April & Sept–Oct |
| **Hemorrhagic Septicemia (HS)** | Alum / Oil Adjuvant | 6 months | Annually | May–June (Pre-monsoon) |
| **Black Quarter (BQ)** | Formalin-killed Anaculture | 6 months | Annually | May–June (Pre-monsoon) |
| **Lumpy Skin Disease (LSD)** | Goat Pox Vaccine (3 ml SC) | 4 months | Annually | February–March |
| **Anthrax** | Live Spore Vaccine | 4 months | Annually in endemic zones | Pre-monsoon |
| **Deworming Protocol** | Broad-spectrum (Albendazole/Fenbendazole) | All ages | Every 3–4 months | Seasonal rotation |

*Always vaccinate only healthy animals. Never vaccinate during acute fever or late pregnancy.*`
      },
      te: {
        title: "💉 గేదెల పూర్తి వ్యాక్సినేషన్ & టీకాల క్యాలెండర్",
        content: `| వ్యాధి పేరు | టీకా రకం | మొదట వేసే వయస్సు | కాలపరిమితి | వేయవలసిన సమయం |
| :--- | :--- | :--- | :--- | :--- |
| **గాలికుంటు (FMD)** | పాలివాలెంట్ వ్యాక్సిన్ | 3-4 నెలలు | ప్రతి 6 నెలలకు ఒకసారి | మార్చి-ఏప్రిల్ & సెప్టెంబర్-అక్టోబర్ |
| **గొంతువాపు (HS)** | హెచ్.ఎస్. వ్యాక్సిన్ | 6 నెలలు | సంవత్సరానికి ఒకసారి | మే - జూన్ (వర్షాకాలం ముందు) |
| **జబ్బవాపు (BQ)** | బి.క్యూ. వ్యాక్సిన్ | 6 నెలలు | సంవత్సరానికి ఒకసారి | మే - జూన్ (వర్షాకాలం ముందు) |
| **లంపీ స్కిన్ (LSD)** | గోట్ పాక్స్ వ్యాక్సిన్ | 4 నెలలు | సంవత్సరానికి ఒకసారి | ఫిబ్రవరి - మార్చి |
| **నట్టల నివారణ** | అల్బెండజోల్ / ఫెన్‌బెండజోల్ | అన్ని వయసులకు | ప్రతి 3-4 నెలలకు | ఋతువుల మార్పు సమయంలో |

*ఆరోగ్యంగా ఉన్న పశువులకు మాత్రమే టీకాలు వేయించాలి. జ్వరం ఉన్నప్పుడు లేదా ఈనే చివరి నెలల్లో టీకాలు వేయరాదు.*`
      },
      hi: {
        title: "💉 भैंसों का संपूर्ण टीकाकरण कैलेंडर",
        content: `| रोग | टीका | प्रारंभिक उम्र | आवृत्ति | सही समय |
| :--- | :--- | :--- | :--- | :--- |
| **खुरपका-मुंहपका (FMD)** | पॉलीवेलेंट टीका | 3-4 माह | हर 6 महीने में | मार्च-अप्रैल एवं सितंबर-अक्टूबर |
| **गलघोंटू (HS)** | एचएस टीका | 6 माह | प्रतिवर्ष | मई-जून (मानसून से पहले) |
| **लंगड़ा बुखार (BQ)** | बीक्यू टीका | 6 माह | प्रतिवर्ष | मई-जून (मानसून से पहले) |
| **लम्पी स्किन (LSD)** | गोट पॉक्स टीका | 4 माह | प्रतिवर्ष | फरवरी-मार्च |
| **पेट के कीड़े (डिवर्मिंग)** | एलबेंडाजोल / फेनबेंडाजोल | सभी उम्र | हर 3-4 माह में | मौसम परिवर्तन पर |

*केवल स्वस्थ पशुओं का ही टीकाकरण कराएं। तेज बुखार में टीका न लगवाएं।*`
      }
    },

    nutrition: {
      en: {
        title: "🌾 Scientific Buffalo Feeding & Nutritional Guidelines",
        content: `**Daily Nutritional Requirements for Milking Buffalo (10–12 Liters Yield)**:
• **Green Fodder**: 30–40 kg (mix of cereal like Napier/Maize and leguminous like Berseem/Cowpea).
• **Dry Fodder**: 4–6 kg (paddy straw, wheat bhusa, or sorghum stover).
• **Concentrate Feed**: 2 kg maintenance + 400g per liter of milk produced (approx. 4–5 kg total).
• **Mineral Mixture**: 50 g chelated mineral mixture daily (prevents reproductive issues & mastitis).
• **Common Salt**: 30–50 g daily in feed.
• **Clean Drinking Water**: 80–100 liters per day free access.

**Seasonal Nutrition**:
In hot summers, provide bypass fat (100–150g) and baking soda (30g) to prevent ruminal acidosis and sustain milk fat percentage.`
      },
      te: {
        title: "🌾 పాడి గేదెల పోషకాహారం & మేత నిర్వహణ",
        content: `**రోజువారీ సమతుల్య ఆహారం (10-12 లీటర్ల పాలిచ్చే గేదెకు)**:
• **పచ్చిమేత**: 30-40 కిలోలు (సూపర్ నేపియర్, మొక్కజొన్న, లేదా జొన్నతో పాటు ఉలవ/పిల్లిపెసర వంటి పప్పుజాతి మేత).
• **ఎండుమేత**: 4-6 కిలోలు (వరి గడ్డి లేదా జొన్న చొప్ప).
• **దాణా**: గేదె నిర్వహణకు 2 కిలోలు + ఇచ్చే ప్రతి లీటరు పాలకు 400 గ్రాములు (మొత్తం సుమారు 4-5 కిలోలు).
• **ఖనిజ లవణాల మిశ్రమం**: రోజుకు 50 గ్రాముల మినరల్ మిక్చర్ తప్పనిసరి (కాల్షియం, ఫాస్ఫరస్ లోపాలు రాకుండా).
• **ఉప్పు**: రోజుకు 30-40 గ్రాముల అయోడైజ్డ్ ఉప్పు.
• **త్రాగునీరు**: రోజుకు 80-100 లీటర్ల శుభ్రమైన మంచినీరు.

ఎండాకాలంలో జీర్ణవ్యవస్థ సరిగ్గా ఉండటానికి మరియు వెన్న శాతం తగ్గకుండా రోజుకు 30 గ్రాముల సోడా ఉప్పు మరియు బైపాస్ ఫ్యాట్ ఇవ్వాలి.`
      },
      hi: {
        title: "🌾 दुधारू भैंस का संतुलित आहार व पोषण प्रबंधन",
        content: `**दैनिक आहार चार्ट (10-12 लीटर दूध देने वाली भैंस)**:
• **हरा चारा**: 30-40 किग्रा (नेपियर, मक्का, बरसीम)।
• **सूखा भूसा**: 4-6 किग्रा (गेहूं का भूसा या पुआल)।
• **संतुलित दाना**: 2 किग्रा शरीर पोषण + 400 ग्राम प्रति लीटर दूध (कुल 4-5 किग्रा)।
• **मिनरल मिक्सचर**: रोजाना 50 ग्राम (रोग प्रतिरोधक क्षमता व बांझपन से बचाव हेतु)।
• **नमक**: 30-50 ग्राम रोजाना।
• **स्वच्छ पानी**: 80-100 लीटर प्रतिदिन।

गर्मियों में दूध का फैट बनाए रखने हेतु 30 ग्राम मीठा सोडा (Baking Soda) दाने में मिलाएं।`
      }
    },

    emergency: {
      en: {
        title: "🚨 24/7 Veterinary Emergency Helpline & First Aid Protocols",
        content: `**📞 Andhra Pradesh 24/7 Mobile Veterinary Ambulance**: **1962** (Toll-Free)

**When to Seek Immediate Emergency Attention**:
1. **Peracute High Fever (> 104°F / 40°C)** with heavy shivering and recumbency.
2. **Acute Severe Bloat**: Left flank ballooning, respiratory distress, and collapse.
3. **Severe Choking**: Sudden profuse salivation, neck extension, and panic while swallowing.
4. **Vaginal/Uterine Prolapse**: Keep prolapsed mass clean, moist, wrapped in a clean wet sheet, and elevate hindquarters.
5. **Dystocia (Difficult Calving)**: Calf feet or head visible for > 2 hours without progress.
6. **Severe Bleeding Wounds**: Apply direct pressure with clean sterile gauze and bandage firmly.

Keep emergency numbers of your local Mandal Veterinary Hospital and village animal husbandry assistant readily available.`
      },
      te: {
        title: "🚨 24/7 అత్యవసర పశువైద్య హెల్ప్‌లైన్ & ప్రథమ చికిత్స",
        content: `**📞 ఆంధ్రప్రదేశ్ ఉచిత మొబైల్ వెటర్నరీ అంబులెన్స్**: **1962** (టోల్ ఫ్రీ)

**ఈ పరిస్థితుల్లో వెంటనే డాక్టర్‌ను పిలవండి**:
1. **తీవ్రమైన అధిక జ్వరం (> 104°F)** తో పశువు వణుకుతూ కింద పడిపోవడం.
2. **తీవ్ర కడుపుబ్బరం (Bloat)**: ఎడమ వైపు కడుపు ఉబ్బి ఊపిరి ఆడకపోవడం.
3. **గొంతులో ఆహారం అడ్డం పడటం (Choking)**: నోటి నుండి తీవ్రంగా సొంగ కారడం, దగ్గు.
4. **మాయ పడకపోవడం లేదా గర్భాశయం బయటకు రావడం (Prolapse)**: బయటకు వచ్చిన భాగాన్ని తడి గుడ్డతో కప్పి మురికి చేరకుండా ఉంచండి.
5. **ఈనడంలో సమస్య (Dystocia)**: 2 గంటలైనా దూడ బయటకు రాకపోవడం.
6. **తీవ్రమైన రక్తస్రావం**: శుభ్రమైన గుడ్డతో గట్టిగా అదిమి పట్టి కట్టు కట్టండి.

మీ గ్రామ పశుసంవర్ధక సహాయకుడు (AHA) లేదా మండల పశువైద్యుడి నంబర్‌ను అందుబాటులో ఉంచుకోండి.`
      },
      hi: {
        title: "🚨 24/7 आपातकालीन पशु हेल्पलाइन एवं प्राथमिक उपचार",
        content: `**📞 टोल-फ्री पशु चिकित्सा एम्बुलेंस सेवा**: **1962**

**तत्काल डॉक्टर को बुलाने योग्य स्थितियां**:
1. **तेज बुखार (> 104°F)** और पशु का बैठ जाना।
2. **गंभीर अफरा (Bloat)**: बाईं कोख का फूलना और दम घुटना।
3. **गले में रुकावट (Choking)**: झागदार लार और बेचैनी।
4. **फूल/पाछा दिखना (Prolapse)**: बाहर निकले भाग को साफ गीले कपड़े से ढकें।
5. **कठिन प्रसव (Dystocia)**: 2 घंटे से अधिक समय तक प्रसव न होना।
6. **गंभीर रक्तस्राव**: साफ कपड़े से कसकर दबाएं।`
      }
    }
  }
};

// ============================================================================
// NATURAL LANGUAGE INTENT & TOPIC DETECTOR
// ============================================================================

function matchVeterinaryKnowledge(query, lang = 'en', caseData = null) {
  const q = query.toLowerCase();

  // 1. Diagnostic Tests Matching
  if (
    q.includes('cmt') || q.includes('california') || q.includes('somatic') || q.includes('cell count') ||
    q.includes('పరీక్ష') && (q.includes('పొదుగు') || q.includes('పాలు')) ||
    q.includes('टेस्ट') && (q.includes('थनैला') || q.includes('दूध') || q.includes('सीएमटी'))
  ) {
    return {
      title: KNOWLEDGE_BASE.tests.cmt[lang].title,
      body: KNOWLEDGE_BASE.tests.cmt[lang].content
    };
  }

  if (
    q.includes('rt-pcr') || q.includes('pcr') || q.includes('molecular') ||
    (q.includes('rt pcr') || q.includes('ఆర్టీ పీసీఆర్') || q.includes('पीसीआर'))
  ) {
    return {
      title: KNOWLEDGE_BASE.tests.rtpcr[lang].title,
      body: KNOWLEDGE_BASE.tests.rtpcr[lang].content
    };
  }

  if (
    q.includes('elisa') || q.includes('3abc') || q.includes('serolog') || q.includes('antibody') ||
    q.includes('ఎలైసా') || q.includes('एलाइजा')
  ) {
    return {
      title: KNOWLEDGE_BASE.tests.elisa[lang].title,
      body: KNOWLEDGE_BASE.tests.elisa[lang].content
    };
  }

  if (
    q.includes('blood smear') || q.includes('smear') || q.includes('blood test') || q.includes('giemsa') ||
    q.includes('రక్త పరీక్ష') || q.includes('రక్తపు పూత') || q.includes('खून की जांच') || q.includes('स्मीयर')
  ) {
    return {
      title: KNOWLEDGE_BASE.tests.bloodsmear[lang].title,
      body: KNOWLEDGE_BASE.tests.bloodsmear[lang].content
    };
  }

  // 2. Specific Diseases Matching
  // Foot and Mouth Disease
  if (
    q.includes('fmd') || q.includes('foot and mouth') || q.includes('foot-and-mouth') ||
    q.includes('blister') || q.includes('drool') || q.includes('salivat') || q.includes('smack') ||
    q.includes('గాలికుంటు') || q.includes('బొబ్బ') || q.includes('సొంగ') || q.includes('గిట్ట') ||
    q.includes('खुरपका') || q.includes('मुंहपका') || q.includes('छाले') || q.includes('लार')
  ) {
    const d = KNOWLEDGE_BASE.diseases.fmd[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Lumpy Skin Disease
  if (
    q.includes('lsd') || q.includes('lumpy') || q.includes('nodule') || q.includes('lump') ||
    q.includes('లంపీ') || q.includes('గడ్డ') || q.includes('కణుతు') || q.includes('చర్మం') ||
    q.includes('लंपी') || q.includes('गांठ') || q.includes('चकत्ते') || q.includes('त्वचा')
  ) {
    const d = KNOWLEDGE_BASE.diseases.lsd[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Mastitis
  if (
    q.includes('mastitis') || q.includes('udder') || q.includes('teat') || q.includes('bloody milk') || q.includes('clot') ||
    q.includes('పొదుగు') || q.includes('చను') || q.includes('రక్తపు పాలు') || q.includes('మస్టిటిస్') ||
    q.includes('थनैला') || q.includes('थन') || q.includes('दूध में खून') || q.includes('मैस्टाइटिस')
  ) {
    const d = KNOWLEDGE_BASE.diseases.mastitis[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Hemorrhagic Septicemia
  if (
    q.includes('hs') || q.includes('hemorrhagic') || q.includes('septicemia') || q.includes('throat') || q.includes('dewlap') || q.includes('snoring') ||
    q.includes('గొంతువాపు') || q.includes('గురక') || q.includes('హెచ్.ఎస్') ||
    q.includes('गलघोंटू') || q.includes('गले में सूजन') || q.includes('घरघराहट')
  ) {
    const d = KNOWLEDGE_BASE.diseases.hs[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Black Quarter
  if (
    q.includes('bq') || q.includes('black quarter') || q.includes('crepitation') || q.includes('crackle') || q.includes('shoulder swelling') ||
    q.includes('జబ్బవాపు') || q.includes('బి.క్యూ') || q.includes('కిరకిర') ||
    q.includes('लंगड़ा बुखार') || q.includes('काला बावा') || q.includes('चर्र-चर्र')
  ) {
    const d = KNOWLEDGE_BASE.diseases.bq[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Bloat
  if (
    q.includes('bloat') || q.includes('tympany') || q.includes('flank') || q.includes('drum') || q.includes('gas') ||
    q.includes('కడుపుబ్బరం') || q.includes('కడుపు ఉబ్బి') || q.includes('గ్యాస్') ||
    q.includes('अफरा') || q.includes('पेट फूलना') || q.includes('गैस')
  ) {
    const d = KNOWLEDGE_BASE.diseases.bloat[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Surra
  if (
    q.includes('surra') || q.includes('trypanosom') || q.includes('circling') ||
    q.includes('సర్రా') || q.includes('గుండ్రంగా తిరగడం') ||
    q.includes('सर्रा') || q.includes('चक्कर काटना')
  ) {
    const d = KNOWLEDGE_BASE.diseases.surra[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Multiple Disease / Differential
  if (
    q.includes('multiple') || q.includes('differential') || q.includes('overlap') ||
    q.includes('బహుళ') || q.includes('డిఫరెన్షియల్') || q.includes('మిశ్రమ') ||
    q.includes('एकाधिक') || q.includes('विभेदक') || q.includes('मिश्रित')
  ) {
    const d = KNOWLEDGE_BASE.diseases.differential[lang];
    return formatDiseaseResponse(d, lang);
  }

  // Healthy Buffalo Care
  if (
    q.includes('healthy') || q.includes('normal') || q.includes('vital') || q.includes('temperature') ||
    q.includes('ఆరోగ్య') || q.includes('సాధారణ') || q.includes('ఉష్ణోగ్రత') ||
    q.includes('स्वस्थ') || q.includes('सामान्य') || q.includes('तापमान')
  ) {
    const d = KNOWLEDGE_BASE.diseases.healthy[lang];
    return formatDiseaseResponse(d, lang);
  }

  // 3. General Topics: Precautions, Vaccinations, Nutrition, Emergency
  if (
    q.includes('precaution') || q.includes('prevent') || q.includes('biosecurity') || q.includes('disinfect') || q.includes('isolate') ||
    q.includes('జాగ్రత్త') || q.includes('నివారణ') || q.includes('పరిశుభ్రత') || q.includes('క్రిమిసంహారక') ||
    q.includes('सावधानी') || q.includes('बचाव') || q.includes('स्वच्छता') || q.includes('कीटाणुनाशक')
  ) {
    return {
      title: KNOWLEDGE_BASE.general.precautions[lang].title,
      body: KNOWLEDGE_BASE.general.precautions[lang].content
    };
  }

  if (
    q.includes('vaccin') || q.includes('schedule') || q.includes('shot') || q.includes('deworm') ||
    q.includes('టీకా') || q.includes('వ్యాక్సిన్') || q.includes('నట్టల') ||
    q.includes('टीका') || q.includes('वैक्सीन') || q.includes('डिवर्मिंग') || q.includes('कीड़े की दवा')
  ) {
    return {
      title: KNOWLEDGE_BASE.general.vaccination[lang].title,
      body: KNOWLEDGE_BASE.general.vaccination[lang].content
    };
  }

  if (
    q.includes('feed') || q.includes('diet') || q.includes('nutrit') || q.includes('fodder') || q.includes('mineral') || q.includes('water') ||
    q.includes('మేత') || q.includes('దాణా') || q.includes('పచ్చిగడ్డి') || q.includes('మినరల్') || q.includes('ఆహారం') ||
    q.includes('चारा') || q.includes('दाना') || q.includes('पोषण') || q.includes('मिनरल') || q.includes('आहार')
  ) {
    return {
      title: KNOWLEDGE_BASE.general.nutrition[lang].title,
      body: KNOWLEDGE_BASE.general.nutrition[lang].content
    };
  }

  if (
    q.includes('emergency') || q.includes('helpline') || q.includes('1962') || q.includes('doctor') || q.includes('hospital') || q.includes('ambulance') ||
    q.includes('అత్యవసర') || q.includes('డాక్టర్') || q.includes('వైద్యుడు') || q.includes('ఆసుపత్రి') || q.includes('అంబులెన్స్') ||
    q.includes('आपातकाल') || q.includes('डॉक्टर') || q.includes('अस्पताल') || q.includes('एम्बुलेंस') || q.includes('हेल्पलाइन')
  ) {
    return {
      title: KNOWLEDGE_BASE.general.emergency[lang].title,
      body: KNOWLEDGE_BASE.general.emergency[lang].content
    };
  }

  // 4. Case-Specific Context Handler
  if (caseData && caseData.diseasePrediction) {
    const diseaseName = caseData.diseasePrediction.toLowerCase();
    let matchedDisease = null;
    if (diseaseName.includes('foot') || diseaseName.includes('fmd')) matchedDisease = KNOWLEDGE_BASE.diseases.fmd[lang];
    else if (diseaseName.includes('lumpy') || diseaseName.includes('lsd')) matchedDisease = KNOWLEDGE_BASE.diseases.lsd[lang];
    else if (diseaseName.includes('mastitis')) matchedDisease = KNOWLEDGE_BASE.diseases.mastitis[lang];
    else if (diseaseName.includes('multiple') || diseaseName.includes('differential')) matchedDisease = KNOWLEDGE_BASE.diseases.differential[lang];
    else matchedDisease = KNOWLEDGE_BASE.diseases.healthy[lang];

    if (lang === 'te') {
      return {
        title: `📋 కేస్ నివేదిక: ${caseData.caseId || 'BUF-Case'} (${caseData.tagNumber || 'ట్యాగ్'})`,
        body: `• **నిర్ధారించిన వ్యాధి**: ${caseData.diseasePrediction}\n• **తీవ్రత స్థాయి**: ${caseData.severity || 'పరిశీలనలో ఉంది'}\n• **గుర్తించిన లక్షణాలు**: ${Array.isArray(caseData.symptoms) ? caseData.symptoms.join(', ') : caseData.symptoms}\n• **ప్రాంతం**: ${caseData.area} (పిన్‌కోడ్: ${caseData.pincode})\n\n${matchedDisease.name} సంరక్షణ మార్గదర్శకాలు:\n${formatDiseaseResponse(matchedDisease, lang).body}`
      };
    } else if (lang === 'hi') {
      return {
        title: `📋 केस रिपोर्ट: ${caseData.caseId || 'BUF-Case'} (${caseData.tagNumber || 'टैग'})`,
        body: `• **अनुमानित रोग**: ${caseData.diseasePrediction}\n• **गंभीरता स्तर**: ${caseData.severity || 'निरीक्षण में'}\n• **पहचाने गए लक्षण**: ${Array.isArray(caseData.symptoms) ? caseData.symptoms.join(', ') : caseData.symptoms}\n• **स्थान**: ${caseData.area} (पिनकोड: ${caseData.pincode})\n\n${matchedDisease.name} उपचार और सावधानियां:\n${formatDiseaseResponse(matchedDisease, lang).body}`
      };
    } else {
      return {
        title: `📋 Case Diagnostic Brief: ${caseData.caseId || 'BUF-Case'} (${caseData.tagNumber || 'Tag'})`,
        body: `• **Predicted Disease**: ${caseData.diseasePrediction}\n• **Severity Assessment**: ${caseData.severity || 'Under Assessment'}\n• **Reported Symptoms**: ${Array.isArray(caseData.symptoms) ? caseData.symptoms.join(', ') : caseData.symptoms}\n• **Location**: ${caseData.area} (Pincode: ${caseData.pincode})\n\n${matchedDisease.name} Guidance:\n${formatDiseaseResponse(matchedDisease, lang).body}`
      };
    }
  }

  // 5. Default Comprehensive AI Chatbot Response
  if (lang === 'te') {
    return {
      title: "🐮 నమస్కారం! నేను మీ పశువైద్య ఏఐ అసిస్టెంట్‌ని (ChatGPT / Gemini తరహా)",
      body: `నేను గేదెల ఆరోగ్యం, రోగ నిర్ధారణ పరీక్షలు, నివారణ జాగ్రత్తలు మరియు అత్యవసర చికిత్సలో మీకు పూర్తి సహాయాన్ని అందించగలను.

**నేను సమాధానం ఇవ్వగల ముఖ్య అంశాలు**:
1. **వ్యాధుల సమాచారం**: గాలికుంటు (FMD), లంపీ స్కిన్ (LSD), పొదుగు వాపు (Mastitis), గొంతువాపు (HS), జబ్బవాపు (BQ), సర్రా, మరియు కడుపుబ్బరం (Bloat).
2. **ల్యాబ్ పరీక్షలు**: కాలిఫోర్నియా మాస్టిటిస్ టెస్ట్ (CMT), ఆర్టీ-పీసీఆర్ (RT-PCR), ఎలైసా (ELISA), మరియు బ్లడ్ స్మీయర్ పరీక్షలు.
3. **జాగ్రత్తలు & పరిశుభ్రత**: క్రిమిసంహారకాలు (సోడా ద్రావణం, పొటాషియం పర్మాంగనేట్), క్వారంటైన్ నిబంధనలు, ఈగల నివారణ.
4. **టీకాల క్యాలెండర్**: గాలికుంటు, గొంతువాపు, మరియు లంపీ స్కిన్ వ్యాక్సిన్ సమయాలు.
5. **మేత & పోషణ**: పచ్చిగడ్డి, ఎండుగడ్డి, దాణా, మరియు ఖనిజ లవణాల మిశ్రమం.
6. **అత్యవసర సహాయం**: ఆంధ్రప్రదేశ్ 24/7 మొబైల్ వెటర్నరీ అంబులెన్స్ (1962).

మీ గేదెకు ఉన్న లక్షణాల గురించి లేదా మీకు కావలసిన సమాచారం గురించి టైప్ చేయండి లేదా మైక్ ద్వారా మాట్లాడండి!`
    };
  } else if (lang === 'hi') {
    return {
      title: "🐮 नमस्ते! मैं आपका पशु चिकित्सा एआई सहायक हूँ (ChatGPT / Gemini स्तर)",
      body: `मैं भैंसों के स्वास्थ्य, नैदानिक जांच, रोग रोकथाम, सावधानियों और आपातकालीन प्राथमिक चिकित्सा में आपकी पूर्ण सहायता कर सकता हूँ।

**मुख्य विषय जिन पर आप पूछ सकते हैं**:
1. **रोग एवं लक्षण**: खुरपका-मुंहपका (FMD), लम्पी त्वचा रोग (LSD), थनैला (Mastitis), गलघोंटू (HS), लंगड़ा बुखार (BQ), सर्रा, और अफरा (Bloat)।
2. **प्रयोगशाला परीक्षण**: कैलिफोर्निया मैस्टाइटिस टेस्ट (CMT), RT-PCR, ELISA, और ब्लड स्मीयर जांच विधि।
3. **सावधानियां व स्वच्छता**: बाड़े का विसंक्रमण (सोडा पानी, पोटाश/लाल दवा), मक्खी-मच्छर नियंत्रण, टीट डिपिंग।
4. **टीकाकरण कैलेंडर**: FMD, HS, BQ और LSD का सही समय।
5. **संतुलित आहार**: हरा चारा, सूखा भूसा, दाना व मिनरल मिक्सचर।
6. **आपातकालीन हेल्पलाइन**: 24/7 पशु एम्बुलेंस सेवा (1962)।

कृपया अपनी भैंस के लक्षण बोलकर या लिखकर पूछें!`
    };
  } else {
    return {
      title: "🐮 Welcome! I am your AI Veterinary Assistant (ChatGPT & Gemini Powered)",
      body: `I am an expert clinical intelligence chatbot specialized in water buffalo medicine, livestock herd health, diagnostic testing, and biosecurity precautions.

**Topics you can ask me about**:
1. **Disease Profiles**: Foot-and-Mouth Disease (FMD), Lumpy Skin Disease (LSD), Clinical Mastitis, Hemorrhagic Septicemia (HS), Black Quarter (BQ), Surra, and Acute Bloat.
2. **Diagnostic Tests**: California Mastitis Test (CMT paddle method), RT-PCR, 3ABC ELISA, Milk Somatic Cell Count (SCC), and Blood Smears.
3. **Farm Biosecurity & Precautions**: Disinfection dilutions (4% Sodium Carbonate, 1% KMnO4, 0.5% Povidone-Iodine), 21-day quarantine protocols, and vector control.
4. **Vaccination Schedules**: Bi-annual FMD, pre-monsoon HS/BQ, and annual LSD schedules.
5. **Nutrition & Herd Care**: Balanced ration (green/dry fodder, concentrates, bypass fat, chelated minerals).
6. **24/7 Emergency Support**: Immediate triage protocols and AP Mobile Veterinary Ambulance (1962).

How can I assist you with your herd today? Describe your buffalo's symptoms or ask any specific question!`
    };
  }
}

function formatDiseaseResponse(disease, lang) {
  let body = '';
  if (lang === 'te') {
    body = `**తీవ్రత స్థాయి**: ${disease.severity}\n**వ్యాప్తి మార్గం**: ${disease.transmission}\n\n**ముఖ్య లక్షణాలు**:\n${disease.symptoms.map(s => `• ${s}`).join('\n')}\n\n**చేయించవలసిన ల్యాబ్ పరీక్షలు**:\n${disease.diagnosticTests}\n\n**తీసుకోవలసిన ముఖ్య జాగ్రత్తలు**:\n${disease.precautions.map(p => `• ${p}`).join('\n')}\n\n**టీకా నిర్వహణ**: ${disease.vaccination}\n**అత్యవసర హెల్ప్‌లైన్**: ${disease.helpline}`;
  } else if (lang === 'hi') {
    body = `**गंभीरता स्तर**: ${disease.severity}\n**संक्रमण का माध्यम**: ${disease.transmission}\n\n**प्रमुख लक्षण**:\n${disease.symptoms.map(s => `• ${s}`).join('\n')}\n\n**आवश्यक नैदानिक परीक्षण**:\n${disease.diagnosticTests}\n\n**मुख्य सावधानियां एवं बचाव**:\n${disease.precautions.map(p => `• ${p}`).join('\n')}\n\n**टीकाकरण**: ${disease.vaccination}\n**आपातकालीन हेल्पलाइन**: ${disease.helpline}`;
  } else {
    body = `**Severity Assessment**: ${disease.severity}\n**Transmission**: ${disease.transmission}\n\n**Clinical Signs & Symptoms**:\n${disease.symptoms.map(s => `• ${s}`).join('\n')}\n\n**Diagnostic Laboratory Tests**:\n${disease.diagnosticTests}\n\n**Mandatory Precautions & Biosecurity**:\n${disease.precautions.map(p => `• ${p}`).join('\n')}\n\n**Vaccination Schedule**: ${disease.vaccination}\n**Emergency Assistance**: ${disease.helpline}`;
  }

  return {
    title: `📌 ${disease.name}`,
    body
  };
}

// ============================================================================
// GEMINI / LLM GENERATION WITH FULL INTELLIGENCE FALLBACK
// ============================================================================

async function generateAIAnswer(transcript, requestedLanguage = 'en-IN', context = '', caseData = null) {
  const lang = detectLanguage(transcript, requestedLanguage);
  const disclaimer = getDisclaimer(lang);

  const apiKey = process.env.GEMINI_API_KEY || process.env.LLM_API_KEY;

  if (apiKey) {
    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({
        model: GEMINI_MODEL,
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 1024
        }
      });

      const langInstruction = lang === 'te'
        ? 'CRITICAL MANDATE: You MUST reply 100% strictly in fluent, natural Telugu script (తెలుగు లిపి). Do NOT reply in English or transliteration. Use authoritative veterinary terminology.'
        : lang === 'hi'
        ? 'CRITICAL MANDATE: You MUST reply 100% strictly in fluent, natural Hindi Devanagari script (हिन्दी देवनागरी लिपि). Do NOT reply in English or transliteration. Use authoritative veterinary terminology.'
        : 'Reply in clear, authoritative, clinical English (India). Format with clean markdown headers and bullet points.';

      const systemPrompt = [
        'You are an expert AI Veterinary Doctor and Buffalo Health Specialist for a livestock health surveillance platform in Andhra Pradesh, India.',
        'Act like an empathetic, highly knowledgeable AI assistant (similar to ChatGPT / Gemini), providing comprehensive, clinical, and practical answers.',
        langInstruction,
        'Scope of expertise: All buffalo diseases (Foot-and-Mouth Disease/FMD, Lumpy Skin Disease/LSD, Clinical Mastitis, Hemorrhagic Septicemia/HS, Black Quarter/BQ, Surra, Acute Bloat, Milk Fever, Calf Diarrhea, Parasites, Healthy Buffalo care, Multiple Disease Differential Diagnosis).',
        'Always include relevant diagnostic tests (e.g. CMT, RT-PCR, Somatic Cell Count, Blood Smears, ELISA), biosecurity precautions (4% sodium carbonate, 1% KMnO4, 0.5% povidone-iodine teat dips, quarantine), vaccination timelines, and emergency 1962 mobile ambulance helpline when needed.',
        'Structure responses with clear headers, bullet points, and actionable guidance.',
        caseData ? `Current Active Case Details: ${JSON.stringify(caseData)}` : '',
        `User Context: ${context}`,
        `User Question: ${transcript}`
      ].filter(Boolean).join('\n\n');

      const result = await model.generateContent(systemPrompt);
      const response = await result.response;
      let replyText = response.text().trim();

      if (!replyText.includes('⚠️') && !replyText.includes('గమనిక') && !replyText.includes('अस्वीकरण') && !replyText.includes('Disclaimer')) {
        replyText += disclaimer;
      }
      return replyText;
    } catch (llmErr) {
      console.warn('Gemini LLM API call error, engaging high-performance knowledge engine:', llmErr.message || llmErr);
      // Fall through to offline knowledge engine
    }
  }

  // Offline / Knowledge Graph Engine
  const matched = matchVeterinaryKnowledge(transcript, lang, caseData);
  return `${matched.title}\n\n${matched.body}${disclaimer}`;
}

// ============================================================================
// ASSISTANT ROUTE HANDLER
// ============================================================================

router.post('/', async (req, res) => {
  try {
    const { transcript, language = 'en-IN', caseId } = req.body || {};
    if (typeof transcript !== 'string' || !transcript.trim()) {
      return res.status(400).json({ message: 'Please enter a question or message.' });
    }

    let targetCase = null;
    if (caseId) {
      targetCase = await Case.findOne({ caseId }).lean();
    }

    let context = 'Role: Buffalo Farmer / Herd Caretaker';
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      try {
        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, jwtSecret);
        if (decoded && decoded.id) {
          const userCases = await Case.find({ userId: decoded.id }).lean();
          const total = userCases.length;
          const active = userCases.filter(c => c.status !== 'Closed' && c.status !== 'Recovered').length;
          context = `User has ${total} total registered cases, ${active} active monitoring cases. User role: ${decoded.role || 'Buffalo Owner'}.`;
        }
      } catch (authErr) {
        // Continue with default context
      }
    }

    const reply = await generateAIAnswer(transcript.trim(), language, context, targetCase);

    res.json({ reply });
  } catch (err) {
    console.error('AI Assistant Route Error:', err);
    res.status(500).json({ message: 'AI Assistant is temporarily unavailable. Please try again later.' });
  }
});

module.exports = router;
