const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { jwtSecret, requireAuth } = require('../middleware/auth');

const router = express.Router();
const SALT_ROUNDS = 10;
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const mongoose = require('mongoose');
const User = require('../models/User');

const fallbackUsersFile = path.join(__dirname, '..', 'data', 'users.json');

function normalizeRole(role) {
  if (!role) return 'Buffalo Owner';
  const r = role.toString().toLowerCase().replace(/_/g, ' ');
  if (r.includes('system admin') || r.includes('system_admin')) return 'System Admin';
  if (r.includes('volunteer')) return 'Volunteer';
  if (r.includes('vet')) return 'Veterinarian';
  if (r.includes('ngo')) return 'NGO';
  if (r.includes('admin')) return 'System Admin';
  if (r.includes('buffalo') || r.includes('animal') || r.includes('owner') || r.includes('farmer')) return 'Buffalo Owner';
  return 'Buffalo Owner';
}

// Signup
router.post('/register', async (req, res) => {
  const { name, email, password, role, phone, emergencyContactConsent, area, streetName, pincode } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ success: false, message: 'Name, email, and password are required.' });
  }

  const cleanRole = normalizeRole(role);
  const consent = Boolean(emergencyContactConsent);

  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const existing = await User.findOne({ email: email.toLowerCase().trim() });
      if (existing) {
        return res.status(409).json({ success: false, message: 'An account with this email already exists.' });
      }
      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      const user = await User.create({
        name: name.trim(),
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        role: cleanRole,
        phone: phone ? phone.trim() : '',
        area: area ? area.trim() : '',
        streetName: streetName ? streetName.trim() : '',
        pincode: pincode ? pincode.trim() : '',
        emergencyContactConsent: consent,
      });
      const token = jwt.sign({ id: user._id, role: user.role }, jwtSecret, { expiresIn: '7d' });
      return res.status(201).json({
        success: true,
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          area: user.area,
          streetName: user.streetName,
          pincode: user.pincode,
          emergencyContactConsent: user.emergencyContactConsent,
        },
      });
    }

    // Fallback JSON users
    let users = [];
    if (fs.existsSync(fallbackUsersFile)) {
      users = JSON.parse(fs.readFileSync(fallbackUsersFile));
    }
    if (users.find((u) => u.email && u.email.toLowerCase() === email.toLowerCase().trim())) {
      return res.status(409).json({ success: false, message: 'An account with this email already exists.' });
    }
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    const newUser = {
      id: Date.now().toString(),
      name: name.trim(),
      email: email.toLowerCase().trim(),
      passwordHash: hashedPassword,
      role: cleanRole,
      phone: phone ? phone.trim() : '',
      area: area ? area.trim() : '',
      streetName: streetName ? streetName.trim() : '',
      pincode: pincode ? pincode.trim() : '',
      emergencyContactConsent: consent,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    fs.writeFileSync(fallbackUsersFile, JSON.stringify(users, null, 2));
    const token = jwt.sign({ id: newUser.id, role: newUser.role }, jwtSecret, { expiresIn: '7d' });
    return res.status(201).json({
      success: true,
      token,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        phone: newUser.phone,
        area: newUser.area,
        streetName: newUser.streetName,
        pincode: newUser.pincode,
        emergencyContactConsent: newUser.emergencyContactConsent,
      },
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ success: false, message: 'Unable to register user.' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required.' });
  }

  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const user = await User.findOne({ email: email.toLowerCase().trim() });
      if (!user) {
        return res.status(401).json({ success: false, message: 'Invalid email or password.' });
      }
      if (user.password) {
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
          return res.status(401).json({ success: false, message: 'Invalid email or password.' });
        }
      }
      const token = jwt.sign({ id: user._id, role: user.role }, jwtSecret, { expiresIn: '7d' });
      return res.json({
        success: true,
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          area: user.area,
          streetName: user.streetName,
          pincode: user.pincode,
          emergencyContactConsent: user.emergencyContactConsent,
          avatar: user.avatar,
        },
      });
    }

    // Fallback JSON users
    let users = [];
    if (fs.existsSync(fallbackUsersFile)) {
      users = JSON.parse(fs.readFileSync(fallbackUsersFile));
    }
    const found = users.find((u) => u.email && u.email.toLowerCase() === email.toLowerCase().trim());
    if (!found) return res.status(401).json({ success: false, message: 'Invalid email or password.' });

    let valid = false;
    if (found.passwordHash && found.passwordHash.startsWith('$2')) {
      valid = await bcrypt.compare(password, found.passwordHash);
    } else if (found.passwordHash && found.passwordHash.length === 64) {
      const hex = crypto.createHash('sha256').update(password).digest('hex');
      valid = hex === found.passwordHash;
    }
    if (!valid) return res.status(401).json({ success: false, message: 'Invalid email or password.' });

    const token = jwt.sign({ id: found.id, role: found.role }, jwtSecret, { expiresIn: '7d' });
    return res.json({
      success: true,
      token,
      user: {
        id: found.id,
        name: found.name,
        email: found.email,
        role: found.role,
        phone: found.phone,
        area: found.area,
        streetName: found.streetName,
        pincode: found.pincode,
        emergencyContactConsent: found.emergencyContactConsent,
        avatar: found.avatar,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Unable to login.' });
  }
});

// Google Sign-In
router.post('/google', async (req, res) => {
  const { credential, name, email, picture, role, phone, area, emergencyContactConsent } = req.body;
  let userEmail = email;
  let userName = name;
  let userPicture = picture;

  if (credential) {
    try {
      const parts = credential.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf-8'));
        userEmail = payload.email || userEmail;
        userName = payload.name || userName;
        userPicture = payload.picture || userPicture;
      }
    } catch (e) {
      console.warn('Could not decode Google JWT credential token:', e);
    }
  }

  if (!userEmail) {
    return res.status(400).json({ success: false, message: 'Google authentication failed: Email missing.' });
  }

  try {
    const cleanRole = normalizeRole(role);
    const consent = typeof emergencyContactConsent === 'boolean' ? emergencyContactConsent : true;
    const cleanPhone = phone ? phone.trim() : '';
    const cleanArea = area ? area.trim() : '';

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      let user = await User.findOne({ email: userEmail.toLowerCase().trim() });
      if (!user) {
        user = await User.create({
          name: userName || 'Google User',
          email: userEmail.toLowerCase().trim(),
          role: cleanRole,
          avatar: userPicture || '',
          phone: cleanPhone,
          area: cleanArea,
          emergencyContactConsent: consent,
          verified: true,
        });
      } else {
        // Update existing user if phone/area/consent provided
        let updated = false;
        if (cleanPhone && !user.phone) { user.phone = cleanPhone; updated = true; }
        if (cleanArea && !user.area) { user.area = cleanArea; updated = true; }
        if (typeof emergencyContactConsent === 'boolean') { user.emergencyContactConsent = consent; updated = true; }
        if (updated) await user.save();
      }

      const token = jwt.sign({ id: user._id, role: user.role }, jwtSecret, { expiresIn: '7d' });
      return res.json({
        success: true,
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          area: user.area,
          streetName: user.streetName,
          pincode: user.pincode,
          emergencyContactConsent: user.emergencyContactConsent,
          avatar: user.avatar,
        },
      });
    }

    // Fallback JSON users
    let users = [];
    if (fs.existsSync(fallbackUsersFile)) {
      users = JSON.parse(fs.readFileSync(fallbackUsersFile));
    }
    let found = users.find((u) => u.email && u.email.toLowerCase() === userEmail.toLowerCase().trim());
    if (!found) {
      found = {
        id: Date.now().toString(),
        name: userName || 'Google User',
        email: userEmail.toLowerCase().trim(),
        role: cleanRole,
        avatar: userPicture || '',
        phone: cleanPhone,
        area: cleanArea,
        emergencyContactConsent: consent,
        createdAt: new Date().toISOString(),
      };
      users.push(found);
      fs.writeFileSync(fallbackUsersFile, JSON.stringify(users, null, 2));
    } else {
      if (cleanPhone && !found.phone) found.phone = cleanPhone;
      if (cleanArea && !found.area) found.area = cleanArea;
      if (typeof emergencyContactConsent === 'boolean') found.emergencyContactConsent = consent;
      fs.writeFileSync(fallbackUsersFile, JSON.stringify(users, null, 2));
    }

    const token = jwt.sign({ id: found.id, role: found.role }, jwtSecret, { expiresIn: '7d' });
    return res.json({
      success: true,
      token,
      user: {
        id: found.id,
        name: found.name,
        email: found.email,
        role: found.role,
        phone: found.phone,
        area: found.area,
        streetName: found.streetName,
        pincode: found.pincode,
        emergencyContactConsent: found.emergencyContactConsent,
        avatar: found.avatar,
      },
    });
  } catch (error) {
    console.error('Google login error:', error);
    res.status(500).json({ success: false, message: 'Google authentication failed.' });
  }
});

// Update Profile
router.put('/profile', requireAuth, async (req, res) => {
  const {
    name,
    phone,
    role,
    avatar,
    area,
    streetName,
    pincode,
    emergencyContactConsent,
    notificationPreferences
  } = req.body;

  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const user = await User.findById(req.user.id);
      if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

      if (name) user.name = name.trim();
      if (phone !== undefined) user.phone = phone.trim();
      if (role) user.role = normalizeRole(role);
      if (avatar !== undefined) user.avatar = avatar;
      if (area !== undefined) user.area = area.trim();
      if (streetName !== undefined) user.streetName = streetName.trim();
      if (pincode !== undefined) user.pincode = pincode.trim();
      if (emergencyContactConsent !== undefined) user.emergencyContactConsent = Boolean(emergencyContactConsent);
      if (notificationPreferences && typeof notificationPreferences === 'object') {
        user.notificationPreferences = notificationPreferences;
      }

      await user.save();
      return res.json({
        success: true,
        message: 'Profile updated successfully.',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          area: user.area,
          streetName: user.streetName,
          pincode: user.pincode,
          emergencyContactConsent: user.emergencyContactConsent,
          avatar: user.avatar,
          notificationPreferences: user.notificationPreferences
        },
      });
    }

    // Fallback JSON user update
    if (fs.existsSync(fallbackUsersFile)) {
      let users = JSON.parse(fs.readFileSync(fallbackUsersFile));
      const idx = users.findIndex(u => u.id === req.user.id);
      if (idx !== -1) {
        if (name) users[idx].name = name.trim();
        if (phone !== undefined) users[idx].phone = phone.trim();
        if (role) users[idx].role = normalizeRole(role);
        if (avatar !== undefined) users[idx].avatar = avatar;
        if (area !== undefined) users[idx].area = area.trim();
        if (streetName !== undefined) users[idx].streetName = streetName.trim();
        if (pincode !== undefined) users[idx].pincode = pincode.trim();
        if (emergencyContactConsent !== undefined) users[idx].emergencyContactConsent = Boolean(emergencyContactConsent);
        if (notificationPreferences && typeof notificationPreferences === 'object') {
          users[idx].notificationPreferences = notificationPreferences;
        }

        fs.writeFileSync(fallbackUsersFile, JSON.stringify(users, null, 2));
        return res.json({
          success: true,
          message: 'Profile updated successfully.',
          user: users[idx]
        });
      }
    }
    return res.status(404).json({ success: false, message: 'User not found.' });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ success: false, message: 'Unable to update profile.' });
  }
});

// Get current user profile (/me)
router.get('/me', requireAuth, async (req, res) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const user = await User.findById(req.user.id).select('-password');
      if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
      return res.json({
        success: true,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          area: user.area,
          streetName: user.streetName,
          pincode: user.pincode,
          emergencyContactConsent: user.emergencyContactConsent || false,
          avatar: user.avatar,
          notificationPreferences: user.notificationPreferences || { smsAlerts: true, emailAlerts: true, redZoneAlerts: true },
          createdAt: user.createdAt,
        },
      });
    }

    if (fs.existsSync(fallbackUsersFile)) {
      const users = JSON.parse(fs.readFileSync(fallbackUsersFile));
      const found = users.find(u => u.id === req.user.id);
      if (!found) return res.status(404).json({ success: false, message: 'User not found.' });
      return res.json({ success: true, user: found });
    }
    return res.status(404).json({ success: false, message: 'User not found.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Server error fetching user profile.' });
  }
});

// GET System Accounts (Returns accounts present in this system for Google / Profile selection)
router.get('/system-accounts', async (req, res) => {
  try {
    let accounts = [];
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const users = await User.find({}).select('name email role area phone avatar emergencyContactConsent').limit(10).lean();
      accounts = users.map(u => ({
        id: u._id,
        name: u.name,
        email: u.email,
        role: u.role,
        area: u.area || 'Andhra Pradesh',
        phone: u.phone || '',
        avatar: u.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name)}&background=10b981&color=fff`
      }));
    }

    if (accounts.length === 0 && fs.existsSync(fallbackUsersFile)) {
      const fUsers = JSON.parse(fs.readFileSync(fallbackUsersFile, 'utf8')) || [];
      accounts = fUsers.map(u => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        area: u.area || 'Andhra Pradesh',
        phone: u.phone || '',
        avatar: u.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name)}&background=10b981&color=fff`
      }));
    }

    return res.json({ success: true, count: accounts.length, accounts });
  } catch (err) {
    console.error('Fetch system accounts error:', err);
    res.status(500).json({ success: false, message: 'Could not fetch system accounts.' });
  }
});

// POST /api/auth/forgot-password: Generate OTP and send email
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  if (!email || !email.trim()) {
    return res.status(400).json({ success: false, message: 'Please enter your registered email address.' });
  }

  const cleanEmail = email.toLowerCase().trim();

  try {
    const emailService = require('../services/emailService');
    let user = null;
    let isDb = false;

    if (mongoose.connection && mongoose.connection.readyState === 1 && User) {
      user = await User.findOne({ email: cleanEmail });
      if (user) isDb = true;
    }

    let fallbackUsers = [];
    let fallbackIdx = -1;
    if (!user && fs.existsSync(fallbackUsersFile)) {
      fallbackUsers = JSON.parse(fs.readFileSync(fallbackUsersFile, 'utf8'));
      fallbackIdx = fallbackUsers.findIndex(u => u.email && u.email.toLowerCase().trim() === cleanEmail);
      if (fallbackIdx !== -1) {
        user = fallbackUsers[fallbackIdx];
      }
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No account registered with this email address. Please verify your email or create a new account.'
      });
    }

    // Generate 6-digit numeric verification OTP
    const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
    const resetToken = crypto.randomBytes(24).toString('hex');
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 mins

    if (isDb) {
      user.resetPasswordOtp = resetCode;
      user.resetPasswordToken = resetToken;
      user.resetPasswordExpires = expiresAt;
      await user.save();
    } else if (fallbackIdx !== -1) {
      fallbackUsers[fallbackIdx].resetPasswordOtp = resetCode;
      fallbackUsers[fallbackIdx].resetPasswordToken = resetToken;
      fallbackUsers[fallbackIdx].resetPasswordExpires = expiresAt.toISOString();
      fs.writeFileSync(fallbackUsersFile, JSON.stringify(fallbackUsers, null, 2));
    }

    // Dispatch real email via emailService
    let emailResult = {};
    try {
      emailResult = await emailService.sendPasswordResetEmail(cleanEmail, user.name, resetCode, resetToken);
    } catch (mailErr) {
      console.warn('Mail dispatch warning:', mailErr.message);
    }

    return res.json({
      success: true,
      message: `Password reset verification code has been dispatched to ${cleanEmail}. Please check your inbox (and spam folder).`,
      resetCode: resetCode,
      previewUrl: emailResult.previewUrl || null,
      email: cleanEmail
    });

  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ success: false, message: 'Failed to process password reset request.' });
  }
});

// POST /api/auth/reset-password: Verify OTP and set new password
router.post('/reset-password', async (req, res) => {
  const { email, code, newPassword } = req.body;
  if (!email || !code || !newPassword) {
    return res.status(400).json({ success: false, message: 'Email, 6-digit verification code, and new password are required.' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
  }

  const cleanEmail = email.toLowerCase().trim();
  const cleanCode = code.toString().trim();

  try {
    let user = null;
    let isDb = false;

    if (mongoose.connection && mongoose.connection.readyState === 1 && User) {
      user = await User.findOne({ email: cleanEmail });
      if (user) isDb = true;
    }

    let fallbackUsers = [];
    let fallbackIdx = -1;
    if (!user && fs.existsSync(fallbackUsersFile)) {
      fallbackUsers = JSON.parse(fs.readFileSync(fallbackUsersFile, 'utf8'));
      fallbackIdx = fallbackUsers.findIndex(u => u.email && u.email.toLowerCase().trim() === cleanEmail);
      if (fallbackIdx !== -1) {
        user = fallbackUsers[fallbackIdx];
      }
    }

    if (!user) {
      return res.status(404).json({ success: false, message: 'Account not found.' });
    }

    // Verify OTP code
    const storedOtp = user.resetPasswordOtp;
    const expiresAt = user.resetPasswordExpires ? new Date(user.resetPasswordExpires) : null;

    if (!storedOtp || storedOtp !== cleanCode) {
      return res.status(400).json({ success: false, message: 'Invalid verification code. Please check the 6-digit code sent to your email.' });
    }

    if (!expiresAt || expiresAt.getTime() < Date.now()) {
      return res.status(400).json({ success: false, message: 'Verification code has expired. Please request a new code.' });
    }

    // Hash new password and clear OTP fields
    const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);

    if (isDb) {
      user.password = hashedPassword;
      user.resetPasswordOtp = undefined;
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;
      await user.save();
    } else if (fallbackIdx !== -1) {
      fallbackUsers[fallbackIdx].passwordHash = hashedPassword;
      delete fallbackUsers[fallbackIdx].resetPasswordOtp;
      delete fallbackUsers[fallbackIdx].resetPasswordToken;
      delete fallbackUsers[fallbackIdx].resetPasswordExpires;
      fs.writeFileSync(fallbackUsersFile, JSON.stringify(fallbackUsers, null, 2));
    }

    return res.json({
      success: true,
      message: 'Password successfully updated! You can now sign in with your new password.'
    });

  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ success: false, message: 'Failed to reset password.' });
  }
});

module.exports = router;
