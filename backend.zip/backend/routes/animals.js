const express = require('express');
const mongoose = require('mongoose');
const Animal = require('../models/Animal');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Get all animals for the logged-in user
router.get('/', requireAuth, async (req, res) => {
  try {
    const query = (req.user.role === 'veterinarian' || req.user.role === 'admin') ? {} : { owner: req.user._id };
    const animals = await Animal.find(query).sort({ createdAt: -1 }).populate('owner', 'name email phone');
    res.json(animals);
  } catch (error) {
    console.error('Fetch animals error:', error);
    res.status(500).json({ message: 'Unable to fetch animals.' });
  }
});

// Create new animal
router.post('/', requireAuth, async (req, res) => {
  try {
    const { name, breed, age, sex, area, latitude, longitude } = req.body;
    if (!name || !area) {
      return res.status(400).json({ message: 'Name and area are required.' });
    }

    const animal = await Animal.create({
      name: name.trim(),
      species: 'Buffalo',
      breed: breed ? breed.trim() : '',
      age: age ? Number(age) : null,
      sex: sex || 'Unknown',
      owner: req.user._id,
      location: {
        area: area.trim(),
        latitude: latitude || null,
        longitude: longitude || null,
      }
    });

    res.status(201).json(animal);
  } catch (error) {
    console.error('Create animal error:', error);
    res.status(500).json({ message: 'Unable to register animal.' });
  }
});

// Get single animal
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const animal = await Animal.findById(req.params.id).populate('owner', 'name email phone');
    if (!animal) return res.status(404).json({ message: 'Animal not found.' });

    // Permissions check
    if (req.user.role !== 'veterinarian' && String(animal.owner._id) !== String(req.user._id)) {
      return res.status(403).json({ message: 'Forbidden.' });
    }

    res.json(animal);
  } catch (error) {
    res.status(500).json({ message: 'Unable to fetch animal.' });
  }
});

// Update animal
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const animal = await Animal.findById(req.params.id);
    if (!animal) return res.status(404).json({ message: 'Animal not found.' });

    if (req.user.role !== 'veterinarian' && String(animal.owner) !== String(req.user._id)) {
      return res.status(403).json({ message: 'Forbidden.' });
    }

    const updates = { ...req.body };
    delete updates.owner; // prevent reassignment
    delete updates.species; // keep as Buffalo

    const updated = await Animal.findByIdAndUpdate(req.params.id, updates, { new: true });
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Unable to update animal.' });
  }
});

module.exports = router;
