const mongoose = require('mongoose');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '..', '.env') });
const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/animal-health';

const VERIFIED_GOVT_HOSPITALS = [
  {
    name: 'NTR Veterinary Super Speciality Hospital (Labbipet)',
    category: 'Government Super Speciality & Apex Institutional Care',
    facilityType: 'Super Speciality Animal Hospital',
    city: 'Vijayawada, Andhra Pradesh',
    distanceText: 'Labbipet / Bandar Rd',
    rating: 4.6,
    userRatingsTotal: 1350,
    isOpenNow: true,
    timings: '24x7 Emergency Services & 8:00 AM - 6:00 PM OPD',
    phone: '+91 866 247 6167',
    bestFor: 'Complex bovine illnesses, surgical procedures, emergency obstetrics, and advanced diagnostic testing for dairy buffaloes and livestock.',
    address: 'Door No. 39-10-22, Bandar Rd (MG Road), Punammathota, Labbipet, Vijayawada, Andhra Pradesh 520010',
    latitude: 16.5042,
    longitude: 80.6418,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=NTR+Veterinary+Super+Speciality+Hospital+Punammathota+Labbipet+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=NTR+Veterinary+Super+Speciality+Hospital,+Punammathota,+Labbipet,+Vijayawada,+Andhra+Pradesh+520010',
    source: 'Government Apex Hospital'
  },
  {
    name: 'NTR College of Veterinary Science & University Hospital (Gannavaram)',
    category: 'Government Super Speciality & Apex Institutional Care',
    facilityType: 'Apex University Research & Teaching Hospital',
    city: 'Kesarapalli, Gannavaram, Andhra Pradesh',
    distanceText: 'Gannavaram / Airport',
    rating: 4.7,
    userRatingsTotal: 420,
    isOpenNow: true,
    timings: '24/7 Inpatient & Critical Care | 9:00 AM - 5:00 PM Clinical Services',
    phone: '+91 866 288 2382',
    bestFor: 'Major operations, calving complications (dystocia), severe toxicity, and specialized large-animal pathology departments.',
    address: 'NH 16, Kesarapalli (Opposite Vijayawada International Airport), Gannavaram, Andhra Pradesh 521102',
    latitude: 16.5266,
    longitude: 80.7834,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=NTR+College+of+Veterinary+Science+Kesarapalli+Gannavaram',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=NTR+College+of+Veterinary+Science,+Kesarapalli,+Gannavaram,+Andhra+Pradesh+521102',
    source: 'Government College & Apex Hospital'
  },
  {
    name: 'YSR Sanchara Pashu Arogya Seva (1962 Mobile Veterinary Clinics)',
    category: 'Doorstep Emergency Services (Highly Recommended)',
    facilityType: 'Doorstep Mobile Emergency Van & Ambulance',
    city: 'Statewide Andhra Pradesh (All Mandals)',
    distanceText: 'Doorstep Farm Visit (Dispatched locally)',
    rating: 5.0,
    userRatingsTotal: 4800,
    isOpenNow: true,
    timings: '24x7 Operational (Round-the-clock Doorstep Dispatch)',
    phone: '1962',
    bestFor: 'Treating a sick buffalo directly at your farm or shed without the hassle of transporting large livestock. Equipped with a vet, para-vet, and medicines.',
    address: 'Directorate of Animal Husbandry, Bandar Road, Labbipet, Vijayawada, Andhra Pradesh 520010',
    latitude: 16.5048,
    longitude: 80.6425,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Directorate+of+Animal+Husbandry+Bandar+Road+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Directorate+of+Animal+Husbandry,+Bandar+Road,+Labbipet,+Vijayawada,+Andhra+Pradesh+520010',
    source: 'State Emergency Services (1962)'
  },
  {
    name: 'District Veterinary Polyclinic & Diagnostic Hub (Governorpet)',
    category: 'Government Super Speciality & Apex Institutional Care',
    facilityType: 'District Central Polyclinic & Diagnostic Laboratory',
    city: 'Governorpet, Vijayawada, Andhra Pradesh',
    distanceText: 'Governorpet / Old Bus Stand',
    rating: 4.5,
    userRatingsTotal: 430,
    isOpenNow: true,
    timings: '24x7 Emergency Casualties | 8:00 AM - 6:00 PM Daily OPD',
    phone: '+91 866 257 4288',
    bestFor: 'District headquarters referral polyclinic with dedicated bacteriology/pathology lab, fracture surgery, and emergency overnight care.',
    address: 'Opp. Old Bus Stand, Bunder Road, Governorpet, Vijayawada, Andhra Pradesh 520002',
    latitude: 16.5112,
    longitude: 80.6268,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=District+Veterinary+Polyclinic+Governorpet+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Opp+Old+Bus+Stand,+Bunder+Road,+Governorpet,+Vijayawada,+Andhra+Pradesh+520002',
    source: 'District Veterinary Polyclinic'
  },
  {
    name: 'Government Veterinary Hospital (Satyanarayanapuram)',
    category: 'Local Government Veterinary Dispensaries (Areawise)',
    facilityType: 'Urban Area Veterinary Hospital',
    city: 'Satyanarayanapuram, Vijayawada, Andhra Pradesh',
    distanceText: 'Satyanarayanapuram',
    rating: 4.2,
    userRatingsTotal: 135,
    isOpenNow: true,
    timings: '8:00 AM - 12:00 PM & 3:00 PM - 5:00 PM (Mon-Sat)',
    phone: '+91 93933 23775',
    bestFor: 'Regular livestock health checks, vaccinations (FMD, HS, BQ), artificial insemination, and routine wound dressing.',
    address: 'Door No. 21-8-47, G S Raju Road, near Govt Regional Press, Mutyalammapadu, Satyanarayanapuram, Vijayawada, Andhra Pradesh 520011',
    latitude: 16.5265,
    longitude: 80.6275,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=GS+Raju+Road+Satyanarayanapuram+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=G+S+Raju+Road,+Satyanarayanapuram,+Vijayawada,+Andhra+Pradesh+520011',
    source: 'Local Government Dispensary'
  },
  {
    name: 'Veterinary Hospital / Rural Livestock Unit (Ayodhya Nagar)',
    category: 'Local Government Veterinary Dispensaries (Areawise)',
    facilityType: 'Rural Livestock Unit & Veterinary Hospital',
    city: 'Ayodhya Nagar, Vijayawada, Andhra Pradesh',
    distanceText: 'Ayodhya Nagar',
    rating: 4.1,
    userRatingsTotal: 90,
    isOpenNow: true,
    timings: '8:30 AM - 1:00 PM & 3:30 PM - 5:30 PM (Mon-Sat)',
    phone: '+91 99598 36618',
    bestFor: 'First-aid care, deworming drives, mineral deficiency supplementation, acute infection stabilization, and local farm calls.',
    address: 'Main Road, Ayodhya Nagar, near Madhuranagar Railway Station, Vijayawada, Andhra Pradesh 520011',
    latitude: 16.5285,
    longitude: 80.6340,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Ayodhya+Nagar+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Ayodhya+Nagar,+Vijayawada,+Andhra+Pradesh+520011',
    source: 'Rural Livestock Unit'
  },
  {
    name: 'Government Veterinary Hospital (Kanuru)',
    category: 'Local Government Veterinary Dispensaries (Areawise)',
    facilityType: 'Suburban Veterinary Hospital',
    city: 'Kanuru, Vijayawada, Andhra Pradesh',
    distanceText: 'Kanuru / Auto Nagar',
    rating: 4.3,
    userRatingsTotal: 110,
    isOpenNow: true,
    timings: '8:00 AM - 12:30 PM & 3:00 PM - 5:00 PM (Mon-Sat)',
    phone: '+91 866 258 2244',
    bestFor: 'Proximity for dairy farmers around Auto Nagar, Kanuru, and eastern agricultural areas. Scheduled deworming and preventive vaccine administration.',
    address: 'Kanuru Main Road, Near Post Office, DNR Colony, Kanuru, Vijayawada, Andhra Pradesh 520007',
    latitude: 16.4880,
    longitude: 80.6920,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Kanuru+Main+Road+Kanuru+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Kanuru+Main+Road,+Kanuru,+Vijayawada,+Andhra+Pradesh+520007',
    source: 'Local Government Hospital'
  },
  {
    name: 'Government Veterinary Dispensary (Gunadala)',
    category: 'Local Government Veterinary Dispensaries (Areawise)',
    facilityType: 'Local Veterinary Dispensary',
    city: 'Gunadala, Vijayawada, Andhra Pradesh',
    distanceText: 'Gunadala / Eluru Rd',
    rating: 4.2,
    userRatingsTotal: 82,
    isOpenNow: true,
    timings: '8:00 AM - 12:00 PM & 3:00 PM - 5:00 PM (Mon-Sat)',
    phone: '+91 866 245 1199',
    bestFor: 'Preventive vaccinations, general cattle checkups, nutritional counseling, and basic medical care for Gunadala and Ramavarappadu livestock.',
    address: 'Eluru Road, Near Gunadala Centre, Gunadala, Vijayawada, Andhra Pradesh 520004',
    latitude: 16.5165,
    longitude: 80.6650,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Gunadala+Centre+Eluru+Road+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Gunadala+Centre,+Eluru+Road,+Vijayawada,+Andhra+Pradesh+520004',
    source: 'State Animal Husbandry Dept'
  },
  {
    name: 'Government Veterinary Dispensary (Bhavanipuram / Gollapudi)',
    category: 'Local Government Veterinary Dispensaries (Areawise)',
    facilityType: 'Suburban Livestock Care Unit',
    city: 'Bhavanipuram, Vijayawada, Andhra Pradesh',
    distanceText: 'Bhavanipuram / Gollapudi',
    rating: 4.3,
    userRatingsTotal: 75,
    isOpenNow: true,
    timings: '8:00 AM - 12:30 PM & 3:00 PM - 5:00 PM (Mon-Sat)',
    phone: '+91 866 241 3322',
    bestFor: 'Western corridor dairy farmers, Gollapudi agricultural belt, and Bhavanipuram. Routine treatments, emergency trauma triage, and seasonal vaccination drives.',
    address: 'NH 65, Near Gollapudi Market Yard / Milk Project, Bhavanipuram, Vijayawada, Andhra Pradesh 521225',
    latitude: 16.5400,
    longitude: 80.5920,
    googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Gollapudi+Market+Yard+Vijayawada',
    directionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Gollapudi+Market+Yard,+Bhavanipuram,+Vijayawada,+Andhra+Pradesh+521225',
    source: 'State Animal Husbandry Dept'
  }
];

async function resetSystem() {
  console.log('Connecting to MongoDB at:', mongoURI);
  await mongoose.connect(mongoURI);
  console.log('MongoDB connected successfully.');

  const db = mongoose.connection.db;

  // 1. Clear all cases
  const casesRes = await db.collection('cases').deleteMany({});
  console.log(`[CLEARED] Deleted ${casesRes.deletedCount} cases from 'cases' collection.`);

  // 2. Clear all users / logins
  const usersRes = await db.collection('users').deleteMany({});
  console.log(`[CLEARED] Deleted ${usersRes.deletedCount} users from 'users' collection.`);

  // 3. Clear alerts, animals, healthrecords, reviews, volunteers
  const alertsRes = await db.collection('alerts').deleteMany({});
  console.log(`[CLEARED] Deleted ${alertsRes.deletedCount} alerts.`);

  const animalsRes = await db.collection('animals').deleteMany({});
  console.log(`[CLEARED] Deleted ${animalsRes.deletedCount} animals.`);

  const healthRes = await db.collection('healthrecords').deleteMany({});
  console.log(`[CLEARED] Deleted ${healthRes.deletedCount} healthrecords.`);

  const reviewsRes = await db.collection('reviews').deleteMany({});
  console.log(`[CLEARED] Deleted ${reviewsRes.deletedCount} reviews.`);

  // 4. Reset JSON fallbacks
  const usersJsonPath = path.join(__dirname, 'data', 'users.json');
  fs.writeFileSync(usersJsonPath, JSON.stringify([], null, 2), 'utf-8');
  console.log('[CLEARED] Reset backend/data/users.json to empty array.');

  const issuesJsonPath = path.join(__dirname, 'data', 'issues.json');
  fs.writeFileSync(issuesJsonPath, JSON.stringify([], null, 2), 'utf-8');
  console.log('[CLEARED] Reset backend/data/issues.json to empty array.');

  // 5. Replace hospitals collection with exact verified government hospitals
  await db.collection('hospitals').deleteMany({});
  const insertRes = await db.collection('hospitals').insertMany(VERIFIED_GOVT_HOSPITALS);
  console.log(`[UPDATED] Populated ${insertRes.insertedCount} verified government veterinary hospitals in 'hospitals' collection.`);

  await mongoose.disconnect();
  console.log('System reset complete. All cases and logins removed; verified hospitals updated.');
  process.exit(0);
}

resetSystem().catch(err => {
  console.error('Reset error:', err);
  process.exit(1);
});
