const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Animal = require('./models/Animal');
const Case = require('./models/Case');
const Alert = require('./models/Alert');
const HealthRecord = require('./models/HealthRecord');

dotenv.config();

const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/animal-health';

async function seedDatabase() {
  try {
    await mongoose.connect(mongoURI);
    console.log('Connected to MongoDB for seeding...');

    // Clear existing
    await User.deleteMany({});
    await Animal.deleteMany({});
    await Case.deleteMany({});
    await Alert.deleteMany({});
    await HealthRecord.deleteMany({});

    // 1. Create Users
    const farmer = await User.create({ name: 'Demo Farmer', email: 'farmer@demo.com', password: 'password', role: 'animal_owner', phone: '' });
    const vet = await User.create({ name: 'Dr. Smith', email: 'vet@demo.com', password: 'password', role: 'veterinarian', phone: '', emergencyContactConsent: false });
    const admin = await User.create({ name: 'System Admin', email: 'admin@demo.com', password: 'password', role: 'System Admin', phone: '' });

    // 2. Create Buffalo
    const buffalo1 = await Animal.create({
      name: 'B-101',
      species: 'Buffalo',
      breed: 'Murrah',
      age: 48,
      sex: 'Female',
      owner: farmer._id,
      location: { area: 'Benz Circle', latitude: 16.5238, longitude: 80.6408 },
      status: 'Healthy',
    });

    const buffalo2 = await Animal.create({
      name: 'B-102',
      species: 'Buffalo',
      breed: 'Murrah',
      age: 60,
      sex: 'Female',
      owner: farmer._id,
      location: { area: 'MG Road', latitude: 16.5115, longitude: 80.6441 },
      status: 'Critical',
    });

    // 3. Create Health Records
    await HealthRecord.create({
      animalId: buffalo1._id,
      recordType: 'Vaccination',
      description: 'FMD Vaccine administered.',
      veterinarianId: vet._id,
    });

    // 4. Create a Case
    await Case.create({
      animalId: buffalo2._id,
      animalType: 'Buffalo',
      symptoms: ['Fever', 'Lethargy', 'Skin lesions'],
      diseasePrediction: 'Lumpy Skin Disease',
      confidenceScore: 88,
      severity: 'High',
      riskPercentage: 85,
      area: 'MG Road',
      streetName: 'Main St',
      pincode: '520010',
      latitude: 16.5115,
      longitude: 80.6441,
      description: 'Multiple lesions observed on the skin.',
      status: 'Reported',
      userId: farmer._id,
      emergency: true,
      alertLevel: 'High',
    });

    console.log('Seeding completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
}

seedDatabase();
