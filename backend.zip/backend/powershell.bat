@"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" %*
