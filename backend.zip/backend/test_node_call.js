const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

async function testCall() {
  const formData = new FormData();
  formData.append('requestId', 'req_test_123');
  formData.append('image', fs.createReadStream('../ml-service/real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png'));
  
  try {
    const res = await axios.post('http://127.0.0.1:5000/predict', formData, {
      headers: { ...formData.getHeaders() },
      timeout: 10000
    });
    console.log("Success! Status:", res.status, "isBuffalo:", res.data.isBuffalo, "Prediction:", res.data.prediction);
  } catch (err) {
    console.error("Axios call failed:", err.message);
    if (err.response) {
      console.error("Response data:", err.response.data);
      console.error("Response status:", err.response.status);
    }
  }
}

testCall();
