import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Star, MessageSquare, Trash2, Edit3, ShieldAlert, CheckCircle2, User, Send } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../context/LanguageContext';

export default function Reviews() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editRating, setEditRating] = useState(5);
  const [editText, setEditText] = useState('');
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get('/api/reviews');
      if (data && data.reviews) {
        setReviews(data.reviews);
      }
    } catch (err) {
      console.error('Fetch reviews error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!reviewText.trim()) return;
    setSubmitting(true);
    setMessage(null);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      const { data } = await axios.post('/api/reviews', {
        rating,
        reviewText: reviewText.trim()
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (data.success) {
        setMessage('Thank you for sharing your experience!');
        setReviewText('');
        setRating(5);
        fetchReviews();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit review. Please sign in to write a review.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdate = async (id) => {
    if (!editText.trim()) return;
    try {
      const token = localStorage.getItem('token');
      const { data } = await axios.put(`/api/reviews/${id}`, {
        rating: editRating,
        reviewText: editText.trim()
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (data.success) {
        setEditingId(null);
        fetchReviews();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update review.');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete your review?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/api/reviews/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchReviews();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete review.');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-emerald-900 rounded-3xl p-8 text-white shadow-lg space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-700/60 rounded-full text-xs font-bold uppercase tracking-wider text-teal-200 backdrop-blur-md">
          <Star className="w-4 h-4 text-amber-300 fill-amber-300" />
          {t('reviews.badge', 'User Experience & Integrity')}
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight">{t('reviews.title', 'Platform Feedback & Reviews')}</h1>
        <p className="text-teal-100 text-sm max-w-2xl leading-relaxed">
          {t('reviews.subtitle', 'Real feedback from animal owners, field volunteers, NGOs, and veterinarians using the Buffalo Health Risk Intelligence platform.')}
        </p>
      </div>

      {/* Write a Review Section */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-bold text-base text-slate-800 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-emerald-600" />
          <span>{t('reviews.writeReviewTitle', 'Share Your Feedback')}</span>
        </h3>

        {message && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{message}</span>
          </div>
        )}

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">{t('reviews.ratingLabel', 'Overall Rating')}</label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onClick={() => setRating(star)}
                  className="p-1 hover:scale-110 transition"
                >
                  <Star className={`w-6 h-6 ${star <= rating ? 'text-amber-400 fill-amber-400' : 'text-slate-300'}`} />
                </button>
              ))}
              <span className="text-xs font-bold text-slate-600 ml-2">{rating} {t('reviews.ofStars', 'of 5 stars')}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">{t('reviews.reviewTextLabel', 'Your Review & Comments')}</label>
            <textarea
              rows={3}
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              placeholder={t('reviews.reviewPlaceholder', 'Write your genuine experience with disease predictions, risk maps, health records, or assistance...')}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
              required
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm"
          >
            <Send className="w-4 h-4" />
            <span>{submitting ? t('reviews.submitting', 'Submitting...') : t('reviews.submitBtn', 'Submit Feedback')}</span>
          </button>
        </form>
      </div>

      {/* Reviews Display List */}
      <div className="space-y-4">
        <h3 className="font-bold text-base text-slate-900">{t('reviews.recentReviews', 'Community Reviews')}</h3>

        {loading ? (
          <div className="py-12 text-center text-xs font-bold text-slate-500">{t('reviews.loading', 'Loading feedback...')}</div>
        ) : reviews.length === 0 ? (
          <div className="bg-slate-50 border border-slate-200 p-12 rounded-3xl text-center space-y-2">
            <Star className="w-10 h-10 text-slate-300 mx-auto" />
            <h4 className="font-bold text-slate-700 text-sm">{t('reviews.noReviews', 'No reviews yet')}</h4>
            <p className="text-xs text-slate-500">{t('reviews.noReviewsDesc', 'Be the first to share your experience with the platform.')}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {reviews.map((rev) => {
              const isOwner = user && (user.id === rev.userId || user._id === rev.userId);
              return (
                <div key={rev._id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-sm border border-emerald-300">
                        {rev.userName ? rev.userName.charAt(0).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{rev.userName}</span>
                          <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                            {rev.userRole}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {new Date(rev.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star key={s} className={`w-4 h-4 ${s <= rev.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200'}`} />
                      ))}
                    </div>
                  </div>

                  {editingId === rev._id ? (
                    <div className="space-y-3 pt-2">
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <button key={s} type="button" onClick={() => setEditRating(s)}>
                            <Star className={`w-5 h-5 ${s <= editRating ? 'text-amber-400 fill-amber-400' : 'text-slate-300'}`} />
                          </button>
                        ))}
                      </div>
                      <textarea
                        rows={2}
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                      />
                      <div className="flex gap-2">
                        <button onClick={() => handleUpdate(rev._id)} className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold">{t('reviews.save', 'Save')}</button>
                        <button onClick={() => setEditingId(null)} className="px-4 py-1.5 bg-slate-200 text-slate-700 rounded-lg text-xs font-bold">{t('records.cancel', 'Cancel')}</button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-700 leading-relaxed font-medium">{rev.reviewText}</p>
                  )}

                  {isOwner && editingId !== rev._id && (
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-3 text-xs">
                      <button
                        onClick={() => {
                          setEditingId(rev._id);
                          setEditRating(rev.rating);
                          setEditText(rev.reviewText);
                        }}
                        className="text-slate-500 hover:text-emerald-700 flex items-center gap-1 font-semibold"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> {t('reviews.edit', 'Edit')}
                      </button>
                      <button
                        onClick={() => handleDelete(rev._id)}
                        className="text-rose-500 hover:text-rose-700 flex items-center gap-1 font-semibold"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> {t('caseDetail.delete', 'Delete')}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
