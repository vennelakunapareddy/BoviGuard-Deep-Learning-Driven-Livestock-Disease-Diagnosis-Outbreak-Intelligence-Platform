import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Phone, MapPin, ShieldCheck, Bell, Lock, LogOut, Save, CheckCircle2, AlertTriangle, Loader, Camera, Shield, Globe } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../context/LanguageContext';
import { getServerUrl, setServerUrl } from '../api';

export default function Settings() {
  const { t } = useTranslation();
  const token = localStorage.getItem('token');
  const navigate = useNavigate();
  const { logout } = useAuth();

  const [serverIp, setLocalServerIp] = useState(getServerUrl() || 'http://192.168.0.100:3000');
  const [testingServer, setTestingServer] = useState(false);
  const [serverStatus, setServerStatus] = useState(null);

  const testServerConnection = async (targetUrl) => {
    setTestingServer(true);
    setServerStatus(null);
    const cleanUrl = (targetUrl || serverIp).trim().replace(/\/+$/, '');
    try {
      const res = await fetch(`${cleanUrl}/api/health`, { method: 'GET' });
      if (res.ok) {
        const data = await res.json();
        setServerStatus({ ok: true, msg: `Connected successfully! Service: ${data.service || 'backend'}, Status: ${data.status}` });
      } else {
        setServerStatus({ ok: false, msg: `Server responded with HTTP ${res.status}` });
      }
    } catch (e) {
      setServerStatus({ ok: false, msg: `Connection failed: ${e.message}. Ensure PC and phone are on same Wi-Fi.` });
    } finally {
      setTestingServer(false);
    }
  };

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  // Password Change State
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [passwords, setPasswords] = useState({ current: '', newPass: '', confirm: '' });

  // User Profile State
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'Animal Owner',
    avatar: '',
    area: '',
    streetName: '',
    pincode: '',
    emergencyContactConsent: false,
    notificationPreferences: {
      smsAlerts: true,
      emailAlerts: true,
      redZoneAlerts: true
    }
  });

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (data && data.user) {
        setProfile({
          name: data.user.name || '',
          email: data.user.email || '',
          phone: data.user.phone || '',
          role: data.user.role || 'Animal Owner',
          avatar: data.user.avatar || '',
          area: data.user.area || '',
          streetName: data.user.streetName || '',
          pincode: data.user.pincode || '',
          emergencyContactConsent: Boolean(data.user.emergencyContactConsent),
          notificationPreferences: data.user.notificationPreferences || { smsAlerts: true, emailAlerts: true, redZoneAlerts: true }
        });
      }
    } catch (err) {
      console.error('Could not load profile:', err);
      setError('Failed to load profile data.');
    } finally {
      setLoading(false);
    }
  };

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const { data } = await axios.put('/api/auth/profile', {
        name: profile.name,
        phone: profile.phone,
        role: profile.role,
        avatar: profile.avatar,
        area: profile.area,
        streetName: profile.streetName,
        pincode: profile.pincode,
        emergencyContactConsent: profile.emergencyContactConsent,
        notificationPreferences: profile.notificationPreferences
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (data && data.success) {
        setSuccess('Profile updated successfully.');
        const stored = JSON.parse(localStorage.getItem('user') || '{}');
        localStorage.setItem('user', JSON.stringify({ ...stored, ...data.user }));
        setTimeout(() => setSuccess(''), 4000);
      }
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to update profile. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  if (loading) return (
    <div className="py-20 text-center text-xs font-bold text-slate-500">
      Loading profile information...
    </div>
  );

  const isEmergencyEligible = ['Volunteer', 'Veterinarian', 'NGO', 'volunteer', 'veterinarian', 'ngo'].includes(profile.role);

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      {/* Toast Notification */}
      {success && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-3 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-3 animate-in fade-in">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* 1. Profile Header Card */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="w-20 h-20 rounded-3xl bg-emerald-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-lg shadow-emerald-600/30 overflow-hidden border-2 border-white">
              {profile.avatar ? (
                <img src={profile.avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                profile.name ? profile.name.charAt(0).toUpperCase() : 'U'
              )}
            </div>
            <button className="absolute -bottom-1 -right-1 p-2 bg-slate-900 text-white rounded-xl shadow-md hover:bg-slate-800 transition">
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>

          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">{profile.name || t('roles.buffalo_owner', 'Buffalo Owner')}</h1>
            <p className="text-xs text-slate-500 font-medium">{profile.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-extrabold rounded-full border border-emerald-200">
                {t(`roles.${profile.role}`, profile.role)}
              </span>
              {profile.area && (
                <span className="text-xs text-slate-500 font-semibold flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" /> {profile.area}
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={handleProfileSave}
          disabled={saving}
          className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl transition flex items-center gap-2 shadow-md shadow-emerald-600/20 disabled:opacity-50"
        >
          {saving ? <Loader className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>{saving ? '...' : t('settings.saveChangesBtn', 'Save Profile Changes')}</span>
        </button>
      </div>

      <form onSubmit={handleProfileSave} className="space-y-6">
        
        {/* 2. Personal Information Section */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <User className="w-4 h-4 text-emerald-600" /> {t('settings.profileInfo', 'Profile Information')}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.fullName', 'Full Name')} *</label>
              <input
                type="text"
                value={profile.name}
                onChange={e => setProfile(p => ({ ...p, name: e.target.value }))}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.emailAddress', 'Email Address')}</label>
              <input
                type="email"
                value={profile.email}
                disabled
                className="w-full p-3 bg-slate-100 border border-slate-200 rounded-xl text-xs font-semibold text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.phoneNumber', 'Phone Number')}</label>
              <input
                type="tel"
                value={profile.phone}
                onChange={e => setProfile(p => ({ ...p, phone: e.target.value }))}
                placeholder="+91 94410 97544"
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.role', 'Role')}</label>
              <select
                value={profile.role}
                onChange={e => setProfile(p => ({ ...p, role: e.target.value }))}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="buffalo_owner">{t('roles.buffalo_owner', 'Buffalo Owner')}</option>
                <option value="volunteer">{t('roles.volunteer', 'Volunteer')}</option>
                <option value="veterinarian">{t('roles.veterinarian', 'Veterinarian')}</option>
                <option value="ngo">{t('roles.ngo', 'NGO')}</option>
                <option value="system_admin">{t('roles.system_admin', 'System Admin')}</option>
              </select>
            </div>
          </div>
        </div>

        {/* 3. Location Information Section */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-600" /> {t('map.location', 'Location Details')}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.areaVillage', 'Area / Village')}</label>
              <input
                type="text"
                value={profile.area}
                onChange={e => setProfile(p => ({ ...p, area: e.target.value }))}
                placeholder="e.g. Ibrahimpatnam"
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.streetName', 'Street / Colony')}</label>
              <input
                type="text"
                value={profile.streetName}
                onChange={e => setProfile(p => ({ ...p, streetName: e.target.value }))}
                placeholder="e.g. Canal Road"
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('settings.pincode', 'Pincode')}</label>
              <input
                type="text"
                maxLength={6}
                value={profile.pincode}
                onChange={e => setProfile(p => ({ ...p, pincode: e.target.value }))}
                placeholder="521225"
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* 4. Emergency Assistance Participation Section */}
        {isEmergencyEligible && (
          <div className="bg-emerald-50/60 border border-emerald-200 rounded-3xl p-6 space-y-3">
            <h3 className="font-bold text-sm text-emerald-950 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" /> {t('emergencyDirectory.title', 'Emergency Assistance Directory')}
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {t('settings.emergencyConsent', 'Allow phone number to appear in Public Emergency Directory for dairy farmers')}
            </p>

            <label className="flex items-start gap-3 cursor-pointer pt-2">
              <input
                type="checkbox"
                checked={profile.emergencyContactConsent}
                onChange={e => setProfile(p => ({ ...p, emergencyContactConsent: e.target.checked }))}
                className="mt-0.5 h-4 w-4 text-emerald-600 rounded"
              />
              <span className="text-xs font-bold text-slate-800">
                {t('auth.emergencyConsent', 'Allow to share contact details in Emergency Contacts directory')}
              </span>
            </label>
          </div>
        )}

        {/* 5. Preferences Section */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Bell className="w-4 h-4 text-emerald-600" /> {t('settings.notifications', 'Notification Preferences')}
          </h3>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl cursor-pointer">
              <div>
                <span className="text-xs font-bold text-slate-800 block">{t('settings.redZoneAlerts', 'Live Red Zone Epidemic Warnings')}</span>
                <span className="text-[11px] text-slate-500">{t('settings.smsAlerts', 'SMS Outbreak Notifications')}</span>
              </div>
              <input
                type="checkbox"
                checked={profile.notificationPreferences?.smsAlerts ?? true}
                onChange={e => setProfile(p => ({
                  ...p,
                  notificationPreferences: { ...p.notificationPreferences, smsAlerts: e.target.checked }
                }))}
                className="h-4 w-4 text-emerald-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl cursor-pointer">
              <div>
                <span className="text-xs font-bold text-slate-800 block">{t('settings.emailAlerts', 'Email Alerts & Case Summaries')}</span>
                <span className="text-[11px] text-slate-500">{t('reports.subtitle', 'Surveillance logs and reports')}</span>
              </div>
              <input
                type="checkbox"
                checked={profile.notificationPreferences?.emailAlerts ?? true}
                onChange={e => setProfile(p => ({
                  ...p,
                  notificationPreferences: { ...p.notificationPreferences, emailAlerts: e.target.checked }
                }))}
                className="h-4 w-4 text-emerald-600 rounded"
              />
            </label>
          </div>
        </div>

        {/* 6. Backend Server Connection (Mobile Wi-Fi) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Globe className="w-4 h-4 text-emerald-600" /> Backend Server IP & Network
          </h3>
          <p className="text-xs text-slate-500 font-medium">
            Configure the PC server address for live data and PyTorch ML predictions over Wi-Fi.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={serverIp}
              onChange={(e) => setLocalServerIp(e.target.value)}
              placeholder="http://192.168.0.100:3000"
              className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button
              type="button"
              onClick={() => {
                setServerUrl(serverIp);
                setSuccess('Backend server address updated successfully.');
                setTimeout(() => setSuccess(''), 4000);
              }}
              className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition"
            >
              Save Server IP
            </button>
            <button
              type="button"
              disabled={testingServer}
              onClick={() => testServerConnection(serverIp)}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-900 text-slate-200 font-bold text-xs rounded-xl shadow-sm transition disabled:opacity-50"
            >
              {testingServer ? 'Testing...' : 'Test Connection'}
            </button>
          </div>
          {serverStatus && (
            <div className={`p-3 rounded-xl text-xs font-bold ${
              serverStatus.ok ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
            }`}>
              {serverStatus.ok ? '✓ ' : '⚠️ '}
              {serverStatus.msg}
            </div>
          )}
        </div>

        {/* 7. Security Section */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-600" /> {t('settings.security', 'Security & Password')}
          </h3>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-800 block">{t('settings.changePassword', 'Change Account Password')}</span>
              <span className="text-[11px] text-slate-500">{t('auth.password', 'Password')}</span>
            </div>
            <button
              type="button"
              onClick={() => setShowPasswordForm(!showPasswordForm)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
            >
              {showPasswordForm ? t('reviews.cancel', 'Cancel') : t('settings.changePassword', 'Change Password')}
            </button>
          </div>

          {showPasswordForm && (
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <input type="password" placeholder={t('settings.currentPassword', 'Current Password')} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold" />
              <input type="password" placeholder={t('settings.newPassword', 'New Password')} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold" />
              <input type="password" placeholder={t('settings.confirmPassword', 'Confirm New Password')} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold" />
              <button type="button" onClick={() => { setSuccess(t('settings.passwordUpdated', 'Password updated successfully.')); setShowPasswordForm(false); }} className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl">
                {t('settings.updatePasswordBtn', 'Update Password')}
              </button>
            </div>
          )}

          <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
            <span className="text-xs font-bold text-slate-600">{t('nav.signOut', 'Sign Out')}</span>
            <button
              type="button"
              onClick={handleLogout}
              className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl border border-rose-200 transition flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" /> {t('nav.signOut', 'Sign Out')}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
