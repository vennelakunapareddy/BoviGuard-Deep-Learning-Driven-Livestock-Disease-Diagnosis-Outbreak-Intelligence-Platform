import React, { useEffect, useState } from 'react';
import { 
  Stethoscope, 
  MapPin, 
  PhoneCall, 
  ShieldCheck, 
  UserPlus, 
  Building2, 
  X, 
  CheckCircle2, 
  AlertCircle,
  Users,
  Search,
  Check
} from 'lucide-react';
import axios from 'axios';
import { useTranslation } from '../context/LanguageContext';

export default function EmergencyContacts() {
  const { t } = useTranslation();
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [roleFilter, setRoleFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Registration Modal State
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [regSuccess, setRegSuccess] = useState('');
  const [regError, setRegError] = useState('');

  const [form, setForm] = useState({
    name: '',
    phone: '',
    role: 'Volunteer',
    area: '',
    district: 'Krishna',
    availabilityStatus: 'available',
    organization: '',
    consent: true
  });

  useEffect(() => {
    fetchEmergencyContacts();
  }, []);

  const fetchEmergencyContacts = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const { data } = await axios.get('/api/users/emergency-contacts', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const list = Array.isArray(data) ? data : data.contacts || [];
      setContacts(list);
    } catch (err) {
      console.error('Error fetching emergency contacts:', err);
      setContacts([]);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    setRegError('');
    setRegSuccess('');

    if (!form.name.trim() || !form.phone.trim() || !form.area.trim()) {
      setRegError('Please provide your name, phone number, and area.');
      return;
    }

    setSubmitting(true);
    try {
      // 1. Register as volunteer
      await axios.post('/api/volunteers/register', {
        name: form.name.trim(),
        phone: form.phone.trim(),
        area: form.area.trim(),
        district: form.district.trim(),
        role: form.role,
        availabilityStatus: form.availabilityStatus,
        latitude: 16.5062,
        longitude: 80.6480
      });

      // 2. Also try updating user profile if logged in
      const token = localStorage.getItem('token');
      if (token) {
        try {
          await axios.put('/api/users/profile', {
            emergencyContactConsent: true,
            phone: form.phone.trim(),
            area: form.area.trim()
          }, {
            headers: { Authorization: `Bearer ${token}` }
          });
        } catch (ignored) {}
      }

      setRegSuccess('You have been registered successfully into the Emergency Support Directory!');
      setForm({
        name: '',
        phone: '',
        role: 'Volunteer',
        area: '',
        district: 'Krishna',
        availabilityStatus: 'available',
        organization: '',
        consent: true
      });

      // Refresh list
      await fetchEmergencyContacts();
      setTimeout(() => {
        setShowRegisterModal(false);
        setRegSuccess('');
      }, 2000);

    } catch (err) {
      setRegError(err?.response?.data?.message || 'Failed to register. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = contacts.filter(c => {
    if (roleFilter !== 'All') {
      if (roleFilter === 'Animal Owner' && !(c.role === 'Animal Owner' || c.role === 'Farmer' || c.role === 'Dairy Farmer')) {
        return false;
      }
      if (roleFilter === 'Veterinarian' && !(c.role === 'Veterinarian' || c.role === 'Para-Veterinarian')) {
        return false;
      }
      if (roleFilter === 'Volunteer' && !(c.role === 'Volunteer' || c.role?.toLowerCase().includes('volunteer') || c.role === 'Para-Veterinary Officer')) {
        return false;
      }
      if (roleFilter === 'NGO' && c.role !== 'NGO') {
        return false;
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = c.name?.toLowerCase().includes(q);
      const matchArea = c.area?.toLowerCase().includes(q);
      const matchPhone = c.phone?.toLowerCase().includes(q);
      const matchRole = c.role?.toLowerCase().includes(q);
      return matchName || matchArea || matchPhone || matchRole;
    }

    return true;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-teal-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl space-y-4 border border-emerald-800/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-800/80 rounded-full text-xs font-bold uppercase tracking-wider text-emerald-200 backdrop-blur-md">
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              {t('emergencyDirectory.badge', 'Real Verified Directory & Live Responders')}
            </div>
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight mt-2">
              {t('emergencyDirectory.title', 'Emergency Assistance Directory')}
            </h1>
            <p className="text-emerald-100/90 text-xs sm:text-sm max-w-2xl mt-1 leading-relaxed">
              {t('emergencyDirectory.subtitle', 'Direct emergency contacts for registered livestock owners, veterinarians, and field volunteers with explicit phone sharing consent for rapid outbreak containment.')}
            </p>
          </div>

          <button
            onClick={() => setShowRegisterModal(true)}
            className="px-5 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-2xl text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition active:scale-95 shrink-0 self-start md:self-auto"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t('emergencyDirectory.registerVolunteerBtn', 'Register as Volunteer')}</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative max-w-md pt-2">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder={t('emergencyDirectory.searchPlaceholder', 'Search by name, area, or phone number...')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/60 border border-emerald-700/50 rounded-xl pl-10 pr-4 py-2 text-xs font-medium text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-400"
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { key: 'All', label: `${t('emergencyDirectory.allRegistered', 'All Registered')} (${contacts.length})` },
          { key: 'Volunteer', label: t('emergencyDirectory.fieldVolunteers', 'Field Volunteers') },
          { key: 'Veterinarian', label: t('emergencyDirectory.veterinarians', 'Veterinarians') },
          { key: 'Animal Owner', label: t('emergencyDirectory.dairyFarmers', 'Dairy Farmers') },
          { key: 'NGO', label: t('emergencyDirectory.ngoWelfare', 'NGOs & Welfare') }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setRoleFilter(tab.key)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              roleFilter === tab.key 
                ? 'bg-emerald-600 text-white shadow-sm' 
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Contact Cards Grid */}
      {loading ? (
        <div className="py-20 text-center text-xs font-bold text-slate-500">
          {t('emergencyDirectory.loading', 'Loading real verified emergency contacts...')}
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 p-12 rounded-3xl text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Users className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-extrabold text-slate-800">{t('emergencyDirectory.noContacts', 'No Volunteer Contacts In This Category')}</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {t('emergencyDirectory.noContactsDesc', 'Only real registered responders who have provided phone details are displayed. Be the first to register in your area!')}
            </p>
          </div>
          <button
            onClick={() => setShowRegisterModal(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t('emergencyDirectory.registerNow', 'Register as Volunteer Now')}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((c) => (
            <div 
              key={c._id || c.id || c.phone} 
              className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-emerald-400 shadow-sm transition space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-emerald-100 text-emerald-800 font-extrabold flex items-center justify-center text-sm border-2 border-emerald-300">
                      {c.name ? c.name.charAt(0).toUpperCase() : 'V'}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 leading-snug">{c.name}</h3>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {c.role || 'Registered User'}
                      </span>
                    </div>
                  </div>

                  <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-extrabold rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    {c.availabilityStatus === 'available' ? t('emergencyDirectory.available', 'Available') : (c.availabilityStatus === 'busy' ? t('emergencyDirectory.busy', 'Busy') : (c.availabilityStatus || 'Active'))}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
                  {c.area ? (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="font-semibold text-slate-800">{c.area}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-slate-400">
                      <MapPin className="w-4 h-4 shrink-0" />
                      <span>Vijayawada / Andhra Pradesh</span>
                    </div>
                  )}

                  {c.organization && (
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-400 shrink-0" />
                      <span className="text-slate-700">{c.organization}</span>
                    </div>
                  )}
                </div>
              </div>

              {c.phone ? (
                <a
                  href={`tel:${c.phone}`}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs flex items-center justify-center gap-2 transition shadow-sm active:scale-95"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>{t('emergencyDirectory.callNow', 'Call')} {c.phone}</span>
                </a>
              ) : (
                <div className="py-2 text-center text-xs text-slate-400 font-bold bg-slate-100 rounded-xl">
                  {t('emergencyDirectory.phoneUnavailable', 'Phone Unavailable')}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ========================================================================= */}
      {/* VOLUNTEER REGISTRATION MODAL */}
      {/* ========================================================================= */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 p-6 sm:p-8 space-y-6">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">{t('emergencyDirectory.modalTitle', 'Register in Emergency Support Directory')}</h3>
                  <p className="text-xs text-slate-500">{t('emergencyDirectory.modalSubtitle', 'Help nearby dairy farmers and veterinary teams during outbreak emergencies in your district.')}</p>
                </div>
              </div>
              <button 
                onClick={() => setShowRegisterModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {regSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{regSuccess}</span>
              </div>
            )}

            {regError && (
              <div className="p-3 bg-rose-50 border border-rose-300 text-rose-900 rounded-xl text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{regError}</span>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-700 mb-1">{t('emergencyDirectory.nameLabel', 'Full Name')} *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 mb-1">{t('emergencyDirectory.phoneLabel', 'Phone Number (Direct Calls)')} *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9441097544"
                    value={form.phone}
                    onChange={e => setForm({ ...form, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 mb-1">{t('emergencyDirectory.roleLabel', 'Community Role')}</label>
                  <select
                    value={form.role}
                    onChange={e => setForm({ ...form, role: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="Volunteer">{t('emergencyDirectory.fieldVolunteers', 'Field Volunteers')}</option>
                    <option value="Para-Veterinarian">{t('roles.veterinarian', 'Veterinarian')} (Para-Vet)</option>
                    <option value="Veterinarian">{t('roles.veterinarian', 'Veterinarian')}</option>
                    <option value="Animal Owner">{t('emergencyDirectory.dairyFarmers', 'Dairy Farmers')}</option>
                    <option value="NGO">{t('emergencyDirectory.ngoWelfare', 'NGOs & Welfare')}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 mb-1">{t('emergencyDirectory.areaLabel', 'Area / Village')} *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Benz Circle, Vijayawada"
                    value={form.area}
                    onChange={e => setForm({ ...form, area: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 mb-1">{t('emergencyDirectory.availabilityLabel', 'Availability')}</label>
                  <select
                    value={form.availabilityStatus}
                    onChange={e => setForm({ ...form, availabilityStatus: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="available">{t('emergencyDirectory.available', 'Available')} (24x7)</option>
                    <option value="on-call">{t('emergencyDirectory.available', 'Available')} (On-Call)</option>
                    <option value="unavailable">{t('emergencyDirectory.busy', 'Busy')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-1">{t('emergencyDirectory.orgLabel', 'Organization / Clinic (Optional)')}</label>
                <input
                  type="text"
                  placeholder="e.g. Krishna Milk Producers Cooperative"
                  value={form.organization}
                  onChange={e => setForm({ ...form, organization: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-2.5">
                <input
                  type="checkbox"
                  id="consentCheckbox"
                  checked={form.consent}
                  onChange={e => setForm({ ...form, consent: e.target.checked })}
                  className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="consentCheckbox" className="text-[11px] text-slate-600 font-medium leading-snug cursor-pointer">
                  {t('emergencyDirectory.consentNotice', 'I explicitly consent to publish my contact number in this directory for emergency veterinary and herd assistance during outbreaks.')}
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2.5 text-slate-600 hover:text-slate-900 font-bold transition text-xs"
                >
                  {t('records.cancel', 'Cancel')}
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl transition shadow active:scale-95 disabled:opacity-60 text-xs flex items-center gap-2"
                >
                  {submitting ? t('emergencyDirectory.submitting', 'Registering Responder...') : t('emergencyDirectory.submitBtn', 'Complete Volunteer Registration')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
