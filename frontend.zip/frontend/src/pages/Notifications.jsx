import React, { useState, useEffect } from 'react';
import { Bell, CheckCircle, AlertTriangle, Info, ShieldAlert, Loader } from 'lucide-react';
import axios from 'axios';
import { useTranslation } from '../context/LanguageContext';

export default function Notifications() {
  const { t } = useTranslation();
  const token = localStorage.getItem('token');
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setLoading(true);
    setError('');
    try {
      // Pull alerts from backend (red alert engine) + user's case updates
      const [alertsRes, casesRes] = await Promise.all([
        axios.get('/api/alerts', { headers: token ? { Authorization: `Bearer ${token}` } : {} }),
        axios.get('/api/cases?mine=true', { headers: token ? { Authorization: `Bearer ${token}` } : {} }),
      ]);
      const alerts = (alertsRes.data || []).map(a => ({
        id: a._id || a.id || Math.random(),
        type: a.alertLevel === 'Critical' || a.alertLevel === 'High' ? 'critical' : 'warning',
        title: `${a.alertLevel} Alert: ${a.disease} Cluster`,
        body: `${a.totalCases} cases in ${a.area}. Immediate attention required.`,
        time: a.createdAt ? new Date(a.createdAt).toLocaleString() : 'Recently',
        read: false,
      }));
      const caseUpdates = (casesRes.data || []).slice(0, 5).map(c => ({
        id: c._id || c.id,
        type: c.status === 'Resolved' ? 'success' : c.severity === 'High' ? 'critical' : 'info',
        title: `Case #${String(c._id || c.id).slice(-6).toUpperCase()} — ${c.status}`,
        body: `${c.diseasePrediction} in ${c.area}. Severity: ${c.severity}.`,
        time: c.createdAt ? new Date(c.createdAt).toLocaleString() : '',
        read: c.status === 'Resolved',
      }));
      setNotifications([...alerts, ...caseUpdates]);
    } catch (err) {
      setError('Could not load notifications. ' + (err?.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const iconMap = {
    critical: <ShieldAlert className="w-5 h-5 text-red-500" />,
    warning: <AlertTriangle className="w-5 h-5 text-orange-400" />,
    success: <CheckCircle className="w-5 h-5 text-green-500" />,
    info: <Info className="w-5 h-5 text-brand-primary" />,
  };
  const bgMap = {
    critical: 'border-l-4 border-red-500 bg-red-500/5',
    warning: 'border-l-4 border-orange-400 bg-orange-400/5',
    success: 'border-l-4 border-green-500 bg-green-500/5',
    info: 'border-l-4 border-brand-primary bg-brand-primary/5',
  };

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in duration-500">
      <div className="mb-8 flex justify-between items-end flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-brand-text flex items-center gap-3">
            <Bell className="text-brand-primary" /> {t('notificationsPage.title', 'Notification Center')}
            {unreadCount > 0 && (
              <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>
            )}
          </h1>
          <p className="text-brand-muted mt-2">{t('notificationsPage.subtitle', 'System alerts, case updates, and veterinary responses.')}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchNotifications} className="btn-outline text-sm flex items-center gap-2">
            {t('notificationsPage.refresh', 'Refresh')}
          </button>
          <button onClick={markAllRead} className="btn-outline text-sm flex items-center gap-2" disabled={unreadCount === 0}>
            <CheckCircle className="w-4 h-4" /> {t('notificationsPage.markAllRead', 'Mark all as read')}
          </button>
        </div>
      </div>

      {loading ? (
        <div className="glass-card p-12 text-center">
          <Loader className="w-8 h-8 animate-spin text-brand-primary mx-auto mb-3" />
          <p className="text-brand-muted">{t('emergencyDirectory.loading', 'Loading notifications...')}</p>
        </div>
      ) : error ? (
        <div className="glass-card p-8 text-center text-red-400">
          <AlertTriangle className="w-8 h-8 mx-auto mb-3" />
          <p>{error}</p>
          <button onClick={fetchNotifications} className="btn-primary mt-4">{t('assistant.retryBtn', 'Retry')}</button>
        </div>
      ) : notifications.length === 0 ? (
        <div className="glass-card border-slate-200 p-12 text-center text-brand-muted">
          <Bell className="w-12 h-12 mx-auto mb-4 text-slate-300" />
          <h3 className="text-lg font-bold text-brand-text mb-2">{t('notificationsPage.noNotifications', 'No notifications found.')}</h3>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map(n => (
            <div
              key={n.id}
              className={`glass-card p-5 flex gap-4 items-start transition cursor-pointer ${bgMap[n.type] || ''} ${n.read ? 'opacity-60' : ''}`}
              onClick={() => setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x))}
            >
              <div className="mt-0.5 shrink-0">{iconMap[n.type]}</div>
              <div className="flex-1">
                <div className="flex justify-between items-start gap-2">
                  <p className={`font-bold text-sm ${n.read ? 'text-brand-muted' : 'text-brand-text'}`}>{n.title}</p>
                  <span className="text-xs text-brand-muted shrink-0">{n.time}</span>
                </div>
                <p className="text-sm text-brand-muted mt-1">{n.body}</p>
              </div>
              {!n.read && <div className="w-2 h-2 rounded-full bg-brand-primary mt-2 shrink-0" />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
