import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { 
  ShieldAlert, 
  Mail, 
  Lock, 
  Phone, 
  User, 
  LogIn, 
  UserPlus, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Sparkles, 
  ArrowRight, 
  Globe,
  KeyRound,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../context/LanguageContext';
import BoviGuardLogo from '../components/BoviGuardLogo';

export default function Auth() {
  const { t, language, changeLanguage } = useTranslation();
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  // Forgot password modal & reset state
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotStep, setForgotStep] = useState('email'); // 'email' | 'code'
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotCode, setForgotCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');
  const [previewUrl, setPreviewUrl] = useState(null);
  const [sentCodeNotice, setSentCodeNotice] = useState(null);

  const { login, register } = useAuth();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'Buffalo Owner',
    emergencyContactConsent: true,
    password: ''
  });

  const handleChange = (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setFormData({ ...formData, [e.target.name]: value });
  };

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      if (isLogin) {
        await login(formData.email, formData.password);
      } else {
        await register(formData);
      }
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || t('auth.authFailed', 'Authentication failed. Please check your credentials.'));
    } finally {
      setLoading(false);
    }
  };

  const fillDemoAccount = (role) => {
    setError('');
    setMessage('');
    if (role === 'Buffalo Owner') {
      setFormData({
        name: 'Venkata Ramana (Farmer)',
        email: 'farmer@buffalohealth.org',
        phone: '',
        role: 'Buffalo Owner',
        emergencyContactConsent: false,
        password: 'Password@123'
      });
    } else if (role === 'Veterinarian') {
      setFormData({
        name: 'Dr. Suresh Kumar (BVSc)',
        email: 'vet@buffalohealth.org',
        phone: '',
        role: 'Veterinarian',
        emergencyContactConsent: false,
        password: 'Password@123'
      });
    } else if (role === 'Volunteer') {
      setFormData({
        name: 'K. Rajesh (Community Volunteer)',
        email: 'volunteer@buffalohealth.org',
        phone: '',
        role: 'Volunteer',
        emergencyContactConsent: false,
        password: 'Password@123'
      });
    } else if (role === 'NGO') {
      setFormData({
        name: 'Gowthami Dairy Animal Welfare NGO',
        email: 'ngo@buffalohealth.org',
        phone: '',
        role: 'NGO',
        emergencyContactConsent: false,
        password: 'Password@123'
      });
    } else if (role === 'System Admin') {
      setFormData({
        name: 'System Administrator',
        email: 'admin@buffalohealth.org',
        phone: '',
        role: 'System Admin',
        emergencyContactConsent: false,
        password: 'Password@123'
      });
    }
  };

  const handleSendResetCode = async (e) => {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setForgotLoading(true);
    setForgotError('');
    setForgotSuccess('');
    setPreviewUrl(null);
    setSentCodeNotice(null);

    try {
      const { data } = await axios.post('/api/auth/forgot-password', {
        email: forgotEmail.trim()
      });

      setForgotSuccess(data.message || `Password reset verification code dispatched to ${forgotEmail}.`);
      if (data.previewUrl) setPreviewUrl(data.previewUrl);
      if (data.resetCode) {
        setSentCodeNotice(data.resetCode);
        setForgotCode(data.resetCode);
      }
      setForgotStep('code');
    } catch (err) {
      setForgotError(err.response?.data?.message || 'Failed to dispatch recovery email. Please check the email address.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleResetPasswordSubmit = async (e) => {
    e.preventDefault();
    setForgotError('');
    setForgotSuccess('');

    if (!forgotCode.trim()) {
      setForgotError('Please enter the 6-digit verification code.');
      return;
    }
    if (newPassword.length < 6) {
      setForgotError('Password must be at least 6 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setForgotError('Passwords do not match. Please re-enter.');
      return;
    }

    setForgotLoading(true);
    try {
      const { data } = await axios.post('/api/auth/reset-password', {
        email: forgotEmail.trim(),
        code: forgotCode.trim(),
        newPassword
      });

      setMessage(data.message || 'Password successfully updated! Please sign in with your new password.');
      setFormData(prev => ({ ...prev, email: forgotEmail.trim(), password: newPassword }));
      setShowForgotModal(false);
      setForgotStep('email');
      setForgotEmail('');
      setForgotCode('');
      setNewPassword('');
      setConfirmPassword('');
      setForgotError('');
      setForgotSuccess('');
    } catch (err) {
      setForgotError(err.response?.data?.message || 'Failed to reset password. Please verify the code.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 flex flex-col items-center justify-start sm:justify-center p-4 sm:p-6 md:p-8 py-10 sm:py-16 relative overflow-y-auto">
      
      {/* Ambient background with buffalo herd imagery and emerald gradients */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <img 
          src="https://images.unsplash.com/photo-1546445317-29f4545f9d52?auto=format&fit=crop&w=1920&q=80" 
          alt="Buffalo Herd Background" 
          className="w-full h-full object-cover object-center opacity-20 filter blur-[1px] brightness-75 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-950/90 to-emerald-950/40" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Language Switcher Bar at top */}
      <div className="relative z-20 mb-3 flex items-center justify-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-800 shadow-lg">
        <Globe className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <button
          type="button"
          onClick={() => changeLanguage('en')}
          className={`px-2.5 py-0.5 rounded-full text-xs font-bold transition ${
            language === 'en' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          English
        </button>
        <button
          type="button"
          onClick={() => changeLanguage('te')}
          className={`px-2.5 py-0.5 rounded-full text-xs font-bold transition ${
            language === 'te' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          తెలుగు
        </button>
        <button
          type="button"
          onClick={() => changeLanguage('hi')}
          className={`px-2.5 py-0.5 rounded-full text-xs font-bold transition ${
            language === 'hi' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          हिन्दी
        </button>
      </div>

      {/* Centered Modal / Card - Fully scrollable and nicely padded */}
      <div className="relative z-10 w-full max-w-md bg-slate-900/95 backdrop-blur-2xl border border-slate-800 rounded-3xl shadow-2xl p-5 sm:p-7 space-y-4 sm:space-y-5 my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-1">
            <BoviGuardLogo size="xl" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Bovi<span className="text-emerald-400">Guard</span>
          </h1>
          <p className="text-xs font-semibold text-slate-400">
            {t('auth.brandSubtitle', 'AI-Powered Livestock Disease Intelligence & Surveillance')}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 p-1 bg-slate-950/70 border border-slate-800 rounded-2xl">
          <button
            type="button"
            onClick={() => { setIsLogin(true); setError(''); setMessage(''); }}
            className={`py-2 text-xs font-extrabold rounded-xl transition flex items-center justify-center gap-1.5 ${
              isLogin 
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" /> {t('auth.signIn', 'Sign In')}
          </button>
          <button
            type="button"
            onClick={() => { setIsLogin(false); setError(''); setMessage(''); }}
            className={`py-2 text-xs font-extrabold rounded-xl transition flex items-center justify-center gap-1.5 ${
              !isLogin 
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" /> {t('auth.createAccount', 'Create Account')}
          </button>
        </div>

        {/* Status Alerts */}
        {error && (
          <div className="p-3 bg-rose-500/15 border border-rose-500/40 rounded-xl text-xs font-semibold text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span className="flex-1">{error}</span>
          </div>
        )}
        {message && (
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-xl text-xs font-semibold text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span className="flex-1">{message}</span>
          </div>
        )}

        {/* Main Authentication Form */}
        <form onSubmit={handleAuth} className="space-y-3.5">
          {!isLogin && (
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                {t('auth.fullName', 'Full Name')} *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                <input
                  type="text"
                  name="name"
                  required={!isLogin}
                  placeholder={t('auth.fullNamePlaceholder', 'e.g. Ramesh Reddy')}
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
              {t('auth.email', 'Email Address')} *
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
              <input
                type="email"
                name="email"
                required
                placeholder={t('auth.emailPlaceholder', 'farmer@buffalohealth.org')}
                value={formData.email}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>
          </div>

          {!isLogin && (
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                {t('auth.phone', 'Phone Number (For Outbreak & Vet Alerts)')}
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                <input
                  type="tel"
                  name="phone"
                  placeholder={t('auth.phonePlaceholder', '+91 94410 97544')}
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                />
              </div>
              <div className="flex items-start gap-2 pt-2">
                <input
                  type="checkbox"
                  id="emergencyConsent"
                  name="emergencyContactConsent"
                  checked={formData.emergencyContactConsent}
                  onChange={handleChange}
                  className="mt-0.5 rounded bg-slate-950 border-slate-700 text-emerald-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="emergencyConsent" className="text-[11px] text-slate-300 leading-snug cursor-pointer select-none">
                  {t('auth.emergencyConsent', 'Allow to share contact details in Emergency Contacts directory')}
                </label>
              </div>
            </div>
          )}

          {!isLogin && (
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                {t('auth.role', 'Platform Role')} *
              </label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              >
                <option value="Buffalo Owner">{t('roles.buffalo_owner', 'Buffalo Owner')}</option>
                <option value="Veterinarian">{t('roles.veterinarian', 'Veterinarian (BVSc)')}</option>
                <option value="Volunteer">{t('roles.volunteer', 'Volunteer')}</option>
                <option value="NGO">{t('roles.ngo', 'NGO')}</option>
                <option value="System Admin">{t('roles.system_admin', 'System Admin')}</option>
              </select>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                {t('auth.password', 'Password')} *
              </label>
              {isLogin && (
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 transition"
                >
                  {t('auth.forgotPassword', 'Forgot Password?')}
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
              <input
                type="password"
                name="password"
                required
                placeholder={t('auth.passwordPlaceholder', '••••••••')}
                value={formData.password}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
            ) : isLogin ? (
              <>
                <span>{t('auth.signInBtn', 'Sign In to Dashboard')}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>{t('auth.createAccountBtn', 'Complete Registration')}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Autofill Controls for all 5 roles */}
        <div className="pt-2.5 border-t border-slate-800/80 text-center space-y-2">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> {t('auth.demoPersonas', 'One-Click Demo Personas')}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            <button
              type="button"
              onClick={() => fillDemoAccount('Buffalo Owner')}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 transition"
            >
              🐄 {t('roles.buffalo_owner', 'Buffalo Owner')}
            </button>
            <button
              type="button"
              onClick={() => fillDemoAccount('Veterinarian')}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 transition"
            >
              🩺 {t('roles.veterinarian', 'Veterinarian')}
            </button>
            <button
              type="button"
              onClick={() => fillDemoAccount('Volunteer')}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 transition"
            >
              🤝 {t('roles.volunteer', 'Volunteer')}
            </button>
            <button
              type="button"
              onClick={() => fillDemoAccount('NGO')}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 transition"
            >
              🏢 {t('roles.ngo', 'NGO')}
            </button>
            <button
              type="button"
              onClick={() => fillDemoAccount('System Admin')}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 transition"
            >
              ⚡ {t('roles.system_admin', 'System Admin')}
            </button>
          </div>
        </div>
      </div>

      {/* Forgot Password & Reset Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 max-w-md w-full space-y-5 shadow-2xl text-white">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    {forgotStep === 'email' 
                      ? t('auth.resetPasswordTitle', 'Reset Account Password') 
                      : t('auth.enterResetCode', 'Enter 6-Digit Verification Code')}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {forgotStep === 'email'
                      ? t('auth.resetPasswordDesc', 'Enter your registered email address to receive password reset instructions.')
                      : t('auth.enterResetCodeDesc', 'Check your inbox for the 6-digit recovery code and choose a new password.')}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setShowForgotModal(false);
                  setForgotStep('email');
                  setForgotError('');
                  setForgotSuccess('');
                }} 
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error Message */}
            {forgotError && (
              <div className="p-3 bg-rose-500/15 border border-rose-500/40 rounded-xl text-xs font-semibold text-rose-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="flex-1">{forgotError}</span>
              </div>
            )}

            {/* Success Message */}
            {forgotSuccess && (
              <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-xl text-xs font-semibold text-emerald-300 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="flex-1 space-y-1">
                  <span>{forgotSuccess}</span>
                  {sentCodeNotice && (
                    <div className="pt-1 flex items-center gap-2">
                      <span className="text-[11px] text-emerald-200">OTP Code:</span>
                      <span className="font-mono font-black text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30 text-xs">
                        {sentCodeNotice}
                      </span>
                    </div>
                  )}
                  {previewUrl && (
                    <div className="pt-1">
                      <a
                        href={previewUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:text-amber-200 underline"
                      >
                        <ExternalLink className="w-3 h-3" />
                        {t('auth.viewEmailPreview', 'View Sent Email Preview ↗')}
                      </a>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 1: Enter Email */}
            {forgotStep === 'email' ? (
              <form onSubmit={handleSendResetCode} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    {t('auth.email', 'Email Address')} *
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                    <input
                      type="email"
                      required
                      placeholder={t('auth.emailPlaceholder', 'farmer@buffalohealth.org')}
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={forgotLoading}
                  className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition active:scale-95"
                >
                  {forgotLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>{t('auth.sendingRecovery', 'Sending Verification Email...')}</span>
                    </>
                  ) : (
                    <>
                      <Mail className="w-4 h-4" />
                      <span>{t('auth.sendRecoveryLink', 'Send Recovery Email')}</span>
                    </>
                  )}
                </button>
              </form>
            ) : (
              /* STEP 2: Enter Code & New Password */
              <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    {t('auth.enterResetCode', '6-Digit Verification Code')} *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    placeholder={t('auth.codePlaceholder', '6-digit code (e.g. 482910)')}
                    value={forgotCode}
                    onChange={(e) => setForgotCode(e.target.value)}
                    className="w-full px-3.5 py-2 font-mono tracking-widest text-center text-lg font-black bg-slate-950 border border-emerald-500/50 rounded-xl text-emerald-400 focus:outline-none focus:border-emerald-400 transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    {t('auth.newPassword', 'New Password')} *
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                    <input
                      type="password"
                      required
                      placeholder={t('auth.newPasswordPlaceholder', 'Enter new password...')}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    {t('auth.confirmNewPassword', 'Confirm New Password')} *
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                    <input
                      type="password"
                      required
                      placeholder={t('auth.confirmNewPasswordPlaceholder', 'Confirm new password...')}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setForgotStep('email');
                      setForgotError('');
                    }}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition"
                  >
                    {t('auth.backToEmail', '← Back to Email')}
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition active:scale-95"
                  >
                    {forgotLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>{t('auth.resettingPassword', 'Updating Password...')}</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{t('auth.resetPasswordBtn', 'Update & Reset Password')}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
