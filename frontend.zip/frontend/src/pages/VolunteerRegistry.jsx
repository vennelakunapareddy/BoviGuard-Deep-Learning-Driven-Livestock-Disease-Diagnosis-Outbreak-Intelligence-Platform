import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Users, 
  PhoneCall, 
  MapPin, 
  ShieldCheck, 
  UserPlus, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Compass, 
  HeartHandshake,
  Award,
  Clock,
  Sparkles
} from 'lucide-react';
import { useTranslation } from '../context/LanguageContext';

export default function VolunteerRegistry() {
  const { t } = useTranslation();
  const [volunteers, setVolunteers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState('all');
  const [districtFilter, setDistrictFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Registration Modal State
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [registering, setRegistering] = useState(false);
  const [regSuccess, setRegSuccess] = useState('');
  const [regError, setRegError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    role: 'Para-Veterinarian',
    district: 'Krishna',
    mandal: 'Vijayawada',
    area: '',
    availabilityStatus: 'available',
    latitude: 16.5062,
    longitude: 80.6480
  });

  useEffect(() => {
    fetchVolunteers();
  }, [statusFilter, districtFilter]);

  const fetchVolunteers = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {};
      if (statusFilter !== 'all') params.status = statusFilter;
      if (districtFilter !== 'all') params.district = districtFilter;
      if (searchQuery) params.query = searchQuery;

      const { data } = await axios.get('/api/volunteers', { params });
      if (data && data.volunteers) {
        setVolunteers(data.volunteers);
      } else {
        setVolunteers([]);
      }
    } catch (err) {
      console.error('Fetch volunteers error:', err);
      setError('Unable to load volunteer registry. Please check network connectivity.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchVolunteers();
  };

  const handleFormChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const detectLocationForRegistration = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setFormData(prev => ({
            ...prev,
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude
          }));
        },
        (err) => console.warn('GPS location failed:', err),
        { timeout: 8000 }
      );
    }
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    setRegistering(true);
    setRegError('');
    setRegSuccess('');

    try {
      const { data } = await axios.post('/api/volunteers/register', formData);
      if (data.success) {
        setRegSuccess('Volunteer successfully registered in Emergency Network!');
        setTimeout(() => {
          setShowRegisterModal(false);
          setRegSuccess('');
          fetchVolunteers();
        }, 1500);
      }
    } catch (err) {
      setRegError(err.response?.data?.message || 'Failed to submit volunteer registration.');
    } finally {
      setRegistering(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-emerald-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 rounded-full text-xs font-bold uppercase tracking-wider text-emerald-300">
              <HeartHandshake className="w-4 h-4 text-emerald-400" />
              <span>{t('volunteers.badge', 'Andhra Pradesh Field Response Network')}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              {t('volunteers.title', 'Livestock Field Volunteers & Paravets')}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm font-medium leading-relaxed">
              {t('volunteers.subtitle', 'Find verified veterinary assistants, local paravets, and community volunteers available for immediate emergency on-ground assistance.')}
            </p>
          </div>

          <div className="shrink-0 w-full md:w-auto">
            <button
              onClick={() => { setShowRegisterModal(true); detectLocationForRegistration(); }}
              className="w-full sm:w-auto px-6 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition active:scale-95"
            >
              <UserPlus className="w-4 h-4" />
              <span>{t('volunteers.registerAsVolunteer', 'Register as Volunteer')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-sm flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
        
        {/* Availability Status Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: t('volunteers.allStatus', 'All Availability') },
            { id: 'available', label: `🟢 ${t('volunteers.availableBadge', 'Available')}` },
            { id: 'on-call', label: `🟡 ${t('volunteers.busyBadge', 'Engaged')}` }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                statusFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* District Filter & Search Query */}
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={districtFilter}
            onChange={(e) => setDistrictFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="all">{t('volunteers.allDistricts', 'All Districts')}</option>
            <option value="Krishna">Krishna District</option>
            <option value="Guntur">Guntur District</option>
            <option value="NTR">NTR District</option>
            <option value="West Godavari">West Godavari</option>
          </select>

          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 flex-1 sm:flex-initial">
            <div className="relative flex-1 sm:w-60">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder={t('volunteers.searchPlaceholder', 'Search volunteer name, phone, area or mandal...')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <button
              type="submit"
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition"
            >
              {t('volunteers.searchBtn', 'Search')}
            </button>
          </form>
        </div>
      </div>

      {/* Volunteer Directory Cards Grid */}
      {loading ? (
        <div className="py-24 text-center space-y-3">
          <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            {t('emergencyDirectory.loading', 'Loading emergency volunteers...')}
          </p>
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 p-6 rounded-2xl text-center space-y-2">
          <AlertCircle className="w-8 h-8 text-rose-500 mx-auto" />
          <p className="text-sm font-bold text-rose-800">{error}</p>
        </div>
      ) : volunteers.length === 0 ? (
        <div className="bg-slate-50 border border-slate-200 p-12 rounded-3xl text-center space-y-3">
          <Users className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-700">{t('volunteers.noVolunteers', 'No registered volunteers found matching criteria.')}</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {t('emergencyDirectory.noContactsDesc', 'Try switching filter tabs or click "Register as Volunteer" to join the emergency response team.')}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {volunteers.map((vol, idx) => {
            const isAvailable = vol.availabilityStatus === 'available';
            const isOnCall = vol.availabilityStatus === 'on-call';
            const cleanPhone = vol.phone ? vol.phone.replace(/[^0-9+]/g, '') : '';

            return (
              <div
                key={vol._id || idx}
                className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-emerald-500 shadow-sm hover:shadow-xl transition-all duration-200 flex flex-col justify-between space-y-5 group"
              >
                <div className="space-y-3">
                  
                  {/* Top Name & Status */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 font-black flex items-center justify-center text-lg border border-emerald-300 shadow-sm shrink-0">
                        {vol.name ? vol.name.charAt(0).toUpperCase() : 'V'}
                      </div>
                      <div>
                        <h3 className="font-extrabold text-base text-slate-900 group-hover:text-emerald-700 transition leading-snug">
                          {vol.name}
                        </h3>
                        <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 inline-block mt-0.5">
                          {vol.role || 'Para-Veterinarian'}
                        </span>
                      </div>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider shrink-0 ${
                      isAvailable 
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                        : isOnCall 
                        ? 'bg-amber-50 text-amber-700 border border-amber-200' 
                        : 'bg-slate-100 text-slate-600'
                    }`}>
                      {isAvailable ? `🟢 ${t('volunteers.availableBadge', 'Available')}` : isOnCall ? `🟡 ${t('volunteers.busyBadge', 'Engaged')}` : `⚪ ${t('volunteers.busyBadge', 'Busy')}`}
                    </span>
                  </div>

                  {/* Experience & Specialization */}
                  {vol.experience && (
                    <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs text-slate-700 font-semibold flex items-center gap-2">
                      <Award className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="truncate">{vol.experience}</span>
                    </div>
                  )}

                  {/* Location Info */}
                  <div className="space-y-1.5 text-xs text-slate-600 pt-1 font-medium">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{vol.area}{vol.mandal ? `, ${vol.mandal}` : ''} ({vol.district || 'Andhra Pradesh'})</span>
                    </div>
                  </div>
                </div>

                {/* Direct Call Button for Farmers */}
                <div className="pt-4 border-t border-slate-100">
                  {vol.phone ? (
                    <a
                      href={`tel:${cleanPhone}`}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl text-xs flex items-center justify-center gap-2 transition shadow-md shadow-emerald-600/20 active:scale-95"
                    >
                      <PhoneCall className="w-4 h-4" />
                      <span>{t('volunteers.callDirect', 'Call Direct')} ({vol.phone})</span>
                    </a>
                  ) : (
                    <div className="py-2.5 bg-slate-100 text-slate-400 font-bold rounded-xl text-xs text-center">
                      {t('emergencyDirectory.phoneUnavailable', 'Phone Protected')}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Volunteer Registration Modal */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl border border-slate-200 my-8">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">{t('volunteers.modalTitle', 'Volunteer & Para-Vet Registration')}</h3>
                  <p className="text-xs text-slate-500 font-medium">{t('volunteers.modalSubtitle', 'Join the active animal health surveillance and rapid support network.')}</p>
                </div>
              </div>
              <button
                onClick={() => setShowRegisterModal(false)}
                className="text-slate-400 hover:text-slate-600 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {regSuccess && (
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{regSuccess}</span>
              </div>
            )}
            {regError && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{regError}</span>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.fullName', 'Full Name')} *</label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. Ramesh Babu"
                  value={formData.name}
                  onChange={handleFormChange}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.phoneNumber', 'Phone Number')} *</label>
                  <input
                    type="tel"
                    name="phone"
                    required
                    placeholder="+91 94410 97544"
                    value={formData.phone}
                    onChange={handleFormChange}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.professionalRole', 'Field Role')} *</label>
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleFormChange}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Para-Veterinarian">{t('volunteers.roleParavet', 'Para-Veterinarian')}</option>
                    <option value="Veterinary Clinical Intern">{t('volunteers.roleVetAssistant', 'Veterinary Assistant')}</option>
                    <option value="Gopala Mitra">{t('volunteers.roleGopalaMitra', 'Gopala Mitra')}</option>
                    <option value="Community Animal Health Worker">{t('volunteers.roleCommunityVolunteer', 'Community Volunteer')}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.district', 'District')} *</label>
                  <select
                    name="district"
                    value={formData.district}
                    onChange={handleFormChange}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Krishna">Krishna</option>
                    <option value="Guntur">Guntur</option>
                    <option value="NTR">NTR</option>
                    <option value="West Godavari">West Godavari</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.mandal', 'Mandal')} *</label>
                  <input
                    type="text"
                    name="mandal"
                    placeholder="e.g. Gannavaram"
                    value={formData.mandal}
                    onChange={handleFormChange}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.areaVillage', 'Village / Area')} *</label>
                <input
                  type="text"
                  name="area"
                  required
                  placeholder="e.g. Dairy Milk Chilling Center, Near Highway"
                  value={formData.area}
                  onChange={handleFormChange}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 mb-1 font-bold">{t('volunteers.availabilityStatus', 'Current Availability')}</label>
                <select
                  name="availabilityStatus"
                  value={formData.availabilityStatus}
                  onChange={handleFormChange}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                >
                  <option value="available">🟢 {t('volunteers.availableNow', 'Available for Emergency Visits')}</option>
                  <option value="on-call">🟡 {t('volunteers.engagedNow', 'Currently Busy / Engaged')}</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition"
                >
                  {t('reviews.cancel', 'Cancel')}
                </button>
                <button
                  type="submit"
                  disabled={registering}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs transition shadow-md shadow-emerald-600/20 disabled:opacity-50"
                >
                  {registering ? t('emergencyDirectory.submitting', 'Registering Responder...') : t('volunteers.submitBtn', 'Register as Active Volunteer')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
