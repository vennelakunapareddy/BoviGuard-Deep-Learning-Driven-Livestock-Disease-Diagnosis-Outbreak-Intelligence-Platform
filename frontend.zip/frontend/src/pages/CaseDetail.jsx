import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Activity, 
  ArrowLeft, 
  Calendar, 
  MapPin, 
  User, 
  Stethoscope, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Edit, 
  Trash2, 
  FileText, 
  Send, 
  X, 
  AlertCircle,
  Download,
  Check
} from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { 
  getDiseaseInfo, 
  isSpreadableDisease, 
  MANDATORY_ISOLATION_INSTRUCTION,
  CLINICAL_SAMPLE_DIRECTIVES,
  DISEASE_AWARENESS
} from '../constants/diseaseInfo';
import { useTranslation } from '../context/LanguageContext';

const PRESCRIBED_LAB_TESTS = {
  Mastitis: [
    { name: 'California Mastitis Test (CMT)', type: 'Cow-side Screening', sample: 'Quarter Milk (10 mL)', purpose: 'Rapid detection of somatic cell and inflammatory reaction' },
    { name: 'Somatic Cell Count (SCC) Analysis', type: 'Laboratory Cytology', sample: 'Preserved Milk Sample', purpose: 'Quantification of inflammatory leukocytes' },
    { name: 'Bacterial Isolation & Culture', type: 'Microbiology', sample: 'Aseptic Milk Swab', purpose: 'Identification of Streptococcus / Staphylococcus / Coliform pathogens' },
    { name: 'Antibiotic Susceptibility Testing (AST)', type: 'Antibiogram', sample: 'Isolated Culture', purpose: 'Determines sensitive antibiotics to prevent resistant strain development' }
  ],
  Foot_and_Mouth_Disease: [
    { name: 'Real-Time RT-PCR (FMDV 5-UTR / 3D gene)', type: 'Molecular Diagnostics', sample: 'Vesicular fluid / Oral epithelium swab', purpose: 'Rapid confirmation of Foot-and-Mouth Disease viral RNA' },
    { name: 'Antigen Detection ELISA (Solid Phase)', type: 'Serology / Virology', sample: 'Epithelial suspension / Vesicle fluid', purpose: 'Serotyping of FMDV serotypes (O, A, Asia-1)' },
    { name: 'Non-Structural Protein (NSP) 3ABC ELISA', type: 'Serological Screening', sample: 'Serum (5 mL clotted blood)', purpose: 'Differentiating infected from vaccinated animals (DIVA)' },
    { name: 'Virus Neutralization Test (VNT)', type: 'Confirmatory Titration', sample: 'Paired Serum Samples', purpose: 'Gold-standard viral neutralization and immune titer check' }
  ],
  Lumpy_Skin_Disease: [
    { name: 'Capripoxvirus Real-Time PCR', type: 'Molecular Diagnostics', sample: 'Skin scab / Nodule core biopsy / EDTA blood', purpose: 'Definitive detection of LSDV viral DNA' },
    { name: 'Whole Blood Viremia PCR', type: 'Hematology PCR', sample: 'EDTA Anticoagulated Blood (5 mL)', purpose: 'Detects active systemic viremia during febrile stage' },
    { name: 'Histopathological Biopsy Evaluation', type: 'Pathology', sample: 'Formalin-fixed cutaneous nodule', purpose: 'Identification of intracytoplasmic inclusion bodies and vasculitis' },
    { name: 'Capripox Indirect ELISA / Serum Neutralization', type: 'Serology', sample: 'Serum (Plain vial)', purpose: 'Surveillance of herd antibodies and immunity profile' }
  ],
  Multiple_Disease_Diagnosis: [
    { name: 'Differential Multiplex RT-PCR Panel', type: 'Molecular Virology', sample: 'Oral swabs, vesicular fluid, EDTA blood', purpose: 'Differential screening for FMDV, VSV, BVDV, and Bluetongue' },
    { name: 'Complete Blood Count (CBC) & Leukogram', type: 'Hematology', sample: 'EDTA Blood (3 mL)', purpose: 'Evaluating leukopenia, toxic neutrophils, and inflammatory response' },
    { name: 'Giemsa Blood Smear Examination', type: 'Parasitology', sample: 'Peripheral ear-vein blood smear', purpose: 'Ruling out hemoparasitic coinfections (Theileriosis, Babesiosis)' },
    { name: 'Broad-Spectrum Antibiogram & Pathogen Panel', type: 'Microbiology', sample: 'Lesion swab / Sterile aspirate', purpose: 'Determining exact secondary bacterial involvement' }
  ],
  Healthy_Buffalo: [
    { name: 'Routine Complete Hemogram (CBC & PCV)', type: 'Preventive Hematology', sample: 'EDTA Blood (2 mL)', purpose: 'Baseline health and anemia status verification' },
    { name: 'Fecal Floatation & Sedimentation Exam', type: 'Preventive Parasitology', sample: 'Fresh Fecal Sample (10 g)', purpose: 'Screening for liver flukes, amphistomes, and gastrointestinal nematodes' },
    { name: 'Baseline California Mastitis Test (CMT)', type: 'Quarter Screening', sample: 'Fore-milk (5 mL per teat)', purpose: 'Routine herd mastitis monitoring and milk hygiene check' }
  ]
};

const getCaseImage = (img) => {
  if (!img || img === '' || img === 'null' || img === 'undefined') return '/default-buffalo.jpg';
  if (img.startsWith('data:') || img.startsWith('http://') || img.startsWith('https://')) {
    return img;
  }
  return img.startsWith('/') ? img : `/${img}`;
};

export default function CaseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useTranslation();
  const token = localStorage.getItem('token');
  const [caseData, setCaseData] = useState(null);
  const isAdmin = Boolean(user && (user.role === 'System Admin' || user.role === 'system_admin' || user.role === 'Admin' || (user.role || '').toLowerCase().includes('admin')));
  const isCaseOwner = Boolean(
    user && caseData && (
      (caseData.userId && String(caseData.userId) === String(user.id || user._id)) ||
      (caseData.registeredByEmail && user.email && caseData.registeredByEmail.toLowerCase().trim() === user.email.toLowerCase().trim()) ||
      (caseData.ownerName && user.name && caseData.ownerName.toLowerCase().trim() === user.name.toLowerCase().trim()) ||
      (caseData.registeredBy && user.name && caseData.registeredBy.toLowerCase().trim() === user.name.toLowerCase().trim())
    )
  );
  const canModifyCase = isAdmin || isCaseOwner;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');

  // Status & Note Modal States
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [statusInput, setStatusInput] = useState('Open');
  const [treatmentInput, setTreatmentInput] = useState('');
  const [vetNotesInput, setVetNotesInput] = useState('');
  const [followUpInput, setFollowUpInput] = useState('');
  const [updating, setUpdating] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleExportPDF = () => {
    window.print();
  };

  useEffect(() => {
    fetchCaseDetails();
  }, [id]);

  const fetchCaseDetails = async () => {
    setLoading(true);
    setError('');
    try {
      const { data } = await axios.get(`/api/cases/${id}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      setCaseData(data);
      setStatusInput(data.status || 'Open');
      setTreatmentInput(data.treatmentInfo || '');
      setVetNotesInput(data.veterinaryNotes || '');
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to fetch case record details.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (e) => {
    e.preventDefault();
    setUpdating(true);
    try {
      const { data } = await axios.put(`/api/cases/${caseData.caseId || caseData._id}`, {
        status: statusInput,
        treatmentInfo: treatmentInput,
        veterinaryNotes: vetNotesInput,
        followUpNotes: followUpInput
      }, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });

      setCaseData(data.case);
      setShowStatusModal(false);
      setToast('Case status and treatment notes updated successfully.');
      setTimeout(() => setToast(''), 4000);
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to update case record.');
    } finally {
      setUpdating(false);
    }
  };

  const handleDeleteCase = async () => {
    setDeleting(true);
    try {
      await axios.delete(`/api/cases/${caseData.caseId || caseData._id}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      setToast('Case record deleted successfully.');
      setTimeout(() => {
        navigate('/cases');
      }, 1000);
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to delete case record.');
      setShowDeleteModal(false);
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return (
    <div className="py-20 text-center text-xs font-bold text-slate-500">
      {t('common.loading', 'Loading digital health record details...')}
    </div>
  );

  if (error || !caseData) return (
    <div className="max-w-3xl mx-auto py-12 text-center space-y-4">
      <AlertTriangle className="w-12 h-12 text-rose-500 mx-auto" />
      <h2 className="text-xl font-bold text-slate-800">{t('caseDetail.caseNotFound', 'Case Record Not Found')}</h2>
      <p className="text-xs text-slate-500">{error || 'The requested case ID could not be loaded.'}</p>
      <Link to="/cases" className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 text-white text-xs font-bold rounded-xl">
        <ArrowLeft className="w-4 h-4" /> {t('caseDetail.backToRecords', 'Back to Digital Health Records')}
      </Link>
    </div>
  );

  const getSeverityBadge = (sev) => {
    if (sev === 'Critical' || sev === 'High') return 'bg-rose-100 text-rose-800 border-rose-300';
    if (sev === 'Medium' || sev === 'Moderate') return 'bg-amber-100 text-amber-800 border-amber-300';
    return 'bg-emerald-100 text-emerald-800 border-emerald-300';
  };

  const getStatusBadge = (st) => {
    if (st === 'Recovered' || st === 'Closed') return 'bg-emerald-600 text-white';
    if (st === 'Under Treatment') return 'bg-amber-500 text-white';
    if (st === 'Emergency') return 'bg-rose-600 text-white animate-pulse';
    return 'bg-blue-600 text-white';
  };

  const diseaseInfo = getDiseaseInfo(caseData.diseasePrediction);
  const isSpreadable = isSpreadableDisease(caseData.diseasePrediction);

  const defaultSampleDirective = CLINICAL_SAMPLE_DIRECTIVES[diseaseInfo.key] || CLINICAL_SAMPLE_DIRECTIVES.Healthy_Buffalo;
  const defaultAwareness = DISEASE_AWARENESS[diseaseInfo.key] || DISEASE_AWARENESS.Healthy_Buffalo;

  const awarenessStopKey = diseaseInfo.key === 'Foot_and_Mouth_Disease' ? 'fmdStopSpread'
    : diseaseInfo.key === 'Lumpy_Skin_Disease' ? 'lsdStopSpread'
    : diseaseInfo.key === 'Mastitis' ? 'mastitisStopSpread'
    : diseaseInfo.key === 'Multiple_Disease_Diagnosis' ? 'multipleStopSpread'
    : 'healthyStopSpread';

  const awarenessPreventKey = diseaseInfo.key === 'Foot_and_Mouth_Disease' ? 'fmdPreventFuture'
    : diseaseInfo.key === 'Lumpy_Skin_Disease' ? 'lsdPreventFuture'
    : diseaseInfo.key === 'Mastitis' ? 'mastitisPreventFuture'
    : diseaseInfo.key === 'Multiple_Disease_Diagnosis' ? 'multiplePreventFuture'
    : 'healthyPreventFuture';

  const symptomsList = Array.isArray(caseData.symptoms)
    ? caseData.symptoms
    : (typeof caseData.symptoms === 'string'
        ? (caseData.symptoms.trim().startsWith('[')
            ? (() => { try { return JSON.parse(caseData.symptoms); } catch { return [caseData.symptoms]; } })()
            : caseData.symptoms.split(',').map(s => s.trim()).filter(Boolean))
        : []);

  return (
    <div className="max-w-5xl mx-auto space-y-6 py-4">
      {/* Toast */}
      {toast && (
        <div className="fixed top-6 right-6 z-50 bg-emerald-600 text-white px-6 py-4 rounded-2xl shadow-2xl font-bold text-sm flex items-center gap-3 animate-in fade-in no-print">
          <CheckCircle2 className="w-6 h-6 text-emerald-200" />
          <span>{toast}</span>
        </div>
      )}

      {/* Screen Interactive Layout */}
      <div className="screen-only-layout space-y-6">
        {/* Top Header */}
        <div className="flex items-center justify-between">
        <Link to="/cases" className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-emerald-600 transition">
          <ArrowLeft className="w-4 h-4" /> {t('caseDetail.backToRecords', 'Back to Digital Health Records')}
        </Link>

        <div className="flex items-center gap-2 flex-wrap no-print">
          {/* Export Case PDF */}
          <button
            onClick={handleExportPDF}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-sm"
            title="Download or Print full Case Record as PDF"
          >
            <Download className="w-4 h-4" />
            <span>Export Case PDF</span>
          </button>

          {canModifyCase ? (
            <>
              <button
                onClick={() => setShowStatusModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-sm"
              >
                <Edit className="w-4 h-4" /> {t('caseDetail.updateStatusBtn', 'Update Status & Vet Notes')}
              </button>
              <button
                onClick={() => setShowDeleteModal(true)}
                className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl transition flex items-center gap-2 border border-rose-200"
              >
                <Trash2 className="w-4 h-4" /> {t('caseDetail.deleteBtn', 'Delete')}
              </button>
            </>
          ) : (
            <div className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-500 flex items-center gap-1.5">
              <span>🔒 {t('caseDetail.viewOnlyNotice', 'View Only (Registered by member)')}</span>
            </div>
          )}
        </div>
      </div>

      {/* Case Header Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">{caseData.caseId || 'BUF-2026-0001'}</h1>
              <span className={`px-3 py-1 rounded-full text-xs font-extrabold shadow-sm ${getStatusBadge(caseData.status)}`}>
                {t(`status.${(caseData.status || 'open').toLowerCase().replace(/\s+/g, '')}`, caseData.status || 'Open')}
              </span>
              <span className={`px-3 py-1 rounded-full text-xs font-extrabold border ${getSeverityBadge(caseData.severity)}`}>
                {t('dashboard.severityCol', 'Severity')}: {t(`severity.${(caseData.severity || 'low').toLowerCase()}`, caseData.severity || 'Low')}
              </span>
              {isSpreadable ? (
                <span className="px-3 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300 shadow-xs flex items-center gap-1.5 animate-pulse">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                  ⚠️ {t('diagnosisResult.spreadable', 'Spreadable (Contagious Risk)')}
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  🟢 {t('diagnosisResult.nonSpreadable', 'Non-Spreadable')}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Registered on {new Date(caseData.createdAt || Date.now()).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">{t('caseDetail.tagId', 'Buffalo Tag ID')}</span>
            <span className="text-base font-extrabold text-slate-800 font-mono">{caseData.tagNumber}</span>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <span className="text-slate-400 font-bold uppercase text-[10px] block">Buffalo Name</span>
            <span className="font-extrabold text-slate-800">{caseData.buffaloName || 'N/A'}</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('caseDetail.breedAndGender', 'Breed & Gender')}</span>
            <span className="font-extrabold text-slate-800">{caseData.breed} ({caseData.gender})</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('caseDetail.age', 'Age')}</span>
            <span className="font-extrabold text-slate-800">{caseData.age} {t('caseDetail.years', 'Years')}</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('caseDetail.ownerName', 'Owner Name')}</span>
            <span className="font-extrabold text-slate-800">{caseData.ownerName}</span>
          </div>
        </div>
      </div>

      {/* Spreadable Containment Directive Banner */}
      {isSpreadable ? (
        <div className="bg-rose-50 border-2 border-rose-200 rounded-3xl p-5 text-xs space-y-2 text-rose-900 shadow-sm">
          <div className="flex items-center gap-2 font-black text-rose-900 text-sm sm:text-base">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{t('caseDetail.contagiousAlert', 'CONTAGIOUS DISEASE ALERT: High Herd Spread Risk')}</span>
          </div>
          <p className="text-rose-800 font-bold leading-relaxed text-xs sm:text-sm">
            <strong>Mandatory Directive:</strong> {t('diagnosisResult.mandatoryIsolationText', MANDATORY_ISOLATION_INSTRUCTION)}
          </p>
          <div className="flex flex-wrap gap-4 text-xs font-medium text-rose-700 pt-1 border-t border-rose-200/60">
            <span><strong>{t('diagnosisResult.transmissionLabel', 'Transmission')}:</strong> {diseaseInfo.transmission}</span>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-4 text-xs space-y-1 text-emerald-900 shadow-sm">
          <div className="flex items-center gap-2 font-bold text-emerald-900">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>🟢 {t('caseDetail.nonSpreadableAlert', 'Non-Spreadable Condition (Localized / Environmental)')}</span>
          </div>
          <p className="text-emerald-800 font-medium leading-relaxed text-xs">
            {t('diagnosisResult.nonSpreadable', 'Non-spreadable condition. Localized or environmental — no herd quarantine required.')}
          </p>
        </div>
      )}

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Left Column: Health & AI Details (2 Cols) */}
        <div className="md:col-span-2 space-y-6">
          
          {/* Location Information */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <MapPin className="w-4 h-4 text-emerald-600" /> {t('caseDetail.locationInfo', 'General Location Details')}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-slate-400 font-bold text-[10px] uppercase block">{t('caseDetail.areaVillage', 'Area / Village')}</span>
                <span className="font-bold text-slate-800">{caseData.area}</span>
              </div>
              <div>
                <span className="text-slate-400 font-bold text-[10px] uppercase block">{t('caseDetail.streetName', 'Street Name')}</span>
                <span className="font-bold text-slate-800">{caseData.streetName || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-400 font-bold text-[10px] uppercase block">{t('caseDetail.pincode', 'Pincode')}</span>
                <span className="font-bold text-slate-800">{caseData.pincode}</span>
              </div>
            </div>
          </div>

          {/* Symptoms & Clinical Info */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <Stethoscope className="w-4 h-4 text-emerald-600" /> {t('caseDetail.symptomsAndHealth', 'Symptoms & Health Details')}
            </h3>

            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">{t('caseDetail.observedSymptoms', 'Observed Symptoms')}</span>
              <div className="flex flex-wrap gap-2">
                {Array.isArray(caseData.symptoms) && caseData.symptoms.map(s => (
                  <span key={s} className="px-3 py-1 bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold rounded-xl">
                    {t(`symptoms.${s}`, s)}
                  </span>
                ))}
              </div>
            </div>

            {caseData.diseaseDescription && (
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">{t('caseDetail.symptomsDesc', 'Symptoms Description')}</span>
                <p className="text-xs text-slate-700 font-medium leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                  {caseData.diseaseDescription}
                </p>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs pt-2 border-t border-slate-100">
              <div>
                <span className="text-slate-400 font-bold text-[10px] uppercase block">{t('caseDetail.symptomsStartDate', 'Symptoms Start Date')}</span>
                <span className="font-bold text-slate-800">
                  {caseData.symptomsStartDate ? new Date(caseData.symptomsStartDate).toLocaleDateString('en-IN') : 'N/A'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 font-bold text-[10px] uppercase block">{t('caseDetail.bodyTemp', 'Body Temperature')}</span>
                <span className="font-bold text-slate-800">{caseData.temperature || 'Not recorded'}</span>
              </div>
              <div>
                <span className="text-slate-400 font-bold text-[10px] uppercase block">{t('caseDetail.vetConsulted', 'Vet Consulted')}</span>
                <span className="font-bold text-slate-800">{caseData.veterinarianName || 'None'}</span>
              </div>
            </div>
          </div>

          {/* AI Disease Analysis */}
          <div className="bg-gradient-to-br from-emerald-900 to-teal-950 text-white rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-emerald-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-300" />
                <h3 className="font-extrabold text-base">{t('caseDetail.aiAnalysisTitle', 'AI Disease Prediction Analysis')}</h3>
              </div>
              <span className="px-3 py-1 bg-emerald-800/80 text-emerald-200 text-xs font-extrabold rounded-full border border-emerald-700">
                {caseData.confidenceScore || 85}% {t('diagnosisResult.confidence', 'Confidence')}
              </span>
            </div>

            <div>
              <span className="text-[10px] uppercase tracking-wider text-emerald-300 font-bold block">{t('caseDetail.predictedCondition', 'Predicted Condition')}</span>
              <h2 className="text-2xl font-extrabold text-white mt-0.5">{t(`diseases.${caseData.diseasePrediction}`, (caseData.diseasePrediction || 'Healthy_Buffalo').replace(/_/g, ' '))}</h2>
            </div>

            {caseData.immediateAction && (
              <div className="p-3 bg-emerald-800/50 rounded-xl border border-emerald-700 text-xs text-emerald-100 font-medium">
                <strong>{t('caseDetail.immediateAction', 'Immediate Recommended Action')}:</strong> {caseData.immediateAction}
              </div>
            )}
          </div>

          {/* DEDICATED CLINICAL SAMPLE DIRECTIVE CARD */}
          <div className={`rounded-3xl p-6 border-2 space-y-3 shadow-sm ${
            diseaseInfo.key === 'Mastitis'
              ? 'bg-blue-50/90 border-blue-400'
              : 'bg-indigo-50/90 border-indigo-400'
          }`}>
            <div className="flex items-center gap-2 font-black text-xs uppercase tracking-wider text-indigo-950">
              <span className="text-xl">{diseaseInfo.key === 'Mastitis' ? '🥛' : '🧪'}</span>
              <span>
                {diseaseInfo.key === 'Mastitis'
                  ? t('sampleDirectives.milkSampleTitle', 'Milk Sample Submission Directive (Mastitis)')
                  : t('sampleDirectives.title', 'Clinical Sample Submission for Laboratory Testing')}
              </span>
            </div>
            <p className="text-xs sm:text-sm font-extrabold text-slate-900 leading-relaxed">
              {t(`sampleDirectives.${diseaseInfo.key}`, defaultSampleDirective.instruction)}
            </p>
            <div className="pt-2 border-t border-indigo-200/60 text-[11px] font-bold text-indigo-800">
              🔬 {t('sampleDirectives.subtitle', 'Mandatory Veterinary Diagnostic Protocol')}
            </div>
          </div>

          {/* DEDICATED DISEASE AWARENESS & FUTURE PREVENTION CARD */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <ShieldAlert className="w-4 h-4 text-emerald-600" /> {t('awareness.title', 'Disease Awareness & Prevention Guide')}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 space-y-1.5">
                <span className="text-xs font-black text-rose-900 block">🛑 {t('awareness.stopSpreadTitle', 'How to Stop Disease Spread (Immediate Biosecurity)')}</span>
                <p className="text-xs font-semibold text-rose-950 leading-relaxed">
                  {t(`awareness.${awarenessStopKey}`, defaultAwareness.stopSpread)}
                </p>
              </div>

              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-1.5">
                <span className="text-xs font-black text-emerald-900 block">🌱 {t('awareness.preventFutureTitle', 'How to Avoid Recurrence in the Future')}</span>
                <p className="text-xs font-semibold text-emerald-950 leading-relaxed">
                  {t(`awareness.${awarenessPreventKey}`, defaultAwareness.preventFuture)}
                </p>
              </div>
            </div>
          </div>

          {/* SAFE VETERINARY GUIDANCE CARD */}
          <div className="bg-emerald-50/90 border-2 border-emerald-500/80 rounded-3xl p-6 space-y-3 shadow-sm">
            <div className="flex items-center gap-2 text-emerald-950 font-black text-xs uppercase tracking-wider">
              <span className="text-base">🩺</span>
              <span>{t('diagnosisResult.veterinaryGuidanceTitle', 'Veterinary Guidance')}</span>
            </div>
            <p className="text-xs sm:text-sm font-bold text-slate-800 leading-relaxed">
              {t('diagnosisResult.veterinaryGuidanceText', 'This result is an AI-assisted screening result and should not be considered a final veterinary diagnosis. Please consult a qualified veterinarian for confirmation and treatment.')}
            </p>
            <div className="pt-2 border-t border-emerald-200/70 text-xs font-extrabold text-emerald-800 flex items-center gap-2">
              🚨 {t('diagnosisResult.emergencyContact', 'Veterinary Emergency Helpline: 1962')}
            </div>
          </div>

          {/* NECESSARY CLINICAL PRECAUTIONS CARD */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" /> {t('diagnosisResult.necessaryPrecautions', 'Necessary Precautions & Biosecurity')}
            </h3>

            <div className="bg-amber-50/70 border border-amber-200 p-4 rounded-2xl space-y-1">
              <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider block">Primary Clinical Precaution Directive</span>
              <p className="font-bold text-amber-950 text-sm leading-snug">
                {diseaseInfo.precaution || 'Ensure sterile environment, isolate affected animals, and monitor vitals.'}
              </p>
            </div>

            {diseaseInfo.additionalPrecautions && diseaseInfo.additionalPrecautions.length > 0 && (
              <div className="bg-white border border-slate-200 p-4 rounded-2xl space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Herd Biosecurity & Care Checklist</span>
                <ul className="space-y-2 text-xs text-slate-700 font-medium">
                  {diseaseInfo.additionalPrecautions.map((p, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-600 font-bold shrink-0 mt-0.5">•</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Image & Audit Timeline (1 Col) */}
        <div className="space-y-6">
          
          {/* Buffalo Image Card */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-slate-900">{t('caseDetail.uploadedImage', 'Buffalo Image')}</h3>
            <div className="rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 max-h-64 flex items-center justify-center">
              <img
                src={getCaseImage(caseData.image)}
                onError={(e) => { e.target.onerror = null; e.target.src = '/default-buffalo.jpg'; }}
                alt="Buffalo"
                className="max-h-64 w-auto object-contain"
              />
            </div>
          </div>

          {/* Treatment & Veterinary Notes */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-2">{t('caseDetail.vetFieldNotes', 'Veterinary Notes')}</h3>
            <div className="space-y-2 text-xs">
              <div>
                <span className="text-slate-400 font-bold uppercase text-[10px] block">Field Treatment Notes</span>
                <p className="font-semibold text-slate-800">{caseData.treatmentInfo || caseData.currentTreatment || 'None recorded.'}</p>
              </div>
              <div>
                <span className="text-slate-400 font-bold uppercase text-[10px] block">Veterinary Clinical Observations</span>
                <p className="font-semibold text-slate-800">{caseData.veterinaryNotes || 'No notes added yet.'}</p>
              </div>
            </div>
          </div>

          {/* Case Audit Timeline */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <Clock className="w-4 h-4 text-emerald-600" /> {t('caseDetail.auditHistory', 'Case Audit Timeline')}
            </h3>

            <div className="space-y-3">
              {Array.isArray(caseData.history) && caseData.history.length > 0 ? (
                caseData.history.map((h, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-xs">
                    <div className="w-2 h-2 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                    <div>
                      <p className="font-bold text-slate-800">{h.action}</p>
                      <p className="text-[11px] text-slate-500">{h.details}</p>
                      <span className="text-[10px] text-slate-400">
                        {new Date(h.timestamp).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 font-bold">Created on {new Date(caseData.createdAt).toLocaleDateString('en-IN')}</p>
              )}
            </div>
          </div>
        </div>
      </div>
      </div> {/* End screen-only-layout */}

      {/* Update Status & Vet Notes Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">{t('caseDetail.updateModalTitle', 'Update Status & Veterinary Notes')}</h3>
              <button onClick={() => setShowStatusModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateStatus} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t('caseDetail.caseStatus', 'Case Status')}</label>
                <select
                  value={statusInput}
                  onChange={e => setStatusInput(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 text-xs font-bold rounded-xl"
                >
                  <option value="Open">{t('status.open', 'Open')}</option>
                  <option value="Under Treatment">{t('status.undertreatment', 'Under Treatment')}</option>
                  <option value="Recovered">{t('status.recovered', 'Recovered / Resolved')}</option>
                  <option value="Closed">{t('status.closed', 'Closed')}</option>
                  <option value="Emergency">{t('status.emergency', 'Emergency')}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Field Treatment Information</label>
                <input
                  type="text"
                  value={treatmentInput}
                  onChange={e => setTreatmentInput(e.target.value)}
                  placeholder="e.g. Disinfected wound, applied topical spray"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 text-xs font-semibold rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t('caseDetail.vetFieldNotes', 'Veterinary Notes')}</label>
                <textarea
                  value={vetNotesInput}
                  onChange={e => setVetNotesInput(e.target.value)}
                  rows={3}
                  placeholder="Add clinical observations, follow-up instructions..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 text-xs font-semibold rounded-xl"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  disabled={updating}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition shadow-md"
                >
                  {updating ? t('common.loading', 'Saving Changes...') : t('caseDetail.saveChanges', 'Save Updates')}
                </button>
                <button
                  type="button"
                  onClick={() => setShowStatusModal(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
                >
                  {t('common.cancel', 'Cancel')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-rose-600 mx-auto" />
            <h3 className="font-extrabold text-base text-slate-900">Confirm Record Deletion</h3>
            <p className="text-xs text-slate-500 font-medium">
              Are you sure you want to delete case <strong>{caseData.caseId}</strong>? This action cannot be undone.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={handleDeleteCase}
                disabled={deleting}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition shadow-md"
              >
                {deleting ? 'Deleting...' : 'Yes, Delete Record'}
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                {t('common.cancel', 'Cancel')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          COMPLETE OFFICIAL VETERINARY CLINICAL CASE DOSSIER (PRINT / PDF EXPORT)
          Contains exhaustive data: Buffalo clinical photo, symptoms profile,
          prescribed laboratory tests, biosecurity & disease awareness directives,
          veterinary treatment observations, and official sign-off seals.
         ========================================================================= */}
      <div id="complete-case-dossier-print" className="hidden print:block w-full bg-white text-slate-900 p-2 sm:p-4 text-xs font-sans">
        
        {/* Dossier Header Banner */}
        <div className="border-b-2 border-slate-900 pb-3 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl border-2 border-emerald-800 flex items-center justify-center bg-emerald-50 text-emerald-900 font-black text-xl">
                🛡️
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-800 block">
                  BUFFALO HEALTH & DISEASE INTELLIGENCE PLATFORM
                </span>
                <h1 className="text-xl font-black uppercase text-slate-900 tracking-tight leading-none">
                  Buffalo Health Record & Disease Prediction Report
                </h1>
                <span className="text-[11px] font-bold text-slate-600">
                  Comprehensive Clinical Health Dossier & Preventive Biosecurity Guide
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-extrabold uppercase text-slate-500 block">Report Reference ID</span>
              <span className="text-lg font-black text-slate-900 font-mono">{caseData.caseId || caseData._id}</span>
              <span className="text-[10px] font-bold text-emerald-700 block">Digital Health Record</span>
            </div>
          </div>

          {/* Status & Risk Badges Row */}
          <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-600">Filing Date:</span>
              <strong className="text-slate-900">{new Date(caseData.createdAt || Date.now()).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}</strong>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded border border-slate-400 font-extrabold text-[11px] uppercase bg-slate-100 text-slate-800">
                Status: {caseData.status || 'Open'}
              </span>
              <span className={`px-2.5 py-0.5 rounded border font-extrabold text-[11px] uppercase ${
                (caseData.severity === 'Critical' || caseData.severity === 'High') ? 'bg-rose-100 text-rose-900 border-rose-300' :
                (caseData.severity === 'Medium' || caseData.severity === 'Moderate') ? 'bg-amber-100 text-amber-900 border-amber-300' :
                'bg-emerald-100 text-emerald-900 border-emerald-300'
              }`}>
                Severity: {caseData.severity || 'Medium'}
              </span>
              {isSpreadable ? (
                <span className="px-2.5 py-0.5 rounded border border-rose-400 bg-rose-100 text-rose-900 font-black text-[11px] uppercase">
                  ⚠️ Spreadable (Epidemic Herd Risk)
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded border border-emerald-400 bg-emerald-100 text-emerald-900 font-black text-[11px] uppercase">
                  🟢 Non-Spreadable (Localized Condition)
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Section 1: Animal & Farmer Identification Grid */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-slate-50/50">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
            <span>📋</span>
            <span>Section 1: Animal Demographic & Livestock Farmer Particulars</span>
          </h2>
          <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs">
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Buffalo Tag Identification (RFID / Ear Tag):</span>
              <span className="font-black text-slate-900 text-sm font-mono">{caseData.tagNumber}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Farmer / Registered Owner:</span>
              <span className="font-bold text-slate-900 text-sm">{caseData.ownerName}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Buffalo Name / Call Name:</span>
              <span className="font-bold text-slate-800">{caseData.buffaloName || 'N/A'}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Registered Contact / Email:</span>
              <span className="font-bold text-slate-800">{caseData.registeredByEmail || 'Registered Local Member'}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Species & Breed (Gender):</span>
              <span className="font-bold text-slate-800">Water Buffalo (Bubalus bubalis) • {caseData.breed} ({caseData.gender})</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Village / Settlement:</span>
              <span className="font-bold text-slate-800">{caseData.area}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Age & Physical Maturity:</span>
              <span className="font-bold text-slate-800">{caseData.age} Years</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold text-[10px] uppercase block">Street Address & Pincode:</span>
              <span className="font-bold text-slate-800">{caseData.streetName ? `${caseData.streetName}, ` : ''}{caseData.pincode} (District: {caseData.area || 'AP'})</span>
            </div>
          </div>
        </div>

        {/* Section 2: Buffalo Photograph (Visual Health Inspection) */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-white">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2.5 flex items-center gap-1.5">
            <span>📷</span>
            <span>Section 2: Buffalo Photograph (Clinical Visual Inspection)</span>
          </h2>
          <div className="flex flex-col items-center justify-center p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <img
              src={getCaseImage(caseData.image)}
              onError={(e) => { e.target.onerror = null; e.target.src = '/default-buffalo.jpg'; }}
              alt={`Buffalo Tag ${caseData.tagNumber}`}
              className="max-h-60 max-w-full object-contain rounded-md border border-slate-300 shadow-sm mx-auto"
            />
            <p className="mt-2 text-[11px] font-semibold text-slate-700 text-center">
              Visual photographic inspection for Buffalo #{caseData.tagNumber} ({caseData.buffaloName || caseData.breed || 'Murrah Buffalo'})
            </p>
          </div>
        </div>

        {/* Section 3: Symptoms Profile & Clinical Vitals */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-slate-50/50">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
            <span>🩺</span>
            <span>Section 3: Clinical Symptoms Profile, Onset & Physiological Vitals</span>
          </h2>

          <div className="space-y-2.5">
            {/* Vitals row */}
            <div className="grid grid-cols-3 gap-3 bg-white p-2.5 rounded border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 font-semibold text-[10px] uppercase block">Symptoms Onset Date:</span>
                <span className="font-bold text-slate-900">
                  {caseData.symptomsStartDate ? new Date(caseData.symptomsStartDate).toLocaleDateString('en-IN') : 'Recent (< 48 hrs)'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold text-[10px] uppercase block">Measured Body Temperature:</span>
                <span className="font-bold text-slate-900">
                  {caseData.temperature ? `${caseData.temperature}` : 'Normal range (101.5 °F)'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold text-[10px] uppercase block">Case Filing Status:</span>
                <span className="font-bold text-emerald-800">{caseData.status || 'Active / Recorded'}</span>
              </div>
            </div>

            {/* Observed Symptoms List */}
            <div>
              <span className="text-slate-500 font-bold text-[10px] uppercase block mb-1.5">
                Observed Clinical Symptoms Reported:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {symptomsList && symptomsList.length > 0 ? (
                  symptomsList.map((s, idx) => (
                    <span key={idx} className="px-2 py-0.5 bg-white border border-slate-300 rounded font-bold text-[11px] text-slate-800">
                      • {t(`symptoms.${s}`, s.replace(/_/g, ' '))}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 italic">Standard clinical observation recorded</span>
                )}
              </div>
            </div>

            {/* Symptoms Description Paragraph */}
            {caseData.diseaseDescription && (
              <div className="bg-white p-2.5 rounded border border-slate-200">
                <span className="text-slate-500 font-bold text-[10px] uppercase block mb-0.5">Clinical Symptoms Description:</span>
                <p className="text-xs text-slate-800 font-medium leading-relaxed">
                  {caseData.diseaseDescription}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Section 4: AI Disease Prediction & Epidemiological Assessment */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-white">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
            <span>🔬</span>
            <span>Section 4: Diagnostic Assessment & Epidemiological Risk Classification</span>
          </h2>

          <div className="space-y-2">
            <div className="flex items-center justify-between bg-slate-100 p-2.5 rounded border border-slate-200">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 block">Primary Disease Prediction:</span>
                <h3 className="text-base font-black text-slate-900">
                  {diseaseInfo.displayName || (caseData.diseasePrediction || 'Healthy Buffalo').replace(/_/g, ' ')}
                </h3>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold uppercase text-slate-500 block">AI Screening Confidence:</span>
                <span className="text-sm font-black text-emerald-800 font-mono">
                  {caseData.confidenceScore || 85}% Diagnostic Match
                </span>
              </div>
            </div>

            {isSpreadable && (
              <div className="bg-rose-50 border-l-4 border-rose-600 p-2 text-xs text-rose-900">
                <strong>Mandatory Containment Directive:</strong> {MANDATORY_ISOLATION_INSTRUCTION}
                <div className="text-[11px] text-rose-700 mt-0.5">
                  <strong>Transmission Vector:</strong> {diseaseInfo.transmission}
                </div>
              </div>
            )}

            {caseData.immediateAction && (
              <div className="bg-amber-50 border border-amber-200 p-2 rounded text-xs text-amber-900">
                <strong>Immediate Action Required:</strong> {caseData.immediateAction}
              </div>
            )}
          </div>
        </div>

        {/* Section 5: Prescribed Diagnostic Lab Tests & Clinical Sample Protocol (Requested specifically by user) */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-slate-50/50">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
            <span>🧪</span>
            <span>Section 5: Prescribed Laboratory Diagnostic Tests & Clinical Sample Directives</span>
          </h2>

          {/* Sample Directive Box */}
          <div className="bg-indigo-50 border border-indigo-200 p-2.5 rounded mb-2.5">
            <div className="flex items-center gap-1.5 text-indigo-950 font-black text-xs uppercase mb-1">
              <span>📌</span>
              <span>{defaultSampleDirective.title}</span>
            </div>
            <p className="text-xs text-indigo-950 font-semibold leading-relaxed">
              {defaultSampleDirective.instruction}
            </p>
            <div className="text-[10px] text-indigo-700 font-medium mt-1">
              <strong>Sample Transport Protocol:</strong> Transport in sterile, sealed containers maintained in cold chain (2°C – 8°C) within 24 hours to the District Veterinary Diagnostic Laboratory (DVDL).
            </div>
          </div>

          {/* Prescribed Confirmatory Tests Table */}
          <div className="bg-white rounded border border-slate-200 overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-600">
                  <th className="p-2 border-r border-slate-200">#</th>
                  <th className="p-2 border-r border-slate-200">Prescribed Diagnostic Test</th>
                  <th className="p-2 border-r border-slate-200">Test Methodology</th>
                  <th className="p-2 border-r border-slate-200">Required Biological Specimen</th>
                  <th className="p-2">Diagnostic Objective</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-[11px]">
                {(PRESCRIBED_LAB_TESTS[diseaseInfo.key] || PRESCRIBED_LAB_TESTS.Healthy_Buffalo).map((test, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="p-2 border-r border-slate-200 font-bold text-slate-500">{i + 1}</td>
                    <td className="p-2 border-r border-slate-200 font-bold text-slate-900">{test.name}</td>
                    <td className="p-2 border-r border-slate-200 text-slate-700">{test.type}</td>
                    <td className="p-2 border-r border-slate-200 text-slate-700">{test.sample}</td>
                    <td className="p-2 text-slate-700">{test.purpose}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 6: Disease Awareness & Herd Biosecurity Directives (Requested specifically by user) */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-white">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
            <span>🛡️</span>
            <span>Section 6: Disease Awareness, Herd Biosecurity & Prevention Guidelines</span>
          </h2>

          <div className="grid grid-cols-2 gap-3 mb-2.5">
            {/* Immediate Biosecurity */}
            <div className="bg-rose-50 border border-rose-200 p-2.5 rounded">
              <span className="text-[10px] font-black uppercase text-rose-900 block mb-1">
                🛑 Immediate Biosecurity: How to Halt Disease Spread
              </span>
              <p className="text-xs font-medium text-rose-950 leading-relaxed">
                {defaultAwareness.stopSpread}
              </p>
            </div>

            {/* Long-term Prevention */}
            <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded">
              <span className="text-[10px] font-black uppercase text-emerald-900 block mb-1">
                🌱 Long-Term Prevention: How to Avoid Recurrence in the Future
              </span>
              <p className="text-xs font-medium text-emerald-950 leading-relaxed">
                {defaultAwareness.preventFuture}
              </p>
            </div>
          </div>

          {/* Herd Precautions Checklist */}
          {diseaseInfo.additionalPrecautions && diseaseInfo.additionalPrecautions.length > 0 && (
            <div className="bg-slate-50 border border-slate-200 p-2 rounded text-[11px]">
              <span className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                Key Veterinary Biosecurity Checklist for Farm Staff:
              </span>
              <ul className="grid grid-cols-2 gap-x-4 gap-y-1 text-slate-700">
                {diseaseInfo.additionalPrecautions.map((prec, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span className="text-emerald-700 font-bold">✔</span>
                    <span>{prec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Section 7: Field Treatment & Care Management Notes */}
        <div className="border border-slate-300 rounded-lg p-3 mb-4 print-avoid-break bg-slate-50/50">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
            <span>💊</span>
            <span>Section 7: Field Treatment & Care Management Notes</span>
          </h2>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-2.5 rounded border border-slate-200">
              <span className="text-[10px] font-bold uppercase text-slate-500 block mb-0.5">
                Field Treatment / Medication Administered:
              </span>
              <p className="font-semibold text-slate-900">
                {caseData.treatmentInfo || caseData.currentTreatment || 'Standard symptomatic supportive care administered.'}
              </p>
            </div>

            <div className="bg-white p-2.5 rounded border border-slate-200">
              <span className="text-[10px] font-bold uppercase text-slate-500 block mb-0.5">
                Clinical Follow-Up & Caretaker Observations:
              </span>
              <p className="font-semibold text-slate-900">
                {caseData.veterinaryNotes || 'Buffalo is under active observation. Monitor appetite, water intake, and vitals daily.'}
              </p>
            </div>
          </div>

          <div className="mt-2 text-[11px] text-emerald-800 font-bold bg-emerald-50 border border-emerald-200 p-1.5 rounded flex items-center justify-between">
            <span>🚨 24/7 Animal Health Emergency Helpline: 1962 (Toll-Free)</span>
            <span>Follow-up Recommended: 48–72 Hours</span>
          </div>
        </div>

        {/* Section 8: Case Record Summary & Caretaker Confirmation */}
        <div className="border border-slate-300 rounded-lg p-3 print-avoid-break bg-white">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2.5 flex items-center gap-1.5">
            <span>📋</span>
            <span>Section 8: Case Record Summary & Caretaker Confirmation</span>
          </h2>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
              <span className="text-[10px] font-bold uppercase text-slate-500 block mb-0.5">Livestock Caretaker / Owner:</span>
              <p className="font-extrabold text-slate-900 text-sm">{caseData.ownerName || 'Livestock Owner'}</p>
              <p className="text-[11px] text-slate-600 mt-0.5">Location: {caseData.area || 'Local Farm'} • Pincode: {caseData.pincode}</p>
              <span className="text-[10px] text-slate-500 block mt-1">Confirmed on: {new Date(caseData.createdAt || Date.now()).toLocaleDateString('en-IN')}</span>
            </div>

            <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
              <span className="text-[10px] font-bold uppercase text-slate-500 block mb-0.5">Digital Record Authentication:</span>
              <p className="font-mono font-bold text-slate-900 text-xs">Dossier ID: {caseData.caseId || caseData._id}</p>
              <p className="text-[11px] text-emerald-700 font-semibold mt-0.5">Status: {caseData.status || 'Active'} • Severity: {caseData.severity || 'Medium'}</p>
              <span className="text-[10px] text-slate-500 block mt-1">Report Generated: {new Date().toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        {/* Document Footer */}
        <div className="mt-4 pt-2 border-t border-slate-300 text-[10px] text-slate-500 text-center space-y-0.5">
          <p className="font-semibold text-slate-700">
            Buffalo Health Record & Disease Prediction Report • Digital Livestock Health Management
          </p>
          <p>
            Generated for livestock health monitoring, symptoms tracking, prescribed diagnostics, and disease prevention biosecurity.
          </p>
        </div>

      </div>

      {/* Print-specific style for Clean Multi-page Case PDF Export */}
      <style>{`
        @media print {
          @page {
            size: A4 portrait;
            margin: 10mm;
          }
          body, html, #root, #root > div, main {
            height: auto !important;
            min-height: 100% !important;
            overflow: visible !important;
            position: static !important;
            background: #ffffff !important;
          }
          .screen-only-layout, .no-print, aside, nav, header, #voice-assistant-widget {
            display: none !important;
          }
          #complete-case-dossier-print {
            display: block !important;
            visibility: visible !important;
            width: 100% !important;
            max-width: 100% !important;
            position: static !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          .max-w-5xl {
            max-width: 100% !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            position: static !important;
          }
          .print-avoid-break {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
        }
      `}</style>
    </div>
  );
}
