import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileBarChart, 
  Download, 
  FileText, 
  Filter, 
  Search, 
  Printer, 
  FileSpreadsheet, 
  Activity, 
  AlertTriangle, 
  ShieldCheck, 
  TrendingUp, 
  PieChart as PieIcon,
  BarChart3,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';
import axios from 'axios';
import { useTranslation } from '../context/LanguageContext';

const DISEASE_COLORS = {
  'Foot_and_Mouth_Disease': '#e11d48',
  'Foot and Mouth Disease': '#e11d48',
  'Lumpy_Skin_Disease': '#f59e0b',
  'Lumpy Skin Disease': '#f59e0b',
  'Mastitis': '#3b82f6',
  'Healthy_Buffalo': '#10b981',
  'Healthy Buffalo': '#10b981',
  'Multiple_Disease_Diagnosis': '#8b5cf6',
  'Multiple Disease Diagnosis': '#8b5cf6',
  'Default': '#64748b'
};

const SEVERITY_COLORS = {
  'Critical': '#e11d48',
  'High': '#ea580c',
  'Medium': '#f59e0b',
  'Low': '#10b981'
};

export default function Reports() {
  const { t } = useTranslation();
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    area: '',
    severity: '',
    status: '',
    startDate: '',
    endDate: ''
  });

  useEffect(() => {
    fetchReports();
  }, [filters]);

  const fetchReports = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.area) params.append('area', filters.area);
      if (filters.severity) params.append('severity', filters.severity);
      if (filters.startDate) params.append('startDate', filters.startDate);
      if (filters.endDate) params.append('endDate', filters.endDate);

      const { data } = await axios.get(`/api/cases?${params.toString()}`);
      
      let filteredData = data;
      if (filters.status) {
        filteredData = data.filter(c => c.status === filters.status);
      }
      setCases(filteredData);
    } catch (err) {
      console.error('Failed to fetch reports', err);
    } finally {
      setLoading(false);
    }
  };

  // KPI Calculations
  const stats = useMemo(() => {
    const total = cases.length;
    const critical = cases.filter(c => c.severity === 'Critical' || c.severity === 'High').length;
    const active = cases.filter(c => c.status !== 'Resolved' && c.status !== 'Recovered' && c.status !== 'Closed').length;
    const recovered = cases.filter(c => c.status === 'Resolved' || c.status === 'Recovered' || c.status === 'Closed').length;
    const recoveryRate = total > 0 ? Math.round((recovered / total) * 100) : 100;

    return { total, critical, active, recovered, recoveryRate };
  }, [cases]);

  // Disease Prevalence Chart Data
  const diseaseChartData = useMemo(() => {
    const map = {};
    cases.forEach(c => {
      const raw = c.diseasePrediction || 'Healthy Buffalo';
      map[raw] = (map[raw] || 0) + 1;
    });

    return Object.entries(map).map(([name, count]) => {
      const color = DISEASE_COLORS[name] || DISEASE_COLORS.Default;
      return {
        name,
        count,
        percentage: Math.round((count / (cases.length || 1)) * 100),
        color
      };
    });
  }, [cases]);

  // Severity Profile Chart Data
  const severityChartData = useMemo(() => {
    const counts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    cases.forEach(c => {
      const s = c.severity || 'Low';
      if (counts[s] !== undefined) counts[s]++;
      else counts.Low++;
    });

    return [
      { name: 'Critical', count: counts.Critical, fill: SEVERITY_COLORS.Critical },
      { name: 'High', count: counts.High, fill: SEVERITY_COLORS.High },
      { name: 'Medium', count: counts.Medium, fill: SEVERITY_COLORS.Medium },
      { name: 'Low', count: counts.Low, fill: SEVERITY_COLORS.Low }
    ];
  }, [cases]);

  // Chronological Outbreak Trend Data
  const trendChartData = useMemo(() => {
    const map = {};
    const sorted = [...cases].sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
    
    sorted.forEach(c => {
      const dateKey = new Date(c.createdAt || Date.now()).toLocaleDateString('en-IN', {
        month: 'short',
        day: 'numeric'
      });
      map[dateKey] = (map[dateKey] || 0) + 1;
    });

    const entries = Object.entries(map);
    return entries.slice(-12).map(([date, cases]) => ({ date, cases }));
  }, [cases]);

  const handleExportCSV = () => {
    if (cases.length === 0) return alert('No data to export');

    const headers = [
      'Case ID',
      'Animal Species',
      'Predicted Disease',
      'Severity',
      'Risk Percentage',
      'Jurisdiction Area',
      'Case Status',
      'Created Date'
    ];
    
    const rows = cases.map(c => [
      c.caseId || c._id,
      c.animalType || 'Buffalo',
      `"${c.diseasePrediction || 'Healthy Buffalo'}"`,
      c.severity || 'Low',
      `${c.riskPercentage || '90'}%`,
      `"${c.area || 'Krishna District'}"`,
      c.status || 'Open',
      new Date(c.createdAt || Date.now()).toLocaleDateString('en-IN')
    ]);

    const csvContent = '\uFEFF' + [
      headers.join(','),
      ...rows.map(r => r.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `buffalo_epidemiology_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPDF = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-500 py-2">
      {/* Printable Report Header Container */}
      <div id="analytics-printable-header" className="hidden">
        <div className="text-center border-b-2 border-emerald-800 pb-3 mb-4">
          <h1 className="text-xl font-black uppercase text-emerald-900">
            Government of Andhra Pradesh • Animal Husbandry Department
          </h1>
          <p className="text-xs font-bold text-slate-700">
            District Epidemiological Surveillance & Disease Analytics Report
          </p>
          <p className="text-[10px] text-slate-500">
            Generated on: {new Date().toLocaleString('en-IN')} | Krishna District Central Registry
          </p>
        </div>
      </div>

      {/* Screen Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/80 pb-4 no-print">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-3">
            <span className="p-2 bg-emerald-100 text-emerald-800 rounded-2xl shadow-sm">
              <FileBarChart className="w-6 h-6 text-emerald-700" />
            </span>
            {t('reports.title', 'Epidemiological Analytics & Reports')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
            Real-time disease incidence trends, herd quarantine metrics, and verified case registries.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button 
            onClick={handlePrintPDF} 
            className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-sm"
          >
            <Printer className="w-4 h-4" /> Extract PDF Report
          </button>
          <button 
            onClick={handleExportCSV} 
            className="px-4 py-2.5 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> {t('reports.exportCsv', 'Export Excel / CSV')}
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. EXECUTIVE KPI SUMMARY METRIC CARDS                                      */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Screenings */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">Screened Animals</span>
            <span className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
              <Activity className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
            {stats.total}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">Digital Registry Cases</p>
        </div>

        {/* High & Critical Alerts */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">High / Critical Contagion</span>
            <span className="p-2 bg-rose-50 text-rose-700 rounded-xl">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-600 font-mono">
            {stats.critical}
          </div>
          <p className="text-[11px] text-rose-600/80 font-semibold">Priority Triage Alerts</p>
        </div>

        {/* Active Under Treatment */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">Active Quarantine</span>
            <span className="p-2 bg-amber-50 text-amber-700 rounded-xl">
              <TrendingUp className="w-4 h-4 text-amber-600" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-700 font-mono">
            {stats.active}
          </div>
          <p className="text-[11px] text-amber-700/80 font-semibold">Under Active Surveillance</p>
        </div>

        {/* Recovery Rate */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">Recovery Rate</span>
            <span className="p-2 bg-teal-50 text-teal-700 rounded-xl">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-700 font-mono">
            {stats.recoveryRate}%
          </div>
          <p className="text-[11px] text-emerald-700/80 font-semibold">{stats.recovered} Cases Resolved</p>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. RECHARTS VISUAL ANALYTICS SECTION                                      */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Outbreak Incidence Trend Chart */}
        <div className="lg:col-span-2 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              <h2 className="text-base font-extrabold text-slate-900">
                Epidemiological Incidence Waves (Recent Dates)
              </h2>
            </div>
            <span className="text-xs font-bold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-lg">
              Daily Volume
            </span>
          </div>

          <div className="h-64 w-full">
            {trendChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTrend" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#059669" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#059669" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Area type="monotone" dataKey="cases" stroke="#059669" strokeWidth={3} fillOpacity={1} fill="url(#colorTrend)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Insufficient temporal data to graph trend
              </div>
            )}
          </div>
        </div>

        {/* Disease Prevalence Donut Chart */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieIcon className="w-5 h-5 text-indigo-600" />
              <h2 className="text-base font-extrabold text-slate-900">
                Disease Prevalence
              </h2>
            </div>
            <span className="text-xs font-bold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-lg">
              Pathology Share
            </span>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            {diseaseChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={diseaseChartData}
                    dataKey="count"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                  >
                    {diseaseChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(val, name, item) => [`${val} cases (${item.payload.percentage}%)`, name]}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-xs text-slate-400">No disease distribution records</div>
            )}
          </div>

          {/* Donut Legend */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px]">
            {diseaseChartData.map((d, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }}></span>
                <span className="text-slate-700 font-semibold truncate">{d.name}:</span>
                <span className="font-bold text-slate-900 font-mono">{d.percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Second Row: Severity Breakdown Bar Chart */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-amber-600" />
            <h2 className="text-base font-extrabold text-slate-900">
              Clinical Severity Triage Distribution
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-semibold">Triage Priority Protocol</span>
        </div>

        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={severityChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }}
              />
              <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                {severityChartData.map((entry, index) => (
                  <Cell key={`bar-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. MULTI-PARAMETRIC FILTERS                                              */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm no-print space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <Filter className="w-4 h-4 text-emerald-600" /> 
            <span>{t('reports.filterTitle', 'Filter Surveillance Records')}</span>
          </h2>
          <button 
            onClick={() => setFilters({area: '', severity: '', status: '', startDate: '', endDate: ''})} 
            className="text-xs font-bold text-slate-500 hover:text-emerald-700 transition"
          >
            {t('diagnosisResult.reset', 'Reset All')}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
          <input 
            type="text" 
            placeholder={t('reports.filterArea', 'Filter by Mandal / Area')}
            className="border border-slate-200 bg-slate-50/70 rounded-xl p-2.5 text-xs font-semibold focus:bg-white transition"
            value={filters.area}
            onChange={(e) => setFilters({...filters, area: e.target.value})}
          />
          <select 
            className="border border-slate-200 bg-slate-50/70 rounded-xl p-2.5 text-xs font-semibold focus:bg-white transition"
            value={filters.severity}
            onChange={(e) => setFilters({...filters, severity: e.target.value})}
          >
            <option value="">{t('reports.filterSeverity', 'All Severities')}</option>
            <option value="Critical">{t('severity.critical', 'Critical')}</option>
            <option value="High">{t('severity.high', 'High (Red)')}</option>
            <option value="Medium">{t('severity.medium', 'Medium (Yellow)')}</option>
            <option value="Low">{t('severity.low', 'Low (Green)')}</option>
          </select>
          <select 
            className="border border-slate-200 bg-slate-50/70 rounded-xl p-2.5 text-xs font-semibold focus:bg-white transition"
            value={filters.status}
            onChange={(e) => setFilters({...filters, status: e.target.value})}
          >
            <option value="">{t('reports.filterStatus', 'All Statuses')}</option>
            <option value="Open">{t('status.open', 'Open')}</option>
            <option value="Under Treatment">{t('status.undertreatment', 'Under Treatment')}</option>
            <option value="Recovered">{t('status.recovered', 'Recovered')}</option>
            <option value="Closed">{t('status.closed', 'Closed')}</option>
          </select>
          <input 
            type="date" 
            className="border border-slate-200 bg-slate-50/70 rounded-xl p-2.5 text-xs font-semibold focus:bg-white transition"
            value={filters.startDate}
            onChange={(e) => setFilters({...filters, startDate: e.target.value})}
          />
          <input 
            type="date" 
            className="border border-slate-200 bg-slate-50/70 rounded-xl p-2.5 text-xs font-semibold focus:bg-white transition"
            value={filters.endDate}
            onChange={(e) => setFilters({...filters, endDate: e.target.value})}
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. CLINICAL CASES REGISTRY TABLE                                          */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-600" />
            <h3 className="font-extrabold text-sm text-slate-900">
              Recorded Cases Registry ({cases.length} entries)
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-semibold no-print">
            Click any row to open full clinical dossier
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs font-bold text-slate-400">
            {t('emergencyDirectory.loading', 'Loading reports and synchronizing data...')}
          </div>
        ) : cases.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <FileText className="w-10 h-10 mx-auto text-slate-300" />
            <h4 className="text-sm font-extrabold text-slate-700">
              {t('reports.noReports', 'No report records match the selected filters.')}
            </h4>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] uppercase tracking-wider font-extrabold text-slate-500">
                  <th className="py-3 px-4">{t('reports.colCaseId', 'Case ID')}</th>
                  <th className="py-3 px-4">{t('reports.colDisease', 'Disease / Condition')}</th>
                  <th className="py-3 px-4">{t('reports.colSeverity', 'Severity')}</th>
                  <th className="py-3 px-4">{t('reports.colArea', 'Mandal / Area')}</th>
                  <th className="py-3 px-4">{t('reports.colStatus', 'Status')}</th>
                  <th className="py-3 px-4">{t('reports.colDate', 'Date')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {cases.map(c => {
                  const diseaseKey = c.diseasePrediction ? c.diseasePrediction.replace(/\s+/g, '_') : 'Healthy_Buffalo';
                  const sevKey = (c.severity || 'low').toLowerCase();
                  const statKey = (c.status || 'open').toLowerCase().replace(/\s+/g, '');
                  const isHighSev = c.severity === 'High' || c.severity === 'Critical';

                  return (
                    <tr 
                      key={c._id} 
                      onClick={() => window.location.href = `/cases/${c.caseId || c._id}`}
                      className="hover:bg-emerald-50/50 cursor-pointer transition text-xs font-semibold"
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-950">
                        {c.caseId || `#${c._id.slice(-6).toUpperCase()}`}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {t(`diseases.${diseaseKey}`, c.diseasePrediction || 'Healthy Buffalo')}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                          isHighSev 
                            ? 'bg-rose-50 text-rose-700 border-rose-200' 
                            : c.severity === 'Medium' 
                              ? 'bg-amber-50 text-amber-700 border-amber-200' 
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        }`}>
                          {t(`severity.${sevKey}`, c.severity || 'Low')} ({c.riskPercentage || '90'}%)
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {c.area || 'Krishna District'}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 text-[11px] font-bold">
                          {t(`status.${statKey}`, c.status || 'Open')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-500 font-mono">
                        {new Date(c.createdAt || Date.now()).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Print-specific style */}
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #analytics-printable-header, #analytics-printable-header * {
            visibility: visible !important;
            display: block !important;
          }
          .max-w-7xl, .max-w-7xl * {
            visibility: visible !important;
          }
          .no-print {
            display: none !important;
          }
          .max-w-7xl {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 16px !important;
          }
        }
      `}</style>
    </div>
  );
}
