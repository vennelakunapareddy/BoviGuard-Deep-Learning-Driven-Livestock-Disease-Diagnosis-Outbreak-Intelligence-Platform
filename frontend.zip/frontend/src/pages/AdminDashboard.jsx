import React, { useState, useEffect } from 'react';
import { ShieldCheck, Users, FileText, AlertTriangle, CheckCircle, Trash2, Loader, RefreshCw, BarChart3 } from 'lucide-react';
import axios from 'axios';
import { useTranslation } from '../context/LanguageContext';

export default function AdminDashboard() {
  const { t } = useTranslation();
  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}` };

  const [users, setUsers] = useState([]);
  const [cases, setCases] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('users');
  const [actionMsg, setActionMsg] = useState('');

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    setLoading(true);
    setError('');
    try {
      const [usersRes, casesRes, statsRes] = await Promise.all([
        axios.get('/api/users', { headers }),
        axios.get('/api/cases', { headers }),
        axios.get('/api/dashboard/stats', { headers }),
      ]);
      setUsers(usersRes.data || []);
      setCases(casesRes.data || []);
      setStats(statsRes.data || {});
    } catch (err) {
      setError('Failed to load admin data: ' + (err?.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  const verifyUser = async (userId) => {
    try {
      await axios.put(`/api/users/${userId}/verify`, {}, { headers });
      setUsers(prev => prev.map(u => String(u._id || u.id) === String(userId) ? { ...u, verified: true } : u));
      setActionMsg('User verified successfully.');
      setTimeout(() => setActionMsg(''), 3000);
    } catch (err) {
      setActionMsg('Error: ' + (err?.response?.data?.message || 'Failed to verify user.'));
    }
  };

  const deleteUser = async (userId, userName) => {
    if (!window.confirm(`Remove user "${userName}"? This cannot be undone.`)) return;
    try {
      await axios.delete(`/api/users/${userId}`, { headers });
      setUsers(prev => prev.filter(u => String(u._id || u.id) !== String(userId)));
      setActionMsg('User removed.');
      setTimeout(() => setActionMsg(''), 3000);
    } catch (err) {
      setActionMsg('Error: ' + (err?.response?.data?.message || 'Failed to remove user.'));
    }
  };

  const updateCaseStatus = async (caseId, status) => {
    try {
      await axios.put(`/api/cases/${caseId}`, { status }, { headers });
      setCases(prev => prev.map(c => String(c._id || c.id) === String(caseId) ? { ...c, status } : c));
      setActionMsg(`Case status updated to "${status}".`);
      setTimeout(() => setActionMsg(''), 3000);
    } catch (err) {
      setActionMsg('Error: ' + (err?.response?.data?.message || 'Failed to update case.'));
    }
  };

  const roleColors = {
    admin: 'bg-purple-100 text-purple-700',
    veterinarian: 'bg-blue-100 text-blue-700',
    volunteer: 'bg-green-100 text-green-700',
    buffalo_owner: 'bg-amber-100 text-amber-800',
    animal_owner: 'bg-orange-100 text-orange-700',
    ngo: 'bg-teal-100 text-teal-700',
    system_admin: 'bg-purple-100 text-purple-700',
  };

  if (loading) return (
    <div className="max-w-7xl mx-auto flex items-center justify-center h-64">
      <Loader className="w-8 h-8 animate-spin text-brand-primary" />
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in duration-500 space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-brand-text flex items-center gap-3">
            <ShieldCheck className="text-brand-primary" /> {t('adminPanel.title', 'Admin Control Panel')}
          </h1>
          <p className="text-brand-muted mt-1">{t('adminPanel.subtitle', 'Manage users, verify professionals, and oversee all system cases.')}</p>
        </div>
        <button onClick={fetchAll} className="btn-outline flex items-center gap-2 text-sm">
          <RefreshCw className="w-4 h-4" /> {t('adminPanel.refresh', 'Refresh')}
        </button>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5" /> {error}
        </div>
      )}
      {actionMsg && (
        <div className={`p-4 rounded-xl border flex items-center gap-2 text-sm font-semibold ${actionMsg.startsWith('Error') ? 'bg-red-500/10 border-red-500/30 text-red-400' : 'bg-green-500/10 border-green-500/30 text-green-400'}`}>
          <CheckCircle className="w-5 h-5" /> {actionMsg}
        </div>
      )}

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: t('adminPanel.totalCases', 'Total Cases'), value: stats.totalCases, color: 'text-brand-text' },
            { label: t('adminPanel.activeCases', 'Active Cases'), value: stats.activeCases, color: 'text-orange-400' },
            { label: t('adminPanel.redAlerts', 'Red Alerts'), value: stats.redAlertAreas, color: 'text-red-400' },
            { label: t('adminPanel.resolved', 'Resolved'), value: stats.resolvedCases, color: 'text-green-400' },
          ].map(s => (
            <div key={s.label} className="glass-card p-4">
              <div className="text-xs font-bold text-brand-muted uppercase mb-1">{s.label}</div>
              <div className={`text-3xl font-bold ${s.color}`}>{s.value ?? 0}</div>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b border-brand-card pb-1">
        {[
          { id: 'users', label: `${t('adminPanel.tabsUsers', 'Users')} (${users.length})`, icon: Users },
          { id: 'cases', label: `${t('adminPanel.tabsCases', 'Cases')} (${cases.length})`, icon: FileText },
          { id: 'config', label: t('adminPanel.tabsConfig', 'Config & Analytics'), icon: BarChart3 },
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-t-lg transition ${activeTab === tab.id ? 'bg-brand-primary text-white' : 'text-brand-muted hover:text-brand-text hover:bg-brand-card'}`}
            >
              <Icon className="w-4 h-4" /> {tab.label}
            </button>
          );
        })}
      </div>

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-brand-card">
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colName', 'Name')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colEmail', 'Email')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colRole', 'Role')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colVerified', 'Verified')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colJoined', 'Joined')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colActions', 'Actions')}</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => {
                  const uid = u._id || u.id;
                  return (
                    <tr key={uid} className="border-b border-brand-card/50 hover:bg-brand-dark/30 transition">
                      <td className="py-3 px-4 font-medium text-brand-text">{u.name}</td>
                      <td className="py-3 px-4 text-brand-muted">{u.email}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${roleColors[u.role] || 'bg-slate-100 text-slate-600'}`}>
                          {t(`roles.${u.role}`, u.role?.replace('_', ' '))}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {u.verified ? (
                          <span className="flex items-center gap-1 text-green-500 text-xs font-bold">
                            <CheckCircle className="w-4 h-4" /> {t('adminPanel.verifiedBadge', 'Verified')}
                          </span>
                        ) : (
                          <span className="text-xs text-brand-muted">{t('adminPanel.pendingBadge', 'Pending')}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-brand-muted text-xs">
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '—'}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          {!u.verified && ['veterinarian', 'volunteer'].includes(u.role) && (
                            <button
                              onClick={() => verifyUser(uid)}
                              className="text-xs bg-green-500/10 border border-green-500/30 text-green-400 hover:bg-green-500/20 px-2 py-1 rounded-lg flex items-center gap-1 transition"
                            >
                              <CheckCircle className="w-3 h-3" /> {t('adminPanel.verifyBtn', 'Verify')}
                            </button>
                          )}
                          <button
                            onClick={() => deleteUser(uid, u.name)}
                            className="text-xs bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 px-2 py-1 rounded-lg flex items-center gap-1 transition"
                          >
                            <Trash2 className="w-3 h-3" /> {t('adminPanel.removeBtn', 'Remove')}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {users.length === 0 && (
              <div className="p-8 text-center text-brand-muted">{t('adminPanel.noUsers', 'No users found.')}</div>
            )}
          </div>
        </div>
      )}

      {/* Cases Tab */}
      {activeTab === 'cases' && (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-brand-card">
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colCaseId', 'Case ID')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colDisease', 'Disease')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colArea', 'Area')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colSeverity', 'Severity')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colStatus', 'Status')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colDate', 'Date')}</th>
                  <th className="text-left py-3 px-4 text-brand-muted font-semibold text-xs uppercase">{t('adminPanel.colUpdateStatus', 'Update Status')}</th>
                </tr>
              </thead>
              <tbody>
                {cases.map(c => {
                  const cid = c._id || c.id;
                  const diseaseKey = c.diseasePrediction ? c.diseasePrediction.replace(/\s+/g, '_') : 'Healthy_Buffalo';
                  const sevKey = (c.severity || 'low').toLowerCase();
                  const statKey = (c.status || 'open').toLowerCase().replace(/\s+/g, '');
                  return (
                    <tr key={cid} className="border-b border-brand-card/50 hover:bg-brand-dark/30 transition">
                      <td className="py-3 px-4 font-mono text-xs text-brand-muted">#{String(cid).slice(-6).toUpperCase()}</td>
                      <td className="py-3 px-4 font-medium text-brand-text">{t(`diseases.${diseaseKey}`, t(`diseases.${c.diseasePrediction}`, c.diseasePrediction))}</td>
                      <td className="py-3 px-4 text-brand-muted">{c.area}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${c.severity === 'High' ? 'bg-red-100 text-red-600' : c.severity === 'Medium' ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'}`}>
                          {t(`severity.${sevKey}`, c.severity)}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${c.status === 'Resolved' ? 'bg-green-100 text-green-600' : c.status === 'In Progress' ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-600'}`}>
                          {t(`status.${statKey}`, c.status)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-brand-muted text-xs">
                        {c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '—'}
                      </td>
                      <td className="py-3 px-4">
                        <select
                          value={c.status}
                          onChange={e => updateCaseStatus(cid, e.target.value)}
                          className="text-xs bg-brand-dark border border-brand-card text-brand-text rounded-lg px-2 py-1 outline-none focus:border-brand-primary"
                        >
                          {['Reported', 'Under Observation', 'In Progress', 'Resolved'].map(s => {
                            const sk = s.toLowerCase().replace(/\s+/g, '');
                            return <option key={s} value={s}>{t(`status.${sk}`, s)}</option>;
                          })}
                        </select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {cases.length === 0 && (
              <div className="p-8 text-center text-brand-muted">{t('adminPanel.noCases', 'No cases found.')}</div>
            )}
          </div>
        </div>
      )}

      {/* Config & Analytics Tab */}
      {activeTab === 'config' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="glass-card p-6">
            <h2 className="text-lg font-bold text-brand-text mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" /> {t('adminPanel.redZoneThresholds', 'Red Zone Thresholds')}
            </h2>
            <form onSubmit={e => { e.preventDefault(); setActionMsg('Thresholds updated successfully.'); setTimeout(() => setActionMsg(''), 3000); }} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-brand-muted uppercase mb-2">{t('adminPanel.critThresholdLabel', 'Critical Case Count Threshold (per Area/Week)')}</label>
                <input type="number" defaultValue={5} className="w-full bg-brand-dark border border-brand-card text-brand-text rounded-lg p-2 focus:border-brand-primary outline-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-brand-muted uppercase mb-2">{t('adminPanel.highSevTriggerLabel', 'High Severity Trigger (%)')}</label>
                <input type="number" defaultValue={60} className="w-full bg-brand-dark border border-brand-card text-brand-text rounded-lg p-2 focus:border-brand-primary outline-none" />
              </div>
              <button type="submit" className="btn-primary w-full mt-4">{t('adminPanel.saveConfigBtn', 'Save Configuration')}</button>
            </form>
          </div>

          <div className="glass-card p-6">
            <h2 className="text-lg font-bold text-brand-text mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-brand-primary" /> {t('adminPanel.geoAnalytics', 'Geographic Disease Analytics')}
            </h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-semibold text-brand-text mb-1">
                  <span>Benz Circle (FMD)</span>
                  <span className="text-red-400">{t('adminPanel.highRisk', 'High Risk')} (8 Cases)</span>
                </div>
                <div className="w-full bg-brand-dark rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: '80%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-semibold text-brand-text mb-1">
                  <span>Autonagar (LSD)</span>
                  <span className="text-orange-400">{t('adminPanel.mediumRisk', 'Medium Risk')} (3 Cases)</span>
                </div>
                <div className="w-full bg-brand-dark rounded-full h-2">
                  <div className="bg-orange-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-semibold text-brand-text mb-1">
                  <span>MG Road (Mastitis)</span>
                  <span className="text-brand-primary">{t('adminPanel.lowRisk', 'Low Risk')} (1 Case)</span>
                </div>
                <div className="w-full bg-brand-dark rounded-full h-2">
                  <div className="bg-brand-primary h-2 rounded-full" style={{ width: '10%' }}></div>
                </div>
              </div>
            </div>
            <div className="mt-6 pt-4 border-t border-brand-card">
              <p className="text-xs text-brand-muted">{t('adminPanel.geoNote', 'Analytics are generated in real-time based on incoming case reports and CNN predictions.')}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
