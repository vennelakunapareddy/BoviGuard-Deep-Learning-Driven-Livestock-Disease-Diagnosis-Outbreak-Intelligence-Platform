import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  UploadCloud, 
  Camera, 
  CheckCircle, 
  AlertTriangle, 
  ShieldAlert, 
  Zap, 
  Save, 
  Info,
  Activity,
  HeartPulse,
  Search,
  X,
  RotateCcw,
  Check,
  ChevronRight,
  Filter,
  Sparkles
} from 'lucide-react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import DiagnosisResult from '../components/DiagnosisResult';
import { useTranslation } from '../context/LanguageContext';
import { classifyBuffaloImageClient } from '../services/clientImageClassifier';

const SYMPTOM_CATEGORIES = [
  {
    id: 'mouth_hoof',
    label: 'Mouth & Hoof',
    shortLabel: 'Mouth / Hoof',
    symptoms: [
      'Blisters on Mouth / Tongue / Lips',
      'Mouth Lesions',
      'Excessive Salivation (Drooling)',
      'Smacking of Lips',
      'Hoof Swelling / Blisters',
      'Lameness / Difficulty Walking',
      'Interdigital Foot Wounds',
      'Reluctance to Stand'
    ]
  },
  {
    id: 'skin_nodules',
    label: 'Skin & Nodules',
    shortLabel: 'Skin / Nodules',
    symptoms: [
      'Skin Nodules',
      'Crusty Skin Patches',
      'Hair Loss / Alopecia',
      'Itching',
      'Skin Abrasion / Lesion',
      'Bleeding Wound',
      'Swelling in Throat / Dewlap / Neck'
    ]
  },
  {
    id: 'udder_milk',
    label: 'Udder & Milk',
    shortLabel: 'Udder / Milk',
    symptoms: [
      'Hard/Swollen Udder',
      'Reduced Milk',
      'Vesicles on Udder',
      'Blood or Clots in Milk',
      'Hot / Painful Teats',
      'Watery / Discolored Milk'
    ]
  },
  {
    id: 'general_systemic',
    label: 'Systemic & General',
    shortLabel: 'Systemic',
    symptoms: [
      'Fever / High Temperature',
      'Loss of Appetite',
      'Lethargy',
      'Shivering / Muscle Tremors',
      'Nasal Discharge / Coughing',
      'Labored / Heavy Breathing',
      'Watery Eyes / Lacrimation',
      'Abdominal Bloat / Swollen Belly',
      'Severe Diarrhea / Loose Dung',
      'Rapid Weight Loss / Dullness',
      'Clear Eyes / Active (Normal)'
    ]
  }
];

export default function AIScan() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [image, setImage] = useState(null);
  const [fileObj, setFileObj] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [nonBuffaloData, setNonBuffaloData] = useState(null);
  const [savingCase, setSavingCase] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showSymptoms, setShowSymptoms] = useState(false);
  const [activeCategory, setActiveCategory] = useState('all');
  const [symptomSearch, setSymptomSearch] = useState('');
  const resultRef = useRef(null);

  const fileInputRef = useRef(null);
  const nativeCameraInputRef = useRef(null);
  const [scanMode, setScanMode] = useState('upload'); // 'upload' | 'camera'
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraLoading, setCameraLoading] = useState(false);
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  // Auto-bind active camera stream to video element
  useEffect(() => {
    let active = true;
    if (cameraActive && streamRef.current && videoRef.current) {
      const vid = videoRef.current;
      vid.srcObject = streamRef.current;
      vid.setAttribute('playsinline', 'true');
      vid.setAttribute('autoplay', 'true');
      vid.setAttribute('muted', 'true');
      vid.play().catch(e => console.warn('Video auto-play interrupted:', e));
    }
    return () => {
      active = false;
    };
  }, [cameraActive, scanMode]);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
    setCameraLoading(false);
  };

  const startCamera = async () => {
    setErrorMsg(null);
    setCameraLoading(true);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraLoading(false);
      nativeCameraInputRef.current?.click();
      return;
    }

    const constraintConfigs = [
      { video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false },
      { video: { facingMode: 'environment' }, audio: false },
      { video: { facingMode: 'user' }, audio: false },
      { video: true, audio: false }
    ];

    let activeStream = null;
    for (const constraints of constraintConfigs) {
      try {
        activeStream = await navigator.mediaDevices.getUserMedia(constraints);
        if (activeStream) break;
      } catch (e) {
        console.warn('Camera constraint attempt:', constraints, e);
      }
    }

    if (activeStream) {
      streamRef.current = activeStream;
      setCameraActive(true);
      setCameraLoading(false);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = activeStream;
          videoRef.current.play().catch(() => {});
        }
      }, 50);
    } else {
      setCameraLoading(false);
      nativeCameraInputRef.current?.click();
    }
  };

  const captureFrame = async () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setImage(dataUrl);

    const blob = await (await fetch(dataUrl)).blob();
    const capturedFile = new File([blob], `camera_${Date.now()}.jpg`, { type: 'image/jpeg' });
    setFileObj(capturedFile);
    stopCamera();
    setScanMode('upload');
  };

  const handlePredictionResponse = (predictionData) => {
    if (!predictionData) return;
    if (predictionData.isBuffalo === false || predictionData.is_buffalo === false) {
      setNonBuffaloData({
        status: predictionData.status || "rejected",
        entityType: predictionData.entityType || "Non-Buffalo Subject",
        predictedSubject: predictionData.predictedSubject || "Non-Buffalo Image",
        confidenceScore: Number(predictionData.confidenceScore || predictionData.confidence || 0),
        detectedEntityIcon: predictionData.detectedEntityIcon || "⚠️",
        message: predictionData.message || "⚠️ This image does not appear to contain a buffalo. Please upload a clear photo of a buffalo."
      });
      setResult(null);
      setErrorMsg(null);
    } else {
      setResult(predictionData);
      setNonBuffaloData(null);
      setErrorMsg(null);
    }
  };

  // Form details
  const [formData, setFormData] = useState({
    tag: '',
    age: '',
    area: '',
    street: '',
    pincode: '',
    symptoms: [],
    additionalSymptoms: '',
    latitude: null,
    longitude: null
  });

  const availableSymptoms = [
    'Hard/Swollen Udder',
    'Reduced Milk',
    'Vesicles on Udder',
    'Blood or Clots in Milk',
    'Hot / Painful Teats',
    'Watery / Discolored Milk',
    'Blisters on Mouth / Tongue / Lips',
    'Mouth Lesions',
    'Excessive Salivation (Drooling)',
    'Smacking of Lips',
    'Hoof Swelling / Blisters',
    'Lameness / Difficulty Walking',
    'Interdigital Foot Wounds',
    'Reluctance to Stand',
    'Skin Nodules',
    'Crusty Skin Patches',
    'Hair Loss / Alopecia',
    'Itching',
    'Skin Abrasion / Lesion',
    'Bleeding Wound',
    'Swelling in Throat / Dewlap / Neck',
    'Nasal Discharge / Coughing',
    'Labored / Heavy Breathing',
    'Watery Eyes / Lacrimation',
    'Fever / High Temperature',
    'Loss of Appetite',
    'Lethargy',
    'Shivering / Muscle Tremors',
    'Abdominal Bloat / Swollen Belly',
    'Severe Diarrhea / Loose Dung',
    'Rapid Weight Loss / Dullness',
    'Clear Eyes / Active (Normal)'
  ];

  const handleSymptomToggle = (symp) => {
    setFormData(prev => ({
      ...prev,
      symptoms: prev.symptoms.includes(symp)
        ? prev.symptoms.filter(s => s !== symp)
        : [...prev.symptoms, symp]
    }));
  };

  useEffect(() => {
    if (scanning || result || nonBuffaloData || errorMsg) {
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }, [scanning, result, nonBuffaloData, errorMsg]);

  const filteredSymptoms = useMemo(() => {
    let list = availableSymptoms;
    if (activeCategory !== 'all') {
      const cat = SYMPTOM_CATEGORIES.find(c => c.id === activeCategory);
      if (cat) list = cat.symptoms;
    }
    if (symptomSearch.trim()) {
      const q = symptomSearch.toLowerCase().trim();
      list = list.filter(s =>
        s.toLowerCase().includes(q) ||
        t(`symptoms.${s}`, s).toLowerCase().includes(q)
      );
    }
    return list;
  }, [activeCategory, symptomSearch, availableSymptoms, t]);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileObj(file);
      const url = URL.createObjectURL(file);
      setImage(url);
      setResult(null);
      setErrorMsg(null);
      setNonBuffaloData(null);
      setSaveSuccess(false);
      stopCamera();
    }
  };

  const startAnalysis = async () => {
    if (!image) {
      setErrorMsg(t('validation.imageRequired', 'Please upload or capture an image of the affected area.'));
      return;
    }

    const currentRequestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    setScanning(true);
    setResult(null);
    setErrorMsg(null);
    setNonBuffaloData(null);
    setSaveSuccess(false);

    try {
      let imageBase64 = '';
      if (fileObj) {
        imageBase64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result.split(',')[1]);
          reader.onerror = error => reject(error);
          reader.readAsDataURL(fileObj);
        });
      }

      let predictionData = null;

      // 1. Try Express Backend /api/cases/predict (with 45-second timeout)
      try {
        const token = localStorage.getItem('token');
        const caseFormData = new FormData();
        caseFormData.append('requestId', currentRequestId);
        caseFormData.append('animalType', 'Buffalo');
        if (formData.symptoms && formData.symptoms.length > 0) {
          caseFormData.append('symptoms', JSON.stringify(formData.symptoms));
        }
        if (fileObj) {
          caseFormData.append('image', fileObj);
        } else if (imageBase64) {
          caseFormData.append('imageBase64', imageBase64);
        }

        const res = await axios.post('/api/cases/predict', caseFormData, {
          headers: token ? { Authorization: `Bearer ${token}` } : {},
          timeout: 45000
        });
        predictionData = res.data;
      } catch (backendErr) {
        console.warn('Backend predict endpoint failed, attempting direct ML call:', backendErr);
        if (backendErr.response?.data?.isBuffalo === false || backendErr.response?.data?.is_buffalo === false) {
          predictionData = backendErr.response.data;
        }
      }

      // 2. Direct FastAPI ML endpoint on port 5000 fallback
      if (!predictionData) {
        try {
          const formDataPayload = new FormData();
          formDataPayload.append('requestId', currentRequestId);
          formDataPayload.append('animalType', 'Buffalo');
          if (formData.symptoms && formData.symptoms.length > 0) {
            formDataPayload.append('symptoms', formData.symptoms.join(', '));
          }
          if (fileObj) {
            formDataPayload.append('image', fileObj);
          } else if (imageBase64) {
            formDataPayload.append('imageBase64', imageBase64);
          }

          const targetMlUrl = (typeof window !== 'undefined' && localStorage.getItem('server_url'))
            ? localStorage.getItem('server_url').replace(':3000', ':5000') + '/predict'
            : 'http://192.168.0.100:5000/predict';

          const controller = new AbortController();
          const timerId = setTimeout(() => controller.abort(), 45000);
          const mlRes = await fetch(targetMlUrl, {
            method: 'POST',
            body: formDataPayload,
            signal: controller.signal
          });
          clearTimeout(timerId);
          if (mlRes.ok) {
            predictionData = await mlRes.json();
          }
        } catch (mlErr) {
          console.warn('Direct ML call failed:', mlErr);
        }
      }

      // 3. Fallback to client-side Visual Edge AI when offline
      if (!predictionData) {
        predictionData = await runEdgePrediction(fileObj, imageBase64 || image, formData);
      }

      if (predictionData) {
        handlePredictionResponse(predictionData);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      const fallbackEdge = await runEdgePrediction(fileObj, image, formData);
      handlePredictionResponse(fallbackEdge);
    } finally {
      setScanning(false);
    }
  };

  const runEdgePrediction = async (file, base64OrDataUrl, form) => {
    try {
      const visualInput = file || base64OrDataUrl || image;
      const clientResult = await classifyBuffaloImageClient(visualInput, {
        symptoms: form?.symptoms || []
      });
      return clientResult;
    } catch (err) {
      console.error('Edge prediction error:', err);
      return {
        isBuffalo: false,
        is_buffalo: false,
        status: 'rejected',
        entityType: 'Uncertain Visual Evidence',
        predictedSubject: 'Uncertain Frame',
        detectedEntityIcon: '⚠️',
        message: 'Prediction could not be completed reliably on this image. Please upload a clear, well-lit photograph of a buffalo.',
        confidenceScore: 0,
        confidence: 0
      };
    }
  };

  const handleCreateCaseFromPrediction = async () => {
    if (!result || !result.diseasePrediction) return;
    setSavingCase(true);
    try {
      const token = localStorage.getItem('token');
      const caseFormData = new FormData();
      caseFormData.append('animalType', 'Buffalo');
      caseFormData.append('age', formData.age || '4');
      caseFormData.append('tagNumber', formData.tag || 'BUF-' + Math.floor(1000 + Math.random() * 9000));
      caseFormData.append('area', formData.area || 'Vijayawada');
      caseFormData.append('streetName', formData.street || 'Main Road');
      caseFormData.append('pincode', formData.pincode || '520001');
      caseFormData.append('diseasePrediction', result.diseasePrediction);
      caseFormData.append('confidenceScore', result.confidenceScore);
      caseFormData.append('severity', result.severity);
      caseFormData.append('recommendations', JSON.stringify(result.precautions || []));
      caseFormData.append('precautions', JSON.stringify(result.precautions || []));
      caseFormData.append('immediateAction', result.immediateAction || '');
      caseFormData.append('symptoms', JSON.stringify(formData.symptoms.length ? formData.symptoms : (result.symptoms || ['Visual skin lesion'])));

      if (fileObj) {
        caseFormData.append('image', fileObj);
      }

      const { data } = await axios.post('/api/cases', caseFormData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data'
        }
      });

      if (data.success || data.case) {
        setSaveSuccess(true);
        setTimeout(() => {
          navigate('/dashboard');
        }, 1200);
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to save digital health record.');
    } finally {
      setSavingCase(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-2 px-1 sm:px-4">
      {/* Sleek, Neat Header */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-3xl p-6 text-white shadow-md flex items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 rounded-full text-[11px] font-bold uppercase tracking-wider text-emerald-300 border border-emerald-500/30">
            <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
            {t('aiScan.badge', 'AI Disease Diagnostic')}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            {t('aiScan.title', 'Buffalo Health AI Scan')}
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm font-medium">
            {t('aiScan.subtitle', 'Instant disease prediction for FMD, LSD, Mastitis, and Healthy buffaloes.')}
          </p>
        </div>
      </div>

      {/* Hidden Native Camera Input for 1-Tap Mobile Snapping */}
      <input 
        type="file" 
        ref={nativeCameraInputRef} 
        onChange={handleImageUpload} 
        accept="image/*" 
        capture="environment" 
        className="hidden" 
      />

      {/* Hidden File Picker */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleImageUpload} 
        accept="image/*" 
        className="hidden" 
      />

      {/* Main Intake Card (Neat & Streamlined) */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/90 shadow-sm space-y-5">
        
        {/* Sleek 2-Tab Segmented Control: Upload Photo | Camera */}
        <div className="flex items-center justify-center p-1 bg-slate-100 rounded-2xl max-w-sm mx-auto">
          <button
            type="button"
            onClick={() => { stopCamera(); setScanMode('upload'); }}
            className={`flex-1 py-2 px-4 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
              scanMode === 'upload' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UploadCloud className="w-4 h-4" />
            {t('aiScan.uploadPhoto', 'Upload Photo')}
          </button>
          <button
            type="button"
            onClick={() => { stopCamera(); nativeCameraInputRef.current?.click(); }}
            className="flex-1 py-2 px-4 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
          >
            <Camera className="w-4 h-4" />
            {t('aiScan.snapPhoto', 'Snap Photo')}
          </button>
        </div>

        {/* Photo View / Live Video */}
        {scanMode === 'camera' ? (
          <div className="rounded-2xl overflow-hidden border-2 border-emerald-500 bg-slate-950 p-3 space-y-3 max-w-md mx-auto">
            <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center max-h-[260px]">
              {cameraLoading ? (
                <div className="flex flex-col items-center justify-center gap-2 p-4 text-center">
                  <div className="w-8 h-8 border-3 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                  <p className="text-xs font-bold text-emerald-400">Opening Camera...</p>
                </div>
              ) : !cameraActive ? (
                <div className="flex flex-col items-center justify-center gap-2 p-4 text-center">
                  <AlertTriangle className="w-6 h-6 text-amber-400" />
                  <p className="text-xs font-bold text-slate-300">Camera standby</p>
                  <button
                    type="button"
                    onClick={startCamera}
                    className="mt-1 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow"
                  >
                    Activate Camera
                  </button>
                </div>
              ) : (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              )}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={captureFrame}
                disabled={!cameraActive}
                className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Camera className="w-4 h-4" />
                Capture Frame
              </button>
              <button
                type="button"
                onClick={() => { stopCamera(); setScanMode('upload'); }}
                className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div>
            {image ? (
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-950 max-h-[340px] flex items-center justify-center group shadow-inner">
                <img src={image} alt="Upload preview" className="max-h-[320px] w-auto max-w-full object-contain" />
                
                {/* Photo Ready Badge */}
                <div className="absolute top-3 left-3 px-3 py-1 rounded-lg bg-emerald-600/90 text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md shadow">
                  <Check className="w-3.5 h-3.5 stroke-[3]" /> Photo Ready
                </div>

                {/* Floating Bottom Action Buttons */}
                <div className="absolute bottom-3 right-3 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-1.5 bg-white/95 hover:bg-white text-slate-800 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition active:scale-95"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-emerald-600" /> Change
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setImage(null);
                      setFileObj(null);
                      setResult(null);
                      setErrorMsg(null);
                      setNonBuffaloData(null);
                    }}
                    className="px-3.5 py-1.5 bg-rose-600/95 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition active:scale-95"
                  >
                    <X className="w-3.5 h-3.5" /> Remove
                  </button>
                </div>
              </div>
            ) : (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-8 text-center cursor-pointer transition bg-slate-50/50 hover:bg-emerald-50/20 flex flex-col items-center justify-center gap-3 min-h-[220px]"
              >
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-xs">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-extrabold text-slate-800">
                    {t('aiScan.clickOrDrag', 'Tap to upload or select a buffalo image')}
                  </p>
                  <p className="text-xs text-slate-500 font-medium">
                    Upload skin lesions, udder, mouth, or body photos (JPG, PNG)
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Collapsible Symptoms Section (Clean & Uncluttered) */}
        <div className="border border-slate-200/90 rounded-2xl p-4 bg-slate-50/60 transition">
          <button
            type="button"
            onClick={() => setShowSymptoms(!showSymptoms)}
            className="w-full flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2">
              <HeartPulse className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-extrabold text-slate-800">
                {t('aiScan.symptomsLabel', 'Observable Clinical Symptoms')}
              </span>
              <span className="text-[11px] text-slate-400 font-normal">(Optional)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold transition ${
                formData.symptoms.length > 0 ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-slate-200 text-slate-600'
              }`}>
                {formData.symptoms.length} {t('createCase.selectedCount', 'selected')}
              </span>
              <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${showSymptoms ? 'rotate-90' : ''}`} />
            </div>
          </button>

          {showSymptoms && (
            <div className="mt-3 pt-3 border-t border-slate-200/80 space-y-3 animate-fadeIn">
              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                <button
                  type="button"
                  onClick={() => setActiveCategory('all')}
                  className={`px-2.5 py-1 rounded-lg font-bold whitespace-nowrap transition ${
                    activeCategory === 'all'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  All
                </button>
                {SYMPTOM_CATEGORIES.map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setActiveCategory(cat.id)}
                    className={`px-2.5 py-1 rounded-lg font-bold whitespace-nowrap transition ${
                      activeCategory === cat.id
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    {cat.shortLabel}
                  </button>
                ))}
              </div>

              {/* Symptom Chips */}
              <div className="flex flex-wrap gap-1.5 max-h-[190px] overflow-y-auto p-1 bg-white rounded-xl border border-slate-200/70">
                {filteredSymptoms.map((symp) => {
                  const isChecked = formData.symptoms.includes(symp);
                  return (
                    <button
                      key={symp}
                      type="button"
                      onClick={() => handleSymptomToggle(symp)}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 border ${
                        isChecked
                          ? 'bg-emerald-600 text-white border-emerald-600 font-bold shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span>{t(`symptoms.${symp}`, symp)}</span>
                      {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                    </button>
                  );
                })}
              </div>

              {formData.symptoms.length > 0 && (
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, symptoms: [] }))}
                    className="text-[11px] font-bold text-rose-600 hover:text-rose-700 underline"
                  >
                    Clear selected symptoms
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Button: Run AI Disease Analysis */}
        <button
          onClick={startAnalysis}
          disabled={!image || scanning}
          className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-800 disabled:from-slate-300 disabled:to-slate-400 disabled:cursor-not-allowed text-white rounded-2xl text-sm font-black transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 active:scale-[0.99]"
        >
          {scanning ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>{t('aiScan.runningAnalysis', 'Analyzing image with AI...')}</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 fill-white" />
              <span>{t('aiScan.runAnalysis', 'Run AI Disease Analysis')}</span>
            </>
          )}
        </button>
      </div>

      {/* Output Section */}
      <div ref={resultRef} className="w-full space-y-6 pt-1">
        
        {/* Scanning Card */}
        {scanning && (
          <div className="bg-white rounded-3xl p-7 border border-slate-200 shadow-md text-center space-y-4 animate-fadeIn">
            <div className="relative w-14 h-14 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-emerald-500/20 animate-ping" />
              <div className="w-14 h-14 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin" />
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Dual-Modality AI Disease Prediction...
              </h3>
              <p className="text-xs text-slate-500 font-medium max-w-sm mx-auto">
                Extracting deep features with PyTorch MobileNet-V2 & SSDLite to diagnose disease.
              </p>
            </div>
          </div>
        )}

        {/* Non-Buffalo Rejection Alert Card */}
        {nonBuffaloData && (
          <div className="bg-white rounded-3xl p-6 sm:p-7 border-2 border-amber-300 shadow-xl space-y-5 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-rose-100 border border-rose-300 text-rose-900">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Prediction Rejected: No Buffalo Detected</span>
              </div>
              <span className="text-3xl">{nonBuffaloData.detectedEntityIcon}</span>
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">AI Identification Gate</span>
              <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                <span>{nonBuffaloData.predictedSubject}</span>
              </h2>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 rounded-lg text-xs font-bold text-slate-700">
                <span>Category:</span>
                <span className="text-amber-800 font-extrabold">{nonBuffaloData.entityType}</span>
              </div>
            </div>

            {nonBuffaloData.confidenceScore > 0 && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-bold text-slate-700">
                  <span>Detection Confidence</span>
                  <span className="text-amber-800 font-extrabold">{nonBuffaloData.confidenceScore}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full" 
                    style={{ width: `${Math.min(100, Math.max(20, nonBuffaloData.confidenceScore))}%` }}
                  />
                </div>
              </div>
            )}

            <div className="p-3.5 bg-rose-50 rounded-2xl border border-rose-200">
              <p className="text-xs font-bold text-rose-950 leading-relaxed">
                {nonBuffaloData.message}
              </p>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setImage(null);
                  setFileObj(null);
                  setNonBuffaloData(null);
                  fileInputRef.current?.click();
                }}
                className="py-3 px-5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition flex items-center gap-2 shadow-sm"
              >
                <UploadCloud className="w-4 h-4" />
                Upload Buffalo Photo
              </button>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMsg && (
          <div className="bg-rose-50 border border-rose-300 p-5 rounded-3xl space-y-3 animate-fadeIn">
            <div className="flex items-center gap-2 text-rose-900 font-black text-sm">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>Diagnostic Input Notice</span>
            </div>
            <p className="text-xs text-rose-800 font-bold leading-relaxed">
              {errorMsg}
            </p>
          </div>
        )}

        {/* Prediction Results */}
        {result && (
          <DiagnosisResult
            result={result}
            image={image}
            onSaveCase={handleCreateCaseFromPrediction}
            savingCase={savingCase}
            saveSuccess={saveSuccess}
            onReset={() => {
              setImage(null);
              setFileObj(null);
              setResult(null);
              setErrorMsg(null);
              setNonBuffaloData(null);
            }}
          />
        )}
      </div>
    </div>
  );
}
