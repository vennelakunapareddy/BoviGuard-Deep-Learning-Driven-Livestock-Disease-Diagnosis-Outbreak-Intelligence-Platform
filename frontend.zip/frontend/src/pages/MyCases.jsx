import React, { useState, useEffect } from 'react';
import { 
  FolderClock, 
  Filter, 
  Search, 
  ChevronRight, 
  ShieldAlert, 
  ShieldCheck, 
  Activity, 
  AlertTriangle, 
  X,
  Edit,
  Trash2,
  ExternalLink,
  CheckCircle2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { 
  getDiseaseInfo, 
  isSpreadableDisease, 
  MANDATORY_ISOLATION_INSTRUCTION, 
  CLINICAL_SAMPLE_DIRECTIVES, 
  DISEASE_AWARENESS 
} from '../constants/diseaseInfo';
import { useTranslation } from '../context/LanguageContext';

export default function MyCases() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCase, setSelectedCase] = useState(null);
  
  // Status update & delete state
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [statusVal, setStatusVal] = useState('Open');
  const [toast, setToast] = useState('');
  const [deleteId, setDeleteId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get('/api/cases?mine=true', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      setCases(Array.isArray(data) ? data : []);
    } catch (err) {
      console.warn('Network issue fetching cases, loading device cases:', err);
      try {
        const { getInitialCases } = await import('../data/initialCases');
        setCases(getInitialCases());
      } catch {
        setCases([]);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (caseId, newStatus) => {
    try {
      const { data } = await axios.put(`/api/cases/${caseId}`, {
        status: newStatus
      }, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      if (selectedCase && (selectedCase._id === caseId || selectedCase.caseId === caseId)) {
        setSelectedCase(data.case || { ...selectedCase, status: newStatus });
      }
      setToast(t('myCases.statusUpdatedToast', 'Case status updated successfully.'));
      setTimeout(() => setToast(''), 3000);
      setIsUpdatingStatus(false);
      fetchCases();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update case status.');
    }
  };

  const handleDeleteCase = async (idToDelete) => {
    setDeleting(true);
    try {
      await axios.delete(`/api/cases/${idToDelete}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      setDeleteId(null);
      if (selectedCase && (selectedCase._id === idToDelete || selectedCase.caseId === idToDelete)) {
        setSelectedCase(null);
      }
      setToast(t('myCases.caseDeletedToast', 'Case record deleted successfully.'));
      setTimeout(() => setToast(''), 3000);
      fetchCases();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete case record.');
    } finally {
      setDeleting(false);
    }
  };

  const getSeverityColor = (sev) => {
    switch(String(sev).toUpperCase()) {
      case 'CRITICAL': return 'text-purple-600 bg-purple-100 border-purple-200';
      case 'HIGH':
      case 'SEVERE': return 'text-rose-600 bg-rose-100 border-rose-200';
      case 'MEDIUM':
      case 'MODERATE': return 'text-amber-600 bg-amber-100 border-amber-200';
      case 'LOW':
      case 'MILD': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      default: return 'text-emerald-700 bg-emerald-100 border-emerald-200';
    }
  };

  const filteredCases = cases.filter(c => 
    (c._id && c._id.toLowerCase().includes(searchTerm.toLowerCase())) || 
    (c.caseId && c.caseId.toLowerCase().includes(searchTerm.toLowerCase())) || 
    (c.tagNumber && c.tagNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (c.diseasePrediction && c.diseasePrediction.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const stats = {
    total: cases.length,
    active: cases.filter(c => c.status !== 'Resolved' && c.status !== 'Closed').length,
    resolved: cases.filter(c => c.status === 'Resolved' || c.status === 'Closed').length,
    critical: cases.filter(c => c.severity === 'Critical').length,
    high: cases.filter(c => c.severity === 'High').length,
    medium: cases.filter(c => c.severity === 'Medium').length,
    low: cases.filter(c => c.severity === 'Low').length,
  };

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in duration-500 relative space-y-6">
      {/* Toast Alert */}
      {toast && (
        <div className="fixed top-6 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-2xl font-bold text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-200" />
          <span>{toast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 flex items-center gap-3">
            <FolderClock className="w-7 h-7 text-emerald-600" /> {t('myCases.title', 'My Cases')}
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm font-medium mt-1">
            {t('myCases.subtitle', 'Manage your registered cases, track diagnosis history, and view active treatments.')}
          </p>
        </div>
        <button 
          onClick={fetchCases} 
          className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition shadow-sm self-start sm:self-auto"
        >
          {t('myCases.refresh', 'Refresh Cases')}
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">{t('myCases.total', 'Total')}</div>
          <div className="text-2xl font-black text-slate-900 mt-0.5">{stats.total}</div>
        </div>
        <div className="bg-blue-50/50 p-3.5 rounded-2xl border border-blue-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">{t('myCases.active', 'Active')}</div>
          <div className="text-2xl font-black text-blue-700 mt-0.5">{stats.active}</div>
        </div>
        <div className="bg-emerald-50/50 p-3.5 rounded-2xl border border-emerald-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider">{t('myCases.resolved', 'Resolved')}</div>
          <div className="text-2xl font-black text-emerald-700 mt-0.5">{stats.resolved}</div>
        </div>
        <div className="bg-purple-50/50 p-3.5 rounded-2xl border border-purple-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-purple-600 uppercase tracking-wider">{t('myCases.critical', 'Critical')}</div>
          <div className="text-2xl font-black text-purple-700 mt-0.5">{stats.critical}</div>
        </div>
        <div className="bg-rose-50/50 p-3.5 rounded-2xl border border-rose-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-rose-600 uppercase tracking-wider">{t('myCases.high', 'High')}</div>
          <div className="text-2xl font-black text-rose-700 mt-0.5">{stats.high}</div>
        </div>
        <div className="bg-amber-50/50 p-3.5 rounded-2xl border border-amber-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-amber-600 uppercase tracking-wider">{t('myCases.medium', 'Medium')}</div>
          <div className="text-2xl font-black text-amber-700 mt-0.5">{stats.medium}</div>
        </div>
        <div className="bg-yellow-50/50 p-3.5 rounded-2xl border border-yellow-200 text-center shadow-xs">
          <div className="text-[11px] font-bold text-yellow-600 uppercase tracking-wider">{t('myCases.low', 'Low')}</div>
          <div className="text-2xl font-black text-yellow-700 mt-0.5">{stats.low}</div>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              placeholder={t('myCases.search', 'Search cases by tag or disease...')} 
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs font-medium text-slate-800 focus:border-emerald-500 outline-none" 
            />
          </div>
          <span className="text-xs font-bold text-slate-500">
            {filteredCases.length} {t('dashboard.casesCount', 'cases')}
          </span>
        </div>
        
        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-12 text-center text-xs font-bold text-slate-400">{t('common.loading', 'Loading cases...')}</div>
          ) : filteredCases.length === 0 ? (
            <div className="p-12 text-center text-slate-400 space-y-2">
              <FolderClock className="w-12 h-12 mx-auto text-slate-300" />
              <p className="font-bold text-xs">{t('dashboard.noCases', 'No cases reported yet in database.')}</p>
              <button
                onClick={() => navigate('/cases/create')}
                className="mt-2 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition"
              >
                + {t('nav.createCase', 'Register Case')}
              </button>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] uppercase tracking-wider text-slate-400 font-extrabold">
                  <th className="p-4">{t('dashboard.caseIdCol', 'Case ID')} / {t('dashboard.dateCol', 'Date')}</th>
                  <th className="p-4">{t('records.tagNumberCol', 'Tag Number')}</th>
                  <th className="p-4">{t('dashboard.areaCol', 'Area')}</th>
                  <th className="p-4">{t('dashboard.diseaseDiagnosisCol', 'Disease Prediction')}</th>
                  <th className="p-4">{t('records.epidemiologyCol', 'Epidemiology')}</th>
                  <th className="p-4">{t('dashboard.severityCol', 'Severity')}</th>
                  <th className="p-4">{t('dashboard.statusCol', 'Status')}</th>
                  <th className="p-4 text-right">{t('records.actionsCol', 'Actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredCases.map(c => {
                  const isSpreadable = isSpreadableDisease(c.diseasePrediction);
                  return (
                    <tr key={c._id || c.caseId} className="hover:bg-slate-50/50 transition font-medium">
                      <td className="p-4">
                        <div className="font-black text-slate-900">{c.caseId || ('#' + (c._id || '').slice(-6).toUpperCase())}</div>
                        <div className="text-[11px] text-slate-400">{new Date(c.createdAt || Date.now()).toLocaleDateString()}</div>
                      </td>
                      <td className="p-4 font-mono font-bold text-slate-700">{c.tagNumber || 'Unknown'}</td>
                      <td className="p-4 text-slate-600">{c.area || 'Unknown'}</td>
                      <td className="p-4">
                        <span className="font-bold text-slate-900">{t(`diseases.${c.diseasePrediction}`, (c.diseasePrediction || '').replace(/_/g, ' '))}</span>
                        <div className="text-[10px] text-slate-400">{t('diagnosisResult.confidence', 'Confidence')}: {c.confidenceScore}%</div>
                      </td>
                      <td className="p-4">
                        {isSpreadable ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            ⚠️ {t('records.spreadable', 'Spreadable')}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            🟢 {t('records.nonSpreadable', 'Non-Spreadable')}
                          </span>
                        )}
                      </td>
                      <td className="p-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getSeverityColor(c.severity)}`}>
                          {t(`severity.${(c.severity || 'low').toLowerCase()}`, c.severity)}
                        </span>
                      </td>
                      <td className="p-4 font-bold text-slate-800">
                        {t(`status.${(c.status || 'open').toLowerCase().replace(/\s+/g, '')}`, c.status)}
                      </td>
                      <td className="p-4 text-right space-x-1.5">
                        <button 
                          onClick={() => {
                            setSelectedCase(c);
                            setStatusVal(c.status || 'Open');
                            setIsUpdatingStatus(false);
                          }} 
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
                        >
                          {t('dashboard.viewDetails', 'View Details')}
                        </button>
                        <button
                          onClick={() => setDeleteId(c.caseId || c._id)}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-xl transition inline-block"
                          title="Delete case"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Selected Case Detail Modal */}
      {selectedCase && (() => {
        const diseaseInfo = getDiseaseInfo(selectedCase.diseasePrediction);
        const isSpreadable = isSpreadableDisease(selectedCase.diseasePrediction);

        return (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-7 relative space-y-5 animate-in zoom-in-95 duration-200">
              <button 
                onClick={() => setSelectedCase(null)} 
                className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3 pr-8">
                <div>
                  <h2 className="text-xl font-black text-slate-900">{selectedCase.caseId || ('#' + (selectedCase._id || '').slice(-6).toUpperCase())}</h2>
                  <p className="text-xs text-slate-500 font-medium">{t('records.tagNumberCol', 'Tag Number')}: <strong className="font-mono text-slate-800">{selectedCase.tagNumber || 'N/A'}</strong></p>
                </div>
                {isSpreadable ? (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600" /> ⚠️ {t('diagnosisResult.spreadable', 'Spreadable (Contagious)')}
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> 🟢 {t('diagnosisResult.nonSpreadable', 'Non-Spreadable')}
                  </span>
                )}
              </div>

              {/* Status Update Strip */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-600">{t('dashboard.statusCol', 'Status')}:</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-800">
                    {t(`status.${(selectedCase.status || 'open').toLowerCase().replace(/\s+/g, '')}`, selectedCase.status || 'Open')}
                  </span>
                </div>

                {isUpdatingStatus ? (
                  <div className="flex items-center gap-2">
                    <select
                      value={statusVal}
                      onChange={(e) => setStatusVal(e.target.value)}
                      className="text-xs font-bold p-1.5 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="Open">Open</option>
                      <option value="Under Treatment">Under Treatment</option>
                      <option value="Recovered">Recovered</option>
                      <option value="Closed">Closed</option>
                      <option value="Emergency">Emergency</option>
                    </select>
                    <button
                      onClick={() => handleUpdateStatus(selectedCase.caseId || selectedCase._id, statusVal)}
                      className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 transition"
                    >
                      {t('common.save', 'Save')}
                    </button>
                    <button
                      onClick={() => setIsUpdatingStatus(false)}
                      className="px-2 py-1 bg-slate-200 text-slate-700 rounded-lg text-xs font-bold hover:bg-slate-300 transition"
                    >
                      {t('common.cancel', 'Cancel')}
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => { setStatusVal(selectedCase.status || 'Open'); setIsUpdatingStatus(true); }}
                      className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 font-bold rounded-xl text-xs transition flex items-center gap-1.5 shadow-xs"
                    >
                      <Edit className="w-3.5 h-3.5 text-emerald-600" /> {t('caseDetail.updateStatusBtn', 'Update Status')}
                    </button>
                    <button
                      onClick={() => setDeleteId(selectedCase.caseId || selectedCase._id)}
                      className="px-3 py-1.5 bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 font-bold rounded-xl text-xs transition flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> {t('caseDetail.deleteBtn', 'Delete')}
                    </button>
                  </div>
                )}
              </div>

              {/* Spreadable Directive Banner */}
              {isSpreadable ? (
                <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-xs space-y-1 text-rose-900 shadow-xs">
                  <div className="flex items-center gap-2 font-black text-rose-900">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>⚠️ {t('caseDetail.contagiousAlert', 'Contagious Disease Directive')}</span>
                  </div>
                  <p className="text-rose-800 font-bold leading-relaxed">
                    <strong>{t('diagnosisResult.quarantineDirective', 'Mandatory Isolation')}:</strong> {t('diagnosisResult.mandatoryIsolationText', MANDATORY_ISOLATION_INSTRUCTION)}
                  </p>
                </div>
              ) : (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 text-xs space-y-1 text-emerald-900 shadow-xs">
                  <div className="flex items-center gap-2 font-bold text-emerald-900">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>🟢 {t('caseDetail.nonSpreadableAlert', 'Non-Spreadable Condition')}</span>
                  </div>
                </div>
              )}

              {/* Core Info Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('records.diseaseCol', 'Disease Diagnosis')}</span>
                  <span className="font-extrabold text-slate-900 text-sm">{t(`diseases.${selectedCase.diseasePrediction}`, (selectedCase.diseasePrediction || '').replace(/_/g, ' '))}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('records.severityCol', 'Severity')}</span>
                  <span className="font-bold text-slate-800">{t(`severity.${(selectedCase.severity || 'low').toLowerCase()}`, selectedCase.severity)} ({selectedCase.confidenceScore || 85}%)</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('records.areaCol', 'Location')}</span>
                  <span className="font-semibold text-slate-800">{selectedCase.area}, {selectedCase.streetName || ''}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-400 font-bold uppercase text-[10px] block">{t('caseDetail.ownerName', 'Owner')}</span>
                  <span className="font-semibold text-slate-800">{selectedCase.ownerName || selectedCase.registeredBy || 'Owner'}</span>
                </div>
              </div>

              {/* Clinical Sample Directive */}
              {(() => {
                const sampleDirective = CLINICAL_SAMPLE_DIRECTIVES[diseaseInfo.key] || CLINICAL_SAMPLE_DIRECTIVES.Healthy_Buffalo;
                return (
                  <div className={`border-2 rounded-2xl p-4 text-xs space-y-1.5 shadow-xs ${
                    diseaseInfo.key === 'Mastitis'
                      ? 'bg-blue-50/90 border-blue-400'
                      : 'bg-indigo-50/90 border-indigo-300'
                  }`}>
                    <div className="flex items-center gap-2 font-black text-indigo-950 text-xs uppercase tracking-wider">
                      <span className="text-base">{diseaseInfo.key === 'Mastitis' ? '🥛' : '🧪'}</span>
                      <span>
                        {diseaseInfo.key === 'Mastitis'
                          ? t('sampleDirectives.milkSampleTitle', 'Milk Sample Submission Directive (Mastitis)')
                          : t('sampleDirectives.title', 'Clinical Sample Submission for Laboratory Testing')}
                      </span>
                    </div>
                    <p className="font-extrabold text-slate-900 leading-relaxed">
                      {t(`sampleDirectives.${diseaseInfo.key}`, sampleDirective.instruction)}
                    </p>
                  </div>
                );
              })()}

              {/* Action: Open Full EHR Record */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setSelectedCase(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition"
                >
                  {t('common.close', 'Close')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigate(`/cases/${selectedCase.caseId || selectedCase._id}`);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition flex items-center gap-1.5 shadow-sm"
                >
                  <ExternalLink className="w-4 h-4" /> {t('caseDetail.openFullRecord', 'Open Full EHR File')}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Delete Confirmation Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-rose-500 mx-auto animate-bounce" />
            <h3 className="font-extrabold text-base text-slate-900">{t('records.confirmDeleteTitle', 'Confirm Deletion')}</h3>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {t('records.confirmDeleteDesc', 'Are you sure you want to delete this animal health record? This action cannot be undone.')}
            </p>
            <div className="flex gap-3 pt-2">
              <button 
                onClick={() => handleDeleteCase(deleteId)}
                disabled={deleting}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition"
              >
                {deleting ? t('records.deleting', 'Deleting...') : t('records.yesDelete', 'Yes, Delete Record')}
              </button>
              <button 
                onClick={() => setDeleteId(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
              >
                {t('common.cancel', 'Cancel')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
