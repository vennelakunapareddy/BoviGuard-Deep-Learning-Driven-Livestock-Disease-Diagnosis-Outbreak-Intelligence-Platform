import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { FileText, Search, Loader, ShieldCheck, Activity, Trash2, Edit3, Eye, X, CheckCircle, AlertTriangle, PlusCircle, RefreshCw, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  getDiseaseInfo, 
  isSpreadableDisease, 
  MANDATORY_ISOLATION_INSTRUCTION,
  CLINICAL_SAMPLE_DIRECTIVES,
  DISEASE_AWARENESS
} from '../constants/diseaseInfo';
import { useTranslation } from '../context/LanguageContext';

export default function HealthRecords() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const token = localStorage.getItem('token');
  const navigate = useNavigate();
  const isAdmin = Boolean(user && (user.role === 'System Admin' || user.role === 'system_admin' || user.role === 'Admin' || (user.role || '').toLowerCase().includes('admin')));

  const canModifyRecord = (r) => {
    if (!user || !r) return false;
    if (isAdmin) return true;
    const uid = String(user.id || user._id);
    const uemail = (user.email || '').toLowerCase().trim();
    const uname = (user.name || '').toLowerCase().trim();
    const rUid = r.userId ? String(r.userId) : '';
    const rEmail = (r.registeredByEmail || '').toLowerCase().trim();
    const rOwner = (r.ownerName || '').toLowerCase().trim();
    const rRegBy = (r.registeredBy || '').toLowerCase().trim();
    return (rUid && rUid === uid) || (rEmail && rEmail === uemail) || (rOwner && rOwner === uname) || (rRegBy && rRegBy === uname);
  };

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');
  const [spreadableFilter, setSpreadableFilter] = useState('');

  // Selected case for viewing/editing
  const [selectedCase, setSelectedCase] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editStatus, setEditStatus] = useState('Open');
  const [editTreatment, setEditTreatment] = useState('');
  const [editVetNotes, setEditVetNotes] = useState('');
  const [editFollowUp, setEditFollowUp] = useState('');

  // Delete modal state
  const [deleteId, setDeleteId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchRecords();
  }, [user]);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get('/api/cases', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const list = Array.isArray(data) ? data : data.cases || [];
      setRecords(list);
    } catch (err) {
      console.warn('Network issue fetching records, loading device records:', err);
      try {
        const { getInitialCases } = await import('../data/initialCases');
        setRecords(getInitialCases());
      } catch {
        setRecords([]);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async () => {
    if (!selectedCase) return;
    try {
      const { data } = await axios.put(`/api/cases/${selectedCase._id || selectedCase.id}`, {
        status: editStatus,
        treatmentInfo: editTreatment,
        veterinaryNotes: editVetNotes,
        followUpNotes: editFollowUp,
      }, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });

      if (data.success || data.case) {
        setSelectedCase(data.case || { ...selectedCase, status: editStatus, treatmentInfo: editTreatment });
        setIsEditing(false);
        fetchRecords();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update case record.');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await axios.delete(`/api/cases/${deleteId}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      setDeleteId(null);
      if (selectedCase && (selectedCase._id === deleteId || selectedCase.id === deleteId)) {
        setSelectedCase(null);
      }
      fetchRecords();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete record.');
    } finally {
      setDeleting(false);
    }
  };

  const filtered = records.filter(r => {
    const term = searchTerm.toLowerCase();
    const tagMatch = (r.tagNumber || '').toLowerCase().includes(term);
    const diseaseMatch = (r.diseasePrediction || '').toLowerCase().includes(term);
    const areaMatch = (r.area || '').toLowerCase().includes(term);
    const matchesSearch = !searchTerm || tagMatch || diseaseMatch || areaMatch;

    const matchesStatus = !statusFilter || r.status === statusFilter;
    const matchesSeverity = !severityFilter || r.severity === severityFilter;
    const matchesSpreadable = !spreadableFilter || 
      (spreadableFilter === 'Spreadable' ? isSpreadableDisease(r.diseasePrediction) : !isSpreadableDisease(r.diseasePrediction));

    return matchesSearch && matchesStatus && matchesSeverity && matchesSpreadable;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-7 h-7 text-emerald-600" />
            {t('records.title', 'Digital Animal Health Records')}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {t('records.subtitle', 'Complete Electronic Health Records (EHR) & Case Audit Trail for Buffalo Livestock.')}
          </p>
        </div>

        <button 
          onClick={() => navigate('/scan?action=create')}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t('records.newRecord', 'New Health Record')}</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder={t('records.searchPlaceholder', 'Search by tag, disease, or area...')} 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 text-xs rounded-xl text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Spreadable / Non-Spreadable Filter */}
          <select 
            value={spreadableFilter} 
            onChange={(e) => setSpreadableFilter(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-200 text-xs font-bold rounded-xl text-slate-700"
          >
            <option value="">{t('records.allEpidemiologies', 'All Epidemiologies')}</option>
            <option value="Spreadable">{t('records.spreadableOnly', '⚠️ Spreadable Only')}</option>
            <option value="Non-Spreadable">{t('records.nonSpreadableOnly', '🟢 Non-Spreadable Only')}</option>
          </select>

          <select 
            value={statusFilter} 
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-200 text-xs font-semibold rounded-xl text-slate-700"
          >
            <option value="">{t('records.allStatuses', 'All Statuses')}</option>
            <option value="Open">{t('status.open', 'Open')}</option>
            <option value="Under Treatment">{t('status.underTreatment', 'Under Treatment')}</option>
            <option value="Recovered">{t('status.recovered', 'Recovered')}</option>
            <option value="Closed">{t('status.closed', 'Closed')}</option>
            <option value="Emergency">{t('status.emergency', 'Emergency')}</option>
          </select>

          <select 
            value={severityFilter} 
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-200 text-xs font-semibold rounded-xl text-slate-700"
          >
            <option value="">{t('records.allSeverities', 'All Severities')}</option>
            <option value="Low">{t('dashboard.lowSeverity', '🟢 Low')}</option>
            <option value="Medium">{t('dashboard.mediumSeverity', '🟡 Moderate')}</option>
            <option value="High">{t('dashboard.highSeverity', '🔴 High')}</option>
            <option value="Critical">{t('dashboard.criticalSeverity', '🔴 Critical')}</option>
          </select>
        </div>
      </div>

      {/* Table & Cards */}
      {loading ? (
        <div className="py-20 text-center text-xs font-bold text-slate-500">{t('common.loading', 'Loading health records...')}</div>
      ) : filtered.length === 0 ? (
        <div className="bg-slate-50 border border-slate-200 p-12 rounded-3xl text-center space-y-2">
          <FileText className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-700">{t('records.noRecordsFound', 'No Health Records Found')}</h3>
          <p className="text-xs text-slate-500">{t('records.noRecordsDesc', 'No cases match the selected search or filter parameters.')}</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">{t('records.tagNumberCol', 'Tag Number')}</th>
                  <th className="py-3 px-4">{t('records.diseaseCol', 'Disease Diagnosis')}</th>
                  <th className="py-3 px-4">{t('records.epidemiologyCol', 'Epidemiology')}</th>
                  <th className="py-3 px-4">{t('records.severityCol', 'Severity')}</th>
                  <th className="py-3 px-4">{t('records.areaCol', 'Area / Location')}</th>
                  <th className="py-3 px-4">{t('records.statusCol', 'Status')}</th>
                  <th className="py-3 px-4">{t('records.dateCol', 'Date Logged')}</th>
                  <th className="py-3 px-4 text-right">{t('records.actionsCol', 'Actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map(r => {
                  const isSpreadable = isSpreadableDisease(r.diseasePrediction);
                  return (
                    <tr key={r._id || r.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {r.tagNumber || `BUF-${String(r._id || r.id).slice(-6).toUpperCase()}`}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800">
                        {t(`diseases.${r.diseasePrediction}`, (r.diseasePrediction || '').replace(/_/g, ' '))}
                      </td>
                      <td className="py-3.5 px-4">
                        {isSpreadable ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-pulse" />
                            ⚠️ {t('records.spreadable', 'Spreadable')}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                            🟢 {t('records.nonSpreadable', 'Non-Spreadable')}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase ${
                          r.severity === 'Critical' || r.severity === 'High' ? 'bg-rose-100 text-rose-800' : r.severity === 'Medium' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {t(`severity.${(r.severity || 'low').toLowerCase()}`, r.severity)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-600">{r.area}</td>
                      <td className="py-3.5 px-4">
                        <span className="px-2.5 py-1 bg-slate-100 text-slate-800 font-bold text-[10px] rounded-md border border-slate-200">
                          {t(`status.${(r.status || 'open').toLowerCase().replace(/\s+/g, '')}`, r.status || 'Open')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-500 font-medium">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3.5 px-4 text-right space-x-2">
                        <button 
                          onClick={() => {
                            setSelectedCase(r);
                            setEditStatus(r.status || 'Open');
                            setEditTreatment(r.treatmentInfo || '');
                            setEditVetNotes(r.veterinaryNotes || '');
                            setEditFollowUp(r.followUpNotes || '');
                          }}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-lg text-xs transition inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" /> {t('dashboard.viewDetails', 'Details')}
                        </button>
                        {canModifyRecord(r) && (
                          <button 
                            onClick={() => setDeleteId(r._id || r.id)}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition inline-block"
                            title={t('records.deleteTitle', 'Delete record')}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedCase && (() => {
        const diseaseInfo = getDiseaseInfo(selectedCase.diseasePrediction);
        const isSpreadable = isSpreadableDisease(selectedCase.diseasePrediction);
        const caseIdentifier = selectedCase.tagNumber || selectedCase.caseId || selectedCase._id;

        return (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-5 max-h-[92vh] overflow-y-auto shadow-2xl relative">
              <button 
                onClick={() => { setSelectedCase(null); setIsEditing(false); }}
                className="absolute right-5 top-5 text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-6 h-6" />
              </button>

              {/* Modal Top Header */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 pr-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 font-extrabold flex items-center justify-center text-sm">
                    BUF
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900">
                      Case Record: {caseIdentifier}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">Logged on {new Date(selectedCase.createdAt).toLocaleString()}</p>
                  </div>
                </div>

                {/* Spreadable Status Badge in Modal Header */}
                <div>
                  {isSpreadable ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300 shadow-xs">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                      ⚠️ Spreadable (Contagious)
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      🟢 Non-Spreadable
                    </span>
                  )}
                </div>
              </div>

              {/* Spreadable / Containment Alert Directive */}
              {isSpreadable ? (
                <div className="bg-rose-50 border-2 border-rose-200 rounded-2xl p-4 text-xs space-y-1.5 text-rose-900 shadow-xs">
                  <div className="flex items-center gap-2 font-black text-rose-900 text-sm">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>⚠️ Contagious Disease — Spreadable Epidemic Risk</span>
                  </div>
                  <p className="text-rose-800 font-semibold leading-relaxed">
                    <strong>Mandatory Isolation Directive:</strong> {MANDATORY_ISOLATION_INSTRUCTION}
                  </p>
                  <p className="text-[11px] text-rose-700 font-medium">
                    Transmission Mode: {diseaseInfo.transmission}
                  </p>
                </div>
              ) : (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 text-xs space-y-1 text-emerald-900 shadow-xs">
                  <div className="flex items-center gap-2 font-bold text-emerald-900">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>🟢 Non-Spreadable Condition (Localized / Environmental)</span>
                  </div>
                  <p className="text-emerald-800 font-medium leading-relaxed text-[11px]">
                    This condition is not directly contagious across the herd. Focus on clinical care, hygiene, and environmental sanitation.
                  </p>
                  <p className="text-[11px] text-emerald-700 font-medium">
                    Condition Nature: {diseaseInfo.transmission}
                  </p>
                </div>
              )}

              {/* Core Case Information Grid */}
              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <div>
                    <span className="font-bold text-slate-500 uppercase text-[10px]">Disease Diagnosis</span>
                    <p className="font-extrabold text-slate-900 text-sm">{selectedCase.diseasePrediction}</p>
                  </div>
                  <div>
                    <span className="font-bold text-slate-500 uppercase text-[10px]">Epidemiology</span>
                    <p className={`font-extrabold text-sm ${isSpreadable ? 'text-rose-700' : 'text-emerald-700'}`}>
                      {isSpreadable ? '⚠️ Spreadable' : '🟢 Non-Spreadable'}
                    </p>
                  </div>
                  <div>
                    <span className="font-bold text-slate-500 uppercase text-[10px]">Severity Level</span>
                    <p className="font-extrabold text-slate-900 text-sm">{selectedCase.severity}</p>
                  </div>
                  <div>
                    <span className="font-bold text-slate-500 uppercase text-[10px]">Current Status</span>
                    <p className="font-semibold text-emerald-700 text-sm">{selectedCase.status || 'Open'}</p>
                  </div>
                  <div className="col-span-2 sm:col-span-4 pt-2 border-t border-slate-200 flex flex-wrap justify-between gap-2 text-slate-600 text-xs">
                    <span><strong>Location:</strong> {selectedCase.area} {selectedCase.streetName ? `• ${selectedCase.streetName}` : ''} {selectedCase.pincode ? `(${selectedCase.pincode})` : ''}</span>
                    {selectedCase.ownerName && <span><strong>Owner:</strong> {selectedCase.ownerName}</span>}
                  </div>
                </div>

                {/* DEDICATED CLINICAL SAMPLE DIRECTIVE CARD */}
                {(() => {
                  const sampleDirective = CLINICAL_SAMPLE_DIRECTIVES[diseaseInfo.key] || CLINICAL_SAMPLE_DIRECTIVES.Healthy_Buffalo;
                  const awareness = DISEASE_AWARENESS[diseaseInfo.key] || DISEASE_AWARENESS.Healthy_Buffalo;
                  const awarenessStopKey = diseaseInfo.key === 'Foot_and_Mouth_Disease' ? 'fmdStopSpread'
                    : diseaseInfo.key === 'Lumpy_Skin_Disease' ? 'lsdStopSpread'
                    : diseaseInfo.key === 'Mastitis' ? 'mastitisStopSpread'
                    : diseaseInfo.key === 'Multiple_Disease_Diagnosis' ? 'multipleStopSpread'
                    : 'healthyStopSpread';
                  const awarenessPreventKey = diseaseInfo.key === 'Foot_and_Mouth_Disease' ? 'fmdPreventFuture'
                    : diseaseInfo.key === 'Lumpy_Skin_Disease' ? 'lsdPreventFuture'
                    : diseaseInfo.key === 'Mastitis' ? 'mastitisPreventFuture'
                    : diseaseInfo.key === 'Multiple_Disease_Diagnosis' ? 'multiplePreventFuture'
                    : 'healthyPreventFuture';

                  return (
                    <>
                      {/* Clinical Sample Directive */}
                      <div className={`border-2 rounded-2xl p-4 text-xs space-y-2 shadow-xs ${
                        diseaseInfo.key === 'Mastitis'
                          ? 'bg-blue-50/90 border-blue-400'
                          : 'bg-indigo-50/90 border-indigo-300'
                      }`}>
                        <div className="flex items-center gap-2 font-black text-indigo-950 text-xs uppercase tracking-wider">
                          <span className="text-lg">{diseaseInfo.key === 'Mastitis' ? '🥛' : '🧪'}</span>
                          <span>
                            {diseaseInfo.key === 'Mastitis'
                              ? t('sampleDirectives.milkSampleTitle', 'Milk Sample Submission Directive (Mastitis)')
                              : t('sampleDirectives.title', 'Clinical Sample Submission for Laboratory Testing')}
                          </span>
                        </div>
                        <p className="font-extrabold text-slate-900 text-xs sm:text-sm leading-relaxed">
                          {t(`sampleDirectives.${diseaseInfo.key}`, sampleDirective.instruction)}
                        </p>
                        <div className="pt-1.5 border-t border-indigo-200/60 text-[11px] font-bold text-indigo-800">
                          🔬 {t('sampleDirectives.subtitle', 'Mandatory Veterinary Diagnostic Protocol')}
                        </div>
                      </div>

                      {/* Disease Awareness & Prevention Card */}
                      <div className="bg-slate-50 border border-slate-300 rounded-2xl p-4 text-xs space-y-3 shadow-xs">
                        <div className="flex items-center gap-2 font-black text-slate-900 text-xs uppercase tracking-wider">
                          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>{t('awareness.title', 'Disease Awareness & Prevention Guide')}</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 space-y-1">
                            <span className="text-[11px] font-black text-rose-900 block">🛑 {t('awareness.stopSpreadTitle', 'How to Stop Disease Spread (Immediate Biosecurity)')}</span>
                            <p className="text-xs font-semibold text-rose-950 leading-relaxed">
                              {t(`awareness.${awarenessStopKey}`, awareness.stopSpread)}
                            </p>
                          </div>

                          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 space-y-1">
                            <span className="text-[11px] font-black text-emerald-900 block">🌱 {t('awareness.preventFutureTitle', 'How to Avoid Recurrence in the Future')}</span>
                            <p className="text-xs font-semibold text-emerald-950 leading-relaxed">
                              {t(`awareness.${awarenessPreventKey}`, awareness.preventFuture)}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Safe Veterinary Guidance */}
                      <div className="bg-emerald-50/90 border-2 border-emerald-500/80 rounded-2xl p-4 text-xs space-y-2 shadow-xs">
                        <div className="flex items-center gap-2 font-bold text-emerald-950 text-xs uppercase tracking-wider">
                          <span className="text-base">🩺</span>
                          <span>{t('diagnosisResult.veterinaryGuidanceTitle', 'Veterinary Guidance')}</span>
                        </div>
                        <p className="text-xs font-bold text-slate-800 leading-relaxed">
                          {t('diagnosisResult.veterinaryGuidanceText', 'This result is an AI-assisted screening result and should not be considered a final veterinary diagnosis. Please consult a qualified veterinarian for confirmation and treatment.')}
                        </p>
                        <div className="pt-2 border-t border-emerald-200/70 font-extrabold text-emerald-800 text-xs flex items-center gap-1.5">
                          🚨 {t('diagnosisResult.emergencyContact', 'Veterinary Emergency Helpline: 1962')}
                        </div>
                      </div>

                      {/* Administered / Field Treatment Notes if any */}
                      {selectedCase.treatmentInfo && (
                        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
                          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Field Treatment Notes</span>
                          <p className="font-semibold text-slate-800 text-xs mt-0.5">{selectedCase.treatmentInfo}</p>
                        </div>
                      )}
                    </>
                  );
                })()}

                {/* NECESSARY PRECAUTIONS & BIOSECURITY */}
                <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 text-xs space-y-2.5 shadow-xs">
                  <div className="flex items-center gap-2 font-bold text-amber-900 text-sm">
                    <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>🛡️ {t('diagnosisResult.necessaryPrecautions', 'Necessary Precautions & Biosecurity Measures')}</span>
                  </div>

                  <div className="bg-white p-3.5 rounded-xl border border-amber-100 shadow-xs">
                    <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider block">Primary Clinical Precaution</span>
                    <p className="font-bold text-slate-900 mt-0.5 leading-snug">
                      {diseaseInfo.precaution || 'Maintain sterile hygiene, isolate suspect animals, and consult field veterinarian.'}
                    </p>
                  </div>

                  {diseaseInfo.additionalPrecautions && diseaseInfo.additionalPrecautions.length > 0 && (
                    <div className="bg-white p-3.5 rounded-xl border border-amber-100 shadow-xs space-y-1.5">
                      <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Biosecurity & Herd Protection Checklist</span>
                      <ul className="space-y-1.5 text-slate-700 font-medium">
                        {diseaseInfo.additionalPrecautions.map((p, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-amber-500 font-bold shrink-0 mt-0.5">•</span>
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Uploaded Case Image */}
                {selectedCase.image && (
                  <div className="space-y-1">
                    <span className="font-bold text-slate-700 uppercase text-[10px]">Uploaded Case Image</span>
                    <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-900 max-h-48 flex items-center justify-center">
                      <img src={selectedCase.image} alt="Case photo" className="max-h-48 w-auto object-contain" />
                    </div>
                  </div>
                )}

                {/* Observed Symptoms */}
                {selectedCase.symptoms && selectedCase.symptoms.length > 0 && (
                  <div className="space-y-1">
                    <span className="font-bold text-slate-700 uppercase text-[10px]">Symptoms Reported</span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedCase.symptoms.map((s, i) => (
                        <span key={i} className="px-2.5 py-1 bg-slate-100 text-slate-800 font-semibold rounded-md border border-slate-200 text-xs">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Editable Status & Notes */}
                {isEditing ? (
                  <div className="space-y-3 p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl">
                    <h4 className="font-bold text-emerald-900 text-xs">Update Case Notes & Status</h4>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-1">Status</label>
                      <select 
                        value={editStatus} 
                        onChange={e => setEditStatus(e.target.value)}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-xs"
                      >
                        <option value="Open">Open</option>
                        <option value="Under Treatment">Under Treatment</option>
                        <option value="Recovered">Recovered</option>
                        <option value="Closed">Closed</option>
                        <option value="Emergency">Emergency</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-1">Treatment Notes</label>
                      <textarea rows={2} value={editTreatment} onChange={e => setEditTreatment(e.target.value)} className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-1">Veterinary / Field Notes</label>
                      <textarea rows={2} value={editVetNotes} onChange={e => setEditVetNotes(e.target.value)} className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs" />
                    </div>
                    <div className="flex gap-2 pt-2">
                      <button onClick={handleUpdateStatus} className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold text-xs">Save Changes</button>
                      <button onClick={() => setIsEditing(false)} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg font-bold text-xs">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    {canModifyRecord(selectedCase) ? (
                      <button 
                        onClick={() => setIsEditing(true)}
                        className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs transition inline-flex items-center gap-1.5"
                      >
                        <Edit3 className="w-4 h-4" /> {t('caseDetail.updateStatusBtn', 'Update Treatment & Status')}
                      </button>
                    ) : (
                      <div className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-500 flex items-center gap-1.5">
                        <span>🔒 {t('caseDetail.viewOnlyNotice', 'View Only (Registered by member)')}</span>
                      </div>
                    )}

                    <button
                      onClick={() => {
                        const targetId = selectedCase.caseId || selectedCase._id || selectedCase.id;
                        navigate(`/cases/${targetId}`);
                      }}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition inline-flex items-center gap-1.5 shadow-sm"
                    >
                      <ExternalLink className="w-4 h-4" /> Open Full EHR File
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Confirmation Dialog for Delete */}
      {deleteId && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-rose-500 mx-auto animate-bounce" />
            <h3 className="font-extrabold text-base text-slate-900">Confirm Deletion</h3>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              Are you sure you want to delete this animal health record? This action cannot be undone.
            </p>
            <div className="flex gap-3 pt-2">
              <button 
                onClick={handleDeleteConfirm}
                disabled={deleting}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition"
              >
                {deleting ? 'Deleting...' : 'Yes, Delete Record'}
              </button>
              <button 
                onClick={() => setDeleteId(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
