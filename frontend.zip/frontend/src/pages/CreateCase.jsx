import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  PlusCircle, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  MapPin, 
  Stethoscope, 
  User, 
  Trash2,
  Navigation,
  LocateFixed,
  Compass
} from 'lucide-react';
import axios from 'axios';
import { 
  VIJAYAWADA_LOCATIONS, 
  VIJAYAWADA_PINCODES, 
  PINCODE_DESCRIPTIONS, 
  getAreasByPincode 
} from '../data/vijayawadaLocations';
import { useTranslation } from '../context/LanguageContext';
import { checkFmdSymptomCorroboration, normalizeDiseaseKey } from '../constants/diseaseInfo';
import { classifyBuffaloImageClient } from '../services/clientImageClassifier';

export default function CreateCase() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [analyzingImage, setAnalyzingImage] = useState(false);
  const [detectingLocation, setDetectingLocation] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');

  // Vijayawada Selection State
  const [selectedVijayawadaArea, setSelectedVijayawadaArea] = useState('');
  const [selectedVijayawadaPincode, setSelectedVijayawadaPincode] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    tagNumber: '',
    buffaloName: '',
    ownerName: '',
    area: '',
    streetName: '',
    pincode: '',
    latitude: null,
    longitude: null,
    symptoms: [],
    diseaseDescription: '',
    image: null,
    imagePreview: '',
    diseasePrediction: 'Healthy_Buffalo',
    confidenceScore: 85,
    severity: 'Low',
    recommendations: [],
    precautions: [],
    immediateAction: ''
  });

  const availableSymptoms = [
    'Hard/Swollen Udder',
    'Reduced Milk',
    'Vesicles on Udder',
    'Blood or Clots in Milk',
    'Hot / Painful Teats',
    'Watery / Discolored Milk',
    'Blisters on Mouth / Tongue / Lips',
    'Mouth Lesions',
    'Excessive Salivation (Drooling)',
    'Smacking of Lips',
    'Hoof Swelling / Blisters',
    'Lameness / Difficulty Walking',
    'Interdigital Foot Wounds',
    'Reluctance to Stand',
    'Nodules / Circular Lumps on Skin',
    'Crusty Skin Patches',
    'Hair Loss / Alopecia',
    'Itching',
    'Skin Abrasion / Lesion',
    'Bleeding Wound',
    'Swelling in Throat / Dewlap / Neck',
    'Nasal Discharge / Coughing',
    'Labored / Heavy Breathing',
    'Watery Eyes / Lacrimation',
    'Fever / High Temperature',
    'Loss of Appetite',
    'Lethargy',
    'Shivering / Muscle Tremors',
    'Abdominal Bloat / Swollen Belly',
    'Severe Diarrhea / Loose Dung',
    'Rapid Weight Loss / Dullness',
    'Clear Eyes / Active (Normal)'
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setDetectingLocation(true);
    setError('');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        try {
          let geoData = null;
          try {
            const { data } = await axios.get(`/api/cases/geocode/reverse?lat=${lat}&lon=${lon}`);
            if (data && data.valid) geoData = data;
          } catch (e) {
            console.warn('Backend reverse geocode error:', e);
          }

          if (!geoData) {
            const res = await axios.get(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`);
            const item = res.data;
            const addr = item?.address || {};
            const matchPin = item?.display_name?.match(/\b[1-9]\d{5}\b/);
            const rawPin = addr.postcode ? addr.postcode.replace(/\D/g, '') : '';
            const pin = (rawPin && rawPin.length === 6) ? rawPin : (matchPin ? matchPin[0] : '');

            geoData = {
              area: addr.suburb || addr.village || addr.town || addr.city_district || addr.county || addr.city || 'Detected Area',
              streetName: addr.road || addr.pedestrian || 'Main Road',
              pincode: pin,
              latitude: lat,
              longitude: lon
            };
          }

          setFormData(prev => ({
            ...prev,
            area: geoData.area || prev.area || 'Detected Location',
            streetName: geoData.streetName || prev.streetName || 'Main Street',
            pincode: (geoData.pincode && /^[1-9]\d{5}$/.test(geoData.pincode)) ? geoData.pincode : prev.pincode,
            latitude: lat,
            longitude: lon
          }));

          setToast(`📍 GPS Location & Pincode (${geoData.pincode || 'captured'}) auto-filled!`);
          setTimeout(() => setToast(''), 3500);
        } catch (err) {
          console.warn('Reverse geocoding error:', err);
          setFormData(prev => ({ ...prev, latitude: lat, longitude: lon }));
          setToast('📍 GPS coordinates captured!');
          setTimeout(() => setToast(''), 3000);
        } finally {
          setDetectingLocation(false);
        }
      },
      (geoErr) => {
        setError('Unable to detect GPS location. Please check browser permissions.');
        setDetectingLocation(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleVijayawadaAreaSelect = (areaId) => {
    setSelectedVijayawadaArea(areaId);
    if (!areaId) return;
    const loc = VIJAYAWADA_LOCATIONS.find(l => l.id === areaId);
    if (loc) {
      setSelectedVijayawadaPincode(loc.pincode);
      setFormData(prev => ({
        ...prev,
        area: loc.area,
        pincode: loc.pincode,
        streetName: prev.streetName || loc.landmark || 'Main Road',
        latitude: loc.lat,
        longitude: loc.lng
      }));
      setToast(`📍 ${loc.shortName} (${loc.pincode}) selected — GPS coordinates pinned!`);
      setTimeout(() => setToast(''), 3000);
    }
  };

  const handleVijayawadaPincodeSelect = (pin) => {
    setSelectedVijayawadaPincode(pin);
    if (!pin) return;
    const matching = getAreasByPincode(pin);
    if (matching.length > 0) {
      const loc = matching[0];
      setSelectedVijayawadaArea(loc.id);
      setFormData(prev => ({
        ...prev,
        area: loc.area,
        pincode: pin,
        streetName: prev.streetName || loc.landmark || 'Main Road',
        latitude: loc.lat,
        longitude: loc.lng
      }));
      setToast(`📍 Pincode ${pin} (${loc.shortName}) selected — GPS coordinates pinned!`);
      setTimeout(() => setToast(''), 3000);
    } else {
      setFormData(prev => ({ ...prev, pincode: pin }));
    }
  };

  const toggleSymptom = (sym) => {
    setFormData(prev => {
      const exists = prev.symptoms.includes(sym);
      const updated = exists 
        ? prev.symptoms.filter(s => s !== sym) 
        : [...prev.symptoms, sym];
      return { ...prev, symptoms: updated };
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      setError('Please upload a valid image file (JPG, PNG, or WEBP).');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError('Image file size must be less than 10MB.');
      return;
    }

    setError('');
    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({
        ...prev,
        image: file,
        imagePreview: reader.result
      }));
      analyzeImageAI(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const removeImage = () => {
    setFormData(prev => ({ ...prev, image: null, imagePreview: '' }));
  };

  const analyzeImageAI = async (base64Img) => {
    setAnalyzingImage(true);
    setError('');
    try {
      const cleanB64 = base64Img.replace(/^data:image\/\w+;base64,/, '');
      let data = null;
      try {
        const res = await axios.post('/api/cases/predict', {
          animalType: 'Buffalo',
          imageBase64: cleanB64,
          symptoms: formData.symptoms.join(', ')
        });
        data = res.data;
      } catch (backendErr) {
        try {
          const targetMlUrl = (typeof window !== 'undefined' && localStorage.getItem('server_url'))
            ? localStorage.getItem('server_url').replace(':3000', ':5000') + '/predict'
            : 'http://192.168.0.100:5000/predict';
          const res = await axios.post(targetMlUrl, {
            animalType: 'Buffalo',
            imageBase64: cleanB64,
            symptoms: formData.symptoms.join(', ')
          });
          data = res.data;
        } catch {}
      }

      // Fallback to client-side visual classifier if backend unreachable
      if (!data) {
        data = await classifyBuffaloImageClient(base64Img, { symptoms: formData.symptoms });
      }

      if (data && data.isBuffalo === false) {
        const subject = data.predictedSubject || data.entityType || 'Non-Buffalo Image';
        const icon = data.detectedEntityIcon || '⚠️';
        const errMsg = `${icon} Non-Buffalo Detected (${subject}): ${data.message || 'Please upload a clear photograph of a buffalo.'}`;
        setError(errMsg);
        setFormData(prev => ({
          ...prev,
          diseasePrediction: '',
          confidenceScore: 0,
          severity: 'N/A'
        }));
        return;
      }

      if (data) {
        const pred = data.diseasePrediction || data.prediction || 'Healthy Buffalo';

        setFormData(prev => ({
          ...prev,
          diseasePrediction: pred,
          confidenceScore: Math.round(data.confidenceScore || 92),
          severity: data.severity || 'Low',
          recommendations: data.recommendations || data.precautions || [],
          precautions: data.precautions || [],
          immediateAction: data.immediateAction || ''
        }));
      }
    } catch (err) {
      console.warn('AI microservice error:', err);
    } finally {
      setAnalyzingImage(false);
    }
  };

  const validateStep = (currentStep) => {
    setError('');
    if (currentStep === 1) {
      if (!formData.tagNumber.trim()) { setError(t('validation.tagIdRequired', 'Buffalo Tag ID is required.')); return false; }
      if (!formData.ownerName.trim()) { setError(t('validation.ownerNameRequired', 'Owner Name is required.')); return false; }
      if (!formData.area.trim()) { setError(t('validation.areaRequired', 'Please select an Area in Vijayawada from the dropdown above.')); return false; }
      if (!formData.pincode.trim() || !/^\d{6}$/.test(formData.pincode.trim())) {
        setError(t('validation.pincodeRequired', 'Please select a valid 6-digit Pincode from the dropdown above.'));
        return false;
      }
    }
    if (currentStep === 2) {
      if (!formData.symptoms.length) { 
        setError(t('validation.symptomsRequired', "Please enter the buffalo's symptoms before submitting the case.")); 
        return false; 
      }
      if (formData.imagePreview && !formData.diseasePrediction) {
        setError(t('validation.nonBuffaloRejected', 'The uploaded image is not a valid buffalo photo. Please upload a clear photo of a buffalo.'));
        return false;
      }
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep(step)) {
      setStep(prev => Math.min(prev + 1, 2));
    }
  };

  const prevStep = () => {
    setError('');
    setStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateStep(1) || !validateStep(2)) return;

    setLoading(true);
    setError('');

    try {
      const payload = new FormData();
      payload.append('tagNumber', formData.tagNumber);
      payload.append('buffaloName', formData.buffaloName || 'Buffalo');
      payload.append('age', 4);
      payload.append('gender', 'Female');
      payload.append('breed', 'Murrah');
      payload.append('affectedCount', 1);
      payload.append('ownerName', formData.ownerName);
      payload.append('area', formData.area);
      payload.append('streetName', formData.streetName);
      payload.append('pincode', formData.pincode);
      if (formData.latitude) payload.append('latitude', formData.latitude);
      if (formData.longitude) payload.append('longitude', formData.longitude);
      payload.append('symptoms', JSON.stringify(formData.symptoms));
      payload.append('diseaseDescription', formData.diseaseDescription);
      payload.append('diseasePrediction', formData.diseasePrediction);
      payload.append('confidenceScore', formData.confidenceScore);
      payload.append('severity', formData.severity);
      payload.append('immediateAction', formData.immediateAction);
      
      if (formData.image) {
        payload.append('image', formData.image);
      } else if (formData.imagePreview) {
        payload.append('imageBase64', formData.imagePreview);
      }

      const { data } = await axios.post('/api/cases', payload, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`
        }
      });

      if (data && (data.case || data.success || data.message)) {
        setToast(t('createCase.successRedirect', 'Case submitted successfully! Directing to dashboard...'));
        setTimeout(() => {
          navigate('/dashboard');
        }, 1200);
      }
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to submit case. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 py-4">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-6 right-6 z-50 bg-emerald-600 text-white px-6 py-4 rounded-2xl shadow-2xl font-bold text-sm flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-6 h-6 text-emerald-200" />
          <span>{toast}</span>
        </div>
      )}

      {/* Page Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 flex items-center gap-2.5">
            <PlusCircle className="w-6 h-6 text-emerald-600" /> {t('createCase.title', 'Create Buffalo Case Record')}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5 font-semibold">{t('createCase.subtitle', 'Register a new buffalo clinical case with AI-assisted diagnosis & GIS tracking')}</p>
        </div>

        <div className="text-right">
          <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
            {t('createCase.stepOf', 'Step {step} of 2').replace('{step}', step)}
          </span>
        </div>
      </div>

      {/* 2-Step Progress Bar */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { stepNum: 1, title: t('createCase.step1Title', 'Buffalo & Location Info') },
          { stepNum: 2, title: t('createCase.step2Title', 'Symptoms & Photo Upload') }
        ].map(({ stepNum, title }) => {
          const isActive = step === stepNum;
          const isDone = step > stepNum;
          return (
            <button
              key={title}
              type="button"
              onClick={() => stepNum < step && setStep(stepNum)}
              className={`p-3.5 rounded-2xl text-left transition border ${
                isActive
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
                  : isDone
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-white text-slate-400 border-slate-200 cursor-not-allowed'
              }`}
            >
              <div className="text-[10px] font-extrabold uppercase tracking-wider opacity-80">Step {stepNum}</div>
              <div className="text-xs font-extrabold truncate mt-0.5">{title}</div>
            </button>
          );
        })}
      </div>

      {/* Error Notice */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Form Container */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm space-y-6">
        
        {/* STEP 1: Essential Buffalo & Location Details */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Buffalo Details */}
            <div className="space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-100 pb-2.5 flex items-center gap-2">
                <User className="w-4 h-4 text-emerald-600" /> {t('createCase.buffaloAndOwnerInfo', 'Buffalo & Owner Information')}
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('createCase.tagNumber', 'Buffalo Tag ID *')}</label>
                  <input
                    type="text"
                    name="tagNumber"
                    value={formData.tagNumber}
                    onChange={handleInputChange}
                    placeholder={t('createCase.tagNumberPlaceholder', 'e.g. BUF-TAG-9082')}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('createCase.buffaloName', 'Buffalo Name (Optional)')}</label>
                  <input
                    type="text"
                    name="buffaloName"
                    value={formData.buffaloName}
                    onChange={handleInputChange}
                    placeholder={t('createCase.buffaloNamePlaceholder', 'e.g. Gauri / Laxmi')}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('createCase.ownerName', 'Owner Name *')}</label>
                  <input
                    type="text"
                    name="ownerName"
                    value={formData.ownerName}
                    onChange={handleInputChange}
                    placeholder={t('createCase.ownerNamePlaceholder', 'e.g. Ramesh Kumar')}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Location Details with Detect Location Button */}
            <div className="space-y-4 pt-2">
              <div className="border-b border-slate-100 pb-2.5 flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-600" /> {t('createCase.locationDetails', 'Location Details')}
                </h3>

                {/* DETECT MY LOCATION BUTTON */}
                <button
                  type="button"
                  onClick={handleDetectLocation}
                  disabled={detectingLocation}
                  className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-full border border-emerald-200 text-xs font-extrabold transition flex items-center gap-1.5 shadow-sm active:scale-95"
                >
                  <LocateFixed className={`w-3.5 h-3.5 text-emerald-600 ${detectingLocation ? 'animate-spin' : ''}`} />
                  <span>{detectingLocation ? t('createCase.detectingLocation', 'Detecting Location...') : t('createCase.detectMyLocation', 'Detect My Location')}</span>
                </button>
              </div>

              {/* VIJAYAWADA AREA & PINCODE 1-CLICK SELECTOR */}
              <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-blue-900 flex items-center gap-1.5">
                    <Navigation className="w-3.5 h-3.5 text-blue-600" />
                    <span>{t('createCase.vjaSelector', 'Vijayawada Area & Pincode Selector (Accurate GPS)')}</span>
                  </span>
                  {formData.latitude && formData.longitude && (
                    <span className="text-[10px] font-mono bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full font-bold">
                      📍 {formData.latitude.toFixed(4)}° N, {formData.longitude.toFixed(4)}° E
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                      <span>{t('createCase.areaInVja', 'Area in Vijayawada')}</span>
                      <span className="text-slate-400">({VIJAYAWADA_LOCATIONS.length} Areas)</span>
                    </label>
                    <select
                      value={selectedVijayawadaArea}
                      onChange={e => handleVijayawadaAreaSelect(e.target.value)}
                      className="w-full p-2.5 bg-white border border-blue-200 focus:border-blue-500 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-400/20"
                    >
                      <option value="">{t('createCase.chooseVjaArea', '-- Choose Vijayawada Area --')}</option>
                      {VIJAYAWADA_LOCATIONS.map(loc => (
                        <option key={loc.id} value={loc.id}>
                          {loc.area} (PIN: {loc.pincode})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                      <span>{t('createCase.postalPincode', 'Postal Pincode')}</span>
                      <span className="text-slate-400">({VIJAYAWADA_PINCODES.length} Pincodes)</span>
                    </label>
                    <select
                      value={selectedVijayawadaPincode}
                      onChange={e => handleVijayawadaPincodeSelect(e.target.value)}
                      className="w-full p-2.5 bg-white border border-blue-200 focus:border-blue-500 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-400/20"
                    >
                      <option value="">{t('createCase.chooseVjaPincode', '-- Choose Vijayawada Pincode --')}</option>
                      {VIJAYAWADA_PINCODES.map(pin => (
                        <option key={pin} value={pin}>
                          {PINCODE_DESCRIPTIONS[pin] || `${pin} - Vijayawada Area`}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Quick select tags */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] font-extrabold uppercase text-slate-500 self-center mr-1">{t('createCase.quick', 'Quick:')}</span>
                  {[
                    { id: 'benz-circle', label: 'Benz Circle' },
                    { id: 'gollapudi', label: 'Gollapudi Dairy' },
                    { id: 'gunadala', label: 'Gunadala' },
                    { id: 'kondapalli', label: 'Kondapalli' },
                    { id: 'auto-nagar', label: 'Auto Nagar' },
                    { id: 'one-town', label: 'One Town' },
                    { id: 'poranki', label: 'Poranki' }
                  ].map(q => (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => handleVijayawadaAreaSelect(q.id)}
                      className={`text-[10px] px-2 py-1 rounded-lg font-bold transition border ${
                        selectedVijayawadaArea === q.id
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white hover:bg-blue-100 text-slate-700 border-blue-200'
                      }`}
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t('createCase.streetLandmark', 'Street Name / Landmark / House No (Optional)')}</label>
                <input
                  type="text"
                  name="streetName"
                  value={formData.streetName}
                  onChange={handleInputChange}
                  placeholder={t('createCase.streetLandmarkPlaceholder', 'e.g. Near Dairy Farm, Gate 2, Main Road')}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Symptoms Checklist & Image Upload */}
        {step === 2 && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Symptoms Checklist */}
            <div className="space-y-3">
              <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-100 pb-2.5 flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Stethoscope className="w-4 h-4 text-emerald-600" /> {t('createCase.observedSymptoms', 'Observed Symptoms *')}
                </span>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  {formData.symptoms.length} {t('createCase.selectedCount', 'Selected')}
                </span>
              </h3>
              <p className="text-xs text-rose-700 font-semibold bg-rose-50 border border-rose-200 px-3 py-1.5 rounded-xl">
                ⚠️ {t('createCase.symptomsRequiredNotice', "Please enter the buffalo's symptoms before submitting the case.")}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto p-3 bg-slate-50 rounded-2xl border border-slate-200">
                {availableSymptoms.map(sym => {
                  const isSelected = formData.symptoms.includes(sym);
                  return (
                    <div
                      key={sym}
                      onClick={() => toggleSymptom(sym)}
                      className={`p-3 rounded-2xl border text-xs font-bold cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <CheckCircle2 className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-300'}`} />
                        <span>{t(`symptoms.${sym}`, sym)}</span>
                      </span>
                      {isSelected && (
                        <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full text-white">
                          {t('createCase.selectedCount', 'Selected')}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t('createCase.additionalSymptomsDesc', 'Additional Symptoms Description (Optional)')}</label>
                <textarea
                  name="diseaseDescription"
                  value={formData.diseaseDescription}
                  onChange={handleInputChange}
                  rows={2}
                  placeholder={t('createCase.additionalSymptomsDescPlaceholder', 'Describe lesions, discharge, behavior changes, etc.')}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Photo Upload & AI Prediction */}
            <div className="space-y-4 pt-2">
              <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-100 pb-2.5 flex items-center gap-2">
                <Upload className="w-4 h-4 text-emerald-600" /> {t('createCase.buffaloImageSection', 'Buffalo Image & AI Disease Risk Analysis')}
              </h3>

              {!formData.imagePreview ? (
                <label className="border-2 border-dashed border-slate-300 rounded-3xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/50 transition">
                  <Upload className="w-10 h-10 text-slate-400 mb-2" />
                  <span className="text-xs font-bold text-slate-800">{t('createCase.clickOrDragImage', 'Click or drag image file here')}</span>
                  <span className="text-[11px] text-slate-400 mt-0.5">{t('createCase.imageFormatsSupported', 'Supports JPG, PNG, WEBP (Max 10MB)')}</span>
                  <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                </label>
              ) : (
                <div className="space-y-3">
                  <div className="relative rounded-3xl overflow-hidden border border-slate-200 bg-slate-900 max-h-64 flex items-center justify-center">
                    <img src={formData.imagePreview} alt="Buffalo preview" className="max-h-64 w-auto object-contain" />
                    <button
                      type="button"
                      onClick={removeImage}
                      className="absolute top-3 right-3 p-2 bg-rose-600 text-white rounded-full shadow-lg hover:bg-rose-700 transition"
                      title="Remove image"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {analyzingImage ? (
                    <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-xs font-bold text-emerald-900 animate-pulse">
                      <Sparkles className="w-5 h-5 text-emerald-600 animate-spin" />
                      <span>{t('createCase.aiAnalyzing', 'Analyzing image with MobileNetV2 CNN classifier...')}</span>
                    </div>
                  ) : (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block">{t('createCase.aiPredictedDisease', 'AI Predicted Disease')}</span>
                        <span className="text-sm font-extrabold text-emerald-950">
                          {t(`diseases.${formData.diseasePrediction}`, formData.diseasePrediction.replace(/_/g, ' '))}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block">{t('createCase.confidence', 'Confidence')}</span>
                        <span className="text-sm font-extrabold text-emerald-700">{formData.confidenceScore}%</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Navigation & Submit Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          {step > 1 ? (
            <button
              type="button"
              onClick={prevStep}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" /> {t('createCase.back', 'Previous')}
            </button>
          ) : <div />}

          {step < 2 ? (
            <button
              type="button"
              onClick={nextStep}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition flex items-center gap-2 shadow-md shadow-emerald-600/20"
            >
              <span>{t('createCase.next', 'Continue to Symptoms & Upload')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={loading}
              className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-600/30 disabled:opacity-50"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>{loading ? t('createCase.submitting', 'Submitting Case Record...') : t('createCase.submit', 'Submit Case Record')}</span>
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
