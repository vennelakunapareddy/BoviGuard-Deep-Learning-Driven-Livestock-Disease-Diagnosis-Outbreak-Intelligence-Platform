import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, Mic, MicOff, RefreshCw, Trash2, ShieldAlert, Sparkles, Loader, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import axios from 'axios';
import { useTranslation } from '../context/LanguageContext';

export default function AIAssistant() {
  const { t, language: appLang, setLanguage: setAppLang } = useTranslation();
  const token = localStorage.getItem('token');
  const [messages, setMessages] = useState([
    {
      role: 'bot',
      text: t('assistant.initialGreeting', "Hello! I am your AI Veterinary Health Assistant. Ask me about buffalo diseases (FMD, LSD, Mastitis, Healthy Buffalo), symptoms, biosecurity precautions, severity levels, or general herd care.")
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const [language, setLanguage] = useState(appLang === 'te' ? 'te-IN' : appLang === 'hi' ? 'hi-IN' : 'en-IN');
  const [error, setError] = useState('');
  const [cases, setCases] = useState([]);
  const [selectedCaseId, setSelectedCaseId] = useState('');

  const recognitionRef = useRef(null);
  const chatBottomRef = useRef(null);

  useEffect(() => {
    fetchUserCases();
  }, []);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const fetchUserCases = async () => {
    try {
      const { data } = await axios.get('/api/cases', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      if (Array.isArray(data) && data.length > 0) {
        setCases(data);
        setSelectedCaseId(data[0].caseId || data[0]._id);
      }
    } catch (err) {
      console.warn('Could not fetch user cases for assistant context:', err);
    }
  };

  const sendMessage = async (textToSend) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg = { role: 'user', text: query };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    setError('');

    try {
      const { data } = await axios.post(
        '/api/assistant',
        {
          transcript: query,
          language,
          caseId: selectedCaseId
        },
        { headers: token ? { Authorization: `Bearer ${token}` } : {} }
      );

      const botReply = data.reply || 'AI Assistant returned an answer.';
      setMessages(prev => [...prev, { role: 'bot', text: botReply }]);

      // Speech synthesis
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(botReply.replace(/⚠️ Disclaimer:.*/s, ''));
        utter.lang = language;
        window.speechSynthesis.speak(utter);
      }
    } catch (err) {
      const errMsg = err?.response?.data?.message || 'AI Assistant is temporarily unavailable. Please try again later.';
      setError(errMsg);
      setMessages(prev => [...prev, { role: 'bot', text: `⚠️ ${errMsg}`, isError: true }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearChat = () => {
    setMessages([
      {
        role: 'bot',
        text: t('assistant.historyCleared', "Chat history cleared. How can I assist you with your buffalo herd health today?")
      }
    ]);
    setError('');
  };

  const startVoice = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      setError(t('assistant.voiceNotSupported', 'Speech recognition is not supported in your browser. Please use Chrome/Edge.'));
      return;
    }
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = language;
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setListening(true);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
      sendMessage(transcript);
    };
    recognition.onerror = (e) => {
      setListening(false);
      setError(`Voice recognition notice: ${e.error}`);
    };
    recognition.onend = () => setListening(false);

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopVoice = () => {
    recognitionRef.current?.stop();
    setListening(false);
  };

  const quickPrompts = [
    { label: t('assistant.prompt1', "Explain my buffalo's disease"), query: "Explain my buffalo's disease symptoms and severity" },
    { label: t('assistant.promptCMT', "California Mastitis Test (CMT)"), query: "How to perform California Mastitis Test (CMT) and interpret results?" },
    { label: t('assistant.promptLab', "Lab & RT-PCR Tests"), query: "What lab tests and RT-PCR tests are needed for buffalo diseases?" },
    { label: t('assistant.prompt2', "Biosecurity & Precautions"), query: "What biosecurity precautions and disinfection methods should I follow?" },
    { label: t('assistant.promptBloat', "First Aid for Bloat & Fever"), query: "What is the emergency first aid for ruminal bloat and high fever in buffalo?" },
    { label: t('assistant.promptVaccine', "Vaccination Schedule"), query: "What is the complete vaccination schedule for buffaloes?" },
    { label: t('assistant.prompt3', "Emergency Helpline (1962)"), query: "When should I contact a veterinarian or call 1962 mobile ambulance?" }
  ];

  const renderFormattedText = (text) => {
    if (!text) return null;
    const lines = text.split('\n');
    return lines.map((line, lIdx) => {
      // Alert/Disclaimer line
      if (line.includes('⚠️') || line.includes('Disclaimer') || line.includes('గమనిక') || line.includes('अस्वीकरण')) {
        return (
          <div key={lIdx} className="my-2 p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-900 font-semibold text-[11px] leading-relaxed">
            {line}
          </div>
        );
      }
      // Table row
      if (line.startsWith('|') && line.endsWith('|')) {
        const cells = line.split('|').filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
        if (line.includes('---')) return null; // divider
        const isHeader = lIdx === 0 || lines[lIdx - 1]?.includes('---');
        return (
          <div key={lIdx} className="flex gap-2 text-[11px] py-1 border-b border-slate-200">
            {cells.map((cell, cIdx) => (
              <span key={cIdx} className={`flex-1 ${isHeader ? 'font-bold text-slate-900' : 'text-slate-700'}`}>
                {cell.trim()}
              </span>
            ))}
          </div>
        );
      }
      // Heading with emoji or ###
      if (line.startsWith('###') || line.startsWith('##') || /^[📌🔬🧬🧪🩸🛡️💉🌾🚨📋🐮]/.test(line)) {
        return (
          <h4 key={lIdx} className="font-extrabold text-slate-900 text-sm mt-2 mb-1 flex items-center gap-1.5">
            {line.replace(/^###?\s*/, '')}
          </h4>
        );
      }
      // Bullet item
      if (line.trim().startsWith('•') || line.trim().startsWith('-') || /^\d+\.\s/.test(line.trim())) {
        const cleanLine = line.trim().replace(/^[•\-]\s*/, '').replace(/^\d+\.\s*/, '');
        const parts = cleanLine.split(/(\*\*.*?\*\*)/g);
        return (
          <div key={lIdx} className="flex items-start gap-2 pl-2 my-1 text-xs text-slate-800">
            <span className="text-emerald-600 font-bold">•</span>
            <span className="flex-1 leading-relaxed">
              {parts.map((p, pIdx) => {
                if (p.startsWith('**') && p.endsWith('**')) {
                  return <strong key={pIdx} className="font-bold text-slate-900">{p.slice(2, -2)}</strong>;
                }
                return p;
              })}
            </span>
          </div>
        );
      }
      // Regular line with bold formatting
      const parts = line.split(/(\*\*.*?\*\*)/g);
      return (
        <p key={lIdx} className="my-1 text-xs text-slate-800 leading-relaxed">
          {parts.map((p, pIdx) => {
            if (p.startsWith('**') && p.endsWith('**')) {
              return <strong key={pIdx} className="font-bold text-slate-900">{p.slice(2, -2)}</strong>;
            }
            return p;
          })}
        </p>
      );
    });
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-7rem)] flex flex-col space-y-4 py-2">
      {/* Header Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/30">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              {t('assistant.title', 'Veterinary AI Assistant')} <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
            </h1>
            <p className="text-xs text-slate-500 font-medium">{t('assistant.subtitle', 'Context-aware buffalo disease intelligence & general guidance.')}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {cases.length > 0 && (
            <select
              value={selectedCaseId}
              onChange={e => setSelectedCaseId(e.target.value)}
              className="p-2 bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 rounded-xl max-w-[180px]"
            >
              {cases.map(c => (
                <option key={c._id} value={c.caseId || c._id}>
                  {c.caseId} ({c.diseasePrediction ? t(`diseases.${c.diseasePrediction.replace(/\s+/g, '_')}`, c.diseasePrediction) : 'Case'})
                </option>
              ))}
            </select>
          )}

          <select
            value={language}
            onChange={e => {
              setLanguage(e.target.value);
              const newAppLang = e.target.value.startsWith('te') ? 'te' : e.target.value.startsWith('hi') ? 'hi' : 'en';
              if (setAppLang) setAppLang(newAppLang);
            }}
            className="p-2 bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 rounded-xl"
          >
            <option value="en-IN">English</option>
            <option value="te-IN">తెలుగు (Telugu)</option>
            <option value="hi-IN">हिन्दी (Hindi)</option>
          </select>

          <button
            onClick={clearChat}
            className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition"
            title={t('assistant.clearHistory', 'Clear Chat History')}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mandatory Disclaimer Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 flex items-center gap-3 shrink-0">
        <Info className="w-5 h-5 text-amber-600 shrink-0" />
        <p className="text-xs text-amber-900 font-semibold leading-tight">
          {t('assistant.disclaimer', 'AI-generated guidance is for informational purposes only and does not replace professional veterinary diagnosis or treatment.')}
        </p>
      </div>

      {/* Suggested Quick Prompt Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 shrink-0 scrollbar-none">
        {quickPrompts.map((prompt, pIdx) => (
          <button
            key={pIdx}
            onClick={() => sendMessage(prompt.query)}
            className="px-3.5 py-1.5 bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-full text-xs font-bold whitespace-nowrap transition shadow-sm"
          >
            {prompt.label}
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="flex-1 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex gap-3 max-w-[88%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}>
              <div className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 shadow-sm font-bold text-xs ${
                msg.role === 'user' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700 border border-slate-200'
              }`}>
                {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5 text-emerald-600" />}
              </div>

              <div className={`p-4 rounded-2xl text-xs leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-emerald-600 text-white font-semibold rounded-tr-none shadow-md shadow-emerald-600/20 whitespace-pre-line'
                  : msg.isError
                  ? 'bg-rose-50 text-rose-800 border border-rose-200 rounded-tl-none font-semibold'
                  : 'bg-slate-50 text-slate-800 border border-slate-200 rounded-tl-none font-medium'
              }`}>
                {msg.role === 'user' ? msg.text : renderFormattedText(msg.text)}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 max-w-[88%]">
              <div className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 bg-slate-100 border border-slate-200">
                <Bot className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 rounded-tl-none flex items-center gap-3">
                <Loader className="w-4 h-4 animate-spin text-emerald-600" />
                <span className="text-xs text-slate-500 font-bold">{t('assistant.analyzingNotice', 'Analyzing disease records and context...')}</span>
              </div>
            </div>
          )}

          {error && !loading && (
            <div className="flex items-center justify-between p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-700">
              <span>{error}</span>
              <button
                onClick={() => sendMessage(messages[messages.length - 1]?.text || 'Retry')}
                className="px-3 py-1 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition"
              >
                {t('assistant.retryBtn', 'Retry')}
              </button>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Input Form */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center gap-2">
          <button
            type="button"
            onClick={listening ? stopVoice : startVoice}
            className={`p-3 rounded-2xl border transition ${
              listening
                ? 'bg-rose-600 border-rose-600 text-white animate-pulse'
                : 'bg-white border-slate-200 text-slate-500 hover:text-emerald-600 hover:border-emerald-400'
            }`}
            title={listening ? 'Stop Recording' : 'Voice Input'}
          >
            {listening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={loading}
            placeholder={listening ? t('assistant.listeningPlaceholder', 'Listening to your voice query...') : t('assistant.inputPlaceholder', 'Ask about buffalo diseases, symptoms, severity, precautions...')}
            className="flex-1 p-3 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          />

          <button
            type="button"
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            className="p-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl transition disabled:opacity-50 shadow-md shadow-emerald-600/20"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
