import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import { 
  AlertTriangle, 
  MapPin, 
  ShieldAlert, 
  Activity, 
  Search, 
  LocateFixed,
  Compass,
  Navigation,
  CheckCircle,
  Building,
  Info,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import axios from 'axios';
import { io } from 'socket.io-client';
import { getDiseaseInfo, isSpreadableDisease, normalizeDiseaseKey, MANDATORY_ISOLATION_INSTRUCTION } from '../constants/diseaseInfo';
import { useTranslation } from '../context/LanguageContext';
import { getInitialCases } from '../data/initialCases';

// Custom Leaflet Dot Markers
const createDotIcon = (color, isUser = false) => new L.DivIcon({
  className: 'custom-dot-marker',
  html: `<div style="background-color: ${color}; width: ${isUser ? '20px' : '16px'}; height: ${isUser ? '20px' : '16px'}; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 12px ${color}; animation: ${isUser ? 'pulse 1.5s infinite' : 'none'};"></div>`,
  iconSize: [isUser ? 20 : 16, isUser ? 20 : 16],
  iconAnchor: [isUser ? 10 : 8, isUser ? 10 : 8]
});

const greenDot = createDotIcon('#10b981');
const yellowDot = createDotIcon('#f59e0b');
const redDot = createDotIcon('#ef4444');
const userDot = createDotIcon('#3b82f6', true);

// Custom High-Visibility Marker for Searched Area & Location
const selectedPlaceIcon = new L.DivIcon({
  className: 'custom-selected-place-marker',
  html: `
    <div style="position: relative; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
      <div style="position: absolute; width: 44px; height: 44px; border-radius: 50%; background: rgba(37, 99, 235, 0.45); animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      <div style="position: absolute; width: 30px; height: 30px; border-radius: 50%; background: rgba(37, 99, 235, 0.35); animation: pulse 2s infinite;"></div>
      <div style="position: relative; width: 26px; height: 26px; border-radius: 50%; background: #1d4ed8; border: 3px solid #ffffff; box-shadow: 0 0 16px rgba(29, 78, 216, 0.95); display: flex; align-items: center; justify-content: center; color: white; font-size: 13px; font-weight: 900;">📍</div>
    </div>
  `,
  iconSize: [44, 44],
  iconAnchor: [22, 22],
  popupAnchor: [0, -22]
});

// Map view flight animation controller
const MapUpdater = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 250);
    return () => clearTimeout(timer);
  }, [map]);

  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.flyTo(center, zoom, { animate: true, duration: 1.2 });
    }
  }, [center, map, zoom]);
  return null;
};

// Haversine formula for distance calculation in kilometers
function getDistanceKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return null;
  const R = 6371; // Radius of the Earth in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export default function HealthMap() {
  const { t } = useTranslation();
  const [cases, setCases] = useState([]);
  const [redZones, setRedZones] = useState([]);
  const [mapCenter, setMapCenter] = useState([16.5062, 80.6480]); // Centered on Vijayawada
  const [mapZoom, setMapZoom] = useState(13);

  // User location state
  const [userLocation, setUserLocation] = useState(null);
  const [userAddressDetails, setUserAddressDetails] = useState(null);
  const [detectingLocation, setDetectingLocation] = useState(false);
  const [selectedCase, setSelectedCase] = useState(null);

  // Filters & Search
  const [diseaseFilter, setDiseaseFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchingArea, setSearchingArea] = useState(false);
  const [searchMessage, setSearchMessage] = useState('');
  const [searchedPlace, setSearchedPlace] = useState(null);

  useEffect(() => {
    fetchActiveCases();
    fetchRedZones();

    const socket = io();
    socket.on('new_case', () => {
      fetchActiveCases();
      fetchRedZones();
    });

    return () => socket.disconnect();
  }, []);

  const fetchActiveCases = async () => {
    try {
      const token = localStorage.getItem('token');
      const { data } = await axios.get('/api/cases', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const list = Array.isArray(data) ? data : data.cases || [];
      // Strictly show all active cases on the red alert map (status !== 'Closed' && status !== 'Recovered')
      const activeList = list.filter(c => c.status !== 'Closed' && c.status !== 'Recovered');
      setCases(activeList);
    } catch (err) {
      console.warn('Backend offline for map cases, using edge data:', err);
      const activeDefaults = getDefaultMapCases().filter(c => c.status !== 'Closed' && c.status !== 'Recovered');
      setCases(activeDefaults);
    }
  };

  const getDefaultMapCases = () => {
    return getInitialCases();
  };

  const fetchRedZones = async () => {
    try {
      const token = localStorage.getItem('token');
      const { data } = await axios.get('/api/alerts/red-zones', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const alerts = data.alerts || [];
      setRedZones(alerts.length > 0 ? alerts : getDefaultRedZones());
    } catch (err) {
      console.warn('Backend offline for red zones, using edge alerts:', err);
      setRedZones(getDefaultRedZones());
    }
  };

  const getDefaultRedZones = () => [
    {
      _id: 'rz-1',
      alertId: 'ALT-1082',
      disease: 'Foot-and-Mouth Disease (FMD)',
      centerLatitude: 16.5100,
      centerLongitude: 80.6500,
      radiusKm: 1.0,
      radius: 1000,
      radiusMeters: 1000,
      caseCount: 4,
      severity: 'Critical',
      status: 'Active',
      quarantineStrict: true,
      alertMessage: '1 km Containment Zone declared around Krishna District due to contagious FMD cluster.'
    },
    {
      _id: 'rz-2',
      alertId: 'ALT-1083',
      disease: 'Lumpy Skin Disease (LSD)',
      centerLatitude: 16.3067,
      centerLongitude: 80.4365,
      radiusKm: 1.0,
      radius: 1000,
      radiusMeters: 1000,
      caseCount: 3,
      severity: 'High',
      status: 'Active',
      quarantineStrict: true,
      alertMessage: '1 km Vector Surveillance Zone active in Guntur District for LSD.'
    }
  ];

  // DETECT MY LOCATION WITH ACCURATE 6-DIGIT PINCODE RESOLUTION
  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      setSearchMessage('Geolocation is not supported by your browser.');
      return;
    }

    setDetectingLocation(true);
    setSearchMessage('');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        setUserLocation([lat, lon]);
        setMapCenter([lat, lon]);
        setMapZoom(14);

        try {
          let formattedDetails = null;
          try {
            const { data } = await axios.get(`/api/cases/geocode/reverse?lat=${lat}&lon=${lon}`);
            if (data && data.valid) {
              formattedDetails = {
                area: data.area || 'Detected Area',
                road: data.streetName || 'Local Road',
                city: data.city || '',
                district: data.district || '',
                state: data.state || '',
                pincode: data.pincode || '',
                lat,
                lon,
                displayName: data.displayName
              };
            }
          } catch (e) {
            console.warn('Backend geocode endpoint error:', e);
          }

          if (!formattedDetails) {
            const res = await axios.get(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`);
            const item = res.data;
            const addr = item?.address || {};
            const matchPin = item?.display_name?.match(/\b[1-9]\d{5}\b/);
            const rawPin = addr.postcode ? addr.postcode.replace(/\D/g, '') : '';
            const pin = (rawPin && rawPin.length === 6) ? rawPin : (matchPin ? matchPin[0] : '');

            formattedDetails = {
              area: addr.suburb || addr.neighbourhood || addr.village || addr.town || addr.city_district || 'Detected Location',
              road: addr.road || addr.pedestrian || 'Local Area',
              city: addr.city || addr.town || addr.village || '',
              district: addr.state_district || addr.county || addr.district || '',
              state: addr.state || '',
              pincode: pin,
              lat,
              lon,
              displayName: item?.display_name || `${lat.toFixed(4)}, ${lon.toFixed(4)}`
            };
          }

          setUserAddressDetails(formattedDetails);
          setSearchMessage(`📍 Location detected: ${formattedDetails.area} (Pincode: ${formattedDetails.pincode || 'detected'})`);
        } catch (geoErr) {
          console.warn('Reverse geocoding error:', geoErr);
          setUserAddressDetails({
            area: 'Detected Location',
            road: '',
            lat,
            lon,
            displayName: `GPS: ${lat.toFixed(4)}, ${lon.toFixed(4)}`
          });
        } finally {
          setDetectingLocation(false);
        }
      },
      (err) => {
        setSearchMessage('Unable to detect location. Please grant location access in browser permissions.');
        setDetectingLocation(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // ACCURATE OPENSTREETMAP SEARCH FOR ANY AREA / CITY / VILLAGE
  const handleSearchArea = async (e) => {
    e?.preventDefault();
    if (!searchQuery.trim()) return;

    setSearchingArea(true);
    setSearchMessage('');

    try {
      let lat = null;
      let lon = null;
      let displayName = '';
      let pincode = '';

      try {
        const { data } = await axios.get('/api/cases/geocode/search', {
          params: { area: searchQuery }
        });
        if (data && data.valid && data.latitude && data.longitude) {
          lat = data.latitude;
          lon = data.longitude;
          displayName = data.displayName;
          pincode = data.pincode;
        }
      } catch (e) {
        console.warn('Backend geocode search failed:', e);
      }

      if (!lat || !lon) {
        const queryStr = `${searchQuery.trim()}, India`;
        const res = await axios.get('https://nominatim.openstreetmap.org/search', {
          params: {
            q: queryStr,
            format: 'json',
            addressdetails: 1,
            limit: 1
          },
          headers: { 'User-Agent': 'BuffaloHealthMonitor/2.0' }
        });

        const item = res.data && res.data[0];
        if (item) {
          lat = Number(item.lat);
          lon = Number(item.lon);
          displayName = item.display_name;
          const matchPin = displayName.match(/\b[1-9]\d{5}\b/);
          pincode = item.address?.postcode ? item.address.postcode.replace(/\D/g, '') : (matchPin ? matchPin[0] : '');
        }
      }

      if (lat && lon) {
        setMapCenter([lat, lon]);
        setMapZoom(14);
        setSearchedPlace({ lat, lon, name: displayName, pincode });
        setSearchMessage(`🎯 OpenStreetMap marked: ${displayName} ${pincode ? `(Pincode: ${pincode})` : ''}`);
      } else {
        setSearchedPlace(null);
        setSearchMessage(`⚠️ Could not find exact location for "${searchQuery}". Try adding village, city or pincode.`);
      }
    } catch (err) {
      console.error('OpenStreetMap search error:', err);
      setSearchMessage('Location search failed. Please check internet connection.');
    } finally {
      setSearchingArea(false);
    }
  };

  const filteredCases = cases.filter(c => {
    if (diseaseFilter) {
      const pred = c.diseasePrediction || '';
      if (pred !== diseaseFilter && normalizeDiseaseKey(pred) !== normalizeDiseaseKey(diseaseFilter)) return false;
    }
    if (severityFilter && c.severity !== severityFilter) return false;
    if (searchQuery && !c.area?.toLowerCase().includes(searchQuery.toLowerCase()) && !c.pincode?.includes(searchQuery)) return false;
    return true;
  });

  const getMarkerDot = (c) => {
    // 1. Only detected as red alert if active threshold value reaches (>= 3 spreadable cases in 1km region)
    const inEmergency = redZones.some(rz => 
      (rz.disease === c?.diseasePrediction || normalizeDiseaseKey(rz.disease) === normalizeDiseaseKey(c?.diseasePrediction)) &&
      getDistanceKm(
        rz.latitude || rz.coordinates?.latitude || rz.centerLatitude,
        rz.longitude || rz.coordinates?.longitude || rz.centerLongitude,
        c?.latitude,
        c?.longitude
      ) <= (rz.radiusKm || 1.0)
    );
    if (inEmergency) return redDot;

    // 2. Otherwise based on severity level: keep red, yellow, green dot
    const sev = String(c?.severity || '').trim().toLowerCase();
    if (sev === 'critical' || sev === 'high') {
      return redDot;
    }
    if (sev === 'medium' || sev === 'moderate') {
      return yellowDot;
    }
    // Low, Normal, Mild, Healthy
    return greenDot;
  };

  // Only detected as red alert if threshold value reaches (from backend redZones)
  const redAlertAreas = redZones.map(rz => ({
    area: rz.area,
    disease: rz.disease,
    count: rz.caseCount || rz.totalCases,
    lat: rz.latitude || rz.coordinates?.latitude || rz.centerLatitude,
    lng: rz.longitude || rz.coordinates?.longitude || rz.centerLongitude
  }));

  return (
    <div className="max-w-7xl mx-auto space-y-6 py-2">
      
      {/* Header & Controls */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-rose-900/60 text-rose-300 rounded-full text-xs font-bold uppercase tracking-wider border border-rose-700/50">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              {t('map.badge', 'OpenStreetMap Disease Surveillance & Geocoding')}
            </div>
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight mt-2 text-white">
              {t('map.title', 'Red Alert Buffalo Disease Map')}
            </h1>
            <p className="text-slate-300 text-sm font-medium mt-1 max-w-2xl">
              {t('map.subtitle', 'Geographic disease cluster monitoring, live GPS location detection, near location address details, and OpenStreetMap area marking.')}
            </p>
          </div>

          {/* DETECT MY LOCATION BUTTON */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleDetectLocation}
              disabled={detectingLocation}
              className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl text-sm flex items-center gap-2.5 shadow-lg shadow-blue-600/30 transition active:scale-95 disabled:opacity-60"
            >
              <LocateFixed className={`w-5 h-5 ${detectingLocation ? 'animate-spin' : ''}`} />
              <span>{detectingLocation ? t('map.detecting', 'Detecting Location...') : t('map.detectLocation', 'Detect My Location')}</span>
            </button>
          </div>
        </div>

        {/* Search Bar for OpenStreetMap Area Marking */}
        <form onSubmit={handleSearchArea} className="flex flex-col sm:flex-row gap-3 pt-2">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text" 
              placeholder={t('map.searchPlaceholder', 'Enter village, area, city, or 6-digit pincode (e.g. Kondapalli, Guntur, 521225)...')} 
              value={searchQuery} 
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700 text-white placeholder-slate-400 text-sm font-semibold rounded-2xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
            />
          </div>
          <button 
            type="submit" 
            disabled={searchingArea}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-sm flex items-center justify-center gap-2 shadow-md transition disabled:opacity-60"
          >
            {searchingArea ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <Navigation className="w-4 h-4" />}
            <span>{t('map.markArea', 'Mark Area on Map')}</span>
          </button>
        </form>

        {/* Feedback Message */}
        {searchMessage && (
          <div className="p-3.5 bg-slate-800/90 border border-slate-700 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
            <Info className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{searchMessage}</span>
          </div>
        )}

        {/* Active Red Alerts Banner */}
        {redAlertAreas.length > 0 && (
          <div className="p-4 bg-rose-950/60 border border-rose-600/70 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-rose-300 font-extrabold text-xs uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4 text-rose-400 animate-pulse" />
              <span>{t('map.activeRedAlerts', 'ACTIVE RED ALERT OUTBREAK CLUSTERS')} ({redAlertAreas.length} AREAS):</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {redAlertAreas.map(ra => (
                <button
                  key={ra.area}
                  onClick={() => {
                    if (ra.lat && ra.lng) {
                      setMapCenter([ra.lat, ra.lng]);
                      setMapZoom(14);
                    }
                  }}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-md transition flex items-center gap-1.5"
                >
                  <span>🔴 {ra.area}</span>
                  <span className="opacity-80">({ra.count} Cases)</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{t('map.filterDisease', 'Filter Disease')}</label>
          <select 
            value={diseaseFilter} 
            onChange={e => setDiseaseFilter(e.target.value)}
            className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">{t('map.allDiseases', 'All Diseases')}</option>
            <option value="Foot-and-Mouth Disease (FMD)">{t('diseases.Foot_and_Mouth_Disease', 'Foot-and-Mouth Disease (FMD)')}</option>
            <option value="Lumpy Skin Disease (LSD)">{t('diseases.Lumpy_Skin_Disease', 'Lumpy Skin Disease (LSD)')}</option>
            <option value="Clinical Mastitis">{t('diseases.Mastitis', 'Clinical Mastitis')}</option>
            <option value="Multiple Disease Diagnosis">{t('diseases.Multiple_Disease_Diagnosis', 'Multiple Disease Diagnosis')}</option>
            <option value="Healthy Buffalo">{t('diseases.Healthy_Buffalo', 'Healthy Buffalo')}</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{t('map.filterSeverity', 'Filter Severity')}</label>
          <select 
            value={severityFilter} 
            onChange={e => setSeverityFilter(e.target.value)}
            className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">{t('map.allSeverities', 'All Severities')}</option>
            <option value="Low">🟢 Low</option>
            <option value="Medium">🟡 Moderate</option>
            <option value="High">🔴 High / Critical</option>
            <option value="Critical">🔴 Critical</option>
          </select>
        </div>

        <div className="flex items-end">
          <button
            onClick={() => { setDiseaseFilter(''); setSeverityFilter(''); setSearchQuery(''); }}
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition"
          >
            {t('map.resetFilters', 'Reset Filters')}
          </button>
        </div>
      </div>

      {/* OPENSTREETMAP INTERACTIVE MAP CONTAINER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* MAP SECTION */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-3 border border-slate-200 shadow-lg relative overflow-hidden h-[580px]">
          <MapContainer center={mapCenter} zoom={mapZoom} className="w-full h-full rounded-2xl z-0">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapUpdater center={mapCenter} zoom={mapZoom} />

            {/* MARKED SEARCHED LOCATION PIN */}
            {searchedPlace && (
              <Marker
                position={[searchedPlace.lat, searchedPlace.lon]}
                icon={selectedPlaceIcon}
              >
                <Popup>
                  <div className="p-2 space-y-1 text-xs min-w-[200px]">
                    <span className="font-bold text-blue-800 text-sm block">📍 {searchedPlace.name}</span>
                    {searchedPlace.pincode && (
                      <span className="text-slate-600 font-semibold block">Pincode: {searchedPlace.pincode}</span>
                    )}
                    <span className="text-[10px] text-slate-500 font-mono block">
                      GPS: {searchedPlace.lat.toFixed(4)}° N, {searchedPlace.lon.toFixed(4)}° E
                    </span>
                  </div>
                </Popup>
              </Marker>
            )}

            {/* DETECTED USER LOCATION MARKER */}
            {userLocation && (
              <Marker position={userLocation} icon={userDot}>
                <Popup>
                  <div className="p-2 space-y-1 text-xs">
                    <div className="font-black text-blue-700 flex items-center gap-1">
                      <LocateFixed className="w-4 h-4" /> You Are Here (GPS Detected)
                    </div>
                    {userAddressDetails && (
                      <div className="text-slate-600 font-medium">
                        <p><strong>Area:</strong> {userAddressDetails.area}</p>
                        <p><strong>Pincode:</strong> <span className="font-extrabold text-slate-900">{userAddressDetails.pincode || 'N/A'}</span></p>
                        <p><strong>District/State:</strong> {userAddressDetails.district || userAddressDetails.city}, {userAddressDetails.state}</p>
                      </div>
                    )}
                  </div>
                </Popup>
              </Marker>
            )}

            {/* Pulsing Red Alert Emergency Outbreak Circles (1km region buffer, >= 3 Spreadable Cases) */}
            {redZones.map((rz, idx) => {
              const lat = Number(rz.latitude || rz.coordinates?.latitude || rz.centerLatitude);
              const lng = Number(rz.longitude || rz.coordinates?.longitude || rz.centerLongitude);
              if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
              return (
                <Circle
                  key={rz.id || rz._id || idx}
                  center={[lat, lng]}
                  radius={rz.radius || rz.radiusMeters || 1000} // 1000m (1km region)
                  className="pulsing-emergency-circle"
                  pathOptions={{
                    color: '#dc2626',
                    fillColor: '#ef4444',
                    fillOpacity: 0.22,
                    weight: 3,
                    dashArray: '6, 6',
                  }}
                />
              );
            })}

            {/* Case Markers */}
            {filteredCases.map(c => {
              if (!c.latitude || !c.longitude) return null;
              const distFromPlace = searchedPlace
                ? getDistanceKm(searchedPlace.lat, searchedPlace.lon, c.latitude, c.longitude)
                : (userLocation ? getDistanceKm(userLocation[0], userLocation[1], c.latitude, c.longitude) : null);
              return (
                <Marker
                  key={c._id || c.caseId}
                  position={[c.latitude, c.longitude]}
                  icon={getMarkerDot(c)}
                  eventHandlers={{
                    click: () => setSelectedCase({ ...c, distFromUser: distFromPlace, refPlaceName: searchedPlace ? searchedPlace.name : 'You' })
                  }}
                >
                  <Popup>
                    <div className="p-2 space-y-2 text-xs max-w-xs">
                      <div className="flex items-center justify-between gap-2 border-b pb-1">
                        <span className="font-black text-slate-900">{c.diseasePrediction}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          c.severity === 'Critical' || c.severity === 'High' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {c.severity}
                        </span>
                      </div>
                      <div className="space-y-1 text-slate-700 font-medium">
                        <p><strong>Case ID:</strong> {c.caseId}</p>
                        <p><strong>Area:</strong> {c.area}</p>
                        <p><strong>Pincode:</strong> <span className="font-bold text-slate-900">{c.pincode}</span></p>
                        {distFromPlace !== null && (
                          <p className="text-blue-700 font-bold">
                            📍 Distance: {distFromPlace} km from {searchedPlace ? searchedPlace.name : 'your location'}
                          </p>
                        )}
                        <p><strong>Status:</strong> {c.status || 'Open'}</p>
                        <p><strong>Reported:</strong> {new Date(c.createdAt || Date.now()).toLocaleDateString('en-IN')}</p>
                      </div>
                    </div>
                  </Popup>
                </Marker>
              );
            })}
          </MapContainer>
        </div>

        {/* RIGHT COLUMN: OUTBREAK SURVEILLANCE & CASE DETAILS PANEL */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* OUTBREAK SURVEILLANCE SUMMARY */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-600" /> {t('map.surveillanceStatus', 'Surveillance Status')}
              </h3>
              <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                {t('map.liveMonitoring', 'Live Monitoring')}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <span className="text-[10px] text-slate-500 font-bold uppercase block">{t('map.activeOutbreaks', 'Active Outbreaks')}</span>
                <span className="text-2xl font-black text-slate-900">{filteredCases.length}</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">{t('map.recordedCases', 'Recorded cases')}</span>
              </div>
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl">
                <span className="text-[10px] text-rose-600 font-bold uppercase block">{t('map.redAlertZones', 'Red Alert Zones')}</span>
                <span className="text-2xl font-black text-rose-700">{redAlertAreas.length}</span>
                <span className="text-[10px] text-rose-500 block mt-0.5">{t('map.highSeverityClusters', 'High severity clusters')}</span>
              </div>
            </div>

            {/* Red alert areas quick jump */}
            {redAlertAreas.length > 0 && (
              <div className="space-y-2 pt-1">
                <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                  {t('map.clusterHotspots', 'Active Cluster Hotspots:')}
                </span>
                <div className="space-y-1.5 max-h-44 overflow-y-auto">
                  {redAlertAreas.map(ra => (
                    <div
                      key={ra.area}
                      onClick={() => {
                        if (ra.lat && ra.lng) {
                          setMapCenter([ra.lat, ra.lng]);
                          setMapZoom(15);
                        }
                      }}
                      className="p-2.5 bg-rose-50/70 hover:bg-rose-100/80 border border-rose-200 rounded-xl cursor-pointer transition flex items-center justify-between text-xs"
                    >
                      <span className="font-bold text-slate-900">🔴 {ra.area}</span>
                      <span className="font-extrabold text-rose-700 bg-rose-200/60 px-2 py-0.5 rounded-lg text-[10px]">
                        {ra.count} {t('dashboard.casesCount', 'Cases')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* SELECTED CASE / LOCATION CARD */}
          {selectedCase ? (
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4 animate-fadeIn">
              <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3 flex items-center justify-between">
                <span>{t('map.selectedCaseDetails', 'Selected Case Details')}</span>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                  selectedCase.severity === 'Critical' || selectedCase.severity === 'High' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {selectedCase.severity}
                </span>
              </h3>

              <div className="space-y-2 text-xs font-semibold text-slate-800">
                <p><strong>{t('caseDetail.caseId', 'Case ID')}:</strong> {selectedCase.caseId}</p>
                <p><strong>{t('createCase.aiPredictedDisease', 'Disease Prediction')}:</strong> <span className="font-black text-emerald-800">{selectedCase.diseasePrediction}</span></p>
                <p><strong>{t('createCase.tagNumber', 'Tag Number')}:</strong> {selectedCase.tagNumber}</p>
                <p><strong>{t('createCase.locationDetails', 'Location Area')}:</strong> {selectedCase.area}</p>
                <p><strong>{t('createCase.postalPincode', 'Postal Pincode')}:</strong> <span className="font-black text-emerald-900">{selectedCase.pincode}</span></p>
                {selectedCase.distFromUser !== null && (
                  <p className="text-blue-700 font-extrabold text-sm">📍 {t('caseDetail.distance', 'Distance from you')}: {selectedCase.distFromUser} km</p>
                )}
                {selectedCase.precautions && selectedCase.precautions.length > 0 && (
                  <div className="pt-2 border-t border-slate-100 space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">{t('diagnosisResult.necessaryPrecautions', 'Recommended Precautions')}</span>
                    <ul className="list-disc list-inside text-slate-600 space-y-1 font-medium">
                      {selectedCase.precautions.slice(0, 3).map((p, idx) => (
                        <li key={idx}>{p}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm text-center space-y-2">
              <MapPin className="w-8 h-8 text-emerald-600 mx-auto" />
              <h4 className="font-extrabold text-sm text-slate-900">{t('map.clickMarker', 'Click Any Marker on OpenStreetMap')}</h4>
              <p className="text-xs text-slate-500 font-medium">{t('map.clickMarkerDesc', 'Select any disease case marker on the map to view detailed near location info & pincode.')}</p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

