import React, { useState, useEffect } from 'react';
import { Bell, CheckCircle, AlertTriangle, Info, ShieldAlert, Loader } from 'lucide-react';
import axios from 'axios';
import { useTranslation } from '../context/LanguageContext';

export default function NotificationCenter() {
  const { t } = useTranslation();
  const token = localStorage.getItem('token');
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedNotification, setSelectedNotification] = useState(null);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setLoading(true);
    setError('');
    try {
      const [alertsRes, casesRes] = await Promise.all([
        axios.get('/api/alerts', { headers: token ? { Authorization: `Bearer ${token}` } : {} }),
        axios.get('/api/cases?mine=true', { headers: token ? { Authorization: `Bearer ${token}` } : {} }),
      ]);
      const alerts = (alertsRes.data || []).map(a => ({
        id: a._id || a.id || Math.random(),
        type: a.alertLevel === 'Critical' || a.alertLevel === 'High' ? 'critical' : 'warning',
        category: 'System Alerts',
        title: `${a.alertLevel} Alert: ${a.disease} Cluster`,
        body: `${a.totalCases} cases in ${a.area}. Immediate attention required.`,
        time: a.createdAt ? new Date(a.createdAt).toLocaleString() : 'Recently',
        read: false,
        details: a
      }));
      const caseUpdates = (casesRes.data || []).slice(0, 5).map(c => ({
        id: c._id || c.id,
        type: c.status === 'Resolved' ? 'success' : c.severity === 'High' ? 'critical' : 'info',
        category: 'Case Updates',
        title: `Case #${String(c._id || c.id).slice(-6).toUpperCase()} — ${c.status}`,
        body: `${c.diseasePrediction} in ${c.area}. Severity: ${c.severity}.`,
        time: c.createdAt ? new Date(c.createdAt).toLocaleString() : '',
        read: c.status === 'Resolved',
        details: c
      }));
      setNotifications([...alerts, ...caseUpdates]);
    } catch (err) {
      setError('Could not load notifications. ' + (err?.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const iconMap = {
    critical: <ShieldAlert className="w-5 h-5 text-red-500" />,
    warning: <AlertTriangle className="w-5 h-5 text-orange-400" />,
    success: <CheckCircle className="w-5 h-5 text-green-500" />,
    info: <Info className="w-5 h-5 text-brand-primary" />,
  };
  const bgMap = {
    critical: 'border-l-4 border-red-500 bg-red-500/5',
    warning: 'border-l-4 border-orange-400 bg-orange-400/5',
    success: 'border-l-4 border-green-500 bg-green-500/5',
    info: 'border-l-4 border-brand-primary bg-brand-primary/5',
  };

  const grouped = notifications.reduce((acc, curr) => {
    acc[curr.category] = acc[curr.category] || [];
    acc[curr.category].push(curr);
    return acc;
  }, {});

  return (
    <div className="max-w-6xl mx-auto flex gap-6 animate-in fade-in duration-500 h-[calc(100vh-8rem)]">
      <div className="flex-1 flex flex-col min-h-0">
        <div className="mb-6 flex justify-between items-end">
          <div>
            <h1 className="text-2xl font-bold text-brand-text flex items-center gap-3">
              <Bell className="text-brand-primary" /> {t('notificationsPage.title', 'Notification Center')}
              {unreadCount > 0 && (
                <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>
              )}
            </h1>
            <p className="text-brand-muted mt-2">{t('notificationsPage.subtitle', 'Manage your alerts and case updates.')}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={fetchNotifications} className="btn-outline text-sm">{t('notificationsPage.refresh', 'Refresh')}</button>
            <button onClick={markAllRead} className="btn-outline text-sm" disabled={unreadCount === 0}>
              {t('notificationsPage.markAllRead', 'Mark all as read')}
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pr-2 space-y-6">
          {loading ? (
            <div className="glass-card p-12 text-center">
              <Loader className="w-8 h-8 animate-spin text-brand-primary mx-auto mb-3" />
            </div>
          ) : error ? (
            <div className="glass-card p-8 text-center text-red-400">
              <AlertTriangle className="w-8 h-8 mx-auto mb-3" />
              <p>{error}</p>
            </div>
          ) : notifications.length === 0 ? (
            <div className="glass-card p-12 text-center text-brand-muted">
              <Bell className="w-12 h-12 mx-auto mb-4 text-slate-300" />
              <p>{t('notificationsPage.noNotifications', 'No notifications found.')}</p>
            </div>
          ) : (
            Object.keys(grouped).map(category => (
              <div key={category}>
                <h3 className="text-sm font-bold text-brand-muted uppercase tracking-wider mb-3">{category}</h3>
                <div className="space-y-3">
                  {grouped[category].map(n => (
                    <div
                      key={n.id}
                      className={`glass-card p-4 flex gap-4 items-start transition cursor-pointer hover:bg-brand-dark/50 ${bgMap[n.type]} ${n.read ? 'opacity-60' : ''} ${selectedNotification?.id === n.id ? 'ring-2 ring-brand-primary/50' : ''}`}
                      onClick={() => {
                        setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x));
                        setSelectedNotification(n);
                      }}
                    >
                      <div className="mt-0.5 shrink-0">{iconMap[n.type]}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start gap-2">
                          <p className={`font-bold text-sm truncate ${n.read ? 'text-brand-muted' : 'text-brand-text'}`}>{n.title}</p>
                          <span className="text-xs text-brand-muted shrink-0">{n.time}</span>
                        </div>
                        <p className="text-sm text-brand-muted mt-1 truncate">{n.body}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Details pane */}
      <div className="w-[400px] glass-card p-6 flex flex-col">
        {selectedNotification ? (
          <div className="animate-in fade-in slide-in-from-right-4">
            <h2 className="text-xl font-bold text-brand-text mb-4">{t('dashboard.viewDetails', 'Notification Details')}</h2>
            <div className={`p-4 rounded-xl mb-4 border ${bgMap[selectedNotification.type]}`}>
              <div className="flex items-center gap-2 mb-2">
                {iconMap[selectedNotification.type]}
                <span className="font-bold text-brand-text">{selectedNotification.title}</span>
              </div>
              <p className="text-sm text-brand-text/80">{selectedNotification.body}</p>
              <div className="text-xs text-brand-muted mt-2">{selectedNotification.time}</div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-brand-text">Raw Data</h3>
              <pre className="bg-brand-dark/50 p-4 rounded-xl text-xs overflow-auto max-h-[300px] text-brand-muted border border-brand-card">
                {JSON.stringify(selectedNotification.details, null, 2)}
              </pre>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center text-brand-muted opacity-50">
            <Info className="w-12 h-12 mb-4" />
            <p>{t('notificationsPage.noNotifications', 'Select a notification to view details')}</p>
          </div>
        )}
      </div>
    </div>
  );
}
