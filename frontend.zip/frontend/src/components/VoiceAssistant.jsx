import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  X, 
  Volume2, 
  VolumeX, 
  Send, 
  Sparkles, 
  ShieldAlert, 
  AlertTriangle,
  Stethoscope,
  Maximize2,
  Minimize2,
  RotateCcw
} from 'lucide-react';
import axios from 'axios';

// Multilingual Symptom Presets for Rapid Spoken/Tap Triage
// Multilingual Symptom & Triage Presets for Rapid Spoken/Tap Triage
const MULTILINGUAL_PRESETS = {
  'en-IN': [
    { label: 'Blisters & drooling (FMD)', query: 'My buffalo has blisters in mouth and feet with drooling' },
    { label: 'Skin nodules & lumps (LSD)', query: 'Buffalo has circular lumps and nodules all over skin' },
    { label: 'Hard udder & blood milk (Mastitis)', query: 'Udder is hot and hard, milk has blood clots' },
    { label: 'California Mastitis Test (CMT)', query: 'How to perform California Mastitis Test (CMT) and interpret results?' },
    { label: 'Severe bloat & left flank swelling', query: 'Buffalo has severe left flank swelling and bloat with difficulty breathing' },
    { label: 'Throat swelling & fever (HS)', query: 'Buffalo has throat swelling, loud grunting breathing, and high fever' },
    { label: 'Biosecurity & Disinfection', query: 'What biosecurity precautions and shed disinfection should I follow?' },
    { label: '24/7 Emergency Helpline (1962)', query: 'What is the veterinary emergency ambulance helpline and protocol?' }
  ],
  'te-IN': [
    { label: 'నోరు & కాళ్ళలో బొబ్బలు (FMD)', query: 'నా గేదె నోటిలో బొబ్బలు మరియు సొంగ కారుతోంది, కాళ్ళలో పుండ్లు ఉన్నాయి' },
    { label: 'చర్మంపై గుండ్రని గడ్డలు (లంపీ)', query: 'గేదె శరీరంపై గుండ్రని గడ్డలు, కాళ్ల వాపు మరియు జ్వరం ఉన్నాయి' },
    { label: 'గట్టి పొదుగు & రక్తపు పాలు (Mastitis)', query: 'పొదుగు బాగా గట్టిపడి వేడిగా ఉంది, పాలలో రక్తపు గడ్డలు వస్తున్నాయి' },
    { label: 'CMT పొదుగు వాపు పరీక్ష', query: 'కాలిఫోర్నియా మాస్టిటిస్ టెస్ట్ (CMT) పరీక్ష ఎలా చేయాలి మరియు ఫలితాలు ఎలా చూడాలి?' },
    { label: 'ఎడమ వైపు కడుపుబ్బరం (Bloat)', query: 'గేదె ఎడమ వైపు కడుపు బాగా ఉబ్బి ఊపిరి ఆడటం లేదు, ఏం ప్రథమ చికిత్స చేయాలి?' },
    { label: 'గొంతు వాపు & గురక (HS)', query: 'గేదె గొంతు కింద తీవ్రమైన వాపు వచ్చి ఊపిరిలో గురక శబ్దం వస్తోంది' },
    { label: 'కొట్టం పరిశుభ్రత & జాగ్రత్తలు', query: 'వ్యాధులు రాకుండా కొట్టాన్ని ఎలా శుభ్రం చేయాలి, ఏ జాగ్రత్తలు తీసుకోవాలి?' },
    { label: 'అత్యవసర హెల్ప్‌లైన్ (1962)', query: 'అత్యవసర పశువైద్య సహాయం మరియు 1962 మొబైల్ అంబులెన్స్ వివరాలు ఏంటి?' }
  ],
  'hi-IN': [
    { label: 'मुंह व खुरों में छाले (FMD)', query: 'मेरी भैंस के मुंह और पैरों में छाले हैं और अत्यधिक लार गिर रही है' },
    { label: 'त्वचा पर गांठें (लंपी)', query: 'भैंस के शरीर पर गोल गांठें और तेज बुखार है' },
    { label: 'कड़ा थन व खून वाला दूध (थनैला)', query: 'थन में सूजन और दर्द है तथा दूध में खून व थक्के आ रहे हैं' },
    { label: 'CMT थनैला जांच विधि', query: 'कैलिफोर्निया मैस्टाइटिस टेस्ट (CMT) कैसे करें और इसके परिणाम कैसे समझें?' },
    { label: 'बाईं कोख में गंभीर अफरा (Bloat)', query: 'भैंस की बाईं कोख ढोल की तरह फूल गई है और दम घुट रहा है, क्या प्राथमिक उपचार करें?' },
    { label: 'गले में भारी सूजन व घरघराहट (HS)', query: 'भैंस के गले में सूजन है और सांस लेने में भारी आवाज आ रही है' },
    { label: 'जैव-सुरक्षा एवं सावधानियां', query: 'बाड़े को विसंक्रमित करने और बीमारियों से बचाव के क्या नियम हैं?' },
    { label: 'आपातकालीन हेल्पलाइन (1962)', query: 'पशु चिकित्सा आपातकालीन 1962 एम्बुलेंस सेवा की जानकारी दें।' }
  ]
};

const WELCOME_MESSAGES = {
  'en-IN': '🐮 Hello! I am your AI Veterinary Assistant. Click the microphone to describe symptoms, or tap a preset below for instant triage.',
  'te-IN': '🐮 నమస్కారం! నేను మీ పశువైద్య ఏఐ అసిస్టెంట్‌ని. మైక్ ఆన్ చేసి మీ గేదె లక్షణాలు చెప్పండి లేదా కింద ఉన్న బటన్లపై నొక్కండి.',
  'hi-IN': '🐮 नमस्ते! मैं आपका पशु चिकित्सा एआई सहायक हूँ। माइक दबाकर अपनी भैंस के लक्षण बताएं या नीचे दिए गए विकल्पों पर टैप करें।'
};

export default function VoiceAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [inputText, setInputText] = useState('');
  const [language, setLanguage] = useState(() => localStorage.getItem('assistant_lang') || 'en-IN');
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      sender: 'ai',
      text: WELCOME_MESSAGES[localStorage.getItem('assistant_lang') || 'en-IN'] || WELCOME_MESSAGES['en-IN'],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [thinking, setThinking] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [availableVoices, setAvailableVoices] = useState([]);

  const recognitionRef = useRef(null);
  const chatBottomRef = useRef(null);

  // Load voices dynamically on mount and onvoiceschanged
  useEffect(() => {
    const updateVoices = () => {
      if ('speechSynthesis' in window) {
        const vList = window.speechSynthesis.getVoices();
        setAvailableVoices(vList);
      }
    };

    updateVoices();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  // Update language setting and welcome message
  const handleLanguageChange = (newLang) => {
    setLanguage(newLang);
    localStorage.setItem('assistant_lang', newLang);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
    const welcome = WELCOME_MESSAGES[newLang] || WELCOME_MESSAGES['en-IN'];
    setMessages(prev => [
      ...prev,
      {
        id: Date.now().toString(),
        sender: 'ai',
        text: welcome,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = language;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = async (event) => {
        const transcriptResult = event.results[0][0].transcript;
        setIsListening(false);
        if (transcriptResult) {
          await handleUserMessage(transcriptResult);
        }
      };

      recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setSpeechSupported(false);
    }

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [language]);

  // Scroll to bottom on new message
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking]);

  const speakText = (text) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    // Strip markdown formatting symbols and disclaimer for natural speech
    const cleanSpeech = text
      .replace(/[*#•_`~]/g, '')
      .replace(/⚠️.*$/s, '')
      .replace(/📌/g, '')
      .replace(/🛡️/g, '')
      .replace(/🩺/g, '')
      .replace(/🐮/g, '')
      .replace(/•/g, '')
      .replace(/\n+/g, ' ')
      .trim();

    if (!cleanSpeech) return;

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.lang = language;
    utterance.rate = 0.92; // Clear pacing for regional phonetics
    utterance.pitch = 1.0;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = (e) => {
      console.warn('TTS utterance error:', e);
      setIsSpeaking(false);
    };

    // Find best available voice for language (e.g. te-IN or hi-IN)
    const voices = availableVoices.length > 0 ? availableVoices : window.speechSynthesis.getVoices();
    const langCode = language.toLowerCase();
    const shortCode = language.split('-')[0].toLowerCase();

    let matchedVoice = voices.find(v => v.lang.toLowerCase() === langCode) ||
                       voices.find(v => v.lang.toLowerCase().startsWith(shortCode)) ||
                       voices.find(v => v.name.toLowerCase().includes(shortCode === 'te' ? 'telugu' : shortCode === 'hi' ? 'hindi' : 'india'));

    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      stopSpeaking();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.lang = language;
          recognitionRef.current.start();
          setIsListening(true);
        } catch (e) {
          console.warn('Recognition start failed:', e);
        }
      }
    }
  };

  const handleUserMessage = async (textToSend) => {
    const query = textToSend || inputText;
    if (!query || !query.trim()) return;

    const userMsg = {
      id: Date.now().toString(),
      sender: 'user',
      text: query.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setThinking(true);

    try {
      const token = localStorage.getItem('token');
      const res = await axios.post('/api/assistant', {
        transcript: query.trim(),
        language: language
      }, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });

      const replyText = res.data?.reply || 'I received your symptoms. Please isolate the buffalo and consult a field veterinarian immediately.';

      const aiMsg = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
      speakText(replyText);

    } catch (err) {
      console.error('Voice assistant error:', err);
      const errorMsg = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: '⚠️ Network connectivity issue. General advice: If your buffalo has high fever or respiratory distress, contact the AP 24/7 Mobile Ambulance Helpline at 1962 immediately.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setThinking(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleUserMessage();
    }
  };

  return (
    <div id="voice-assistant-widget" className="no-print">
      {/* Floating Action Button at Bottom-Right */}
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 no-print">
        {!isOpen && (
          <div 
            onClick={() => setIsOpen(true)}
            className="hidden sm:flex items-center gap-2 px-3.5 py-2 bg-slate-900/95 hover:bg-slate-900 text-white text-xs font-bold rounded-full shadow-xl border border-slate-700/80 backdrop-blur-md cursor-pointer transition transform hover:scale-105 select-none"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>AI Veterinary Assistant</span>
          </div>
        )}
        <button
          onClick={() => {
            setIsOpen(prev => !prev);
            if (isOpen) stopSpeaking();
          }}
          className="p-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-2xl shadow-emerald-600/40 hover:scale-105 active:scale-95 transition-all duration-200 flex items-center justify-center group"
          aria-label="AI Veterinary Assistant"
          title="AI Veterinary Assistant"
        >
          <div className="relative">
            {isSpeaking ? (
              <Volume2 className="w-7 h-7 animate-bounce text-amber-300" />
            ) : isListening ? (
              <Mic className="w-7 h-7 animate-ping text-rose-300" />
            ) : (
              <Stethoscope className="w-7 h-7 text-white group-hover:rotate-12 transition-transform" />
            )}
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full border-2 border-slate-900 animate-pulse" />
          </div>
        </button>
      </div>

      {/* Floating Chat Modal Panel */}
      {isOpen && (
        <div className="fixed bottom-24 right-4 sm:right-6 w-[92vw] sm:w-[420px] h-[580px] max-h-[85vh] bg-white rounded-3xl border border-slate-200 shadow-2xl z-50 flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-200">
          
          {/* Header */}
          <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-md">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                  <span>AI Veterinary Assistant</span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                    Live
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400 font-medium">Spoken Symptom Triage, Precautions & Chat</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {isSpeaking && (
                <button
                  onClick={stopSpeaking}
                  className="p-1.5 text-amber-400 hover:text-amber-300 transition"
                  title="Stop audio narration"
                >
                  <VolumeX className="w-4 h-4" />
                </button>
              )}
              <select
                value={language}
                onChange={(e) => handleLanguageChange(e.target.value)}
                className="bg-slate-800 text-[11px] font-bold text-slate-300 rounded-lg px-2 py-1 border border-slate-700 outline-none cursor-pointer"
              >
                <option value="en-IN">English (India)</option>
                <option value="te-IN">తెలుగు (Telugu)</option>
                <option value="hi-IN">हिन्दी (Hindi)</option>
              </select>
              <button
                onClick={() => { setIsOpen(false); stopSpeaking(); }}
                className="p-1.5 text-slate-400 hover:text-white transition rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Tap Symptoms Bar */}
          <div className="px-3 py-2 bg-slate-50 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider shrink-0">
              {language.startsWith('te') ? 'త్వరిత ఎంపిక:' : language.startsWith('hi') ? 'त्वरित विकल्प:' : 'Quick:'}
            </span>
            {(MULTILINGUAL_PRESETS[language] || MULTILINGUAL_PRESETS['en-IN']).map((preset, idx) => (
              <button
                key={idx}
                onClick={() => handleUserMessage(preset.query)}
                className="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:border-emerald-300 text-slate-700 text-[11px] font-bold rounded-lg border border-slate-200 transition shrink-0 whitespace-nowrap shadow-xs"
              >
                {preset.label}
              </button>
            ))}
          </div>

          {/* Chat Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl text-xs font-medium leading-relaxed shadow-xs ${
                    msg.sender === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-none whitespace-pre-line'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
                  }`}
                >
                  {msg.sender === 'user' ? (
                    <div>{msg.text}</div>
                  ) : (
                    <div className="space-y-1">
                      {msg.text.split('\n').map((line, lIdx) => {
                        if (line.includes('⚠️') || line.includes('Disclaimer') || line.includes('గమనిక') || line.includes('अस्वीकरण')) {
                          return (
                            <div key={lIdx} className="my-1.5 p-2 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-900 font-semibold text-[11px]">
                              {line}
                            </div>
                          );
                        }
                        if (line.startsWith('###') || line.startsWith('##') || /^[📌🔬🧬🧪🩸🛡️💉🌾🚨📋🐮]/.test(line)) {
                          return (
                            <h4 key={lIdx} className="font-extrabold text-slate-900 text-xs mt-1.5 mb-0.5">
                              {line.replace(/^###?\s*/, '')}
                            </h4>
                          );
                        }
                        if (line.trim().startsWith('•') || line.trim().startsWith('-') || /^\d+\.\s/.test(line.trim())) {
                          const clean = line.trim().replace(/^[•\-]\s*/, '').replace(/^\d+\.\s*/, '');
                          const parts = clean.split(/(\*\*.*?\*\*)/g);
                          return (
                            <div key={lIdx} className="flex items-start gap-1.5 pl-1 text-[11px] text-slate-800">
                              <span className="text-emerald-600 font-bold">•</span>
                              <span className="flex-1">
                                {parts.map((p, pIdx) => {
                                  if (p.startsWith('**') && p.endsWith('**')) {
                                    return <strong key={pIdx} className="font-bold text-slate-900">{p.slice(2, -2)}</strong>;
                                  }
                                  return p;
                                })}
                              </span>
                            </div>
                          );
                        }
                        const parts = line.split(/(\*\*.*?\*\*)/g);
                        return (
                          <p key={lIdx} className="text-[11px] text-slate-800 leading-relaxed">
                            {parts.map((p, pIdx) => {
                              if (p.startsWith('**') && p.endsWith('**')) {
                                return <strong key={pIdx} className="font-bold text-slate-900">{p.slice(2, -2)}</strong>;
                              }
                              return p;
                            })}
                          </p>
                        );
                      })}
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-400 font-semibold mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {thinking && (
              <div className="flex items-center gap-2 p-3 bg-white border border-slate-200 rounded-2xl max-w-[70%] text-xs font-bold text-slate-500 animate-pulse">
                <Sparkles className="w-4 h-4 text-emerald-600 animate-spin" />
                <span>Analyzing symptoms & generating triage...</span>
              </div>
            )}

            <div ref={chatBottomRef} />
          </div>

          {/* Voice & Input Footer */}
          <div className="p-3 bg-white border-t border-slate-200 shrink-0 space-y-2">
            
            {/* Listening Soundwaves Animation */}
            {isListening && (
              <div className="flex items-center justify-center gap-1.5 py-1 text-rose-600 font-bold text-xs animate-pulse">
                <span className="w-1.5 h-4 bg-rose-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-6 bg-rose-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-8 bg-rose-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="w-1.5 h-5 bg-rose-600 rounded-full animate-bounce" style={{ animationDelay: '450ms' }} />
                <span className="w-1.5 h-3 bg-rose-600 rounded-full animate-bounce" style={{ animationDelay: '600ms' }} />
                <span className="ml-2 font-black uppercase tracking-wider">Listening... Speak symptoms now</span>
              </div>
            )}

            {isSpeaking && (
              <div className="flex items-center justify-between px-3 py-1 bg-amber-50 border border-amber-200 rounded-xl text-xs font-bold text-amber-900">
                <span className="flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-amber-600 animate-bounce" />
                  <span>Reading precautions out loud...</span>
                </span>
                <button
                  onClick={stopSpeaking}
                  className="text-amber-700 underline text-[11px] font-black"
                >
                  Mute
                </button>
              </div>
            )}

            {/* Input Form with Big Mic Button */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleListening}
                className={`p-3 rounded-2xl transition-all duration-200 shrink-0 ${
                  isListening 
                    ? 'bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/30 scale-105' 
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20'
                }`}
                title={isListening ? 'Stop listening' : 'Click to speak symptoms'}
              >
                {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  language.startsWith('te')
                    ? "మీ గేదె వ్యాధి లక్షణాలు మాట్లాడండి లేదా టైప్ చేయండి..."
                    : language.startsWith('hi')
                    ? "अपनी भैंस के लक्षण बोलें या टाइप करें..."
                    : "Speak or type buffalo symptoms..."
                }
                className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-800 font-medium focus:outline-none focus:border-emerald-500"
              />

              <button
                type="button"
                onClick={() => handleUserMessage()}
                disabled={!inputText.trim()}
                className="p-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 text-white rounded-2xl transition shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
