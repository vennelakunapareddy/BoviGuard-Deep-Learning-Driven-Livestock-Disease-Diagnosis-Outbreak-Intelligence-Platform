import React from 'react';

export default function BoviGuardLogo({ size = 'md', showText = false, textClassName = '', className = '' }) {
  const dimensions = {
    xs: { box: 'w-7 h-7', font: 'text-sm' },
    sm: { box: 'w-9 h-9', font: 'text-base' },
    md: { box: 'w-11 h-11', font: 'text-xl' },
    lg: { box: 'w-14 h-14', font: 'text-2xl' },
    xl: { box: 'w-20 h-20', font: 'text-3xl' },
  }[size] || { box: 'w-11 h-11', font: 'text-xl' };

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* Official BoviGuard Pure Vector Emblem (No Raster Pictures) */}
      <div className={`${dimensions.box} rounded-2xl p-0.5 bg-gradient-to-br from-emerald-400 via-teal-500 to-cyan-600 shadow-lg shadow-emerald-600/30 shrink-0 relative flex items-center justify-center`}>
        <svg 
          viewBox="0 0 48 48" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1"
          aria-label="BoviGuard Emblem"
        >
          {/* Subtle shield backdrop */}
          <path 
            d="M24 4L8 10V22C8 32.5 14.8 41.5 24 44C33.2 41.5 40 32.5 40 22V10L24 4Z" 
            fill="rgba(255, 255, 255, 0.15)"
          />
          {/* Stylized Bovine Horns Silhouette Arch */}
          <path 
            d="M10 18C12 12 16 9 24 9C32 9 36 12 38 18C35 15 30 14 24 14C18 14 13 15 10 18Z" 
            fill="#FFFFFF" 
            fillOpacity="0.95"
          />
          {/* Central Veterinary Protection Shield */}
          <path 
            d="M24 13L13 18V26C13 33 17.7 39.5 24 41.2C30.3 39.5 35 33 35 26V18L24 13Z" 
            fill="#FFFFFF" 
            fillOpacity="0.22"
            stroke="#FFFFFF" 
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
          {/* Clinical Health Cross Symbol */}
          <path 
            d="M22 21H26V25H30V29H26V33H22V29H18V25H22V21Z" 
            fill="#FFFFFF"
          />
        </svg>
      </div>

      {showText && (
        <div className="min-w-0">
          <span className={`font-black tracking-tight leading-none ${dimensions.font} ${textClassName || 'text-slate-900'}`}>
            Bovi<span className="text-emerald-600">Guard</span>
          </span>
        </div>
      )}
    </div>
  );
}
