import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ScanLine, 
  MapPin, 
  Stethoscope,
  ShieldAlert, 
  Building2,
  Star,
  Cpu,
  Settings,
  LogOut,
  PlusCircle,
  Briefcase,
  FolderClock,
  FileBarChart,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../context/LanguageContext';
import BoviGuardLogo from './BoviGuardLogo';

export default function Sidebar({ isOpen, onClose }) {
  const { logout, user } = useAuth();
  const { t } = useTranslation();
  const navigate = useNavigate();

  const navItems = [
    { name: t('nav.dashboard', 'Dashboard'), path: '/dashboard', icon: LayoutDashboard },
    { name: t('nav.createCase', 'Create Case Record'), path: '/cases/create', icon: PlusCircle },
    { name: t('nav.diseasePrediction', 'Disease Prediction'), path: '/scan', icon: ScanLine },
    { name: t('nav.myCases', 'My Cases'), path: '/my-cases', icon: FolderClock },
    { name: t('nav.digitalHealthRecords', 'Digital Health Records'), path: '/cases', icon: Briefcase },
    { name: t('nav.reports', 'Analytics & Reports'), path: '/reports', icon: FileBarChart },
    { name: t('nav.outbreakMap', 'Red Alert Outbreak Map'), path: '/map', icon: MapPin },
    { name: t('nav.nearbyHospitals', 'Nearby Vet Hospitals (1962)'), path: '/hospitals', icon: Building2 },
    { name: t('nav.emergencySupport', 'Emergency Support Directory'), path: '/emergency-contacts', icon: Stethoscope },
    { name: t('nav.feedbackReviews', 'Feedback & Reviews'), path: '/reviews', icon: Star },
    { name: t('nav.mlEvaluation', 'ML Model Evaluation'), path: '/ml-evaluation', icon: Cpu },
  ];

  return (
    <>
      {/* Mobile Dark Backdrop Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden transition-opacity"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside className={`
        no-print fixed inset-y-0 left-0 z-50 w-72 sm:w-80 bg-white border-r border-slate-200/80 flex flex-col h-full backdrop-blur-xl shadow-2xl lg:shadow-md transition-transform duration-300 ease-in-out
        lg:static lg:translate-x-0 shrink-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Brand Header */}
        <div className="p-4 sm:p-5 flex items-center gap-3 border-b border-slate-100 bg-slate-50/50">
          <BoviGuardLogo size="md" />
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-xl text-slate-900 leading-tight truncate">
              Bovi<span className="text-emerald-600">Guard</span>
            </h1>
            <p className="text-[10px] text-emerald-700 font-extrabold tracking-wider uppercase">{t('appSubtitle', 'Livestock Health Intelligence')}</p>
          </div>

          {/* Close button on mobile */}
          <button 
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-xl text-slate-500 hover:bg-slate-200 hover:text-slate-800 transition"
            aria-label="Close menu"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* User Profile Summary */}
        {user && (
          <div className="p-4 border-b border-slate-100 bg-slate-50/70">
            <div className="flex items-center gap-3">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500 shadow-sm" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-base border-2 border-emerald-300 shadow-sm shrink-0">
                  {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                </div>
              )}
              <div className="overflow-hidden">
                <p className="text-sm font-extrabold text-slate-900 truncate">{user.name}</p>
                <p className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                  {t(`roles.${(user.role || 'buffalo_owner').toLowerCase().replace(/\s+/g, '_')}`, user.role || 'Buffalo Owner')}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Main Navigation Menu */}
        <div className="px-3.5 py-3 flex-1 overflow-y-auto space-y-1.5 scrollbar-thin">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-1.5">{t('platformNav', 'Platform Navigation')}</div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink 
                  key={item.path} 
                  to={item.path}
                  onClick={onClose}
                  className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                    isActive 
                      ? 'bg-emerald-50 text-emerald-800 shadow-sm border border-emerald-200/80 font-bold' 
                      : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900 font-semibold'
                  }`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="truncate">{item.name}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>
        
        {/* Bottom Footer Actions */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50/70 space-y-1">
          <NavLink 
            to="/settings" 
            onClick={onClose}
            className={({ isActive }) => `flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-semibold transition ${
              isActive ? 'bg-emerald-50 text-emerald-800 font-bold' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Settings className="w-5 h-5 text-slate-500 shrink-0" />
            <span>{t('nav.profile', 'Profile')} &amp; {t('nav.settings', 'Settings')}</span>
          </NavLink>
          <button 
            onClick={() => { onClose && onClose(); logout(); navigate('/auth'); }} 
            className="flex items-center gap-3 px-3 py-2 w-full text-left text-sm font-bold text-rose-600 hover:bg-rose-50 rounded-xl transition"
          >
            <LogOut className="w-5 h-5 shrink-0" />
            <span>{t('nav.signOut', 'Sign Out')}</span>
          </button>
        </div>
      </aside>
    </>
  );
}
