import React from 'react';
import { Globe, User, ShieldCheck, Menu } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../context/LanguageContext';
import BoviGuardLogo from './BoviGuardLogo';

export default function Topbar({ onToggleSidebar }) {
  const { user } = useAuth();
  const { language, changeLanguage, t } = useTranslation();

  const formatRole = (role) => {
    if (!role) return t('roles.buffalo_owner', 'Buffalo Owner');
    const key = `roles.${role.toLowerCase().replace(/\s+/g, '_')}`;
    return t(key, role.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '));
  };

  return (
    <header className="no-print h-16 sm:h-20 bg-white/95 border-b border-slate-200/80 backdrop-blur-md flex items-center justify-between px-3 sm:px-6 lg:px-8 z-20 sticky top-0 shadow-xs">
      {/* Left: Mobile Sidebar Toggle + BoviGuard Project Name */}
      <div className="flex items-center gap-2.5 sm:gap-4 flex-1 min-w-0">
        {/* Mobile Hamburger Menu Toggle Button */}
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-700 hover:text-emerald-700 hover:bg-slate-100 transition shrink-0"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Project Branding */}
        <Link to="/dashboard" className="flex items-center gap-2.5 min-w-0 group">
          <BoviGuardLogo size="sm" />
          <div className="min-w-0">
            <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
              Bovi<span className="text-emerald-600">Guard</span>
            </h1>
          </div>
        </Link>
      </div>
      
      {/* Right: Language Dropdown & Profile */}
      <div className="flex items-center gap-2 sm:gap-3 ml-2 sm:ml-6 shrink-0">
        {/* Top-Header Language Dropdown (English, తెలుగు, हिन्दी) */}
        <div className="flex items-center gap-1.5 bg-slate-100/90 hover:bg-slate-200/80 border border-slate-200/80 rounded-full px-2.5 sm:px-3 py-1 sm:py-1.5 transition shadow-xs">
          <Globe className="w-4 h-4 text-emerald-600 shrink-0" />
          <select
            value={language}
            onChange={(e) => changeLanguage(e.target.value)}
            className="bg-transparent text-xs sm:text-sm font-bold text-slate-800 focus:outline-none cursor-pointer pr-1"
            aria-label="Select Language"
          >
            <option value="en">English</option>
            <option value="te">తెలుగు (Telugu)</option>
            <option value="hi">हिन्दी (Hindi)</option>
          </select>
        </div>
        
        {user && (
          <Link 
            to="/settings"
            className="flex items-center gap-2 sm:gap-3 bg-slate-50 border border-slate-200 rounded-full p-1 sm:pl-1.5 sm:pr-3.5 sm:py-1.5 hover:border-emerald-500/50 hover:bg-emerald-50/50 transition shadow-xs"
          >
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} className="w-8 sm:w-9 h-8 sm:h-9 rounded-full object-cover border border-emerald-500" />
            ) : (
              <div className="w-8 sm:w-9 h-8 sm:h-9 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs sm:text-sm uppercase shadow-xs">
                {user.name ? user.name.charAt(0) : <User className="w-4 h-4" />}
              </div>
            )}
            <div className="hidden sm:flex flex-col">
              <span className="text-xs sm:text-sm font-bold text-slate-900 leading-tight truncate max-w-[120px]">{user.name}</span>
              <span className="text-[10px] sm:text-xs text-emerald-700 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> {formatRole(user.role)}
              </span>
            </div>
          </Link>
        )}
      </div>
    </header>
  );
}
