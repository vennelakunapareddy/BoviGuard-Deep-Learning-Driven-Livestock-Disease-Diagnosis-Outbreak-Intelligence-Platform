import React, { useState, useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import { 
  AlertTriangle, 
  MapPin, 
  LocateFixed, 
  ShieldAlert, 
  Radio, 
  Eye, 
  Filter,
  RefreshCw,
  ExternalLink,
  Flame,
  Pill,
  ShieldCheck,
  Building,
  AlertCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import 'leaflet/dist/leaflet.css';
import { 
  getDiseaseInfo, 
  isSpreadableDisease, 
  MANDATORY_ISOLATION_INSTRUCTION 
} from '../constants/diseaseInfo';
import { useTranslation } from '../context/LanguageContext';

// Fix standard Leaflet default icon paths in bundlers
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Haversine formula to compute distance in km
export function haversineDistanceKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return Number.POSITIVE_INFINITY;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// -------------------------------------------------------------
// Custom Leaflet Icons
// -------------------------------------------------------------

// 1. Standard Green Pin Marker (Non-Spreadable or Low-Risk)
const standardGreenPinIcon = new L.DivIcon({
  className: 'custom-standard-green-marker',
  html: `
    <div style="position: relative; width: 28px; height: 36px; display: flex; flex-direction: column; align-items: center;">
      <div style="width: 24px; height: 24px; border-radius: 50% 50% 50% 0; background: #10b981; border: 2.5px solid #ffffff; box-shadow: 0 2px 8px rgba(16, 185, 129, 0.6); transform: rotate(-45deg); display: flex; align-items: center; justify-content: center;">
        <div style="width: 8px; height: 8px; border-radius: 50%; background: #ffffff;"></div>
      </div>
    </div>
  `,
  iconSize: [28, 36],
  iconAnchor: [14, 34],
  popupAnchor: [0, -32],
});

// 2. Standard Yellow/Amber Pin Marker (1-2 Cases or Moderate)
const standardYellowPinIcon = new L.DivIcon({
  className: 'custom-standard-yellow-marker',
  html: `
    <div style="position: relative; width: 28px; height: 36px; display: flex; flex-direction: column; align-items: center;">
      <div style="width: 24px; height: 24px; border-radius: 50% 50% 50% 0; background: #f59e0b; border: 2.5px solid #ffffff; box-shadow: 0 2px 8px rgba(245, 158, 11, 0.6); transform: rotate(-45deg); display: flex; align-items: center; justify-content: center;">
        <div style="width: 8px; height: 8px; border-radius: 50%; background: #ffffff;"></div>
      </div>
    </div>
  `,
  iconSize: [28, 36],
  iconAnchor: [14, 34],
  popupAnchor: [0, -32],
});

// 2b. Standard Red Pin Marker (High/Critical Severity or Red Alert Zone)
const standardRedPinIcon = new L.DivIcon({
  className: 'custom-standard-red-marker',
  html: `
    <div style="position: relative; width: 28px; height: 36px; display: flex; flex-direction: column; align-items: center;">
      <div style="width: 24px; height: 24px; border-radius: 50% 50% 50% 0; background: #ef4444; border: 2.5px solid #ffffff; box-shadow: 0 2px 8px rgba(239, 68, 68, 0.6); transform: rotate(-45deg); display: flex; align-items: center; justify-content: center;">
        <div style="width: 8px; height: 8px; border-radius: 50%; background: #ffffff;"></div>
      </div>
    </div>
  `,
  iconSize: [28, 36],
  iconAnchor: [14, 34],
  popupAnchor: [0, -32],
});

// 3. Massive Pulsing Emergency Zone Beacon (>=3 Spreadable Cases Cluster Centroid)
const emergencyBeaconIcon = (caseCount, disease) => new L.DivIcon({
  className: 'custom-emergency-beacon-marker',
  html: `
    <div style="position: relative; width: 46px; height: 46px; display: flex; align-items: center; justify-content: center;">
      <div style="position: absolute; width: 46px; height: 46px; border-radius: 50%; background: rgba(239, 68, 68, 0.5); animation: ping 1.2s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      <div style="position: absolute; width: 34px; height: 34px; border-radius: 50%; background: rgba(220, 38, 38, 0.4); animation: pulse 1.8s infinite;"></div>
      <div style="position: relative; width: 24px; height: 24px; border-radius: 50%; background: #dc2626; border: 3px solid #ffffff; box-shadow: 0 0 16px rgba(220, 38, 38, 1); display: flex; align-items: center; justify-content: center; color: #ffffff; font-size: 11px; font-weight: 900;">
        ${caseCount}
      </div>
    </div>
  `,
  iconSize: [46, 46],
  iconAnchor: [23, 23],
  popupAnchor: [0, -24],
});

// 4. GPS User Location Pin
const userLocationIcon = new L.DivIcon({
  className: 'custom-user-marker',
  html: `
    <div style="position: relative; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;">
      <div style="position: absolute; width: 28px; height: 28px; border-radius: 50%; background: rgba(37, 99, 235, 0.4); animation: ping 2s infinite;"></div>
      <div style="position: relative; width: 16px; height: 16px; border-radius: 50%; background: #2563eb; border: 3px solid #ffffff; box-shadow: 0 0 12px #2563eb;"></div>
    </div>
  `,
  iconSize: [28, 28],
  iconAnchor: [14, 14],
  popupAnchor: [0, -14],
});

// Map panning animation hook
function MapViewController({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 250);
    return () => clearTimeout(timer);
  }, [map]);

  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.flyTo(center, zoom, { animate: true, duration: 1.2 });
    }
  }, [center, zoom, map]);
  return null;
}

export default function OutbreakMap({ cases = [], height = '550px', showControls = true }) {
  const { t } = useTranslation();
  const [filterMode, setFilterMode] = useState('all'); // 'all', 'emergency-zones', 'isolated'
  const [userLocation, setUserLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState([16.5062, 80.6480]); // Centered on Vijayawada, AP
  const [mapZoom, setMapZoom] = useState(12);

  // Fallback demo cases illustrating:
  // 1. A 3-case cluster of Foot_and_Mouth_Disease within 10km (TRIGGERS MASSIVE 10KM PULSING RED CIRCLE)
  // 2. An isolated 1-case of Lumpy_Skin_Disease (Spreadable but only 1 case -> Standard Yellow Pin, NO 10km circle)
  // 3. Non-spreadable diseases (Mastitis, Healthy Buffalo -> Standard Green Pins, NO 10km circle)
  const DEMO_CASES = [
    // --- 3 CASES OF SPREADABLE FMD IN VIJAYAWADA (TRIGGERS RED ALERT EMERGENCY ZONE) ---
    {
      _id: 'DEMO-FMD-01',
      caseId: 'BUF-2026-FMD-01',
      diseasePrediction: 'Foot_and_Mouth_Disease',
      tagNumber: 'AP-VIJ-1011',
      area: 'Governorpet, Vijayawada',
      latitude: 16.5080,
      longitude: 80.6350,
      severity: 'Critical',
      status: 'Quarantined',
      createdAt: new Date().toISOString()
    },
    {
      _id: 'DEMO-FMD-02',
      caseId: 'BUF-2026-FMD-02',
      diseasePrediction: 'Foot_and_Mouth_Disease',
      tagNumber: 'AP-VIJ-1012',
      area: 'Labbipet Dairy Colony, Vijayawada',
      latitude: 16.5020,
      longitude: 80.6410,
      severity: 'High',
      status: 'Active',
      createdAt: new Date().toISOString()
    },
    {
      _id: 'DEMO-FMD-03',
      caseId: 'BUF-2026-FMD-03',
      diseasePrediction: 'Foot_and_Mouth_Disease',
      tagNumber: 'AP-VIJ-1013',
      area: 'Benz Circle Outskirts, Vijayawada',
      latitude: 16.5140,
      longitude: 80.6520,
      severity: 'Critical',
      status: 'Under Treatment',
      createdAt: new Date().toISOString()
    },

    // --- ISOLATED 1-CASE SPREADABLE (LSD) in Guntur (1 case -> Standard Yellow Pin, NO emergency zone) ---
    {
      _id: 'DEMO-LSD-04',
      caseId: 'BUF-2026-LSD-04',
      diseasePrediction: 'Lumpy_Skin_Disease',
      tagNumber: 'AP-GTR-2201',
      area: 'Kothapet, Guntur',
      latitude: 16.3067,
      longitude: 80.4365,
      severity: 'Medium',
      status: 'Isolated',
      createdAt: new Date().toISOString()
    },

    // --- NON-SPREADABLE CASES (Standard Green Pins, NO emergency zone) ---
    {
      _id: 'DEMO-MAST-05',
      caseId: 'BUF-2026-MAST-05',
      diseasePrediction: 'Mastitis',
      tagNumber: 'AP-GAN-3310',
      area: 'Gannavaram Farms',
      latitude: 16.5420,
      longitude: 80.8010,
      severity: 'Medium',
      status: 'Under Treatment',
      createdAt: new Date().toISOString()
    },
    {
      _id: 'DEMO-HEALTHY-06',
      caseId: 'BUF-2026-HLT-06',
      diseasePrediction: 'Healthy_Buffalo',
      tagNumber: 'AP-KOND-4402',
      area: 'Kondapalli Foothills',
      latitude: 16.5584,
      longitude: 80.8163,
      severity: 'Low',
      status: 'Active',
      createdAt: new Date().toISOString()
    },
    {
      _id: 'DEMO-BQ-07',
      caseId: 'BUF-2026-BQ-07',
      diseasePrediction: 'Lumpy_Skin_Disease',
      tagNumber: 'AP-TEN-5509',
      area: 'Tenali Rural Outpost',
      latitude: 16.2430,
      longitude: 80.6400,
      severity: 'High',
      status: 'Treated',
      createdAt: new Date().toISOString()
    }
  ];

  const activeCasesList = (cases && cases.length > 0) ? cases : DEMO_CASES;

  // ---------------------------------------------------------------------------
  // 1km Haversine Clustering Engine (Enforces the 3+ Active Spreadable cases rule)
  // ---------------------------------------------------------------------------
  const { clusters, enrichedCases, emergencyClusters } = useMemo(() => {
    const RADIUS_KM = 1.0; // 1km region (1000m)
    const CASE_THRESHOLD = 3;

    // Filter items with valid coordinates and active status
    const validCases = activeCasesList
      .filter(c => 
        Number.isFinite(Number(c.latitude)) && 
        Number.isFinite(Number(c.longitude)) && 
        Number(c.latitude) !== 0 &&
        c.status !== 'Closed' &&
        c.status !== 'Recovered'
      )
      .map(c => {
        const disease = c.diseasePrediction;
        const info = getDiseaseInfo(disease);
        const isSpreadable = isSpreadableDisease(disease);
        return {
          ...c,
          latitude: Number(c.latitude),
          longitude: Number(c.longitude),
          diseaseMeta: info,
          isSpreadable
        };
      });

    // Group into 1km clusters by disease & area
    const clusterGroups = [];
    validCases.forEach(item => {
      const itemArea = (item.area || '').trim().toLowerCase();
      let group = clusterGroups.find(candidate => {
        if (candidate.disease !== item.diseasePrediction) return false;
        const candArea = (candidate.area || '').trim().toLowerCase();
        const sameArea = Boolean(itemArea && candArea && itemArea === candArea);
        const near = haversineDistanceKm(candidate.centroid.lat, candidate.centroid.lon, item.latitude, item.longitude) <= RADIUS_KM;
        return sameArea || near;
      });

      if (!group) {
        group = {
          id: `cluster-${item.diseasePrediction}-${clusterGroups.length + 1}`,
          disease: item.diseasePrediction,
          diseaseMeta: item.diseaseMeta,
          isSpreadable: item.isSpreadable,
          area: item.area || 'Unknown Area',
          centroid: { lat: item.latitude, lon: item.longitude },
          cases: []
        };
        clusterGroups.push(group);
      }

      group.cases.push(item);
      // Recalculate centroid
      group.centroid = {
        lat: group.cases.reduce((sum, it) => sum + it.latitude, 0) / group.cases.length,
        lon: group.cases.reduce((sum, it) => sum + it.longitude, 0) / group.cases.length,
      };
    });

    // Process clusters
    const processedClusters = clusterGroups.map(group => {
      const caseCount = group.cases.length;
      // STRICT BUSINESS RULE: >= 3 active cases of a SPREADABLE disease = EMERGENCY ZONE
      const isEmergencyZone = group.isSpreadable && caseCount >= CASE_THRESHOLD;

      return {
        ...group,
        caseCount,
        isEmergencyZone,
        radiusMeters: 1000, // 1000m radius (1km region)
        radiusKm: RADIUS_KM
      };
    });

    const emergencies = processedClusters.filter(c => c.isEmergencyZone);

    // Tag individual cases with whether they are inside an active emergency cluster
    const taggedCases = validCases.map(c => {
      const parentEmergency = emergencies.find(em => 
        em.disease === c.diseasePrediction &&
        (
          haversineDistanceKm(em.centroid.lat, em.centroid.lon, c.latitude, c.longitude) <= RADIUS_KM ||
          (c.area && em.area && c.area.trim().toLowerCase() === em.area.trim().toLowerCase())
        )
      );
      return {
        ...c,
        inEmergencyZone: Boolean(parentEmergency),
        emergencyClusterId: parentEmergency?.id || null
      };
    });

    return {
      clusters: processedClusters,
      enrichedCases: taggedCases,
      emergencyClusters: emergencies
    };
  }, [activeCasesList]);

  // Filter cases and clusters according to UI toggle
  const visibleCases = enrichedCases.filter(c => {
    if (filterMode === 'emergency-zones') return c.inEmergencyZone;
    if (filterMode === 'isolated') return !c.inEmergencyZone;
    return true;
  });

  const handleLocateMe = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setUserLocation([lat, lng]);
          setMapCenter([lat, lng]);
          setMapZoom(13);
        },
        (err) => console.warn('Geolocation failed:', err),
        { enableHighAccuracy: true, timeout: 8000 }
      );
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col space-y-3">
      {/* Top Banner & Surveillance Radar Header */}
      <div className="p-4 sm:p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 text-white flex flex-wrap items-center justify-between gap-4 border-b border-slate-800">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-rose-600/20 text-rose-400 flex items-center justify-center border border-rose-500/40 shrink-0">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="font-black text-lg sm:text-xl text-white tracking-tight">
                {t('map.title', 'Red Alert Outbreak Radar (1km Containment Zones)')}
              </h2>
              {emergencyClusters.length > 0 ? (
                <span className="px-3 py-1 rounded-full bg-rose-600 text-white text-xs font-black animate-pulse flex items-center gap-1.5 shadow-md">
                  <Flame className="w-3.5 h-3.5" />
                  {emergencyClusters.length} {t('dashboard.surveillanceAlert', 'EMERGENCY ZONE')} ACTIVE
                </span>
              ) : (
                <span className="px-3 py-0.5 rounded-full bg-emerald-600/80 text-white text-xs font-extrabold">
                  {t('map.surveillanceStatus', 'HERD SURVEILLANCE STABLE')}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-300 font-medium mt-0.5">
              {t('map.subtitle', 'Live spatial clustering and 1km containment zones across Andhra Pradesh.')}
            </p>
          </div>
        </div>

        {showControls && (
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex bg-slate-800/90 p-1 rounded-2xl border border-slate-700 text-xs font-bold">
              <button
                type="button"
                onClick={() => setFilterMode('all')}
                className={`px-3.5 py-2 rounded-xl transition ${
                  filterMode === 'all' 
                    ? 'bg-emerald-600 text-white shadow-sm font-extrabold' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t('common.all', 'All Cases')} ({enrichedCases.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterMode('emergency-zones')}
                className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
                  filterMode === 'emergency-zones' 
                    ? 'bg-rose-600 text-white shadow-sm font-extrabold' 
                    : 'text-rose-400 hover:text-white'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
                {t('map.filterActiveRedZones', 'Emergency Zones')} ({emergencyClusters.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterMode('isolated')}
                className={`px-3.5 py-2 rounded-xl transition ${
                  filterMode === 'isolated' 
                    ? 'bg-amber-600 text-white shadow-sm font-extrabold' 
                    : 'text-amber-400 hover:text-white'
                }`}
              >
                {t('map.allDiseases', 'Isolated / Standard')}
              </button>
            </div>

            <button
              type="button"
              onClick={handleLocateMe}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-2xl border border-slate-700 transition"
              title={t('map.locateMe', 'Locate My Herd (GPS)')}
            >
              <LocateFixed className="w-5 h-5 text-emerald-400" />
            </button>
          </div>
        )}
      </div>

      {/* Interactive Map Canvas */}
      <div className="relative w-full z-0 px-3 pb-2" style={{ height }}>
        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          className="w-full h-full rounded-2xl overflow-hidden shadow-inner border border-slate-200"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapViewController center={mapCenter} zoom={mapZoom} />

          {/* User Location Marker */}
          {userLocation && (
            <Marker position={userLocation} icon={userLocationIcon}>
              <Popup>
                <div className="p-2 space-y-1 text-xs font-sans">
                  <span className="font-extrabold text-blue-700 flex items-center gap-1">
                    <LocateFixed className="w-4 h-4" /> Your Farm Location (GPS)
                  </span>
                  <p className="text-slate-600">Centerpoint for herd proximity monitoring.</p>
                </div>
              </Popup>
            </Marker>
          )}

          {/* ========================================================================= */}
          {/* 1. MASSIVE SEMI-TRANSPARENT PULSING RED CIRCLES (>= 3 SPREADABLE CASES) */}
          {/* ========================================================================= */}
          {emergencyClusters.map((cluster) => {
            const { centroid, diseaseMeta, caseCount, radiusMeters } = cluster;
            return (
              <React.Fragment key={cluster.id}>
                {/* 1km Massive Pulsing Red Containment Circle */}
                <Circle
                  center={[centroid.lat, centroid.lon]}
                  radius={radiusMeters || 1000} // 1000 meters = 1km
                  className="pulsing-emergency-circle"
                  pathOptions={{
                    color: '#dc2626',
                    fillColor: '#ef4444',
                    fillOpacity: 0.25,
                    weight: 3,
                    dashArray: '8, 8',
                  }}
                />

                {/* Emergency Centroid Beacon Marker with Case Count */}
                <Marker
                  position={[centroid.lat, centroid.lon]}
                  icon={emergencyBeaconIcon(caseCount, cluster.disease)}
                >
                  <Popup>
                    <div className="p-3 space-y-3 max-w-sm text-xs font-sans">
                      {/* Emergency Header */}
                      <div className="flex items-center justify-between border-b border-rose-200 pb-2">
                        <div className="flex items-center gap-1.5 text-rose-800 font-black uppercase tracking-wider text-[11px]">
                          <Flame className="w-4 h-4 text-rose-600 animate-pulse" />
                          <span>EMERGENCY ZONE (1KM BUFFER)</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white font-black text-[10px]">
                          {caseCount} CASES REPORTED
                        </span>
                      </div>

                      {/* Disease & Transmission Details */}
                      <div className="space-y-1">
                        <h4 className="text-base font-black text-slate-900 leading-tight">
                          {diseaseMeta.displayName || cluster.disease}
                        </h4>
                        <p className="text-rose-700 font-extrabold text-[11px]">
                          Mode: {diseaseMeta.transmission}
                        </p>
                      </div>

                      {/* MANDATORY DIRECTIVE BOX */}
                      <div className="p-2.5 bg-rose-50 border border-rose-300 rounded-xl space-y-1">
                        <span className="text-[10px] font-black text-rose-900 uppercase tracking-wider block">
                          Mandatory Quarantine Directive:
                        </span>
                        <p className="text-[11px] font-bold text-rose-950 leading-snug">
                          "{MANDATORY_ISOLATION_INSTRUCTION}"
                        </p>
                      </div>

                      {/* Prescribed Medicine */}
                      <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                        <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wider flex items-center gap-1">
                          <Pill className="w-3.5 h-3.5 text-emerald-600" /> Prescribed Medicine
                        </span>
                        <p className="text-[11px] font-semibold text-slate-800">
                          {diseaseMeta.medicine}
                        </p>
                      </div>

                      {/* Clinical Precaution */}
                      <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                        <span className="text-[10px] font-black text-amber-800 uppercase tracking-wider flex items-center gap-1">
                          <ShieldAlert className="w-3.5 h-3.5 text-amber-600" /> Clinical Precaution
                        </span>
                        <p className="text-[11px] font-semibold text-slate-800">
                          {diseaseMeta.precaution}
                        </p>
                      </div>

                      {/* Contributing Cases in this 1km Cluster */}
                      <div className="text-[10px] text-slate-500 font-medium">
                        Area: <strong>{cluster.area}</strong> | Radius: <strong>1 km</strong>
                      </div>
                    </div>
                  </Popup>
                </Marker>
              </React.Fragment>
            );
          })}

          {/* ========================================================================= */}
          {/* 2. INDIVIDUAL CASE PIN MARKERS (STANDARD GREEN / YELLOW PINS) */}
          {/* ========================================================================= */}
          {visibleCases.map((c) => {
            const isSpreadable = c.isSpreadable;
            const inEmergency = c.inEmergencyZone;

            // Marker Icon Selection:
            // - If in active emergency outbreak zone or Critical/High: Red pin
            // - If Medium/Moderate severity: Yellow pin
            // - Low, Normal, or Healthy: Green pin
            let markerIcon = standardGreenPinIcon;
            const sev = String(c.severity || '').toLowerCase();
            if (inEmergency || sev === 'critical' || sev === 'high') {
              markerIcon = standardRedPinIcon;
            } else if (sev === 'medium' || sev === 'moderate') {
              markerIcon = standardYellowPinIcon;
            }

            return (
              <Marker
                key={c._id || c.caseId}
                position={[c.latitude, c.longitude]}
                icon={markerIcon}
              >
                <Popup>
                  <div className="p-2.5 space-y-2 max-w-xs text-xs font-sans">
                    {/* Header */}
                    <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-1.5">
                      <span className="font-extrabold text-slate-900 leading-tight">
                        {(c.diseasePrediction || 'Unknown Disease').replace(/_/g, ' ')}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                          isSpreadable
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        }`}
                      >
                        {isSpreadable ? 'Spreadable' : 'Non-Spreadable'}
                      </span>
                    </div>

                    {/* Case Metadata */}
                    <div className="space-y-1 text-slate-600 text-[11px]">
                      <p><strong>Tag ID:</strong> <span className="text-slate-900 font-bold">{c.tagNumber || 'N/A'}</span></p>
                      <p><strong>Area:</strong> {c.area || 'Field Outpost'}</p>
                      <p><strong>Severity:</strong> <span className="font-bold text-slate-800">{c.severity || 'Medium'}</span></p>
                      <p><strong>Status:</strong> {c.status || 'Active'}</p>
                    </div>

                    {/* Prescribed Medicine */}
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-[10px] space-y-0.5">
                      <span className="font-bold text-slate-700 block">Prescribed Treatment:</span>
                      <span className="text-slate-900 font-semibold">{c.diseaseMeta?.medicine}</span>
                    </div>

                    {/* Precaution */}
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-[10px] space-y-0.5">
                      <span className="font-bold text-slate-700 block">Clinical Precaution:</span>
                      <span className="text-slate-900 font-semibold">{c.diseaseMeta?.precaution}</span>
                    </div>

                    {/* Emergency Zone Status Notice */}
                    {inEmergency && (
                      <div className="p-2 rounded-lg bg-rose-50 border border-rose-300 text-rose-900 font-black text-[10px] flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        <span>Part of active 1km Outbreak Emergency Zone.</span>
                      </div>
                    )}

                    <div className="pt-1 flex items-center justify-end">
                      <Link
                        to={`/cases/${c.caseId || c._id}`}
                        className="px-3 py-1 bg-slate-900 hover:bg-emerald-600 text-white font-bold rounded-lg transition text-[11px] flex items-center gap-1"
                      >
                        <span>View Case File</span>
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>

      {/* Outbreak Map Legend Footer */}
      <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs font-semibold text-slate-700">
        <div className="flex flex-wrap items-center gap-5">
          {/* Emergency 1km Zone */}
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-full bg-rose-600 border-2 border-white shadow-md animate-ping inline-block" />
            <span className="font-black text-rose-700">
              1km Emergency Zone (&ge;3 Spreadable Cases: FMD, LSD)
            </span>
          </div>

          {/* Isolated 1-2 Spreadable Cases */}
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-amber-500 border border-white shadow-sm inline-block" />
            <span className="font-bold text-amber-800">
              Standard Pin Marker (1–2 Isolated Cases)
            </span>
          </div>

          {/* Non-Spreadable Disease */}
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-500 border border-white shadow-sm inline-block" />
            <span className="font-bold text-emerald-800">
              Standard Green Pin (Non-Spreadable: Clinical Mastitis, Healthy Buffalo)
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 font-medium flex items-center gap-2">
          <Building className="w-3.5 h-3.5 text-slate-400" />
          <span>Haversine 1km Cluster Engine Active</span>
        </div>
      </div>
    </div>
  );
}
