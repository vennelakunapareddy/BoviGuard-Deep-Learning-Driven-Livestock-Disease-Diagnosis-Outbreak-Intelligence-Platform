import React from 'react';
import { Routes, Route, Navigate, Outlet } from 'react-router-dom';

import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import HomeDashboard from './pages/HomeDashboard';
import AIScan from './pages/AIScan';
import HealthMap from './pages/HealthMap';
import EmergencyContacts from './pages/VeterinarySupport';
import Auth from './pages/Auth';
import Reports from './pages/Reports';
import Notifications from './pages/Notifications';
import NotificationCenter from './pages/NotificationCenter';
import HealthRecords from './pages/HealthRecords';
import CreateCase from './pages/CreateCase';
import CaseDetail from './pages/CaseDetail';
import AdminDashboard from './pages/AdminDashboard';
import Settings from './pages/Settings';
import NearbyHospitals from './pages/NearbyHospitals';
import Reviews from './pages/Reviews';
import MLEvaluation from './pages/MLEvaluation';
import MyCases from './pages/MyCases';
import { useAuth } from './context/AuthContext';

function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  return (
    <div className="flex h-screen w-full relative bg-slate-100 font-sans text-slate-900 overflow-hidden">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        <Topbar onToggleSidebar={() => setSidebarOpen(prev => !prev)} />

        <main className="flex-1 overflow-y-auto p-3.5 sm:p-6 scroll-smooth relative w-full">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="bg-slate-100 font-sans min-h-screen text-slate-900">
      <Routes>
        <Route path="/" element={<Navigate to="/auth" replace />} />
        <Route path="/auth" element={<Auth />} />
        
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<HomeDashboard />} />
          <Route path="/scan" element={<AIScan />} />
          <Route path="/map" element={<HealthMap />} />
          <Route path="/emergency-contacts" element={<EmergencyContacts />} />
          <Route path="/cases" element={<HealthRecords />} />
          <Route path="/cases/create" element={<CreateCase />} />
          <Route path="/cases/:id" element={<CaseDetail />} />
          <Route path="/my-cases" element={<MyCases />} />
          <Route path="/health-records" element={<HealthRecords />} />
          <Route path="/hospitals" element={<NearbyHospitals />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/ml-evaluation" element={<MLEvaluation />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/notification-center" element={<NotificationCenter />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;

