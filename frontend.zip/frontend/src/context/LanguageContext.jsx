import React, { createContext, useContext, useState, useEffect } from 'react';
import en from '../translations/en.json';
import te from '../translations/te.json';
import hi from '../translations/hi.json';

const translations = { en, te, hi };

export const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('buffalo_app_lang') || 'en';
  });

  const changeLanguage = (langCode) => {
    if (['en', 'te', 'hi'].includes(langCode)) {
      setLanguage(langCode);
      localStorage.setItem('buffalo_app_lang', langCode);
    }
  };

  /**
   * Helper function to translate keys with dot-notation support and fallback to English.
   * e.g. t('nav.createCase', 'Create Case Record')
   */
  const t = (key, fallback = '') => {
    if (!key) return fallback || '';

    const keys = key.split('.');

    // 1. Try currently selected language
    let current = translations[language];
    for (const k of keys) {
      if (current && current[k] !== undefined) {
        current = current[k];
      } else {
        current = null;
        break;
      }
    }

    if (current !== null && current !== undefined) {
      return current;
    }

    // 2. Fall back to English
    let fallbackVal = translations['en'];
    for (const k of keys) {
      if (fallbackVal && fallbackVal[k] !== undefined) {
        fallbackVal = fallbackVal[k];
      } else {
        fallbackVal = null;
        break;
      }
    }

    if (fallbackVal !== null && fallbackVal !== undefined) {
      return fallbackVal;
    }

    // 3. Fall back to supplied fallback text or key itself
    return fallback || key;
  };

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    // Graceful fallback if used outside Provider
    return {
      language: 'en',
      changeLanguage: () => {},
      t: (key, fallback = '') => fallback || key
    };
  }
  return context;
};
