// Bundled initial cases from backend/data/issues.json
// Ensures all past records, map markers, and case histories load instantly on APK install
export const INITIAL_CASES = [
  {
    "_id": "case_1791970151221_7hhja4",
    "caseId": "BUF-2026-0012",
    "animalType": "Buffalo",
    "tagNumber": "BUF-TEST-888",
    "buffaloName": "Murrah Red Zone Buffalo",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "Vennela Kunapareddy",
    "registeredBy": "Vennela Kunapareddy",
    "registeredByEmail": "",
    "registeredByRole": "Buffalo Owner",
    "area": "Kanuru / Sanath Nagar",
    "streetName": "Main Road",
    "pincode": "520007",
    "latitude": 16.486,
    "longitude": 80.692,
    "coordinates": {
      "latitude": 16.486,
      "longitude": 80.692
    },
    "symptoms": [
      "nodules on skin",
      "high fever",
      "loss of appetite"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-14T09:29:11.221Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "",
    "diseasePrediction": "Lumpy Skin Disease (LSD)",
    "confidenceScore": 85,
    "severity": "High",
    "riskPercentage": 85,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Isolate affected buffalo and consult a qualified veterinarian.",
    "status": "Open",
    "userId": "user_1791970151221",
    "createdAt": "2026-10-14T09:29:11.221Z",
    "updatedAt": "2026-10-14T09:29:11.221Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-14T09:29:11.221Z",
        "details": "Created case BUF-2026-0012 for Buffalo Tag ID BUF-TEST-888"
      }
    ]
  },
  {
    "_id": "case_1791968318197_gil63y",
    "caseId": "BUF-2026-0011",
    "animalType": "Buffalo",
    "tagNumber": "7",
    "buffaloName": "akki",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "varalakshmi",
    "registeredBy": "Vennela Kunapareddy",
    "registeredByEmail": "vennelakunapareddy@gmail.com",
    "registeredByRole": "System Admin",
    "area": "Kanuru / Sanath Nagar",
    "streetName": "VR Siddhartha Engineering College / Sanath Nagar",
    "pincode": "520007",
    "latitude": 16.486,
    "longitude": 80.692,
    "coordinates": {
      "latitude": 16.486,
      "longitude": 80.692
    },
    "symptoms": [
      "Hard/Swollen Udder",
      "Reduced Milk"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-14T08:58:38.197Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1791968318189-704251490.png",
    "diseasePrediction": "Clinical Mastitis",
    "confidenceScore": 65,
    "severity": "Medium",
    "riskPercentage": 55,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Administer intramammary antibiotic infusion as prescribed by a veterinarian; apply cold compresses to relieve udder pain.",
    "status": "Open",
    "userId": "6aa9f8973b3a86f0a43a6e3e",
    "createdAt": "2026-10-14T08:58:38.197Z",
    "updatedAt": "2026-10-14T08:58:38.197Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-14T08:58:38.197Z",
        "details": "Created case BUF-2026-0011 for Buffalo Tag ID 7"
      }
    ]
  },
  {
    "_id": "case_1791967722364_65impc",
    "caseId": "BUF-2026-0010",
    "animalType": "Buffalo",
    "tagNumber": "6",
    "buffaloName": "lucky",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "suresh",
    "registeredBy": "Vennela",
    "registeredByEmail": "24eu04101@vrsec.ac.in",
    "registeredByRole": "Volunteer",
    "area": "Kanuru / Sanath Nagar",
    "streetName": "VR Siddhartha Engineering College / Sanath Nagar",
    "pincode": "520007",
    "latitude": 16.486,
    "longitude": 80.692,
    "coordinates": {
      "latitude": 16.486,
      "longitude": 80.692
    },
    "symptoms": [
      "Nodules / Circular Lumps on Skin"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-14T08:48:42.364Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1791967722353-187894646.png",
    "diseasePrediction": "Lumpy Skin Disease (LSD)",
    "confidenceScore": 99,
    "severity": "High",
    "riskPercentage": 85,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Isolate from herd to prevent arthropod transmission and request veterinary supportive therapy.",
    "status": "Open",
    "userId": "6acf400393b9b9191fdbb009",
    "createdAt": "2026-10-14T08:48:42.364Z",
    "updatedAt": "2026-10-14T08:48:42.364Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela",
        "timestamp": "2026-10-14T08:48:42.364Z",
        "details": "Created case BUF-2026-0010 for Buffalo Tag ID 6"
      }
    ]
  },
  {
    "_id": "case_1791967362912_m15fuu",
    "caseId": "BUF-2026-0006",
    "animalType": "Buffalo",
    "tagNumber": "5",
    "buffaloName": "ramu",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "vishnu",
    "registeredBy": "Vennela",
    "registeredByEmail": "24eu04101@vrsec.ac.in",
    "registeredByRole": "Volunteer",
    "area": "Kanuru / Sanath Nagar",
    "streetName": "VR Siddhartha Engineering College / Sanath Nagar",
    "pincode": "520007",
    "latitude": 16.486,
    "longitude": 80.692,
    "coordinates": {
      "latitude": 16.486,
      "longitude": 80.692
    },
    "symptoms": [
      "Itching",
      "Skin Abrasion / Lesion"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-14T08:42:42.912Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1791967362897-171054982.png",
    "diseasePrediction": "Lumpy Skin Disease (LSD)",
    "confidenceScore": 87,
    "severity": "High",
    "riskPercentage": 85,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Isolate from herd to prevent arthropod transmission and request veterinary supportive therapy.",
    "status": "Open",
    "userId": "6acf400393b9b9191fdbb009",
    "createdAt": "2026-10-14T08:42:42.912Z",
    "updatedAt": "2026-10-14T08:42:42.912Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela",
        "timestamp": "2026-10-14T08:42:42.912Z",
        "details": "Created case BUF-2026-0006 for Buffalo Tag ID 5"
      }
    ]
  },
  {
    "_id": "case_1791900226283_bq8s4e",
    "caseId": "BUF-2026-0005",
    "animalType": "Buffalo",
    "tagNumber": "003",
    "buffaloName": "lakshmi",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "rajesh",
    "registeredBy": "Vennela Kunapareddy",
    "registeredByEmail": "vennelakunapareddy@gmail.com",
    "registeredByRole": "System Admin",
    "area": "Labbipet / MG Road",
    "streetName": "veternary road",
    "pincode": "520010",
    "latitude": 16.505,
    "longitude": 80.642,
    "coordinates": {
      "latitude": 16.505,
      "longitude": 80.642
    },
    "symptoms": [
      "Hard/Swollen Udder"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-13T14:03:46.283Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1791900226270-253969836.png",
    "diseasePrediction": "Clinical Mastitis",
    "confidenceScore": 88,
    "severity": "Medium",
    "riskPercentage": 55,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Administer intramammary antibiotic infusion as prescribed by a veterinarian; apply cold compresses to relieve udder pain.",
    "status": "Open",
    "userId": "6aa9f8973b3a86f0a43a6e3e",
    "createdAt": "2026-10-13T14:03:46.283Z",
    "updatedAt": "2026-10-13T14:03:46.283Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-13T14:03:46.283Z",
        "details": "Created case BUF-2026-0005 for Buffalo Tag ID 003"
      }
    ]
  },
  {
    "_id": "case_1791301266053_2wsbve",
    "caseId": "BUF-2026-0009",
    "animalType": "Buffalo",
    "tagNumber": "1",
    "buffaloName": "lakshmi",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "ramesh",
    "area": "Labbipet / MG Road",
    "streetName": "PVP Square / Gateway Hotel / MG Road",
    "pincode": "520010",
    "latitude": 16.505,
    "longitude": 80.642,
    "coordinates": {
      "latitude": 16.505,
      "longitude": 80.642
    },
    "symptoms": [
      "Excessive Salivation (Drooling)",
      "Nasal Discharge / Coughing"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-06T15:41:06.053Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1791301266031-354038360.png",
    "diseasePrediction": "Foot-and-Mouth Disease (FMD)",
    "confidenceScore": 100,
    "severity": "Critical",
    "riskPercentage": 85,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Isolate the animal immediately, notify municipal livestock officers, and disinfect all premises.",
    "status": "Recovered",
    "userId": "1790171882965",
    "createdAt": "2026-10-06T15:41:06.054Z",
    "updatedAt": "2026-10-09T14:04:14.880Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-06T15:41:06.054Z",
        "details": "Created case BUF-2026-0009 for Buffalo Tag ID 1"
      },
      {
        "action": "Case Updated",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-06T15:41:35.134Z",
        "details": "Status updated to Under Treatment"
      },
      {
        "action": "Case Updated",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-09T14:04:14.880Z",
        "details": "Status updated to Recovered"
      }
    ]
  },
  {
    "_id": "case_1790947720533_7fm5by",
    "caseId": "BUF-2026-0008",
    "animalType": "Buffalo",
    "tagNumber": "3746",
    "buffaloName": "akki",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "yedukondalu",
    "area": "Patamata / High School Road",
    "streetName": "High School Road / Pantakaluva Road Junction",
    "pincode": "520010",
    "latitude": 16.495,
    "longitude": 80.662,
    "coordinates": {
      "latitude": 16.495,
      "longitude": 80.662
    },
    "symptoms": [
      "Nodules / Circular Lumps on Skin",
      "Fever / High Temperature",
      "Swelling in Throat / Dewlap / Neck"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-02T13:28:40.533Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1790947720504-845991777.jpg",
    "diseasePrediction": "Lumpy Skin Disease (LSD)",
    "confidenceScore": 78,
    "severity": "High",
    "riskPercentage": 85,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Isolate from herd to prevent arthropod transmission and request veterinary supportive therapy.",
    "status": "Open",
    "userId": "6abfae1812308a80122dcf47",
    "createdAt": "2026-10-02T13:28:40.533Z",
    "updatedAt": "2026-10-02T13:28:40.533Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-02T13:28:40.533Z",
        "details": "Created case BUF-2026-0008 for Buffalo Tag ID 3746"
      }
    ]
  },
  {
    "_id": "case_1790939075360_4lrqgw",
    "caseId": "BUF-2026-0007",
    "animalType": "Buffalo",
    "tagNumber": "005",
    "buffaloName": "Laxmi",
    "age": 4,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 1,
    "ownerName": "Komali",
    "area": "One Town (Old City / Kaleswara Rao Market)",
    "streetName": "Near Kaleswara Rao Market / Durga Temple Foot",
    "pincode": "520001",
    "latitude": 16.516,
    "longitude": 80.612,
    "coordinates": {
      "latitude": 16.516,
      "longitude": 80.612
    },
    "symptoms": [
      "Clinical Mastitis / Swollen Udder"
    ],
    "diseaseDescription": "",
    "symptomsStartDate": "2026-10-02T11:04:35.360Z",
    "temperature": "",
    "medicalHistory": "",
    "currentTreatment": "",
    "veterinarianName": "",
    "image": "/uploads/buffalo-1790939075340-727328615.png",
    "diseasePrediction": "Clinical Mastitis",
    "confidenceScore": 88,
    "severity": "Medium",
    "riskPercentage": 55,
    "recommendations": [],
    "precautions": [],
    "immediateAction": "Administer intramammary antibiotic infusion as prescribed by a veterinarian; apply cold compresses to relieve udder pain.",
    "status": "Open",
    "userId": "1790171882965",
    "createdAt": "2026-10-02T11:04:35.360Z",
    "updatedAt": "2026-10-02T11:04:35.360Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Vennela Kunapareddy",
        "timestamp": "2026-10-02T11:04:35.360Z",
        "details": "Created case BUF-2026-0007 for Buffalo Tag ID 005"
      }
    ]
  },
  {
    "_id": "case_seed_001",
    "caseId": "BUF-2026-0001",
    "animalType": "Buffalo",
    "tagNumber": "AP-KAN-1011",
    "buffaloName": "Ganga",
    "age": 5,
    "gender": "Female",
    "breed": "Murrah",
    "affectedCount": 2,
    "ownerName": "Ramesh Naidu",
    "area": "Kanuru",
    "streetName": "Auto Nagar Main Road",
    "pincode": "520007",
    "latitude": 16.4912,
    "longitude": 80.6865,
    "coordinates": {
      "latitude": 16.4912,
      "longitude": 80.6865
    },
    "symptoms": [
      "Fever / High Temperature",
      "Blisters on Mouth / Tongue / Lips",
      "Excessive Salivation (Drooling)",
      "Lameness / Difficulty Walking"
    ],
    "diseaseDescription": "Blisters visible on tongue and hooves with extensive drooling.",
    "symptomsStartDate": "2026-09-28T09:00:00.000Z",
    "temperature": "104.5 F",
    "medicalHistory": "Routine FMD booster overdue by 2 months.",
    "currentTreatment": "1% Potassium Permanganate mouth and hoof wash, Meloxicam injection",
    "veterinarianName": "Dr. V. Prasad (B.V.Sc)",
    "image": "",
    "diseasePrediction": "Foot-and-Mouth Disease (FMD)",
    "confidenceScore": 96,
    "severity": "Critical",
    "riskPercentage": 90,
    "recommendations": [
      "Immediate isolation of affected animals from healthy herd.",
      "Apply 1% potassium permanganate wash twice daily to mouth and hoof lesions.",
      "Administer anti-inflammatory analgesics under veterinary supervision.",
      "Prohibit animal movement and milk transport outside premises."
    ],
    "precautions": [
      "Halt all animal movement and milk transport from premises.",
      "Use potassium permanganate (1% KMnO4) foot and mouth washes.",
      "Separate milking utensils and boil milk before disposal.",
      "Disinfect sheds with 4% sodium carbonate or citric acid."
    ],
    "immediateAction": "Mandatory herd quarantine and immediate veterinary intervention.",
    "status": "Open",
    "userId": "user_demo_01",
    "createdAt": "2026-09-30T10:15:00.000Z",
    "updatedAt": "2026-09-30T10:15:00.000Z",
    "history": [
      {
        "action": "Case Created",
        "changedBy": "Ramesh Naidu",
        "timestamp": "2026-09-30T10:15:00.000Z",
        "details": "Reported acute FMD symptoms in Kanuru"
      }
    ]
  }
];

export function getInitialCases() {
  try {
    const custom = localStorage.getItem('offline_cases');
    const customList = custom ? JSON.parse(custom) : [];
    const existingIds = new Set(customList.map(c => c._id || c.caseId));
    const merged = [...customList];
    for (const c of INITIAL_CASES) {
      if (!existingIds.has(c._id) && !existingIds.has(c.caseId)) {
        merged.push(c);
      }
    }
    return merged;
  } catch {
    return INITIAL_CASES;
  }
}
