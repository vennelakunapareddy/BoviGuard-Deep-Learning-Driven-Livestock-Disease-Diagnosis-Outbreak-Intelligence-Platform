// Comprehensive Database of Vijayawada Areas, Neighborhoods, Mandals, and Official Pincodes with verified GPS coordinates

export const VIJAYAWADA_LOCATIONS = [
  {
    id: 'benz-circle',
    area: 'Benz Circle / Bandar Road',
    shortName: 'Benz Circle',
    pincode: '520010',
    lat: 16.5000,
    lng: 80.6540,
    landmark: 'Benz Circle Flyover / Trendset Mall',
    zone: 'South Central Zone'
  },
  {
    id: 'patamata',
    area: 'Patamata / High School Road',
    shortName: 'Patamata',
    pincode: '520010',
    lat: 16.4950,
    lng: 80.6620,
    landmark: 'High School Road / Pantakaluva Road Junction',
    zone: 'South East Zone'
  },
  {
    id: 'moghalrajpuram',
    area: 'Moghalrajpuram / Siddhartha Nagar',
    shortName: 'Moghalrajpuram',
    pincode: '520010',
    lat: 16.5020,
    lng: 80.6485,
    landmark: 'Jammi Chettu Center / Siddhartha Arts College',
    zone: 'South Central Zone'
  },
  {
    id: 'labbipet',
    area: 'Labbipet / MG Road',
    shortName: 'Labbipet',
    pincode: '520010',
    lat: 16.5050,
    lng: 80.6420,
    landmark: 'PVP Square / Gateway Hotel / MG Road',
    zone: 'South Central Zone'
  },
  {
    id: 'one-town',
    area: 'One Town (Old City / Kaleswara Rao Market)',
    shortName: 'One Town',
    pincode: '520001',
    lat: 16.5160,
    lng: 80.6120,
    landmark: 'Near Kaleswara Rao Market / Durga Temple Foot',
    zone: 'West Zone'
  },
  {
    id: 'kothapet',
    area: 'Kothapet / Nehru Bazaar',
    shortName: 'Kothapet',
    pincode: '520001',
    lat: 16.5180,
    lng: 80.6140,
    landmark: 'Nehru Bazaar / Brahmin Street',
    zone: 'West Zone'
  },
  {
    id: 'vinchipet',
    area: 'Vinchipet / Tarapet',
    shortName: 'Vinchipet',
    pincode: '520001',
    lat: 16.5190,
    lng: 80.6180,
    landmark: 'West Railway Station Gate',
    zone: 'West Zone'
  },
  {
    id: 'chitti-nagar',
    area: 'Chitti Nagar / Tunnel Road',
    shortName: 'Chitti Nagar',
    pincode: '520001',
    lat: 16.5240,
    lng: 80.6090,
    landmark: 'Tunnel Road / Milk Project Hill',
    zone: 'West Zone'
  },
  {
    id: 'governorpet',
    area: 'Governorpet / Besant Road',
    shortName: 'Governorpet',
    pincode: '520002',
    lat: 16.5125,
    lng: 80.6275,
    landmark: 'Prakasam Barrage Approach / Besant Road Shopping',
    zone: 'Central Zone'
  },
  {
    id: 'suryaraopet',
    area: 'Suryaraopet / Karl Marx Road',
    shortName: 'Suryaraopet',
    pincode: '520002',
    lat: 16.5110,
    lng: 80.6350,
    landmark: 'Near Police Control Room / Old Bus Stand',
    zone: 'Central Zone'
  },
  {
    id: 'gandhi-nagar',
    area: 'Gandhi Nagar / Railway Station Area',
    shortName: 'Gandhi Nagar',
    pincode: '520003',
    lat: 16.5205,
    lng: 80.6280,
    landmark: 'Vijayawada Junction Railway Station / Press Club',
    zone: 'Central Zone'
  },
  {
    id: 'ayodhya-nagar',
    area: 'Ayodhya Nagar / Madhuranagar',
    shortName: 'Ayodhya Nagar',
    pincode: '520003',
    lat: 16.5280,
    lng: 80.6390,
    landmark: 'Near Madhuranagar Railway Bridge',
    zone: 'North Central Zone'
  },
  {
    id: 'gunadala',
    area: 'Gunadala / Mary Matha Shrine',
    shortName: 'Gunadala',
    pincode: '520004',
    lat: 16.5190,
    lng: 80.6690,
    landmark: 'Gunadala Hill Shrine / Eluru Road',
    zone: 'East Zone'
  },
  {
    id: 'machavaram',
    area: 'Machavaram / Down Hospital Area',
    shortName: 'Machavaram',
    pincode: '520004',
    lat: 16.5170,
    lng: 80.6560,
    landmark: 'Machavaram Down / BRTS Road',
    zone: 'Central East Zone'
  },
  {
    id: 'christurajupuram',
    area: 'Christurajupuram / St. Pauls Cathedral',
    shortName: 'Christurajupuram',
    pincode: '520004',
    lat: 16.5120,
    lng: 80.6520,
    landmark: 'St. Pauls Cathedral / Bishop Grassi High School',
    zone: 'Central East Zone'
  },
  {
    id: 'auto-nagar',
    area: 'Auto Nagar Industrial Estate',
    shortName: 'Auto Nagar',
    pincode: '520007',
    lat: 16.4920,
    lng: 80.6770,
    landmark: '100 Feet Road / Transport Hub / Veterinary Polyclinic',
    zone: 'East Industrial Zone'
  },
  {
    id: 'kanuru',
    area: 'Kanuru / Sanath Nagar',
    shortName: 'Kanuru',
    pincode: '520007',
    lat: 16.4860,
    lng: 80.6920,
    landmark: 'VR Siddhartha Engineering College / Sanath Nagar',
    zone: 'East Extension'
  },
  {
    id: 'ashok-nagar',
    area: 'Ashok Nagar / Revenue Colony',
    shortName: 'Ashok Nagar',
    pincode: '520007',
    lat: 16.4970,
    lng: 80.6690,
    landmark: 'Near Auto Nagar Gate / Veterinary College Road',
    zone: 'East Zone'
  },
  {
    id: 'currency-nagar',
    area: 'Currency Nagar / Loyola College Area',
    shortName: 'Currency Nagar',
    pincode: '520008',
    lat: 16.5120,
    lng: 80.6620,
    landmark: 'Andhra Loyola College Campus / Ring Road',
    zone: 'Central East Zone'
  },
  {
    id: 'satyanarayanapuram',
    area: 'Satyanarayanapuram / Shivaji Cafe Center',
    shortName: 'Satyanarayanapuram',
    pincode: '520011',
    lat: 16.5270,
    lng: 80.6360,
    landmark: 'Shivaji Cafe Center / Main Road Post Office',
    zone: 'North Zone'
  },
  {
    id: 'madhuranagar',
    area: 'Madhuranagar / Railway Colony',
    shortName: 'Madhuranagar',
    pincode: '520011',
    lat: 16.5240,
    lng: 80.6450,
    landmark: 'Madhuranagar Halt / Prabhas College',
    zone: 'North Zone'
  },
  {
    id: 'mutyalammapadu',
    area: 'Mutyalammapadu / Water Tank',
    shortName: 'Mutyalammapadu',
    pincode: '520011',
    lat: 16.5310,
    lng: 80.6320,
    landmark: 'Near Overbridge / Water Tank Road',
    zone: 'North Zone'
  },
  {
    id: 'bhavanipuram',
    area: 'Bhavanipuram / Swathi Theatre',
    shortName: 'Bhavanipuram',
    pincode: '520012',
    lat: 16.5265,
    lng: 80.5925,
    landmark: 'Swathi Theatre / Iron Yard / NH-65 Bypass',
    zone: 'West Zone'
  },
  {
    id: 'vidyadharapuram',
    area: 'Vidyadharapuram / Kummaripalem',
    shortName: 'Vidyadharapuram',
    pincode: '520012',
    lat: 16.5310,
    lng: 80.6020,
    landmark: 'Milk Project / APSRTC Regional Workshop',
    zone: 'West Zone'
  },
  {
    id: 'jakkampudi',
    area: 'Jakkampudi Colony / Economic City',
    shortName: 'Jakkampudi',
    pincode: '520012',
    lat: 16.5710,
    lng: 80.6010,
    landmark: 'Jakkampudi Economic City / Inner Ring Road',
    zone: 'North West Rural Zone'
  },
  {
    id: 'krishna-lanka',
    area: 'Krishna Lanka / Bund Road',
    shortName: 'Krishna Lanka',
    pincode: '520013',
    lat: 16.5010,
    lng: 80.6300,
    landmark: 'Krishna River Bund / Fire Station Road',
    zone: 'South Riverside Zone'
  },
  {
    id: 'ranigari-thota',
    area: 'Ranigari Thota / Tarapet Ghat',
    shortName: 'Ranigari Thota',
    pincode: '520013',
    lat: 16.4940,
    lng: 80.6370,
    landmark: 'Krishnaveni Ghat / NH-16 River Bridge',
    zone: 'South Riverside Zone'
  },
  {
    id: 'ajit-singh-nagar',
    area: 'Ajit Singh Nagar / Pipula Road',
    shortName: 'Ajit Singh Nagar',
    pincode: '520015',
    lat: 16.5440,
    lng: 80.6410,
    landmark: 'Singh Nagar Flyover / Pipula Road Rythu Bazaar',
    zone: 'North Zone'
  },
  {
    id: 'payakapuram',
    area: 'Payakapuram / Kandrika',
    shortName: 'Payakapuram',
    pincode: '520015',
    lat: 16.5580,
    lng: 80.6480,
    landmark: 'Prakash Nagar / Water Tank / Nunna Road',
    zone: 'North Zone'
  },
  {
    id: 'gannavaram',
    area: 'Gannavaram / Vijayawada Airport',
    shortName: 'Gannavaram',
    pincode: '521101',
    lat: 16.5410,
    lng: 80.7980,
    landmark: 'Vijayawada International Airport / NH-16',
    zone: 'Airport Corridor'
  },
  {
    id: 'kesarapalli',
    area: 'Kesarapalli / IT SEZ',
    shortName: 'Kesarapalli',
    pincode: '521102',
    lat: 16.5290,
    lng: 80.7810,
    landmark: 'HCL Technologies / Medha IT Tower',
    zone: 'Airport Corridor'
  },
  {
    id: 'ramavarappadu',
    area: 'Ramavarappadu Ring Road',
    shortName: 'Ramavarappadu',
    pincode: '521108',
    lat: 16.5230,
    lng: 80.6810,
    landmark: 'Ramavarappadu Ring / NH-16 / Inner Ring Road',
    zone: 'East Junction Zone'
  },
  {
    id: 'prasadampadu',
    area: 'Prasadampadu / Enikepadu',
    shortName: 'Prasadampadu',
    pincode: '521108',
    lat: 16.5190,
    lng: 80.6970,
    landmark: 'Enikepadu NH-16 Highway / Currency Nagar Ext.',
    zone: 'East Junction Zone'
  },
  {
    id: 'poranki',
    area: 'Poranki / Penamaluru Center',
    shortName: 'Poranki',
    pincode: '521137',
    lat: 16.4780,
    lng: 80.7090,
    landmark: 'Bandar Road / Penamaluru Police Station',
    zone: 'South East Rural Zone'
  },
  {
    id: 'tadigadapa',
    area: 'Tadigadapa / 100ft Road',
    shortName: 'Tadigadapa',
    pincode: '521137',
    lat: 16.4820,
    lng: 80.6990,
    landmark: 'Don Bosco School / Tadigadapa Donka Road',
    zone: 'South East Rural Zone'
  },
  {
    id: 'kankipadu',
    area: 'Kankipadu / Punadipadu',
    shortName: 'Kankipadu',
    pincode: '521151',
    lat: 16.4350,
    lng: 80.7710,
    landmark: 'Kankipadu Main Bazaar / Veterinary Hospital',
    zone: 'Krishna Rural Delta'
  },
  {
    id: 'nunna',
    area: 'Nunna / Mango Market',
    shortName: 'Nunna',
    pincode: '521212',
    lat: 16.5840,
    lng: 80.6690,
    landmark: 'Asia Biggest Mango Market Yard / Outer Ring Road',
    zone: 'North Rural Zone'
  },
  {
    id: 'gollapudi',
    area: 'Gollapudi / Wholesale Market',
    shortName: 'Gollapudi',
    pincode: '521225',
    lat: 16.5510,
    lng: 80.5720,
    landmark: 'Gollapudi One Center / Bypass Flyover / Dairy Hub',
    zone: 'North West Corridor'
  },
  {
    id: 'kondapalli',
    area: 'Kondapalli / Fort & Industrial Estate',
    shortName: 'Kondapalli',
    pincode: '521228',
    lat: 16.6180,
    lng: 80.5380,
    landmark: 'Kondapalli Fort Foot / Industrial Development Area',
    zone: 'North West Industrial Zone'
  },
  {
    id: 'guntupalli',
    area: 'Guntupalli / Milk Chilling Center',
    shortName: 'Guntupalli',
    pincode: '521241',
    lat: 16.5740,
    lng: 80.5520,
    landmark: 'Vijaya Dairy Chilling Center / Railway Wagon Workshop',
    zone: 'North West Corridor'
  },
  {
    id: 'ibrahimpatnam',
    area: 'Ibrahimpatnam / Ferry / VTPS',
    shortName: 'Ibrahimpatnam',
    pincode: '521456',
    lat: 16.5870,
    lng: 80.5180,
    landmark: 'Dr. NTTPS Thermal Station / Ferry Ghat Krishna River',
    zone: 'West Outer Corridor'
  },
  {
    id: 'tadepalli',
    area: 'Tadepalli / Undavalli',
    shortName: 'Tadepalli',
    pincode: '522501',
    lat: 16.4890,
    lng: 80.6120,
    landmark: 'Undavalli Caves / Buckingham Canal / Seethanagaram',
    zone: 'South Riverfront Capital Zone'
  },
  {
    id: 'mangalagiri',
    area: 'Mangalagiri / AIIMS / Panakala Swamy',
    shortName: 'Mangalagiri',
    pincode: '522503',
    lat: 16.4350,
    lng: 80.5690,
    landmark: 'AIIMS Mangalagiri / Panakala Lakshmi Narasimha Temple',
    zone: 'Capital City Hub'
  }
];

// List of all unique pincodes sorted numerically
export const VIJAYAWADA_PINCODES = [
  ...new Set(VIJAYAWADA_LOCATIONS.map(l => l.pincode))
].sort((a, b) => Number(a) - Number(b));

// Map of Pincodes to primary area descriptions
export const PINCODE_DESCRIPTIONS = {
  '520001': '520001 - One Town, Kothapet, Vinchipet',
  '520002': '520002 - Governorpet, Suryaraopet',
  '520003': '520003 - Gandhi Nagar, Ayodhya Nagar',
  '520004': '520004 - Gunadala, Machavaram',
  '520007': '520007 - Auto Nagar, Kanuru, Ashok Nagar',
  '520008': '520008 - Currency Nagar, Loyola College Area',
  '520010': '520010 - Benz Circle, Patamata, Labbipet, Moghalrajpuram',
  '520011': '520011 - Satyanarayanapuram, Madhuranagar',
  '520012': '520012 - Bhavanipuram, Vidyadharapuram, Jakkampudi',
  '520013': '520013 - Krishna Lanka, Ranigari Thota',
  '520015': '520015 - Ajit Singh Nagar, Payakapuram',
  '521101': '521101 - Gannavaram, Airport Area',
  '521102': '521102 - Kesarapalli, IT SEZ',
  '521108': '521108 - Ramavarappadu, Prasadampadu',
  '521137': '521137 - Poranki, Tadigadapa, Penamaluru',
  '521151': '521151 - Kankipadu, Punadipadu',
  '521212': '521212 - Nunna, Mango Market Yard',
  '521225': '521225 - Gollapudi, One Center',
  '521228': '521228 - Kondapalli, Fort & IDA',
  '521241': '521241 - Guntupalli, Dairy Hub',
  '521456': '521456 - Ibrahimpatnam, Ferry, VTPS',
  '522501': '522501 - Tadepalli, Undavalli Caves',
  '522503': '522503 - Mangalagiri, AIIMS'
};

// Filter areas by selected pincode (or return all if no pincode selected)
export function getAreasByPincode(pincode) {
  if (!pincode) return VIJAYAWADA_LOCATIONS;
  return VIJAYAWADA_LOCATIONS.filter(item => item.pincode === pincode);
}

// Find single location entry by ID or text match
export function findLocation(identifier) {
  if (!identifier) return null;
  const target = String(identifier).trim().toLowerCase();
  return VIJAYAWADA_LOCATIONS.find(item => 
    item.id === target ||
    item.shortName.toLowerCase() === target ||
    item.area.toLowerCase() === target ||
    item.area.toLowerCase().includes(target)
  ) || null;
}
