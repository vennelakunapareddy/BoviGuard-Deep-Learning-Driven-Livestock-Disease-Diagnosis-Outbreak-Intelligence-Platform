/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          dark: '#f8fafc',       // Soft slate background
          card: '#ffffff',       // White card background
          primary: '#10b981',    // Emerald 500
          primaryDark: '#047857',// Emerald 700
          secondary: '#064e3b',  // Emerald 900
          accent: '#f59e0b',     // Amber accent
          text: '#0f172a',       // Slate 900 text
          muted: '#475569'       // Slate 600 muted text
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'scale(1.03)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        }
      },
      animation: {
        fadeIn: 'fadeIn 0.8s ease-out forwards',
        slideUp: 'slideUp 0.5s ease-out forwards',
      }
    },
  },
  plugins: [],
}
