import os
import glob

for split in ['train', 'valid', 'test']:
    p = os.path.join('buffalo_dataset', split)
    if os.path.exists(p):
        print(f"=== {split.upper()} ===")
        classes = sorted([d for d in os.listdir(p) if os.path.isdir(os.path.join(p, d))])
        print("Classes:", classes)
        for c in classes:
            files = [f for f in os.listdir(os.path.join(p, c)) if not f.startswith('.')]
            print(f"  {c}: {len(files)} files. First 3: {files[:3]}")
