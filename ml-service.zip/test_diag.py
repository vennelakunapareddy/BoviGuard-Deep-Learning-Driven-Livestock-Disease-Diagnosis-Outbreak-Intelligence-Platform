import os
import glob
from PIL import Image
from model import BuffaloDiseaseModel, DEFAULT_CLASSES

m = BuffaloDiseaseModel()

# Test Mastitis images
print("--- TESTING MASTITIS IMAGES ---")
mastitis_imgs = glob.glob("real_world_holdout/Mastitis/**", recursive=True)
mastitis_imgs = [f for f in mastitis_imgs if os.path.isfile(f) and f.lower().endswith(('.jpg','.jpeg','.png'))]
for p in mastitis_imgs[:8]:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:30s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | Probs: {res['probabilities']}")

print("\n--- TESTING LUMPY IMAGES ---")
lumpy_imgs = glob.glob("real_world_holdout/lumpy/**", recursive=True)
lumpy_imgs = [f for f in lumpy_imgs if os.path.isfile(f) and f.lower().endswith(('.jpg','.jpeg','.png'))]
for p in lumpy_imgs[:5]:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:30s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | Probs: {res['probabilities']}")
