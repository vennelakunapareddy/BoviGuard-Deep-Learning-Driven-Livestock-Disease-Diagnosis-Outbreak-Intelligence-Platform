import torch
import torch.nn.functional as F
from torchvision import models
from PIL import Image
import glob
import os

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transform = weights.transforms()

def test_img(path, name):
    if not os.path.exists(path):
        print(f"File not found: {path}")
        return
    img = Image.open(path).convert("RGB")
    t = transform(img).unsqueeze(0)
    with torch.no_grad():
        logits = model(t)
        probs = F.softmax(logits, dim=-1).squeeze(0)
    top5_p, top5_idx = torch.topk(probs, 5)
    print(f"=== {name} ===")
    for p, idx in zip(top5_p, top5_idx):
        print(f"  {categories[int(idx)]}: {float(p)*100:.2f}%")

test_img(r"C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png", "C++ Code Screenshot")
test_img("crop_udder_user.png", "User Uploaded Udder Photo")
test_img("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis Teat Screenshot")
test_img("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "Lumpy Skin Sample")
test_img("real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg", "Healthy Buffalo Full Body")
test_img("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "China Temple")
test_img("venv/Lib/site-packages/sklearn/datasets/images/flower.jpg", "Flower")
