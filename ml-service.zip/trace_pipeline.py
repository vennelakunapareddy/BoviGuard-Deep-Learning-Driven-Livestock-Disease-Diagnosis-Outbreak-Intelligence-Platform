import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image
import os

# 1. Load Checkpoint Metadata
ckpt_path = "buffalo_model.pth"
ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)

print("=" * 70)
print("1. CHECKPOINT METADATA:")
print("  Architecture:", ckpt.get("architecture"))
print("  Classes:", ckpt.get("classes"))
print("  Num Classes:", ckpt.get("num_classes"))
print("  Image Size:", ckpt.get("image_size"))
print("  Norm Mean:", ckpt.get("norm_mean"))
print("  Norm Std:", ckpt.get("norm_std"))
print("  Best Test Acc:", ckpt.get("best_test_acc"))

# 2. Build Model Architecture
classes = ckpt.get("classes", ["Foot_and_Mouth_Disease", "Healthy_Buffalo", "Lumpy_Skin_Disease", "Mastitis"])
model = models.efficientnet_b0(weights=None)
in_features = model.classifier[1].in_features
model.classifier = nn.Sequential(
    nn.Dropout(p=0.2),
    nn.Linear(in_features, 512),
    nn.BatchNorm1d(512),
    nn.SiLU(),
    nn.Dropout(p=0.15),
    nn.Linear(512, 4),
)
state_dict = ckpt["model_state_dict"]
model.load_state_dict(state_dict)
model.eval()

# 3. Preprocessing
img_size = ckpt.get("image_size", (240, 240))
norm_mean = ckpt.get("norm_mean", [0.485, 0.456, 0.406])
norm_std = ckpt.get("norm_std", [0.229, 0.224, 0.225])

preprocess_240 = transforms.Compose([
    transforms.Resize(img_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=norm_mean, std=norm_std),
])

preprocess_224 = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# 4. Test Images
test_files = [
    ("crop_udder_user.png", "User Uploaded Udder Photo"),
    (r"C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png", "User C++ Code Screenshot"),
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis Teat Screenshot"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "Lumpy Skin Sample"),
    ("real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg", "Healthy Buffalo Sample")
]

for p, label in test_files:
    if os.path.exists(p):
        print("\n" + "=" * 70)
        print(f"TESTING IMAGE: {label} ({p})")
        img = Image.open(p).convert("RGB")
        
        # Test with 240x240
        t_240 = preprocess_240(img).unsqueeze(0)
        with torch.no_grad():
            logits_240 = model(t_240).squeeze(0)
            probs_240 = F.softmax(logits_240, dim=-1).numpy()
            
        print("--- Model Inference (240x240, Eval Mode, No Grad) ---")
        print("  Raw Logits: ", [round(float(x), 4) for x in logits_240])
        for idx, c in enumerate(classes):
            print(f"    Class {idx} [{c:24s}]: Logit={logits_240[idx]:.4f} | Prob={probs_240[idx]*100:.2f}%")
        pred_idx = int(torch.argmax(logits_240).item())
        print(f"  --> Top-1: Class {pred_idx} = {classes[pred_idx]} ({probs_240[pred_idx]*100:.2f}%)")

        # Test with 224x224
        t_224 = preprocess_224(img).unsqueeze(0)
        with torch.no_grad():
            logits_224 = model(t_224).squeeze(0)
            probs_224 = F.softmax(logits_224, dim=-1).numpy()
        pred_idx_224 = int(torch.argmax(logits_224).item())
        print(f"  --> Top-1 (224x224): Class {pred_idx_224} = {classes[pred_idx_224]} ({probs_224[pred_idx_224]*100:.2f}%)")
