import glob, os, torch, re
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

def inspect_gate_fixed(img, gate):
    w, h = img.size
    img_area = w * h
    
    # det
    det_t = gate.det_transform(img).unsqueeze(0)
    with torch.no_grad():
        preds = gate.detector(det_t)[0]
    det_objs = [{'label': gate.coco_classes[int(l)], 'score': float(s)} for l, s in zip(preds['labels'], preds['scores']) if s > 0.32]
    
    # cls
    cls_t = gate.cls_transform(img).unsqueeze(0)
    with torch.no_grad():
        logits = gate.classifier(cls_t)
        probs = torch.softmax(logits, dim=-1).squeeze(0)
        feat_emb = F.normalize(gate.classifier.features(cls_t).mean([2, 3]).squeeze(0), p=2, dim=0)
        
    top5_p, top5_idx = torch.topk(probs, 5)
    top1_idx = int(top5_idx[0].item())
    top1_cat = gate.imagenet_classes[top1_idx].lower()
    top1_prob = float(top5_p[0]) * 100
    
    sims = torch.mv(gate.bank_embeddings, feat_emb)
    max_sim = float(torch.topk(sims, 1)[0][0])
    
    bovine_objs = [o for o in det_objs if o['label'] == 'cow']
    person_objs = [o for o in det_objs if o['label'] == 'person']
    dog_objs = [o for o in det_objs if o['label'] == 'dog']
    cat_objs = [o for o in det_objs if o['label'] == 'cat']
    bird_objs = [o for o in det_objs if o['label'] == 'bird']
    other_animal_objs = [o for o in det_objs if o['label'] in {'sheep', 'horse', 'elephant', 'bear', 'zebra', 'giraffe'}]
    vehicle_objs = [o for o in det_objs if o['label'] in {'car', 'truck', 'bus', 'motorcycle', 'bicycle', 'airplane', 'boat', 'train'}]
    
    has_buffalo_cls = any(i in {346, 347, 690} for i in [int(x.item()) for x in top5_idx]) or (345 in [int(x.item()) for x in top5_idx] and float(probs[345]) > 0.08)
    
    # 5A Other animals (sheep, goat, bear etc.)
    if other_animal_objs:
        if not has_buffalo_cls and not bovine_objs and max_sim < 0.52:
            top_o = max(other_animal_objs, key=lambda x: x['score'])
            return False, f"Other Animal ({top_o['label']})"
            
    if dog_objs and not has_buffalo_cls and max_sim < 0.50:
        return False, 'Dog'
    if cat_objs and not has_buffalo_cls and max_sim < 0.50:
        return False, 'Cat'
    if bird_objs and not has_buffalo_cls and max_sim < 0.50:
        return False, 'Bird'
    if vehicle_objs and not has_buffalo_cls and max_sim < 0.50:
        return False, 'Vehicle'
    if person_objs and not has_buffalo_cls and not bovine_objs and max_sim < 0.50:
        return False, 'Human'
        
    # ImageNet checks
    if top1_idx in gate.canine_indices and top1_prob > 15.0 and max_sim < 0.48:
        return False, 'Dog (ImageNet)'
    if top1_idx in gate.feline_indices and top1_prob > 12.0 and max_sim < 0.48:
        return False, 'Cat (ImageNet)'
    if top1_idx in gate.bird_indices and top1_prob > 12.0 and max_sim < 0.48:
        return False, 'Bird (ImageNet)'
        
    # Vehicle check without oxcart bug:
    if top1_idx not in {345, 346, 347, 690} and 'oxcart' not in top1_cat:
        veh_words = ['automobile', 'sports car', 'truck', 'cab', 'van', 'jeep', 'bus', 'bicycle', 'motorcycle', 'airplane', 'boat']
        is_v = (top1_idx in gate.vehicle_indices and top1_prob > 12.0) or any(k in top1_cat for k in veh_words) or any(w in top1_cat.split() for w in ['car', 'cars'])
        if is_v and max_sim < 0.50:
            return False, f'Vehicle ({top1_cat})'
            
    # Other mammal ImageNet check
    total_bovine = sum(float(probs[i]) for i in {345, 346, 347, 690}) * 100
    if ((top1_idx in gate.other_mammal_indices and top1_prob > 15.0) or (sum(float(probs[i]) for i in gate.other_mammal_indices)*100 > 25.0 and total_bovine < 5.0)) and max_sim < 0.52:
        if not has_buffalo_cls and not bovine_objs:
            return False, f'Non-Buffalo Animal ({top1_cat})'
            
    if bovine_objs:
        if has_buffalo_cls or max_sim >= 0.52:
            return True, 'Water Buffalo / Bovine'
        else:
            return False, 'Cow / Non-Buffalo Bovine'
            
    if has_buffalo_cls or max_sim >= 0.50:
        return True, 'Water Buffalo'
        
    return False, f'Non-Buffalo ({top1_cat})'

from model import RobustBuffaloValidationGate
gate = RobustBuffaloValidationGate('cpu')

print('--- Testing Non-Buffalo with Fixed Gate ---')
for p in ['../test_human.jpg', '../test_car.jpg', '../test_cat.jpg', '../test_dog.jpg', '../test_hen.jpg', '../unseen_cow.jpg', '../unseen_goat.jpg']:
    ok, reason = inspect_gate_fixed(Image.open(p), gate)
    print(f'{os.path.basename(p):20s} -> is_buffalo: {str(ok):5s} ({reason})')

print('\n--- Testing LSD 101, 102, 103, 104 with Fixed Gate ---')
for f in ['Lumpy_Skin_101.png', 'Lumpy_Skin_102.png', 'Lumpy_Skin_103.png', 'Lumpy_Skin_104.png']:
    p = f'real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/{f}'
    ok, reason = inspect_gate_fixed(Image.open(p), gate)
    print(f'{f:20s} -> is_buffalo: {str(ok):5s} ({reason})')
