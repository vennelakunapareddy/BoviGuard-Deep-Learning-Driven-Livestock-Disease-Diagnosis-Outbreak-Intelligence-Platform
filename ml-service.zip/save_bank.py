import os
import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
feature_extractor = models.mobilenet_v2(weights=weights).eval()
feature_extractor.classifier = torch.nn.Identity()
transform = weights.transforms()

def get_emb(img):
    t = transform(img.convert("RGB")).unsqueeze(0)
    with torch.no_grad():
        emb = F.normalize(feature_extractor(t).squeeze(0), p=2, dim=0)
    return emb

print("Building exemplar bank from buffalo_dataset/train...")
bank_embs = []
bank_labels = []
bank_names = []

CLASSES = ["Foot_and_Mouth_Disease", "Healthy_Buffalo", "Lumpy_Skin_Disease", "Mastitis"]

for cname in CLASSES:
    folder = os.path.join("buffalo_dataset", "train", cname)
    imgs = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(('.jpg','.jpeg','.png','.webp'))]
    for p in imgs:
        bank_embs.append(get_emb(Image.open(p)))
        bank_labels.append(cname)
        bank_names.append(os.path.basename(p))

bank_tensor = torch.stack(bank_embs)
torch.save({
    "embeddings": bank_tensor,
    "labels": bank_labels,
    "classes": CLASSES
}, "exemplar_bank.pt")

print(f"[SUCCESS] Exemplar bank with {len(bank_labels)} samples saved to exemplar_bank.pt!")
