import os
import io
import json
import base64
import uvicorn
from fastapi import FastAPI, File, UploadFile, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from PIL import Image
from typing import List, Optional, Dict, Any

from model import BuffaloDiseaseModel, CLASS_NAMES, DEFAULT_CLASSES, DISEASE_DETAILS, CLASS_DISPLAY

app = FastAPI(title="BoviGuard: Deep Learning-Driven Livestock Disease Diagnosis & Outbreak Intelligence", version="4.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_FILE = os.path.join(BASE_DIR, "buffalo_model.pth")
disease_model = BuffaloDiseaseModel(model_path=MODEL_FILE if os.path.exists(MODEL_FILE) else None)

class PredictionResponse(BaseModel):
    requestId: Optional[str] = None
    success: bool = True
    is_buffalo: bool = True
    isBuffalo: bool = True
    predicted_index: Optional[int] = None
    predicted_class: Optional[str] = None
    prediction: Optional[str] = None
    disease_key: Optional[str] = None
    diseasePrediction: Optional[str] = None
    confidence: float = 0.0
    confidenceScore: Optional[float] = 0.0
    status: str = "confident"
    message: str = "Buffalo health analysis complete."
    entityType: Optional[str] = "Buffalo"
    predictedSubject: Optional[str] = "Water Buffalo"
    detectedEntityIcon: Optional[str] = "🐃"
    severity: Optional[str] = None
    symptoms: Optional[List[str]] = None
    precautions: Optional[List[str]] = None
    recommendations: Optional[List[str]] = None
    immediateAction: Optional[str] = None
    vetAttentionRecommended: Optional[bool] = True
    disclaimer: Optional[str] = "AI-assisted clinical decision support — confirm with licensed veterinary examination."
    raw_logits: Optional[List[float]] = None
    probabilities: Optional[Dict[str, float]] = None
    allProbabilities: Optional[List[Dict[str, Any]]] = None
    top3: Optional[List[Dict[str, Any]]] = None
    model_version: Optional[str] = "4.0-Unbiased-4Class-CNN"
    isUnbiased: Optional[bool] = True
    baselinePriorPerClass: Optional[float] = 25.0
    priorDistribution: Optional[Dict[str, float]] = None

@app.post("/predict", response_model=PredictionResponse)
async def predict_single(
    request: Request,
    image: Optional[UploadFile] = File(None),
    file: Optional[UploadFile] = File(None),
    requestId: Optional[str] = Form(None),
    symptoms: Optional[str] = Form(None),
    imageBase64: Optional[str] = Form(None)
):
    try:
        contents = None
        pil_image = None
        req_id = requestId

        target_file = image or file
        if target_file:
            contents = await target_file.read()
            if contents:
                pil_image = Image.open(io.BytesIO(contents)).convert("RGB")
        elif imageBase64:
            clean_b64 = imageBase64.split(",")[-1]
            contents = base64.b64decode(clean_b64)
            pil_image = Image.open(io.BytesIO(contents)).convert("RGB")
        else:
            # Check for application/json payload
            content_type = request.headers.get("content-type", "")
            if "application/json" in content_type:
                try:
                    body = await request.json()
                    b64 = body.get("imageBase64") or body.get("image") or body.get("image_base64")
                    if b64:
                        clean_b64 = b64.split(",")[-1]
                        contents = base64.b64decode(clean_b64)
                        pil_image = Image.open(io.BytesIO(contents)).convert("RGB")
                    req_id = req_id or body.get("requestId")
                except Exception:
                    pass

        if pil_image is None:
            return JSONResponse(
                status_code=400,
                content={"success": False, "error": "No image or file field provided. Send multipart 'file'/'image' or JSON 'imageBase64'."}
            )

        res = disease_model.predict_detailed(pil_image)
        res["requestId"] = req_id or f"req_{int(io.BytesIO(contents).getbuffer().nbytes if contents else 12345)}"
        return JSONResponse(content=res)
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "error": str(e),
                "message": f"Failed to analyze image: {e}"
            }
        )

@app.post("/predict/multi")
async def predict_multi(images: List[UploadFile] = File(...)):
    results = []
    for img_file in images:
        try:
            contents = await img_file.read()
            pil_image = Image.open(io.BytesIO(contents)).convert("RGB")
            res = disease_model.predict_detailed(pil_image)
            res["filename"] = img_file.filename
            results.append(res)
        except Exception as e:
            results.append({"filename": img_file.filename, "error": str(e)})
    return JSONResponse(content={"results": results, "count": len(results)})

@app.post("/predict/debug")
async def predict_debug(image: UploadFile = File(...)):
    try:
        contents = await image.read()
        pil_image = Image.open(io.BytesIO(contents)).convert("RGB")
        res = disease_model.predict_detailed(pil_image)
        res["image_dimensions"] = pil_image.size
        res["device"] = str(disease_model.device)
        res["model_loaded"] = disease_model.loaded
        return JSONResponse(content=res)
    except Exception as e:
        return JSONResponse(status_code=400, content={"error": str(e)})

@app.get("/metrics")
async def get_metrics():
    metrics_file = os.path.join(BASE_DIR, "metrics.json")
    if os.path.exists(metrics_file):
        try:
            with open(metrics_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            return {"error": f"Failed to read metrics: {e}"}
    return {
        "status": "unbiased_4class_ready",
        "model_version": disease_model.MODEL_VERSION,
        "classes": disease_model.class_names,
        "prior_per_class": 25.0
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "ml-service",
        "model_version": disease_model.MODEL_VERSION,
        "classes": disease_model.class_names,
        "classes_count": disease_model.num_classes,
        "is_unbiased": True,
        "prior_per_class": 25.0,
        "device": str(disease_model.device),
        "checkpoint_loaded": disease_model.loaded
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5000)
