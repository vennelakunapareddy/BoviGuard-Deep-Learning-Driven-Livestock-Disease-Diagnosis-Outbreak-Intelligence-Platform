import test_entity_detector as ted
from PIL import Image
import glob
import os

print("--- TESTING FMD SAMPLES ---")
for p in glob.glob("real_world_holdout/fmd/**", recursive=True):
    if os.path.isfile(p) and p.lower().endswith(('.jpg','.jpeg','.png')):
        res = ted.detect_subject(Image.open(p))
        print(os.path.basename(p)[:30], "Top1:", res["top1_category"], f"({res['top1_prob']}%)", "Bovine:", f"{res['bovine_prob']}%", "Livestock:", f"{res['livestock_prob']}%")
        break

print("\n--- TESTING LUMPY SAMPLES ---")
for p in glob.glob("real_world_holdout/lumpy/**", recursive=True):
    if os.path.isfile(p) and p.lower().endswith(('.jpg','.jpeg','.png')):
        res = ted.detect_subject(Image.open(p))
        print(os.path.basename(p)[:30], "Top1:", res["top1_category"], f"({res['top1_prob']}%)", "Bovine:", f"{res['bovine_prob']}%", "Livestock:", f"{res['livestock_prob']}%")
        break

print("\n--- TESTING MASTITIS SAMPLES ---")
for p in glob.glob("real_world_holdout/Mastitis/**", recursive=True):
    if os.path.isfile(p) and p.lower().endswith(('.jpg','.jpeg','.png')):
        res = ted.detect_subject(Image.open(p))
        print(os.path.basename(p)[:30], "Top1:", res["top1_category"], f"({res['top1_prob']}%)", "Bovine:", f"{res['bovine_prob']}%", "Livestock:", f"{res['livestock_prob']}%")
        break
