import urllib.request
import json
import os

def post_multipart(url, filepath):
    boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
    fn = os.path.basename(filepath)
    with open(filepath, "rb") as f:
        file_bytes = f.read()
    
    body = bytearray()
    body.extend(f"--{boundary}\r\n".encode("utf-8"))
    body.extend(f'Content-Disposition: form-data; name="image"; filename="{fn}"\r\n'.encode("utf-8"))
    body.extend(b"Content-Type: image/jpeg\r\n\r\n")
    body.extend(file_bytes)
    body.extend(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    
    req = urllib.request.Request(url, data=bytes(body))
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))

print("\n" + "=" * 75)
print("TESTING PORT 3000 EXPRESS BACKEND PREDICT ENDPOINT")
print("=" * 75)

for p in [
    "../test_human.jpg",
    "../test_car.jpg",
    "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png",
    "real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_101.png",
    "real_world_holdout/healthy buffalo/buffalo/murrah/130_Murrah_Buffalo_Stock_Photos_.jpg",
]:
    res = post_multipart("http://127.0.0.1:3000/api/cases/predict", p)
    print(f"{os.path.basename(p):35s} -> isBuffalo: {str(res.get('isBuffalo')):5s} | Pred: {str(res.get('prediction')):30s} | Conf: {res.get('confidenceScore')}%")
