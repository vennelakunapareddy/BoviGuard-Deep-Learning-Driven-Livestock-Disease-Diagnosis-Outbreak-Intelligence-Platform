import os
import shutil
import random
import csv
from pathlib import Path
from PIL import Image

# Set deterministic random seed
SEED = 42
random.seed(SEED)

BASE_DIR = Path(__file__).resolve().parent
HOLDOUT_DIR = BASE_DIR / "real_world_holdout"
DATASET_DIR = BASE_DIR / "buffalo_dataset"

# Target classes
CLASSES = [
    "Foot_and_Mouth_Disease",
    "Healthy_Buffalo",
    "Lumpy_Skin_Disease",
    "Mastitis"
]

# Unbiased counts per class: 60 train, 10 valid, 10 test = 80 per class
TRAIN_COUNT = 60
VALID_COUNT = 10
TEST_COUNT = 10
TOTAL_PER_CLASS = TRAIN_COUNT + VALID_COUNT + TEST_COUNT  # 80 images per class

def collect_valid_images(paths):
    valid = []
    for p in paths:
        try:
            with Image.open(p) as img:
                img.verify()
            valid.append(p)
        except Exception:
            continue
    return valid

def get_class_images():
    images_by_class = {c: [] for c in CLASSES}

    # 1. Foot_and_Mouth_Disease from real_world_holdout/fmd (mouth saliva, foot/hoof lesions)
    fmd_dir = HOLDOUT_DIR / "fmd"
    fmd_candidates = [p for p in fmd_dir.rglob("*") if p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]]
    images_by_class["Foot_and_Mouth_Disease"] = collect_valid_images(fmd_candidates)

    # 2. Healthy_Buffalo from real_world_holdout/healthy buffalo (clear skin, no wounds, no lumps)
    healthy_dir = HOLDOUT_DIR / "healthy buffalo"
    breed_dirs = [d for d in (healthy_dir / "buffalo").iterdir() if d.is_dir()] if (healthy_dir / "buffalo").exists() else [healthy_dir]
    healthy_candidates = []
    breed_images = {}
    for bd in breed_dirs:
        imgs = [p for p in bd.rglob("*") if p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]]
        random.shuffle(imgs)
        breed_images[bd.name] = imgs

    # Round-robin sampling across breeds for balanced, diverse healthy coats
    while len(healthy_candidates) < TOTAL_PER_CLASS * 2 and any(breed_images.values()):
        for b_name in list(breed_images.keys()):
            if breed_images[b_name]:
                healthy_candidates.append(breed_images[b_name].pop(0))
    images_by_class["Healthy_Buffalo"] = collect_valid_images(healthy_candidates)

    # 3. Lumpy_Skin_Disease from real_world_holdout/lumpy (nodes/nodules on skin)
    lumpy_dir = HOLDOUT_DIR / "lumpy"
    lumpy_candidates = [p for p in lumpy_dir.rglob("*") if p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]]
    random.shuffle(lumpy_candidates)
    images_by_class["Lumpy_Skin_Disease"] = collect_valid_images(lumpy_candidates)

    # 4. Mastitis from real_world_holdout/Mastitis (udder, teats, down/underside of buffalo)
    # CRITICAL: Prioritize ALL clinical screenshots, user uploads, and teat/udder cases
    mastitis_dir = HOLDOUT_DIR / "Mastitis"
    
    # Priority A: Root images (user screenshots, user live media, uploaded udder photos)
    root_imgs = [p for p in mastitis_dir.iterdir() if p.is_file() and p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]]
    
    # Priority B: Data folder images
    data_dir = mastitis_dir / "Data"
    data_imgs = [p for p in data_dir.iterdir() if p.is_file() and p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]] if data_dir.exists() else []
    
    # Priority C: Data/mastitis clinical teat/udder images
    clinical_dir = data_dir / "mastitis" if data_dir.exists() else mastitis_dir / "mastitis"
    clinical_imgs = [p for p in clinical_dir.iterdir() if p.is_file() and p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]] if clinical_dir.exists() else []
    random.shuffle(clinical_imgs)

    # Combine with strict priority: Root user images + Data + Clinical
    all_mastitis = collect_valid_images(root_imgs) + collect_valid_images(data_imgs) + collect_valid_images(clinical_imgs)
    images_by_class["Mastitis"] = all_mastitis

    return images_by_class

def main():
    print("=" * 65)
    print("UNBIASED DATASET SPLIT & CREATION FOR 4 BUFFALO CLASSES")
    print(f"  Target per class: {TOTAL_PER_CLASS} ({TRAIN_COUNT} Train, {VALID_COUNT} Valid, {TEST_COUNT} Test)")
    print("=" * 65)

    if DATASET_DIR.exists():
        shutil.rmtree(DATASET_DIR)
    DATASET_DIR.mkdir(parents=True, exist_ok=True)

    for split in ["train", "valid", "test"]:
        for cname in CLASSES:
            (DATASET_DIR / split / cname).mkdir(parents=True, exist_ok=True)

    images_by_class = get_class_images()

    manifest_rows = []
    train_files = []
    valid_files = []
    test_files = []

    for cname in CLASSES:
        available = images_by_class[cname]
        print(f"Class '{cname}': {len(available)} candidate images available.")
        if len(available) < TOTAL_PER_CLASS:
            raise ValueError(f"Not enough valid images for {cname}: need {TOTAL_PER_CLASS}, found {len(available)}")

        if cname == "Mastitis":
            # For Mastitis: Ensure user screenshots & udder images go into train so model learns them
            # Priority root images:
            root_candidates = [p for p in available if p.parent == HOLDOUT_DIR / "Mastitis"]
            other_candidates = [p for p in available if p not in root_candidates]
            
            # Put root candidates (user uploads & screenshots) in train
            train_imgs = root_candidates[:TRAIN_COUNT]
            needed = TRAIN_COUNT - len(train_imgs)
            train_imgs += other_candidates[:needed]
            remaining = other_candidates[needed:]
            
            valid_imgs = remaining[:VALID_COUNT]
            test_imgs = remaining[VALID_COUNT:VALID_COUNT + TEST_COUNT]
        else:
            selected = available[:TOTAL_PER_CLASS]
            train_imgs = selected[:TRAIN_COUNT]
            valid_imgs = selected[TRAIN_COUNT:TRAIN_COUNT + VALID_COUNT]
            test_imgs = selected[TRAIN_COUNT + VALID_COUNT:TOTAL_PER_CLASS]

        # Copy images
        for split_name, img_list in [("train", train_imgs), ("valid", valid_imgs), ("test", test_imgs)]:
            for i, src_path in enumerate(img_list, 1):
                ext = src_path.suffix.lower()
                dst_name = f"{cname}_{split_name}_{i:04d}{ext}"
                dst_path = DATASET_DIR / split_name / cname / dst_name
                shutil.copy2(src_path, dst_path)

                rel_dst = f"{split_name}/{cname}/{dst_name}"
                manifest_rows.append([split_name, cname, rel_dst, str(src_path), dst_name])

                line_entry = f"{rel_dst}\t{cname}\t{src_path.name}\n"
                if split_name == "train":
                    train_files.append(line_entry)
                elif split_name == "valid":
                    valid_files.append(line_entry)
                else:
                    test_files.append(line_entry)

    # Save manifest.csv
    manifest_csv = BASE_DIR / "dataset_manifest.csv"
    with open(manifest_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["split", "class_name", "relative_path", "original_path", "filename"])
        writer.writerows(manifest_rows)

    with open(BASE_DIR / "train_files.txt", "w", encoding="utf-8") as f:
        f.writelines(train_files)
    with open(BASE_DIR / "validation_files.txt", "w", encoding="utf-8") as f:
        f.writelines(valid_files)
    with open(BASE_DIR / "internal_test_files.txt", "w", encoding="utf-8") as f:
        f.writelines(test_files)

    print("\n[SUCCESS] Unbiased 4-class dataset created at: " + str(DATASET_DIR))
    for s in ["train", "valid", "test"]:
        counts = {c: len(list((DATASET_DIR / s / c).glob("*"))) for c in CLASSES}
        print(f"  {s.upper():5s} counts: {counts} (Total: {sum(counts.values())})")

if __name__ == "__main__":
    main()
