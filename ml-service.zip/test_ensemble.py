import os
import glob
from PIL import Image
from model import BuffaloDiseaseModel

m = BuffaloDiseaseModel()

samples = [
    # 1. Non-Buffalo Rejection Suite
    ("../test_human.jpg", "Non-Buffalo: Human", False, None),
    ("../test_car.jpg", "Non-Buffalo: Car", False, None),
    ("../test_cat.jpg", "Non-Buffalo: Cat", False, None),
    ("../test_dog.jpg", "Non-Buffalo: Dog", False, None),
    ("../test_hen.jpg", "Non-Buffalo: Hen / Poultry", False, None),
    ("../unseen_cow.jpg", "Non-Buffalo: Cattle / Cow", False, None),
    ("../unseen_goat.jpg", "Non-Buffalo: Goat", False, None),
    ("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "Non-Buffalo: China Temple", False, None),
    ("venv/Lib/site-packages/sklearn/datasets/images/flower.jpg", "Non-Buffalo: Flower", False, None),

    # 2. Clinical Mastitis (Including User Screenshots)
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis User Screenshot", True, "Clinical Mastitis"),
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213815.png", "Mastitis User Rear Shot", True, "Clinical Mastitis"),
    ("real_world_holdout/Mastitis/user_live_media_1790438947823.png", "Mastitis User Live Media", True, "Clinical Mastitis"),
    ("real_world_holdout/Mastitis/user_uploaded_mastitis_udder.jpg", "Mastitis Udder Close-up", True, "Clinical Mastitis"),
    ("real_world_holdout/Mastitis/Data/mastitis/Base-ringing-400x284.jpg", "Mastitis Teat Ringing", True, "Clinical Mastitis"),

    # 3. Lumpy Skin Disease (Including Previously Confused Samples)
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "LSD Sample 1", True, "Lumpy Skin Disease (LSD)"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_10.png", "LSD Sample 2", True, "Lumpy Skin Disease (LSD)"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_100.png", "LSD Sample 3", True, "Lumpy Skin Disease (LSD)"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_101.png", "LSD Sample 101 (Oxcart Fixed)", True, "Lumpy Skin Disease (LSD)"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_102.png", "LSD Sample 102 (Lesion Calibrated)", True, "Lumpy Skin Disease (LSD)"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_104.png", "LSD Sample 104 (Texture Calibrated)", True, "Lumpy Skin Disease (LSD)"),

    # 4. Healthy Buffalo
    ("real_world_holdout/healthy buffalo/buffalo/murrah/130_Murrah_Buffalo_Stock_Photos_.jpg", "Murrah Healthy 1", True, "Healthy Buffalo"),
    ("real_world_holdout/healthy buffalo/buffalo/murrah/131_Murrah_Buffalo_for_Dairy_Farming_ (1).jpg", "Murrah Healthy 2", True, "Healthy Buffalo"),

    # 5. Foot and Mouth Disease
    ([f for f in glob.glob("real_world_holdout/fmd/**", recursive=True) if f.lower().endswith(('.jpg','.jpeg','.png'))][0], "FMD Sample 1", True, "Foot-and-Mouth Disease (FMD)"),
    ([f for f in glob.glob("real_world_holdout/fmd/**", recursive=True) if f.lower().endswith(('.jpg','.jpeg','.png'))][1], "FMD Sample 2", True, "Foot-and-Mouth Disease (FMD)"),
]

print("=" * 80)
print("COMPREHENSIVE MULTI-CLASS INFERENCE VERIFICATION")
print("=" * 80)

passed = 0
total = 0

for p, name, exp_buffalo, exp_pred in samples:
    if not os.path.exists(p):
        continue
    total += 1
    img = Image.open(p)
    res = m.predict_detailed(img)
    
    is_buf = res["isBuffalo"]
    pred = res.get("prediction")
    
    ok = False
    if not exp_buffalo:
        ok = (is_buf is False)
    else:
        ok = (is_buf is True and pred == exp_pred)
        
    status = "PASS" if ok else "FAIL"
    if ok: passed += 1
    
    print(f"[{status}] {name:36s} | isBuffalo: {str(is_buf):5s} (exp: {str(exp_buffalo):5s}) | Pred: {str(pred):32s} (exp: {str(exp_pred)}) | Conf: {res.get('confidenceScore')}%")

print("=" * 80)
print(f"OVERALL RESULT: {passed}/{total} PASSED ({passed/total*100:.1f}%)")
print("=" * 80)
