import numpy as np
from PIL import Image

def analyze_image(path):
    img = Image.open(path).convert("RGB").resize((128, 128))
    arr = np.array(img, dtype=float)
    r, g, b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
    
    # Calculate pinkish/reddish teat skin: high R, moderate G, lower B
    # Mastitis udder often has high red variance and localized bright pink/red areas
    red_diff = r - ((g + b) / 2.0)
    high_red = np.mean(red_diff > 25.0)
    
    # Aspect ratio & vertical texture (udders and hanging teats have strong vertical gradient)
    gy, gx = np.gradient(r)
    vert_dominance = np.mean(np.abs(gy)) / (np.mean(np.abs(gx)) + 1e-5)
    
    print(f"{path[:35]:35s} | high_red: {high_red:.3f} | vert_dom: {vert_dominance:.3f} | mean_R: {np.mean(r):.1f} | mean_B: {np.mean(b):.1f}")

analyze_image("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png")
analyze_image("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213815.png")
analyze_image("real_world_holdout/Mastitis/user_uploaded_mastitis_udder.jpg")
analyze_image("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png")
analyze_image("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_10.png")
analyze_image("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_100.png")
analyze_image("real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg")
