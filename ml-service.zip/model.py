import io
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image, ImageStat
import numpy as np

# ============================================================================
# CANONICAL 4-CLASS ORDERING (FROM TRAINING CHECKPOINT buffalo_model.pth)
# 0 = Foot_and_Mouth_Disease
# 1 = Healthy_Buffalo
# 2 = Lumpy_Skin_Disease
# 3 = Mastitis
# ============================================================================
DEFAULT_CLASSES = [
    "Foot_and_Mouth_Disease",
    "Healthy_Buffalo",
    "Lumpy_Skin_Disease",
    "Mastitis",
]
CLASS_NAMES = DEFAULT_CLASSES

CLASS_DISPLAY = {
    "Foot_and_Mouth_Disease": "Foot-and-Mouth Disease (FMD)",
    "Healthy_Buffalo": "Healthy Buffalo",
    "Lumpy_Skin_Disease": "Lumpy Skin Disease (LSD)",
    "Mastitis": "Clinical Mastitis",
}

DISEASE_DETAILS = {
    "Foot-and-Mouth Disease (FMD)": {
        "severity": "Critical",
        "category": "Spreadable (Epidemic Risk)",
        "symptoms": [
            "Blisters and vesicles on tongue, lips, gums, and hooves",
            "Profuse, ropy salivation and drooling",
            "Severe lameness and reluctance to stand",
            "High fever, shivering, and rapid weight loss"
        ],
        "precautions": [
            "Strictly quarantine infected buffalo immediately",
            "Apply potassium permanganate (1:1000) or 1% alum mouth wash",
            "Wash hooves with 4% sodium carbonate or mild antiseptic footbaths",
            "Halt all livestock movement and milk transport from farm"
        ],
        "immediate_action": "Isolate the animal immediately, notify municipal livestock officers, and disinfect all premises.",
        "vet_attention": True,
        "is_spreadable": True,
    },
    "Healthy Buffalo": {
        "severity": "Low",
        "category": "Healthy Baseline",
        "symptoms": [
            "Normal appetite and rumination (regular cud-chewing)",
            "Clear eyes, moist and cool muzzle",
            "Smooth, lustrous coat and supple skin",
            "Active, calm, and alert behavioral temperament"
        ],
        "precautions": [
            "Maintain routine bi-annual vaccination against FMD and HS",
            "Ensure continuous access to clean, potable drinking water",
            "Provide balanced dry and green fodder with mineral supplements",
            "Perform periodic deworming every 3 to 4 months"
        ],
        "immediate_action": "No medical intervention required. Continue routine daily herd management and hygienic housing.",
        "vet_attention": False,
        "is_spreadable": False,
    },
    "Lumpy Skin Disease (LSD)": {
        "severity": "High",
        "category": "Spreadable (Epidemic Risk)",
        "symptoms": [
            "Firm, circumscribed raised nodular skin lesions (2-5 cm)",
            "High fever, lethargy, and ocular/nasal discharges",
            "Swelling of superficial prescapular and precrural lymph nodes",
            "Secondary ulcerative skin lesions prone to fly strike"
        ],
        "precautions": [
            "Apply vector control using neem oil or cypermethrin sprays against flies and mosquitoes",
            "Isolate infected buffaloes in insect-proof netted sheds",
            "Apply topical povidone-iodine or antibiotic wound spray to burst nodules",
            "Feed easily digestible soft green fodder and electrolyte-fortified water"
        ],
        "immediate_action": "Isolate from herd to prevent arthropod transmission and request veterinary supportive therapy.",
        "vet_attention": True,
        "is_spreadable": True,
    },
    "Clinical Mastitis": {
        "severity": "Medium",
        "category": "Non-Spreadable (Localized/Environmental)",
        "symptoms": [
            "Swollen, hard, hot, or visibly painful udder quarters",
            "Abnormal milk containing clots, flakes, or watery serous fluid",
            "Marked reduction in daily milk yield",
            "Fever and systemic restlessness during milking"
        ],
        "precautions": [
            "Perform daily pre-milking strip cup inspection and California Mastitis Test (CMT)",
            "Wash and sanitize teats with warm chlorhexidine or iodine teat dips",
            "Ensure clean, dry bedding free of accumulated manure and moisture",
            "Milk affected quarters last and discard mastitic milk safely"
        ],
        "immediate_action": "Administer intramammary antibiotic infusion as prescribed by a veterinarian; apply cold compresses to relieve udder pain.",
        "vet_attention": True,
        "is_spreadable": False,
    }
}

# ImageNet Bovine Synset Categories (345: ox, 346: water buffalo, 347: bison, 690: oxcart)
BOVINE_CATEGORIES = {345, 346, 347, 690}

# ImageNet Non-Buffalo Category Sets
CANINE_INDICES = set(range(151, 276))  # 118 domestic dog breeds + wolves, coyotes, dingoes
FELINE_INDICES = set(range(281, 294))  # Domestic and wild felines
BIRD_INDICES = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147)))  # Birds & Poultry (hen, cock, etc.)
OTHER_MAMMAL_INDICES = set(list(range(294, 345)) + list(range(348, 385)))  # Non-bovine mammals (horse, pig, sheep, goat, etc.)
VEHICLE_INDICES = {403, 407, 436, 475, 479, 511, 627, 654, 670, 671, 751, 817, 864, 867, 895, 468, 555, 665, 705, 734, 779, 829}
DOCUMENT_SCREEN_INDICES = {916, 620, 664, 782, 487, 921, 446, 508, 526, 722, 687, 728, 517, 549, 650, 700, 767, 917, 704, 726, 744, 736, 791, 822}
BUILDING_INDICES = {497, 498, 538, 598, 652, 663, 678, 698, 706, 449, 749, 876}

class RobustBuffaloValidationGate:
    """
    Dual-Stage Robust Buffalo Validation Gate:
    Stage 1A: Statistical frame quality & contrast check (rejects blank, black, overexposed, extreme blur).
    Stage 1B: SSDLite320 Object Detector (COCO 91 classes) for macroscopic animals, humans, vehicles, objects.
    Stage 1C: MobileNet-V2 Classifier (ImageNet 1k) for fine-grained synsets (dog breeds, felines, poultry, other mammals, human attire, screens, buildings, objects).
    Stage 1D: Exemplar Bank Feature Similarity (cosine similarity against real buffalo health dataset embeddings)
              for distinguishing genuine buffalo tissue/lesions from non-buffalo images.
    """
    def __init__(self, device):
        self.device = device
        self.ready = False
        try:
            # 1. COCO Object Detector (SSDLite320)
            det_weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
            self.detector = ssdlite320_mobilenet_v3_large(weights=det_weights).to(self.device).eval()
            self.coco_classes = det_weights.meta["categories"]
            self.det_transform = det_weights.transforms()

            # 2. ImageNet Classifier (MobileNet-V2)
            cls_weights = models.MobileNet_V2_Weights.DEFAULT
            self.classifier = models.mobilenet_v2(weights=cls_weights).to(self.device).eval()
            self.imagenet_classes = cls_weights.meta["categories"]
            self.cls_transform = cls_weights.transforms()

            # 3. Exemplar Bank of true buffalo training embeddings (from exemplar_bank.pt)
            bank_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exemplar_bank.pt")
            if os.path.exists(bank_path):
                bank_data = torch.load(bank_path, map_location=self.device)
                self.bank_embeddings = bank_data["embeddings"].to(self.device)
                self.bank_labels = bank_data.get("labels", [])
            else:
                self.bank_embeddings = None
                self.bank_labels = []

            # Categories
            self.buffalo_categories = {346, 347, 690}  # 346: water buffalo, 347: bison, 690: oxcart
            self.canine_indices = set(range(151, 276))  # 118 domestic dog breeds
            self.feline_indices = set(range(281, 294))  # Cats
            self.bird_indices = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147)))  # Poultry & birds
            self.other_mammal_indices = set(list(range(294, 345)) + list(range(348, 385)))  # Non-bovine mammals (horse, pig, sheep, goat, bear, etc.)
            self.vehicle_indices = {403, 407, 436, 475, 479, 511, 627, 654, 670, 671, 751, 817, 864, 867, 895, 468, 555, 665, 705, 734, 779, 829}
            self.document_indices = {916, 620, 664, 782, 487, 921, 446, 508, 526, 722, 687, 728, 517, 549, 650, 700, 767, 917, 704, 726, 744, 736, 791, 822}
            self.building_indices = {497, 498, 538, 598, 652, 663, 678, 698, 706, 449, 749, 876}
            self.human_keywords = [
                "suit", "jersey", "t-shirt", "sweatshirt", "gown", "sunglasses", "wig", "mask",
                "military uniform", "cloak", "scuba diver", "neck brace", "jean", "skirt", "brassiere",
                "swimming trunks", "pajama", "trench coat", "vestment", "apron"
            ]

            self.ready = True
        except Exception as e:
            print(f"Warning: RobustBuffaloValidationGate init error: {e}")
            self.ready = False

    def inspect(self, pil_img: Image.Image) -> dict:
        pil_img = pil_img.convert("RGB")
        w, h = pil_img.size
        img_area = w * h

        # -------------------------------------------------------------
        # STEP 1: Image Quality / Variance Check
        # -------------------------------------------------------------
        stat = ImageStat.Stat(pil_img)
        var = sum(stat.var) / len(stat.var)
        mean_b = sum(stat.mean) / len(stat.mean)
        if var < 12.0 or mean_b < 10 or mean_b > 248:
            return {
                "outcome": "C_UNCERTAIN",
                "is_buffalo": False,
                "status": "uncertain_evidence",
                "entity": "Blank / Low-Contrast Frame",
                "icon": "⚠️",
                "message": "Buffalo validation uncertain: Insufficient visual evidence (blank, dark, or blurry frame). Please provide a clearer photo."
            }

        if not self.ready:
            return {
                "outcome": "A_ACCEPTED",
                "is_buffalo": True,
                "status": "confident",
                "entity": "Water Buffalo / Bovine",
                "icon": "🐃"
            }

        # -------------------------------------------------------------
        # STEP 2: SSDLite320 Object Detection (COCO 91 categories)
        # -------------------------------------------------------------
        try:
            det_t = self.det_transform(pil_img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                preds = self.detector(det_t)[0]

            det_scores = preds['scores']
            det_labels = preds['labels']
            det_boxes = preds['boxes']

            detected_objects = []
            for b, l, s in zip(det_boxes, det_labels, det_scores):
                score_val = float(s)
                if score_val < 0.32:
                    continue
                cat_name = self.coco_classes[int(l)]
                box_area = float((b[2] - b[0]) * (b[3] - b[1]))
                area_pct = (box_area / img_area) * 100
                detected_objects.append({
                    "label": cat_name,
                    "score": score_val,
                    "area_pct": area_pct
                })

            bovine_objs = [o for o in detected_objects if o["label"] == "cow"]
            person_objs = [o for o in detected_objects if o["label"] == "person"]
            dog_objs = [o for o in detected_objects if o["label"] == "dog"]
            cat_objs = [o for o in detected_objects if o["label"] == "cat"]
            bird_objs = [o for o in detected_objects if o["label"] == "bird"]
            other_animal_objs = [o for o in detected_objects if o["label"] in {"sheep", "horse", "elephant", "bear", "zebra", "giraffe"}]
            vehicle_objs = [o for o in detected_objects if o["label"] in {"car", "truck", "bus", "motorcycle", "bicycle", "airplane", "boat", "train"}]
            inanimate_objs = [o for o in detected_objects if o["label"] not in {"cow", "person", "dog", "cat", "bird", "sheep", "horse", "elephant", "bear", "zebra", "giraffe", "__background__"}]

        except Exception as e:
            print(f"Detector error: {e}")
            bovine_objs, person_objs, dog_objs, cat_objs, bird_objs = [], [], [], [], []
            other_animal_objs, vehicle_objs, inanimate_objs = [], [], []

        # -------------------------------------------------------------
        # STEP 3: ImageNet Classification Check & Feature Embedding
        # -------------------------------------------------------------
        try:
            cls_t = self.cls_transform(pil_img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                cls_logits = self.classifier(cls_t)
                cls_probs = torch.softmax(cls_logits, dim=-1).squeeze(0)
                feat_emb = F.normalize(self.classifier.features(cls_t).mean([2, 3]).squeeze(0), p=2, dim=0)

            top5_p, top5_idx = torch.topk(cls_probs, 5)
            top5_indices = [int(idx.item()) for idx in top5_idx]
            top1_idx = top5_indices[0]
            top1_cat = self.imagenet_classes[top1_idx].lower()
            top1_prob = float(top5_p[0]) * 100

            has_buffalo_cls = any(idx in self.buffalo_categories for idx in top5_indices) or (345 in top5_indices and float(cls_probs[345]) > 0.08)
            has_human_attire = any(k in top1_cat for k in self.human_keywords) or any(any(k in self.imagenet_classes[idx].lower() for k in self.human_keywords) for idx in top5_indices[:3])

            total_canine = sum(float(cls_probs[i]) for i in self.canine_indices) * 100
            total_bird = sum(float(cls_probs[i]) for i in self.bird_indices) * 100
            total_feline = sum(float(cls_probs[i]) for i in self.feline_indices) * 100
            total_other_mammal = sum(float(cls_probs[i]) for i in self.other_mammal_indices) * 100
            total_bovine = sum(float(cls_probs[i]) for i in {345, 346, 347, 690}) * 100

        except Exception as e:
            print(f"Classifier error: {e}")
            has_buffalo_cls = False
            has_human_attire = False
            top1_cat = ""
            top1_prob = 0.0
            top1_idx = -1
            total_canine, total_bird, total_feline, total_other_mammal, total_bovine = 0.0, 0.0, 0.0, 0.0, 0.0
            feat_emb = None

        # -------------------------------------------------------------
        # STEP 4: Exemplar Bank Similarity Score & Document Texture Check
        # -------------------------------------------------------------
        try:
            thumb = pil_img.resize((120, 120)).convert("L")
            arr = np.array(thumb, dtype=np.float32)
            gx = np.abs(arr[:, 2:] - arr[:, :-2])
            gy = np.abs(arr[2:, :] - arr[:-2, :])
            mag = np.sqrt(gx[:-2, :]**2 + gy[:, :-2]**2)
            zero_grad_ratio = float(np.mean(mag < 3.8))
            high_grad_ratio = float(np.mean(mag > 24.0))

            rgb_thumb = np.array(pil_img.resize((60, 60)), dtype=np.float32)
            max_c = np.max(rgb_thumb, axis=-1)
            min_c = np.min(rgb_thumb, axis=-1)
            sat_arr = np.where(max_c == 0, 0, (max_c - min_c) / (max_c + 1e-5))
            mean_sat = float(np.mean(sat_arr))
            mean_lum = float(np.mean(0.299 * rgb_thumb[..., 0] + 0.587 * rgb_thumb[..., 1] + 0.114 * rgb_thumb[..., 2]))
            high_white_ratio = float(np.mean(rgb_thumb > 210))

            is_doc_or_screen = (zero_grad_ratio > 0.60 and high_grad_ratio > 0.04) or \
                               (mean_lum > 165 and mean_sat < 0.14 and high_grad_ratio > 0.04) or \
                               (zero_grad_ratio > 0.55 and mean_lum > 135 and high_grad_ratio > 0.04) or \
                               (high_white_ratio > 0.35 and mean_sat < 0.12 and high_grad_ratio > 0.04)
        except Exception as e:
            is_doc_or_screen = False
            zero_grad_ratio = 0.0
            high_grad_ratio = 0.0

        max_sim = 0.0
        top1_bank_label = None
        top3_bank_labels = []
        if self.bank_embeddings is not None and feat_emb is not None:
            try:
                sims = torch.mv(self.bank_embeddings, feat_emb)
                k_num = min(5, len(self.bank_labels)) if self.bank_labels else 1
                topk_s, topk_i = torch.topk(sims, k_num)
                max_sim = float(topk_s[0])
                if self.bank_labels and len(self.bank_labels) > 0:
                    top1_bank_label = self.bank_labels[int(topk_i[0])]
                    top3_bank_labels = [self.bank_labels[int(idx)] for idx in topk_i[:min(3, len(topk_i))]]
            except Exception as e:
                print(f"Exemplar similarity error: {e}")
                max_sim = 0.0

        # -------------------------------------------------------------
        # STEP 5: Rule-Based Multi-Stage Verification Engine
        # -------------------------------------------------------------

        # 5A. Non-Buffalo Animals Detected by SSDLite (bear, horse, sheep/goat, elephant, zebra, giraffe)
        if other_animal_objs:
            top_other = max(other_animal_objs, key=lambda x: x["score"])
            is_lsd_lesion = (max_sim >= 0.52 and len(top3_bank_labels) >= 2 and all(lbl == "Lumpy_Skin_Disease" for lbl in top3_bank_labels))
            if not has_buffalo_cls and not bovine_objs and not is_lsd_lesion and max_sim < 0.58:
                animal_name = top_other["label"]
                display_name = {
                    "bear": "Bear / Wild Animal",
                    "sheep": "Sheep / Goat",
                    "horse": "Horse / Equine",
                    "elephant": "Elephant",
                    "zebra": "Zebra",
                    "giraffe": "Giraffe"
                }.get(animal_name, f"Non-Buffalo Animal ({animal_name})")
                icon_map = {
                    "bear": "🐻",
                    "sheep": "🐑",
                    "horse": "🐴",
                    "elephant": "🐘",
                    "zebra": "🦓",
                    "giraffe": "🦒"
                }
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": display_name,
                    "icon": icon_map.get(animal_name, "🐾"),
                    "message": f"Prediction failed: {display_name} detected. This system only diagnoses water buffaloes."
                }

        # 5B. Canine Detection (Dogs)
        if dog_objs and not has_buffalo_cls and max_sim < 0.55:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": "Domestic Dog",
                "icon": "🐶",
                "message": "Prediction failed: Domestic dog detected. This system only diagnoses water buffaloes."
            }

        # 5C. Feline Detection (Cats)
        if cat_objs and not has_buffalo_cls and max_sim < 0.55:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": "Feline / Cat",
                "icon": "🐱",
                "message": "Prediction failed: Feline/cat detected. This system only diagnoses water buffaloes."
            }

        # 5D. Bird / Poultry Detection
        if bird_objs and not has_buffalo_cls and max_sim < 0.55:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": "Bird / Poultry",
                "icon": "🐔",
                "message": "Prediction failed: Bird/poultry detected. This system only diagnoses water buffaloes."
            }

        # 5E. Vehicles
        if vehicle_objs and not has_buffalo_cls and not bovine_objs and max_sim < 0.55:
            top_veh = max(vehicle_objs, key=lambda x: x["score"])
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Vehicle ({top_veh['label']})",
                "icon": "🚗",
                "message": "Prediction failed: Vehicle detected in the image."
            }

        # 5F. Human Detection (Face, Portrait, Selfie, Handler without Buffalo)
        if person_objs:
            top_person = max(person_objs, key=lambda x: x["score"])
            if top_person["score"] >= 0.40 and not has_buffalo_cls and not (bovine_objs and bovine_objs[0]["score"] >= 0.85) and max_sim < 0.52:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Human / Person",
                    "icon": "👤",
                    "message": "Prediction failed: Human detected in the image. Please point camera at a buffalo."
                }

        # 5G. Fine-Grained ImageNet Rejection Checks
        if ((top1_idx in self.canine_indices and top1_prob > 15.0) or (total_canine > 30.0 and top1_idx in self.canine_indices)) and max_sim < 0.48:
            if not has_buffalo_cls:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Domestic Dog ({self.imagenet_classes[top1_idx]})",
                    "icon": "🐶",
                    "message": f"Prediction failed: Domestic dog detected ({self.imagenet_classes[top1_idx]})."
                }

        if ((top1_idx in self.feline_indices and top1_prob > 12.0) or total_feline > 25.0) and max_sim < 0.48:
            if not has_buffalo_cls:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Feline / Cat ({self.imagenet_classes[top1_idx]})",
                    "icon": "🐱",
                    "message": f"Prediction failed: Feline detected ({self.imagenet_classes[top1_idx]})."
                }

        if ((top1_idx in self.bird_indices and top1_prob > 12.0) or total_bird > 25.0) and max_sim < 0.48:
            if not has_buffalo_cls:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Bird / Poultry ({self.imagenet_classes[top1_idx]})",
                    "icon": "🐔",
                    "message": f"Prediction failed: Bird/poultry detected ({self.imagenet_classes[top1_idx]})."
                }

        if ((top1_idx in self.other_mammal_indices and top1_prob > 15.0) or (total_other_mammal > 20.0 and total_bovine < 5.0)) and max_sim < 0.52:
            if not has_buffalo_cls and not bovine_objs:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Non-Buffalo Animal ({self.imagenet_classes[top1_idx]})",
                    "icon": "🐾",
                    "message": f"Prediction failed: Non-buffalo animal detected ({self.imagenet_classes[top1_idx]})."
                }

        if (has_human_attire or any(k in top1_cat for k in self.human_keywords) or any(any(k in self.imagenet_classes[idx].lower() for k in ["person", "man", "woman", "boy", "girl"]) for idx in top5_indices[:2])) and total_bovine < 5.0 and max_sim < 0.48:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Human / Person ({self.imagenet_classes[top1_idx]})",
                "icon": "👤",
                "message": "Prediction failed: Human detected in the image. Please point camera at a buffalo."
            }

        doc_keywords = [
            "web site", "menu", "envelope", "screen", "monitor", "laptop", "cellular telephone", 
            "crossword", "rule", "paper", "comic book", "book jacket", "binder", "packet", "oscilloscope",
            "notebook", "newspaper", "book", "poster", "scoreboard", "street sign",
            "modem", "printer", "photocopier", "cash machine", "paper towel",
            "carton", "box", "rubber eraser", "pencil", "ballpoint", "quill", "fountain pen"
        ]
        has_doc_cls = any(idx in self.document_indices for idx in top5_indices[:3]) or \
                      any(any(k in self.imagenet_classes[idx].lower() for k in doc_keywords) for idx in top5_indices[:3])

        if (has_doc_cls or any(k in top1_cat for k in doc_keywords) or is_doc_or_screen) and not has_buffalo_cls and not bovine_objs:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Digital Screen / Document ({self.imagenet_classes[top1_idx] if top1_idx >= 0 else 'Text'})",
                "icon": "📄",
                "message": "Prediction failed: Document, text, or digital screen detected in the image. This system specifically diagnoses water buffaloes."
            }

        veh_keywords = ["automobile", "sports car", "truck", "cab", "van", "jeep", "bus", "bicycle", "motorcycle", "airplane", "boat", "minivan", "limousine"]
        if top1_idx not in self.buffalo_categories and top1_idx not in {345, 346, 347, 690} and "oxcart" not in top1_cat:
            is_veh = (top1_idx in self.vehicle_indices and top1_prob > 12.0) or any(k in top1_cat for k in veh_keywords) or any(w in top1_cat.split() for w in ["car", "cars"])
            if is_veh and max_sim < 0.50:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Vehicle ({self.imagenet_classes[top1_idx]})",
                    "icon": "🚗",
                    "message": "Prediction failed: Vehicle detected in the image."
                }

        bldg_keywords = ["palace", "castle", "monastery", "church", "mosque", "tile roof", "bell cote", "beacon", "bridge", "house"]
        if (top1_idx in self.building_indices and top1_prob > 15.0) or any(k in top1_cat for k in bldg_keywords):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Building / Architecture ({self.imagenet_classes[top1_idx]})",
                "icon": "🏛️",
                "message": "Prediction failed: Building / architecture detected in the image."
            }

        # Inanimate everyday objects
        if inanimate_objs and not has_buffalo_cls and max_sim < 0.52:
            top_inanim = max(inanimate_objs, key=lambda x: x["score"])
            if top_inanim["score"] >= 0.45:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Object ({top_inanim['label']})",
                    "icon": "📦",
                    "message": f"Prediction failed: Incompatible object ({top_inanim['label']}) detected in the image."
                }

        # 5H. Bovine Verification (Cow vs Water Buffalo)
        if bovine_objs:
            if has_buffalo_cls or max_sim >= 0.58:
                return {
                    "outcome": "A_ACCEPTED",
                    "is_buffalo": True,
                    "status": "confident",
                    "entity": "Water Buffalo / Bovine",
                    "icon": "🐃"
                }
            else:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Non-Buffalo Livestock / Cow ({self.imagenet_classes[top1_idx]})",
                    "icon": "🐄",
                    "message": "Prediction failed: Domestic cattle / non-buffalo animal detected. This system specifically diagnoses water buffaloes."
                }

        # Direct Water Buffalo confirmation via ImageNet
        if has_buffalo_cls:
            return {
                "outcome": "A_ACCEPTED",
                "is_buffalo": True,
                "status": "confident",
                "entity": "Water Buffalo / Bovine",
                "icon": "🐃"
            }

        # 5I. Lesion / Tissue Verification via Exemplar Bank
        if max_sim >= 0.50 and not is_doc_or_screen:
            return {
                "outcome": "A_ACCEPTED",
                "is_buffalo": True,
                "status": "confident",
                "entity": "Buffalo Lesion / Cutaneous Area",
                "icon": "🔬"
            }

        # 5J. Fallback Rejection
        return {
            "outcome": "B_REJECTED",
            "is_buffalo": False,
            "status": "rejected",
            "entity": f"Non-Buffalo Image ({self.imagenet_classes[top1_idx]})",
            "icon": "⚠️",
            "message": "Prediction failed: No water buffalo or buffalo health condition detected in the image."
        }

NonBuffaloDetector = RobustBuffaloValidationGate


class BuffaloDiseaseModel:
    """
    Production 4-Class Buffalo Disease Inference Engine
    Uses the trained checkpoint buffalo_model.pth (94.6% Test Accuracy)
    calibrated with the Exemplar Feature Bank (k-NN cosine distance-weighted fusion).
    """
    MODEL_VERSION = "4.0-Calibrated-Hybrid-Ensemble"

    def __init__(self, model_path=None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.model_path = model_path or os.path.join(base_dir, "buffalo_model.pth")

        self.class_names = list(DEFAULT_CLASSES)
        self.num_classes = len(self.class_names)
        self.image_size = (240, 240)
        self.norm_mean = [0.485, 0.456, 0.406]
        self.norm_std = [0.229, 0.224, 0.225]
        self.loaded = False
        self.test_acc = 0.9458

        # 1. Non-Buffalo Detection Gate
        self.entity_detector = NonBuffaloDetector(self.device)

        # 2. Build EfficientNet-B0 Architecture matching Checkpoint
        self.model = models.efficientnet_b0(weights=None)
        in_features = self.model.classifier[1].in_features
        self.model.classifier = nn.Sequential(
            nn.Dropout(p=0.2),
            nn.Linear(in_features, 512),
            nn.BatchNorm1d(512),
            nn.SiLU(),
            nn.Dropout(p=0.15),
            nn.Linear(512, self.num_classes),
        )

        # 3. Load Trained Checkpoint Weights
        if os.path.exists(self.model_path):
            try:
                ckpt = torch.load(self.model_path, map_location=self.device, weights_only=False)
                if isinstance(ckpt, dict) and "model_state_dict" in ckpt:
                    self.model.load_state_dict(ckpt["model_state_dict"], strict=True)
                    if "classes" in ckpt:
                        self.class_names = ckpt["classes"]
                        self.num_classes = len(self.class_names)
                    if "image_size" in ckpt:
                        self.image_size = ckpt["image_size"]
                    if "norm_mean" in ckpt:
                        self.norm_mean = ckpt["norm_mean"]
                    if "norm_std" in ckpt:
                        self.norm_std = ckpt["norm_std"]
                    if "best_test_acc" in ckpt:
                        self.test_acc = float(ckpt["best_test_acc"])
                else:
                    self.model.load_state_dict(ckpt, strict=False)

                self.model.to(self.device).eval()
                self.loaded = True
            except Exception as e:
                print(f"Error loading checkpoint {self.model_path}: {e}")
                self.model.to(self.device).eval()
        else:
            print(f"Warning: Checkpoint not found at {self.model_path}")
            self.model.to(self.device).eval()

        # 4. Exemplar Bank for Calibration
        bank_path = os.path.join(base_dir, "exemplar_bank.pt")
        if os.path.exists(bank_path):
            try:
                bdata = torch.load(bank_path, map_location=self.device)
                self.bank_embeddings = bdata["embeddings"].to(self.device)
                self.bank_labels = bdata.get("labels", [])
            except Exception as e:
                print(f"Warning loading exemplar bank in disease model: {e}")
                self.bank_embeddings = None
                self.bank_labels = []
        else:
            self.bank_embeddings = None
            self.bank_labels = []

        self.transform = transforms.Compose([
            transforms.Resize(self.image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=self.norm_mean, std=self.norm_std),
        ])

        print("=" * 68)
        print("LOADED MODEL:")
        print(f"  path             = {self.model_path}")
        print(f"  architecture     = efficientnet_b0")
        print(f"  num_classes      = {self.num_classes}")
        print(f"  class_mapping    = {dict(enumerate(self.class_names))}")
        print(f"  best_test_acc    = {self.test_acc * 100:.2f}% (Trained Checkpoint)")
        print(f"  input_resolution = {self.image_size[0]}x{self.image_size[1]}")
        print(f"  device           = {self.device}")
        print(f"  status           = {'READY' if self.loaded else 'UNINITIALIZED'}")
        print("=" * 68)

    def get_prior_distribution(self):
        return {name: 25.0 for name in self.class_names}

    def display_name(self, class_key):
        return CLASS_DISPLAY.get(class_key, class_key.replace("_", " "))

    def get_details(self, display_disease_name):
        return DISEASE_DETAILS.get(display_disease_name, {
            "severity": "Medium",
            "category": "Veterinary Observation",
            "symptoms": ["General lethargy", "Mild abnormal signs"],
            "precautions": ["Keep animal sheltered and rested", "Provide fresh drinking water"],
            "immediate_action": "Consult a qualified veterinarian for professional diagnosis.",
            "vet_attention": True,
            "is_spreadable": False,
        })

    def predict_detailed(self, image_input) -> dict:
        """
        Pure 4-Class Inference Pipeline:
        1. Pre-inference Non-Buffalo Gate (Rejects dogs, hens/poultry, cats, documents, cars, humans, etc.)
        2. Resize to exact training resolution (240x240)
        3. Model evaluation with Test-Time Augmentation (TTA: original + horizontal flip)
        4. Softmax computation and argmax class mapping
        """
        if isinstance(image_input, (bytes, bytearray)):
            image = Image.open(io.BytesIO(image_input)).convert("RGB")
        elif isinstance(image_input, Image.Image):
            image = image_input.convert("RGB")
        else:
            raise ValueError("Unsupported image input type")

        w, h = image.size
        print("\n" + "=" * 68)
        print("[INFERENCE PIPELINE TRACE]")
        print(f"  1. Input Image: {w}x{h} (Width x Height), Mode: {image.mode}")
        print(f"  2. Preprocessing: Resized to {self.image_size[0]}x{self.image_size[1]}, Normalized (mean={self.norm_mean}, std={self.norm_std})")

        # -------------------------------------------------------------
        # STEP 1: Non-Buffalo Verification Gate
        # -------------------------------------------------------------
        entity_res = self.entity_detector.inspect(image)
        if not entity_res.get("is_buffalo", True):
            detected_subject = entity_res.get("entity", "Non-Buffalo Subject")
            icon = entity_res.get("icon", "⚠️")
            msg = entity_res.get("message", "Prediction failed: No buffalo detected in the image.")
            gate_status = entity_res.get("status", "rejected")

            print(f"  3. Buffalo Detection Gate: REJECTED ({detected_subject}) [{gate_status}]")
            print(f"     -> Final Decision: REJECT NON-BUFFALO (4-class disease model bypassed)")
            print("=" * 68)

            precautions = [
                "Please upload a clear photograph of a water buffalo.",
                "Ensure good lighting and focus on the animal or affected lesion area."
            ]
            recommendations = [
                "Upload a clear photograph showing the buffalo or affected body region."
            ]
            immediate_action = "Ensure the image contains a buffalo before requesting diagnosis."

            if gate_status == "uncertain_evidence":
                precautions = [
                    "Ensure adequate natural or artificial lighting on the buffalo.",
                    "Hold the camera steady to avoid motion blur and ensure sharp focus."
                ]
                recommendations = [
                    "Capture a wider or clearer photograph of the animal or affected body region."
                ]
                immediate_action = "Please re-capture with good lighting and clear focus."

            return {
                "requestId": None,
                "success": True,
                "is_buffalo": False,
                "isBuffalo": False,
                "status": gate_status,
                "entityType": "Uncertain Visual Evidence" if gate_status == "uncertain_evidence" else "Non-Buffalo Subject",
                "predictedSubject": detected_subject,
                "detectedEntityIcon": icon,
                "message": msg,
                "diseasePrediction": None,
                "prediction": None,
                "predicted_index": None,
                "predicted_class": None,
                "disease_key": None,
                "confidence": 0.0,
                "confidenceScore": 0.0,
                "severity": "N/A",
                "symptoms": [],
                "precautions": precautions,
                "recommendations": recommendations,
                "immediateAction": immediate_action,
                "vetAttentionRecommended": False,
                "model_version": self.MODEL_VERSION,
                "probabilities": {},
                "allProbabilities": [],
                "top3": [],
                "priorDistribution": self.get_prior_distribution()
            }

        print(f"  3. Buffalo Detection Gate: BUFFALO DETECTED")

        # -------------------------------------------------------------
        # STEP 2: Exact 240x240 Preprocessing + TTA Forward Pass
        # -------------------------------------------------------------
        t1 = self.transform(image).unsqueeze(0).to(self.device)
        t2 = self.transform(image.transpose(Image.FLIP_LEFT_RIGHT)).unsqueeze(0).to(self.device)

        with torch.no_grad():
            out1 = self.model(t1)
            out2 = self.model(t2)
            # TTA blend matching training evaluate_with_tta
            outputs = 0.60 * out1 + 0.40 * out2
            cnn_probs = F.softmax(outputs, dim=-1).squeeze(0)

        # -------------------------------------------------------------
        # STEP 3: Exemplar Bank Nearest-Neighbor Feature Calibration
        # -------------------------------------------------------------
        final_probs = cnn_probs
        top1_sim = 0.0
        top1_label = None

        if self.bank_embeddings is not None and len(self.bank_labels) > 0 and self.entity_detector.ready:
            try:
                feat_t = self.entity_detector.cls_transform(image).unsqueeze(0).to(self.device)
                with torch.no_grad():
                    feat_emb = F.normalize(self.entity_detector.classifier.features(feat_t).mean([2, 3]).squeeze(0), p=2, dim=0)
                    sims = torch.mv(self.bank_embeddings, feat_emb)
                    top5_s, top5_idx = torch.topk(sims, min(5, len(self.bank_labels)))
                    top1_sim = float(top5_s[0])
                    top1_label = self.bank_labels[int(top5_idx[0])]

                    # Distance-weighted temperature scaled KNN probabilities
                    weights_knn = torch.softmax(top5_s / 0.05, dim=0)
                    knn_probs = torch.zeros(self.num_classes, device=self.device)
                    for w_val, i in zip(weights_knn, top5_idx):
                        c_name = self.bank_labels[int(i)]
                        if c_name in self.class_names:
                            c_idx = self.class_names.index(c_name)
                            knn_probs[c_idx] += w_val

                    # Calibrated Hybrid Blending
                    if top1_sim >= 0.80:
                        final_probs = 0.20 * cnn_probs + 0.80 * knn_probs
                    elif top1_sim >= 0.60:
                        final_probs = 0.50 * cnn_probs + 0.50 * knn_probs
                    elif top1_sim >= 0.50:
                        final_probs = 0.70 * cnn_probs + 0.30 * knn_probs
                    else:
                        final_probs = 0.90 * cnn_probs + 0.10 * knn_probs
            except Exception as e:
                print(f"Hybrid calibration warning: {e}")
                final_probs = cnn_probs

        probs = final_probs.cpu().numpy()
        raw_logits_list = [round(float(v), 4) for v in outputs.squeeze(0).cpu().numpy()]
        pred_idx = int(np.argmax(probs))
        pred_class = self.class_names[pred_idx]
        pred_display = self.display_name(pred_class)
        conf_val = float(probs[pred_idx])

        print(f"  4. Calibrated Hybrid Model Inference:")
        print(f"     CNN Softmax: {[round(float(p), 4) for p in cnn_probs.cpu().numpy()]}")
        if top1_label:
            print(f"     Exemplar Nearest Neighbor: {top1_label} (Cosine Sim: {top1_sim:.4f})")
        print(f"     Calibrated Probabilities: {[round(float(p), 4) for p in probs]}")
        print(f"     Class Mapping Index {pred_idx} -> {pred_class} ({conf_val * 100:.2f}%)")
        print(f"     Final API Result: {pred_display}")
        print("=" * 68)

        probabilities_dict = {
            self.class_names[i]: round(float(probs[i]) * 100, 2)
            for i in range(self.num_classes)
        }

        all_probs_list = [
            {
                "class_index": i,
                "disease": self.display_name(self.class_names[i]),
                "class_key": self.class_names[i],
                "probability": round(float(probs[i]), 4),
                "confidence": round(float(probs[i]) * 100, 2),
                "prior": 25.0
            }
            for i in range(self.num_classes)
        ]
        all_probs_list.sort(key=lambda x: x["confidence"], reverse=True)

        details = self.get_details(pred_display)

        return {
            "predicted_index": pred_idx,
            "predicted_class": pred_class,
            "prediction": pred_display,
            "disease_key": pred_class,
            "diseasePrediction": pred_display,
            "confidence": conf_val,
            "confidenceScore": round(conf_val * 100, 2),
            "status": "confident" if conf_val >= 0.50 else "uncertain",
            "is_buffalo": True,
            "isBuffalo": True,
            "severity": details["severity"],
            "symptoms": details["symptoms"],
            "precautions": details["precautions"],
            "recommendations": details["precautions"],
            "immediateAction": details["immediate_action"],
            "vetAttentionRecommended": details["vet_attention"],
            "raw_logits": [round(float(v), 4) for v in outputs.squeeze(0).cpu().numpy()],
            "probabilities": probabilities_dict,
            "allProbabilities": all_probs_list,
            "top3": all_probs_list[:3],
            "model_version": self.MODEL_VERSION,
            "architecture": "efficientnet_b0",
            "isUnbiased": True,
            "baselinePriorPerClass": 25.0,
            "priorDistribution": self.get_prior_distribution(),
            "disclaimer": "AI-assisted clinical decision support — confirm with licensed veterinary examination."
        }
