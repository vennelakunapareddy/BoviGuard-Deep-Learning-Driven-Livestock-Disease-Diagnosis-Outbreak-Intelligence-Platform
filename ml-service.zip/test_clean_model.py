from PIL import Image
from model import BuffaloDiseaseModel
import os
import glob

m = BuffaloDiseaseModel()

test_cases = [
    (r"C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png", "C++ Code Screenshot"),
    ("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "China Temple"),
    ("venv/Lib/site-packages/sklearn/datasets/images/flower.jpg", "Flower"),
    ("real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg", "Healthy Buffalo"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "Lumpy Skin Sample"),
    ("buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg", "Mastitis Test 1"),
    ("buffalo_dataset/test/Mastitis/Mastitis_test_0005.jpg", "Mastitis Test 5"),
    ("buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg", "FMD Test 1")
]

print("\n" + "=" * 70)
print("TESTING MODEL.PY INFERENCE PIPELINE")
print("=" * 70)
for p, name in test_cases:
    if os.path.exists(p):
        img = Image.open(p)
        res = m.predict_detailed(img)
        print(f"\n--- {name} ---")
        print(f"isBuffalo:     {res['isBuffalo']}")
        if not res['isBuffalo']:
            print(f"Status:        {res['status']}")
            print(f"Subject:       {res['predictedSubject']}")
            print(f"Message:       {res['message']}")
        else:
            print(f"Prediction:    {res['prediction']} (Index {res['predicted_index']})")
            print(f"Confidence:    {res['confidenceScore']}%")
            print(f"Raw Logits:    {res['raw_logits']}")
            print(f"Probabilities: {res['probabilities']}")
