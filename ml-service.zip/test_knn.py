import os
import glob
import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
feature_extractor = models.mobilenet_v2(weights=weights).eval()
feature_extractor.classifier = torch.nn.Identity()
transform = weights.transforms()

def get_emb(img):
    t = transform(img.convert("RGB")).unsqueeze(0)
    with torch.no_grad():
        emb = F.normalize(feature_extractor(t).squeeze(0), p=2, dim=0)
    return emb

# Build exemplar bank from buffalo_dataset/train
print("Building exemplar bank from buffalo_dataset/train...")
bank_embs = []
bank_labels = []
bank_paths = []

for cname in ["Foot_and_Mouth_Disease", "Healthy_Buffalo", "Lumpy_Skin_Disease", "Mastitis"]:
    folder = os.path.join("buffalo_dataset", "train", cname)
    imgs = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(('.jpg','.jpeg','.png','.webp'))]
    for p in imgs:
        bank_embs.append(get_emb(Image.open(p)))
        bank_labels.append(cname)
        bank_paths.append(p)

bank_tensor = torch.stack(bank_embs)
print(f"Exemplar bank ready with {len(bank_labels)} images!")

def knn_classify(test_path, k=5):
    emb = get_emb(Image.open(test_path))
    sims = torch.mv(bank_tensor, emb)
    topk_sims, topk_indices = torch.topk(sims, k)
    
    votes = {}
    print(f"\nTest: {os.path.basename(test_path)}")
    for s, idx in zip(topk_sims, topk_indices):
        lbl = bank_labels[int(idx)]
        votes[lbl] = votes.get(lbl, 0) + float(s)
        print(f"  - Sim: {float(s):.3f} | {lbl:25s} | {os.path.basename(bank_paths[int(idx)])}")
    
    winner = max(votes, key=votes.get)
    max_sim = float(topk_sims[0])
    return winner, max_sim, votes

for p in [
    "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png",
    "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213815.png",
    "real_world_holdout/Mastitis/user_live_media_1790438947823.png",
    "real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png",
    "real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg",
    "venv/Lib/site-packages/sklearn/datasets/images/china.jpg",
    "venv/Lib/site-packages/sklearn/datasets/images/flower.jpg",
]:
    pred, max_sim, votes = knn_classify(p, k=3)
    print(f"--> PREDICTED: {pred} (Max Sim: {max_sim:.3f})")
