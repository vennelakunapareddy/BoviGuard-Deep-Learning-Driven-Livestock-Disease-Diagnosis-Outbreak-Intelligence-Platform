from PIL import Image
import os

path = r'C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866204024.png'
if os.path.exists(path):
    img = Image.open(path)
    w, h = img.size
    print(f"Original screenshot dimensions: {w}x{h}")
    # In media_1790866204024.png, the preview image is approximately at:
    # x: 0.10 * w to 0.44 * w
    # y: 0.10 * h to 0.58 * h
    crop_box = (int(w * 0.10), int(h * 0.10), int(w * 0.44), int(h * 0.58))
    cropped = img.crop(crop_box)
    cropped.save("crop_udder_user.png")
    print("Saved crop_udder_user.png")

    from model import BuffaloDiseaseModel
    m = BuffaloDiseaseModel()
    res = m.predict_detailed(cropped)
    print("Prediction:", res.get("prediction"))
    print("Confidence:", res.get("confidenceScore"))
    print("All Probs:", res.get("probabilities"))
else:
    print(f"File not found: {path}")
