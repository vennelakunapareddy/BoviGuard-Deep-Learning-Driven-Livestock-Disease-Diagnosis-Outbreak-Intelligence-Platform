import os
from PIL import Image

print("=== CHECKING TEST MASTITIS IMAGES ===")
for f in os.listdir("buffalo_dataset/test/Mastitis")[:5]:
    fp = os.path.join("buffalo_dataset/test/Mastitis", f)
    img = Image.open(fp)
    print(f"Test image {f}: size={img.size}, mode={img.mode}")

p_user = "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png"
if os.path.exists(p_user):
    img_u = Image.open(p_user)
    print(f"User screenshot: size={img_u.size}, mode={img_u.mode}")
