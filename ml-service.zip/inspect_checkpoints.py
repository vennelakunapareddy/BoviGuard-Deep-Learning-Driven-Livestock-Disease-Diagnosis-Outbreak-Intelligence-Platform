import torch

for fname in ['buffalo_model.pth', 'buffalo_effnet_b0.pth']:
    print('=' * 60)
    print('INSPECTING:', fname)
    try:
        data = torch.load(fname, map_location='cpu', weights_only=False)
        if isinstance(data, dict):
            print('Top-level keys:', list(data.keys()))
            for k in ['classes', 'num_classes', 'class_names', 'architecture', 'best_test_acc', 'accuracy', 'image_size', 'norm_mean', 'norm_std', 'target_names']:
                if k in data:
                    print(f'  {k}:', data[k])
            sd = data.get('model_state_dict', data)
        else:
            sd = data
            print('Type:', type(data))

        # Check classifier weights
        for k, v in sd.items():
            if 'classifier' in k or 'fc' in k:
                print(f'  Layer {k}: shape {v.shape}')
    except Exception as e:
        print('Error:', e)
