import urllib.request
import json
import os

# 1. Health check
req = urllib.request.urlopen("http://127.0.0.1:5000/health")
print("ML Health:", req.read().decode())

def post_multipart(url, filepath):
    boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
    fn = os.path.basename(filepath)
    with open(filepath, "rb") as f:
        file_bytes = f.read()
    
    body = bytearray()
    body.extend(f"--{boundary}\r\n".encode("utf-8"))
    body.extend(f'Content-Disposition: form-data; name="image"; filename="{fn}"\r\n'.encode("utf-8"))
    body.extend(b"Content-Type: image/jpeg\r\n\r\n")
    body.extend(file_bytes)
    body.extend(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    
    req = urllib.request.Request(url, data=bytes(body))
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))

test_cases = [
    ("../test_human.jpg", "Non-Buffalo Human", False, None),
    ("../test_car.jpg", "Non-Buffalo Car", False, None),
    ("../test_dog.jpg", "Non-Buffalo Dog", False, None),
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis Screenshot", True, "Clinical Mastitis"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_101.png", "LSD 101 Oxcart", True, "Lumpy Skin Disease (LSD)"),
    ("real_world_holdout/healthy buffalo/buffalo/murrah/130_Murrah_Buffalo_Stock_Photos_.jpg", "Healthy Murrah", True, "Healthy Buffalo"),
]

print("\n" + "=" * 75)
print("TESTING LIVE HTTP API ON PORT 5000")
print("=" * 75)

all_ok = True
for path, name, exp_buf, exp_pred in test_cases:
    if os.path.exists(path):
        res = post_multipart("http://127.0.0.1:5000/predict", path)
        is_buf = res.get("isBuffalo")
        pred = res.get("prediction")
        conf = res.get("confidenceScore")
        
        ok = (is_buf == exp_buf) and (not exp_buf or pred == exp_pred)
        if not ok: all_ok = False
        status = "PASS" if ok else "FAIL"
        print(f"[{status}] {name:25s} | isBuffalo: {str(is_buf):5s} | Pred: {str(pred):30s} | Conf: {conf}%")

print("=" * 75)
print("LIVE API TEST RESULT:", "ALL PASSED!" if all_ok else "SOME FAILED")
print("=" * 75)
