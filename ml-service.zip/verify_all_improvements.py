import os
import glob
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

# 1. Load trained 4-class checkpoint
ckpt = torch.load("buffalo_model.pth", map_location="cpu", weights_only=False)
classes = ckpt.get("classes", ["Foot_and_Mouth_Disease", "Healthy_Buffalo", "Lumpy_Skin_Disease", "Mastitis"])

cnn = models.efficientnet_b0(weights=None)
in_f = cnn.classifier[1].in_features
cnn.classifier = nn.Sequential(
    nn.Dropout(0.2), nn.Linear(in_f, 512), nn.BatchNorm1d(512),
    nn.SiLU(), nn.Dropout(0.15), nn.Linear(512, 4)
)
cnn.load_state_dict(ckpt["model_state_dict"])
cnn.eval()

t_cnn = transforms.Compose([
    transforms.Resize((240, 240)),
    transforms.ToTensor(),
    transforms.Normalize(mean=ckpt["norm_mean"], std=ckpt["norm_std"])
])

# 2. Load exemplar bank
bank_data = torch.load("exemplar_bank.pt", map_location="cpu")
bank_embs = bank_data["embeddings"]
bank_labels = bank_data["labels"]

# 3. Load feature extractor
fe_weights = models.MobileNet_V2_Weights.DEFAULT
fe = models.mobilenet_v2(weights=fe_weights).eval()
fe.classifier = nn.Identity()
t_fe = fe_weights.transforms()

def predict_hybrid(img):
    img_rgb = img.convert("RGB")
    # A. Feature extraction
    with torch.no_grad():
        emb = F.normalize(fe(t_fe(img_rgb).unsqueeze(0)).squeeze(0), p=2, dim=0)
        sims = torch.mv(bank_embs, emb)
        top5_s, top5_idx = torch.topk(sims, 5)
        top1_sim = float(top5_s[0])
        top1_label = bank_labels[int(top5_idx[0])]
        
        # Distance-weighted KNN probabilities
        weights_knn = torch.softmax(top5_s / 0.05, dim=0)
        knn_probs = torch.zeros(len(classes))
        for w, i in zip(weights_knn, top5_idx):
            c_idx = classes.index(bank_labels[int(i)])
            knn_probs[c_idx] += float(w)
            
        # CNN probabilities
        out1 = cnn(t_cnn(img_rgb).unsqueeze(0))
        out2 = cnn(t_cnn(img_rgb.transpose(Image.FLIP_LEFT_RIGHT)).unsqueeze(0))
        cnn_probs = torch.softmax(0.60 * out1 + 0.40 * out2, dim=-1).squeeze(0)
        
        # Hybrid Blending
        if top1_sim >= 0.80:
            final_p = 0.20 * cnn_probs + 0.80 * knn_probs
        elif top1_sim >= 0.60:
            final_p = 0.50 * cnn_probs + 0.50 * knn_probs
        elif top1_sim >= 0.50:
            final_p = 0.70 * cnn_probs + 0.30 * knn_probs
        else:
            final_p = 0.90 * cnn_probs + 0.10 * knn_probs
            
        pred_idx = int(torch.argmax(final_p).item())
        pred_class = classes[pred_idx]
        conf = float(final_p[pred_idx])
        
    return pred_class, conf, top1_sim, top1_label

# 4. Test Key Holdout Cases
print("=" * 70)
print("TESTING USER MASTITIS SCREENSHOTS & HOLD-OUT CASES")
print("=" * 70)

test_cases = [
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis"),
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213815.png", "Mastitis"),
    ("real_world_holdout/Mastitis/user_live_media_1790438947823.png", "Mastitis"),
    ("real_world_holdout/Mastitis/user_uploaded_mastitis_udder.jpg", "Mastitis"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "Lumpy_Skin_Disease"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_101.png", "Lumpy_Skin_Disease"),
    ("real_world_holdout/healthy buffalo/buffalo/murrah/130_Murrah_Buffalo_Stock_Photos_.jpg", "Healthy_Buffalo"),
    ("real_world_holdout/healthy buffalo/buffalo/murrah/131_Murrah_Buffalo_for_Dairy_Farming_ (1).jpg", "Healthy_Buffalo"),
]

all_pass = True
for p, expected in test_cases:
    if os.path.exists(p):
        pred_class, conf, sim, knn_lbl = predict_hybrid(Image.open(p))
        status = "PASS" if pred_class == expected else "FAIL"
        if status == "FAIL": all_pass = False
        print(f"[{status}] {os.path.basename(p):35s} -> Pred: {pred_class:22s} ({conf*100:.1f}%) | Expected: {expected}")

print("\n" + "=" * 70)
print(f"KEY CASES RESULT: {'ALL PASS!' if all_pass else 'SOME FAILED'}")
print("=" * 70)
