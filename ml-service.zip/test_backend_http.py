import requests

print("--- TESTING BACKEND PORT 3000 ---")
with open("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "rb") as f:
    files = {"image": ("user_hd_Screenshot.png", f, "image/png")}
    data = {"animalType": "Buffalo"}
    res = requests.post("http://localhost:3000/api/cases/predict", files=files, data=data)
    print("Backend Status code:", res.status_code)
    resp = res.json()
    print("isBuffalo:", resp.get("isBuffalo"))
    print("Prediction:", resp.get("prediction") or resp.get("diseasePrediction"))
    print("Confidence:", resp.get("confidence") or resp.get("confidenceScore"))

with open("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "rb") as f:
    files = {"image": ("china.jpg", f, "image/jpeg")}
    data = {"animalType": "Buffalo"}
    res = requests.post("http://localhost:3000/api/cases/predict", files=files, data=data)
    print("\nNon-Buffalo Backend Status code:", res.status_code)
    resp = res.json()
    print("isBuffalo:", resp.get("isBuffalo"))
    print("Status:", resp.get("status"))
    print("Entity:", resp.get("entityType"))
    print("Subject:", resp.get("predictedSubject"))
