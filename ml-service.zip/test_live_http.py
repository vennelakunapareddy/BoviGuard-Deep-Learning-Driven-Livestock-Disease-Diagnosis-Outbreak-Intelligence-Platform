import urllib.request
import json
import requests

print("--- 1. ML SERVICE HEALTH ---")
res = requests.get("http://127.0.0.1:5000/health")
print("Status code:", res.status_code)
print("Health:", res.json())

print("\n--- 2. PREDICT ON USER MASTITIS SCREENSHOT ---")
with open("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "rb") as f:
    files = {"image": ("user_hd_Screenshot.png", f, "image/png")}
    res = requests.post("http://127.0.0.1:5000/predict", files=files)
    print("Status code:", res.status_code)
    data = res.json()
    print("isBuffalo:", data.get("isBuffalo"))
    print("Prediction:", data.get("prediction"))
    print("Confidence:", data.get("confidenceScore"))

print("\n--- 3. PREDICT ON NON-BUFFALO IMAGE (CHINA TEMPLE) ---")
with open("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "rb") as f:
    files = {"image": ("china.jpg", f, "image/jpeg")}
    res = requests.post("http://127.0.0.1:5000/predict", files=files)
    print("Status code:", res.status_code)
    data = res.json()
    print("isBuffalo:", data.get("isBuffalo"))
    print("Status:", data.get("status"))
    print("Subject:", data.get("predictedSubject"))
    print("Message:", data.get("message"))
