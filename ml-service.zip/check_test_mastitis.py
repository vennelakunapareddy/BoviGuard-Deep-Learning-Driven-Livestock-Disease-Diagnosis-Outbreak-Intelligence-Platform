import os
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image

ckpt = torch.load("buffalo_model.pth", map_location="cpu", weights_only=False)
classes = ckpt.get("classes", ['Foot_and_Mouth_Disease', 'Healthy_Buffalo', 'Lumpy_Skin_Disease', 'Mastitis'])

model = models.efficientnet_b0(weights=None)
in_features = model.classifier[1].in_features
model.classifier = nn.Sequential(
    nn.Dropout(p=0.2),
    nn.Linear(in_features, 512),
    nn.BatchNorm1d(512),
    nn.SiLU(),
    nn.Dropout(p=0.15),
    nn.Linear(512, 4),
)
model.load_state_dict(ckpt["model_state_dict"])
model.eval()

img_size = ckpt.get("image_size", (240, 240))
norm_mean = ckpt.get("norm_mean", [0.485, 0.456, 0.406])
norm_std = ckpt.get("norm_std", [0.229, 0.224, 0.225])

eval_transform = transforms.Compose([
    transforms.Resize(img_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=norm_mean, std=norm_std),
])

print("=== TESTING ALL 10 TEST MASTITIS IMAGES ===")
for f in sorted(os.listdir("buffalo_dataset/test/Mastitis")):
    fp = os.path.join("buffalo_dataset/test/Mastitis", f)
    img = Image.open(fp).convert("RGB")
    t = eval_transform(img).unsqueeze(0)
    with torch.no_grad():
        out = model(t)
        probs = torch.softmax(out, dim=-1).squeeze(0)
    pred_idx = int(torch.argmax(probs).item())
    print(f"File {f}: Pred={classes[pred_idx]} (idx {pred_idx}) | Mastitis Prob={probs[3]*100:.1f}% | Lumpy Prob={probs[2]*100:.1f}%")
