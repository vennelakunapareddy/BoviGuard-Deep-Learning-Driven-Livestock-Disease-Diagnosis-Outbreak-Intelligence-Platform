import io
import base64
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image

def get_target_layer(model, arch_name="mobilenetv2"):
    arch_lower = str(arch_name).lower()
    if "resnet" in arch_lower:
        return model.layer4[-1]
    elif "efficientnet" in arch_lower:
        return model.features[-1]
    else:
        if hasattr(model, "features"):
            return model.features[-1]
        elif hasattr(model, "model") and hasattr(model.model, "features"):
            return model.model.features[-1]
    return list(model.children())[0][-1]

class GradCAM:
    def __init__(self, model, target_layer=None, arch_name="mobilenetv2"):
        self.model = model
        self.target_layer = target_layer or get_target_layer(model, arch_name)
        self.gradients = None
        self.activations = None
        
        def save_activation(module, input, output):
            self.activations = output.detach()

        def save_gradient(module, grad_input, grad_output):
            self.gradients = grad_output[0].detach()

        self.target_layer.register_forward_hook(save_activation)
        self.target_layer.register_full_backward_hook(save_gradient)

    def generate(self, input_tensor, target_class=None):
        self.model.eval()
        self.model.zero_grad()

        output = self.model(input_tensor)
        if target_class is None:
            target_class = output.argmax(dim=1).item()

        score = output[0, target_class]
        score.backward()

        gradients = self.gradients[0]
        activations = self.activations[0]

        weights = torch.mean(gradients, dim=(1, 2), keepdim=True)
        cam = torch.sum(weights * activations, dim=0)
        cam = F.relu(cam)

        cam_min, cam_max = cam.min(), cam.max()
        if cam_max > cam_min:
            cam = (cam - cam_min) / (cam_max - cam_min)
        else:
            cam = torch.zeros_like(cam)

        return cam.cpu().numpy(), target_class

def overlay_heatmap_on_image(pil_img, cam_map, alpha=0.4):
    try:
        import cv2
        w, h = pil_img.size
        cam_resized = cv2.resize(cam_map, (w, h))
        heatmap_uint8 = np.uint8(255 * cam_resized)
        color_heatmap = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
        color_heatmap_rgb = cv2.cvtColor(color_heatmap, cv2.COLOR_BGR2RGB)
        
        orig_np = np.array(pil_img.convert("RGB"))
        blended = np.uint8(orig_np * (1 - alpha) + color_heatmap_rgb * alpha)
        return Image.fromarray(blended)
    except Exception:
        return pil_img

def generate_gradcam_base64(model, input_tensor, pil_img, target_class=None, arch_name="mobilenetv2"):
    try:
        cam_engine = GradCAM(model, arch_name=arch_name)
        cam_map, pred_idx = cam_engine.generate(input_tensor, target_class=target_class)
        overlay_img = overlay_heatmap_on_image(pil_img, cam_map)
        
        buf = io.BytesIO()
        overlay_img.save(buf, format="JPEG")
        b64_str = base64.b64encode(buf.getvalue()).decode("utf-8")
        return f"data:image/jpeg;base64,{b64_str}", overlay_img
    except Exception as e:
        print("Grad-CAM generation exception:", e)
        return None, pil_img
