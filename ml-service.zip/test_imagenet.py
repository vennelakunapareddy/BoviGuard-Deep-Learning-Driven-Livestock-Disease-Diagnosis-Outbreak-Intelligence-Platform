import torch
from torchvision import models, transforms
from PIL import Image
import urllib.request

# Load lightweight ImageNet classifier
weights = models.MobileNet_V3_Small_Weights.DEFAULT
imgnet_model = models.mobilenet_v3_small(weights=weights).eval()
categories = weights.meta["categories"]

preprocess = weights.transforms()

bovine_keywords = [
    "water buffalo", "bison", "ox", "bull", "cow", "cattle", "livestock", 
    "bovid", "dairy", "mammal", "pasture", "leather", "hide"
]

bovine_indices = [
    i for i, cat in enumerate(categories) 
    if any(k in cat.lower() for k in ["buffalo", "ox", "bison", "cattle", "bull", "cow"])
]
print("Bovine categories in ImageNet:", [(i, categories[i]) for i in bovine_indices])

def check_is_buffalo(pil_img):
    t = preprocess(pil_img).unsqueeze(0)
    with torch.no_grad():
        logits = imgnet_model(t)
        probs = torch.softmax(logits, dim=-1).squeeze(0)
    
    top5_probs, top5_indices = torch.topk(probs, 5)
    top1_cat = categories[top5_indices[0]]
    top1_prob = float(top5_probs[0])
    
    print(f"Top 1: {top1_cat} ({top1_prob*100:.1f}%)")
    for idx, p in zip(top5_indices, top5_probs):
        print(f"   - {categories[idx]}: {float(p)*100:.1f}%")

# Test on a buffalo image
import glob
mastitis_sample = glob.glob("real_world_holdout/Mastitis/Data/mastitis/*")[0]
print("\nTesting mastitis sample:", mastitis_sample)
check_is_buffalo(Image.open(mastitis_sample).convert("RGB"))

healthy_sample = glob.glob("real_world_holdout/healthy buffalo/**")[0]
if not glob.os.path.isfile(healthy_sample):
    healthy_sample = [f for f in glob.glob("real_world_holdout/healthy buffalo/**", recursive=True) if glob.os.path.isfile(f)][0]
print("\nTesting healthy buffalo sample:", healthy_sample)
check_is_buffalo(Image.open(healthy_sample).convert("RGB"))
