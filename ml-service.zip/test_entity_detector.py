import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image
import os
import glob

# Load cached MobileNetV2 ImageNet classifier
weights = models.MobileNet_V2_Weights.DEFAULT
entity_model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transform = weights.transforms()

# Bovine / Cattle / Buffalo category indices in ImageNet-1K:
# 345: 'ox'
# 346: 'water buffalo, water ox, Asiatic buffalo, Bubalus bubalis'
# 347: 'bison'
BOVINE_INDICES = {345, 346, 347}

# Extended livestock / herbivore / farm categories:
LIVESTOCK_INDICES = {
    341, 342, 343, 344, # hog, wild boar, warthog, hippo
    345, 346, 347,       # ox, water buffalo, bison
    348, 349, 350,       # ram, bighorn, ibex
    351, 352, 353,       # hartebeest, impala, gazelle
    354, 355             # camel, llama
}

def detect_subject(pil_img: Image.Image):
    t = transform(pil_img).unsqueeze(0)
    with torch.no_grad():
        logits = entity_model(t)
        probs = F.softmax(logits, dim=-1).squeeze(0)
    
    top5_probs, top5_indices = torch.topk(probs, 5)
    top1_idx = int(top5_indices[0])
    top1_prob = float(top5_probs[0])
    top1_cat = categories[top1_idx]
    
    # Calculate bovine aggregate probability
    bovine_prob = sum(float(probs[i]) for i in BOVINE_INDICES)
    livestock_prob = sum(float(probs[i]) for i in LIVESTOCK_INDICES)
    
    return {
        "top1_category": top1_cat,
        "top1_prob": round(top1_prob * 100, 2),
        "bovine_prob": round(bovine_prob * 100, 2),
        "livestock_prob": round(livestock_prob * 100, 2),
        "top5": [(categories[int(idx)], round(float(p) * 100, 2)) for idx, p in zip(top5_indices, top5_probs)]
    }

# Create a synthetic non-buffalo image (e.g. solid color or simple shapes) to test
non_buffalo_img = Image.new("RGB", (224, 224), color=(200, 50, 50))
print("Synthetic non-buffalo:", detect_subject(non_buffalo_img))

# Test on a real healthy buffalo image
healthy_files = [f for f in glob.glob("real_world_holdout/healthy buffalo/**", recursive=True) if os.path.isfile(f)]
if healthy_files:
    print("\nHealthy buffalo sample:", healthy_files[0])
    print(detect_subject(Image.open(healthy_files[0])))
