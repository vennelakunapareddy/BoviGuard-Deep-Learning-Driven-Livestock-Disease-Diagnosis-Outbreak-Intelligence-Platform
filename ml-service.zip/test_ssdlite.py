import torch
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from torchvision import transforms
from PIL import Image
import glob
import os

weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
model = ssdlite320_mobilenet_v3_large(weights=weights).eval()
categories = weights.meta["categories"]
preprocess = weights.transforms()

def detect_objects(pil_img):
    t = preprocess(pil_img).unsqueeze(0)
    with torch.no_grad():
        preds = model(t)[0]
    
    keep = preds["scores"] > 0.40
    boxes = preds["boxes"][keep]
    scores = preds["scores"][keep]
    labels = preds["labels"][keep]
    
    results = []
    for l, s in zip(labels, scores):
        cat = categories[int(l)]
        results.append((cat, round(float(s) * 100, 1)))
    return results

healthy = [f for f in glob.glob("real_world_holdout/healthy buffalo/**", recursive=True) if os.path.isfile(f)][0]
print("Healthy buffalo:", detect_objects(Image.open(healthy)))

china = "venv/Lib/site-packages/sklearn/datasets/images/china.jpg"
print("China temple:", detect_objects(Image.open(china)))

flower = "venv/Lib/site-packages/sklearn/datasets/images/flower.jpg"
print("Flower:", detect_objects(Image.open(flower)))

mastitis = glob.glob("real_world_holdout/Mastitis/Data/mastitis/*")[0]
print("Mastitis teat:", detect_objects(Image.open(mastitis)))
