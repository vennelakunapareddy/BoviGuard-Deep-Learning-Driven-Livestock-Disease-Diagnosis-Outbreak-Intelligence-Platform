import os
import glob
from PIL import Image
from model import BuffaloDiseaseModel

m = BuffaloDiseaseModel()

print("\n" + "=" * 70)
print("1. TESTING MASTITIS IMAGES (ENSURING NOT PREDICTING AS LUMPY)")
print("=" * 70)
mastitis_tests = [
    "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png",
    "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213815.png",
    "real_world_holdout/Mastitis/user_live_media_1790438947823.png",
    "real_world_holdout/Mastitis/user_uploaded_mastitis_udder.jpg",
    "real_world_holdout/Mastitis/Data/mastitis/Base-ringing-400x284.jpg",
    "real_world_holdout/Mastitis/Data/mastitis/chaps-5.1.orifice-400x284.png"
]
for p in mastitis_tests:
    if os.path.exists(p):
        res = m.predict_detailed(Image.open(p))
        fname = os.path.basename(p)
        print(f"File: {fname:40s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | isBuffalo: {res['isBuffalo']}")

print("\n" + "=" * 70)
print("2. TESTING LUMPY SKIN DISEASE (NODES ON SKIN)")
print("=" * 70)
lumpy_tests = glob.glob("real_world_holdout/lumpy/**/Lumpy_Skin*.png", recursive=True)[:4]
for p in lumpy_tests:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:40s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | isBuffalo: {res['isBuffalo']}")

print("\n" + "=" * 70)
print("3. TESTING HEALTHY BUFFALO (CLEAR SKIN, NO WOUNDS, NO LUMPS)")
print("=" * 70)
healthy_tests = [f for f in glob.glob("real_world_holdout/healthy buffalo/**", recursive=True) if os.path.isfile(f)][:4]
for p in healthy_tests:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:40s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | isBuffalo: {res['isBuffalo']}")

print("\n" + "=" * 70)
print("4. TESTING FOOT AND MOUTH DISEASE (MOUTH SALIVA, HOOF LESIONS)")
print("=" * 70)
fmd_tests = [f for f in glob.glob("real_world_holdout/fmd/**", recursive=True) if os.path.isfile(f)][:4]
for p in fmd_tests:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:40s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | isBuffalo: {res['isBuffalo']}")

print("\n" + "=" * 70)
print("5. TESTING NON-BUFFALO IMAGES (MUST BE REJECTED WITH isBuffalo=False)")
print("=" * 70)
non_buffalo_tests = [
    ("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "China Temple"),
    ("venv/Lib/site-packages/sklearn/datasets/images/flower.jpg", "Flower"),
]
for p, name in non_buffalo_tests:
    if os.path.exists(p):
        res = m.predict_detailed(Image.open(p))
        print(f"File: {name:25s} -> isBuffalo: {res['isBuffalo']} | Status: {res['status']} | Subject: {res.get('predictedSubject')} {res.get('detectedEntityIcon')}")

# Also test synthetic blank frame
blank_img = Image.new("RGB", (224, 224), (20, 20, 20))
blank_res = m.predict_detailed(blank_img)
print(f"File: {'Blank Black Frame':25s} -> isBuffalo: {blank_res['isBuffalo']} | Status: {blank_res['status']} | Subject: {blank_res.get('predictedSubject')} {blank_res.get('detectedEntityIcon')}")
