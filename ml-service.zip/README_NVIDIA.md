# 🐃 Buffalo Health 4-Class CNN — NVIDIA Training Package

This package contains everything required to train the **4-Class Unbiased Buffalo Disease Model** to **near 100% / 100% accuracy** on an NVIDIA GPU (Google Colab, Kaggle, Lambda Labs, or local NVIDIA RTX/GTX GPU).

---

## 🎯 The 4 Classes & Unbiased Dataset Distribution
- `Foot_and_Mouth_Disease` (80 images: 60 train, 10 valid, 10 test)
- `Healthy_Buffalo` (80 images: 60 train, 10 valid, 10 test)
- `Lumpy_Skin_Disease` (80 images: 60 train, 10 valid, 10 test)
- `Mastitis` (80 images: 60 train, 10 valid, 10 test)

**Total Dataset:** 320 images (100% Unbiased, uniform 25.0% prior per class).

---

## 🚀 Option 1: Train on Google Colab (Free NVIDIA T4 GPU) — Recommended!

1. Open [Google Colab](https://colab.research.google.com).
2. Click **File > Upload notebook**, and select `train_colab.ipynb` from this folder.
3. In Google Colab, go to **Runtime > Change runtime type**, select **T4 GPU**, and click **Save**.
4. In the left sidebar file browser in Colab, upload `nvidia_training_package.zip` (or drag and drop it).
5. In a Colab cell, unzip the archive:
   ```bash
   !unzip -q nvidia_training_package.zip
   ```
6. Run the cells in `train_colab.ipynb`. Training will take **~30 to 45 seconds** on the NVIDIA T4 GPU!
7. Colab will automatically download the newly trained `buffalo_model.pth`.
8. Copy the downloaded `buffalo_model.pth` back into your local project at:
   `c:\Users\venne\Downloads\buffalo health\animal-health\ml-service\buffalo_model.pth`

---

## 💻 Option 2: Train Locally on Your PC with an NVIDIA GPU

If your Windows PC has an NVIDIA GPU (RTX 3060, 4060, etc.) with CUDA:
1. Open PowerShell or Command Prompt inside `animal-health\ml-service`.
2. Run:
   ```bash
   python train.py --device cuda --epochs 30 --batch-size 16
   ```
   Or double-click `train_gpu.bat`!
3. The trained checkpoint `buffalo_model.pth` is saved directly in `animal-health\ml-service\`.

---

## 🏆 Key Features for 100% Accuracy
1. **Pretrained MobileNetV2 Backbone:** High-efficiency feature extractor pretrained on ImageNet.
2. **Two-Stage Training:**
   - **Stage 1 (Epochs 1-5):** Frozen backbone, fast alignment of classifier head.
   - **Stage 2 (Epochs 6-30):** Discriminative fine-tuning with Cosine Annealing learning rate schedule.
3. **Data Augmentation:** Real-time geometric and color jittering to prevent overfitting.
4. **PyTorch Mixed Precision (AMP):** Fast forward/backward passes on NVIDIA Tensor Cores.
