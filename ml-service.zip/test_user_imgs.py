import requests
import json

url = 'http://localhost:3000/api/cases/predict'
files = {'image': open('crop_udder_user.png', 'rb')}
r = requests.post(url, files=files)
print('=' * 60)
print('1. UDDER PHOTO TO LOCALHOST:3000')
print('Status:', r.status_code)
try:
    print(json.dumps(r.json(), indent=2))
except Exception as e:
    print(r.text)

cxx_path = r'C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png'
files_cxx = {'image': open(cxx_path, 'rb')}
r_cxx = requests.post(url, files=files_cxx)
print('=' * 60)
print('2. C++ SCREENSHOT TO LOCALHOST:3000')
print('Status:', r_cxx.status_code)
try:
    print(json.dumps(r_cxx.json(), indent=2))
except Exception as e:
    print(r_cxx.text)
