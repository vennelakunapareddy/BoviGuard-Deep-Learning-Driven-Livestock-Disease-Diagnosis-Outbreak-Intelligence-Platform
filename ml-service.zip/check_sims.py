import torch
import torch.nn.functional as F
from PIL import Image
from model import BuffaloDiseaseModel

m = BuffaloDiseaseModel()

for name, path in [
    ("China Temple", "venv/Lib/site-packages/sklearn/datasets/images/china.jpg"),
    ("Flower", "venv/Lib/site-packages/sklearn/datasets/images/flower.jpg"),
    ("Mastitis Rear Shot", "real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213815.png")
]:
    img = Image.open(path).convert("RGB")
    ft = m.feature_transform(img).unsqueeze(0)
    emb = F.normalize(m.feature_extractor(ft).squeeze(0), p=2, dim=0)
    sims = {c: float(torch.dot(emb, m.centroids[c])) for c in m.class_names}
    print(f"{name:20s}: {sims}")
