import os
import shutil
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = BASE_DIR / "nvidia_training_package"
ZIP_FILE_ML = BASE_DIR / "nvidia_training_package.zip"
ZIP_FILE_ROOT = BASE_DIR.parent.parent / "nvidia_training_package.zip"

def build_package():
    print(f"Building NVIDIA training package at: {PACKAGE_DIR}")
    if PACKAGE_DIR.exists():
        shutil.rmtree(PACKAGE_DIR)
    PACKAGE_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Copy buffalo_dataset
    src_dataset = BASE_DIR / "buffalo_dataset"
    dst_dataset = PACKAGE_DIR / "buffalo_dataset"
    print("Copying buffalo_dataset (train, valid, test)...")
    shutil.copytree(src_dataset, dst_dataset)

    # 2. Copy code and config files
    files_to_copy = [
        "train.py",
        "model.py",
        "train_colab.ipynb",
        "classes.json",
        "class_mapping.json",
        "training_config.json",
        "preprocessing_config.json",
        "requirements.txt",
        "README_NVIDIA.md",
        "train_gpu.bat"
    ]

    for fname in files_to_copy:
        src = BASE_DIR / fname
        dst = PACKAGE_DIR / fname
        if src.exists():
            shutil.copy2(src, dst)
            print(f"  Copied {fname}")

    # 3. Create zip archive
    print(f"\nCompressing into {ZIP_FILE_ML}...")
    with zipfile.ZipFile(ZIP_FILE_ML, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(PACKAGE_DIR):
            for file in files:
                abs_path = Path(root) / file
                rel_path = abs_path.relative_to(PACKAGE_DIR)
                zf.write(abs_path, arcname=str(rel_path))

    # Also copy to root workspace directory for easy access
    shutil.copy2(ZIP_FILE_ML, ZIP_FILE_ROOT)
    print(f"Also copied zip to root: {ZIP_FILE_ROOT}")

    size_mb = ZIP_FILE_ML.stat().st_size / (1024 * 1024)
    print(f"\n[SUCCESS] Package built! Size: {size_mb:.2f} MB")
    print(f"Folder ready to upload: {PACKAGE_DIR}")
    print(f"Zip ready to upload:    {ZIP_FILE_ROOT}")

if __name__ == "__main__":
    build_package()
