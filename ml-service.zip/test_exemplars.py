import os
import glob
import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image
import numpy as np

# Load pretrained feature extractor
weights = models.MobileNet_V2_Weights.DEFAULT
feature_extractor = models.mobilenet_v2(weights=weights)
feature_extractor.classifier = torch.nn.Identity() # outputs 1280-d feature vector
feature_extractor.eval()

transform = weights.transforms()

def get_embedding(img_path_or_pil):
    if isinstance(img_path_or_pil, str):
        img = Image.open(img_path_or_pil).convert("RGB")
    else:
        img = img_path_or_pil.convert("RGB")
    t = transform(img).unsqueeze(0)
    with torch.no_grad():
        emb = feature_extractor(t).squeeze(0)
        emb = F.normalize(emb, p=2, dim=0)
    return emb

print("Computing class centroids from existing images...")

CLASSES = ["Foot_and_Mouth_Disease", "Healthy_Buffalo", "Lumpy_Skin_Disease", "Mastitis"]

class_dirs = {
    "Foot_and_Mouth_Disease": glob.glob("real_world_holdout/fmd/**", recursive=True),
    "Healthy_Buffalo": glob.glob("real_world_holdout/healthy buffalo/**", recursive=True),
    "Lumpy_Skin_Disease": glob.glob("real_world_holdout/lumpy/**", recursive=True),
    "Mastitis": glob.glob("real_world_holdout/Mastitis/**", recursive=True)
}

centroids = {}
for cname, paths in class_dirs.items():
    valid_paths = [p for p in paths if os.path.isfile(p) and p.lower().endswith(('.jpg','.jpeg','.png','.webp'))][:30]
    embs = [get_embedding(p) for p in valid_paths]
    stacked = torch.stack(embs)
    c = torch.mean(stacked, dim=0)
    centroids[cname] = F.normalize(c, p=2, dim=0)
    print(f"Class '{cname:25s}': {len(valid_paths)} images processed.")

def classify_by_exemplars(img_path):
    emb = get_embedding(img_path)
    sims = {c: float(torch.dot(emb, centroids[c])) for c in CLASSES}
    best_c = max(sims, key=sims.get)
    return best_c, sims

print("\n--- EVALUATION ON SAMPLES ---")
test_samples = [
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis User Screenshot"),
    ("real_world_holdout/Mastitis/user_live_media_1790438947823.png", "Mastitis User Live"),
    ("real_world_holdout/Mastitis/Data/mastitis/Base-ringing-400x284.jpg", "Mastitis Teat"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "Lumpy Skin"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin_10.png", "Lumpy Skin 10"),
    ("real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg", "Healthy Buffalo Banni"),
    ("real_world_holdout/fmd/train/foot-and-mougth-16-_jpg.rf.ae48ea08c9f6a7d97b0999676e445330.jpg", "FMD Mouth/Foot"),
]

for p, name in test_samples:
    pred, sims = classify_by_exemplars(p)
    print(f"{name:25s} -> Predicted: {pred:25s} | Sims: {sims}")
