import torch
import torch.nn.functional as F
from torchvision import models
from PIL import Image, ImageStat
import os

weights = models.MobileNet_V2_Weights.DEFAULT
imgnet_model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transform = weights.transforms()

# Bovine synset categories in ImageNet:
# 345: ox
# 346: water buffalo, water ox, Bubalus bubalis
# 347: bison
BOVINE_CATEGORIES = {345, 346, 347}

def detect_subject(pil_img: Image.Image):
    # 1. Variance check for blank/solid images
    stat = ImageStat.Stat(pil_img)
    var = sum(stat.var) / len(stat.var)
    if var < 12.0:
        return {
            "is_buffalo": False,
            "entity": "Blank / Uniform Image",
            "message": "Prediction failed: No buffalo detected in the image (blank or uniform frame)."
        }

    # 2. ImageNet-1K Subject Classification
    t = transform(pil_img).unsqueeze(0)
    with torch.no_grad():
        logits = imgnet_model(t)
        probs = F.softmax(logits, dim=-1).squeeze(0)

    top5_p, top5_idx = torch.topk(probs, 5)
    top1_idx = int(top5_idx[0])
    top1_cat = categories[top1_idx].lower()
    top1_conf = float(top5_p[0]) * 100

    top5_cats = [categories[int(i)].lower() for i in top5_idx]
    top5_confs = [float(p) * 100 for p in top5_p]

    # Check for direct water buffalo / bison / ox detection
    has_buffalo = any(idx in BOVINE_CATEGORIES for idx in top5_idx[:3])

    # Check if Top-1 is an obvious non-buffalo category
    # Documents, code, websites, screens
    doc_keywords = ["web site", "menu", "envelope", "screen", "monitor", "laptop", "cellular telephone", 
                    "crossword", "rule", "paper", "comic book", "book jacket", "binder", "packet"]
    if any(k in top1_cat for k in doc_keywords):
        return {
            "is_buffalo": False,
            "entity": f"Digital Screen / Document ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Domestic Dogs
    dog_keywords = ["dog", "retriever", "terrier", "shepherd", "spaniel", "poodle", "hound", "collie", "pug", 
                    "bulldog", "chihuahua", "rottweiler", "beagle", "boxer", "maltese"]
    if any(k in top1_cat for k in dog_keywords):
        return {
            "is_buffalo": False,
            "entity": f"Domestic Dog ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Domestic Cats
    cat_keywords = ["cat", "tabby", "siamese", "persian", "egyptian cat"]
    if any(k in top1_cat for k in cat_keywords):
        return {
            "is_buffalo": False,
            "entity": f"Domestic Cat ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Other non-buffalo animals: horses, zebras, sheep, goats, camels
    other_animal_keywords = ["horse", "sorrel", "zebra", "ram", "bighorn", "ibex", "hartebeest", "gazelle", "camel"]
    if any(k in top1_cat for k in other_animal_keywords) and not has_buffalo:
        return {
            "is_buffalo": False,
            "entity": f"Non-Buffalo Animal ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Vehicles
    veh_keywords = ["car", "automobile", "truck", "cab", "van", "jeep", "bus", "bicycle", "motorcycle", "airplane", "boat"]
    if any(k in top1_cat for k in veh_keywords):
        return {
            "is_buffalo": False,
            "entity": f"Vehicle ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Buildings / Architecture
    bldg_keywords = ["palace", "castle", "monastery", "church", "mosque", "tile roof", "bell cote", "beacon", "bridge", "house"]
    if any(k in top1_cat for k in bldg_keywords):
        return {
            "is_buffalo": False,
            "entity": f"Building / Architecture ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Flowers / Plants / Landscape
    plant_keywords = ["honeycomb", "flower", "daisy", "rose", "mushroom", "pomegranate", "corn", "ear", "tree", "pot"]
    if any(k in top1_cat for k in plant_keywords) and not has_buffalo:
        return {
            "is_buffalo": False,
            "entity": f"Plant / Object ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # Humans & clothing
    human_keywords = ["suit", "jersey", "t-shirt", "sweatshirt", "gown", "sunglasses", "wig", "mask", "military uniform", "cloak"]
    if any(k in top1_cat for k in human_keywords):
        return {
            "is_buffalo": False,
            "entity": f"Human / Person ({categories[top1_idx]})",
            "message": f"Prediction failed: No buffalo detected in the image (detected {categories[top1_idx]})."
        }

    # If bovine was detected or animal skin texture detected
    return {
        "is_buffalo": True,
        "entity": "Water Buffalo",
        "top_category": categories[top1_idx]
    }

print("=== TESTING COMPLETE SUBJECT DETECTOR ===")
test_images = [
    (r"C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png", "C++ Code Screenshot"),
    ("venv/Lib/site-packages/sklearn/datasets/images/china.jpg", "China Temple"),
    ("venv/Lib/site-packages/sklearn/datasets/images/flower.jpg", "Flower"),
    ("real_world_holdout/healthy buffalo/buffalo/banni/0caae52ef510154bb215e99a7db35607.jpg", "Healthy Buffalo"),
    ("real_world_holdout/lumpy/Lumpy Skin Images Dataset/Lumpy Skin/Lumpy_Skin.png", "Lumpy Skin Sample"),
    ("real_world_holdout/Mastitis/user_hd_Screenshot_2026-09-26_213716.png", "Mastitis Teat Screenshot")
]

for p, label in test_images:
    if os.path.exists(p):
        res = detect_subject(Image.open(p).convert("RGB"))
        print(f"[{label:25s}] -> is_buffalo={res['is_buffalo']} | Entity={res.get('entity')}")
