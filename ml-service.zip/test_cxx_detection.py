import torch
import torch.nn.functional as F
from torchvision import models
from PIL import Image

cxx_path = r'C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png'
img = Image.open(cxx_path).convert('RGB')

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transform = weights.transforms()

t = transform(img).unsqueeze(0)
with torch.no_grad():
    logits = model(t)
    probs = F.softmax(logits, dim=-1).squeeze(0)

top10_p, top10_idx = torch.topk(probs, 10)
print("Top 10 ImageNet categories for C++ code image:")
for p, idx in zip(top10_p, top10_idx):
    print(f"  {categories[int(idx)]}: {float(p)*100:.2f}%")
