import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
entity_model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transform = weights.transforms()

# Bovine / bovid / farm animal synsets in ImageNet
BOVINE_CLASSES = {"water buffalo", "ox", "bison", "cow", "bull", "cattle", "oxcart"}

# Explicit Non-Buffalo category groups
NON_BUFFALO_KEYWORDS = [
    # Vehicles
    "car", "automobile", "truck", "cab", "van", "jeep", "trailer", "bus", "train",
    "bicycle", "motorcycle", "moped", "airplane", "aircraft", "boat", "ship",
    # Dogs & Cats
    "dog", "retriever", "terrier", "spaniel", "shepherd", "hound", "poodle", "collie",
    "bulldog", "cat", "tabby", "siamese", "persian",
    # Humans & Clothing
    "suit", "jersey", "uniform", "t-shirt", "cardigan", "sweatshirt", "gown", "kimono",
    "swimming trunks", "bikini", "mask", "sunglasses", "sunglass", "wig", "lipstick",
    # Electronics
    "cellular telephone", "cell phone", "laptop", "notebook computer", "mouse", "keyboard",
    "screen", "monitor", "television", "ipod", "remote control",
    # Food & Household
    "pizza", "cheeseburger", "hotdog", "ice cream", "banana", "apple", "orange",
    "coffee mug", "cup", "teapot", "wine bottle", "beer bottle", "plate",
    "chair", "desk", "table", "book", "envelope", "comic book"
]

def classify_entity(pil_img: Image.Image):
    t = transform(pil_img).unsqueeze(0)
    with torch.no_grad():
        logits = entity_model(t)
        probs = F.softmax(logits, dim=-1).squeeze(0)
    
    top5_probs, top5_indices = torch.topk(probs, 5)
    top1_cat = categories[int(top5_indices[0])].lower()
    top1_prob = float(top5_probs[0]) * 100
    
    # Check if top-1 or top-3 is an explicit non-buffalo object with high probability
    is_non_buffalo = False
    detected_name = top1_cat
    
    for idx, prob in zip(top5_indices[:3], top5_probs[:3]):
        cat = categories[int(idx)].lower()
        p = float(prob) * 100
        if any(kw in cat for kw in NON_BUFFALO_KEYWORDS) and p >= 15.0:
            is_non_buffalo = True
            detected_name = cat
            break
            
    # Check if bovine is in top 5
    bovine_in_top5 = any(any(b in categories[int(idx)].lower() for b in BOVINE_CLASSES) for idx in top5_indices)
    if bovine_in_top5:
        is_non_buffalo = False
        
    return {
        "is_buffalo": not is_non_buffalo,
        "top1_category": top1_cat,
        "top1_prob": round(top1_prob, 2),
        "detected_entity": detected_name,
        "bovine_in_top5": bovine_in_top5
    }

print("Flower test:", classify_entity(Image.open('venv/Lib/site-packages/sklearn/datasets/images/flower.jpg')))
print("China temple test:", classify_entity(Image.open('venv/Lib/site-packages/sklearn/datasets/images/china.jpg')))

import glob
healthy = [f for f in glob.glob("real_world_holdout/healthy buffalo/**", recursive=True) if glob.os.path.isfile(f)][0]
print("Healthy buffalo test:", classify_entity(Image.open(healthy)))

mastitis = glob.glob("real_world_holdout/Mastitis/Data/mastitis/*")[0]
print("Mastitis teat test:", classify_entity(Image.open(mastitis)))
