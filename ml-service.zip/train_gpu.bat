@echo off
setlocal
echo ====================================================================
echo  BUFFALO HEALTH MONITORING - 4-CLASS UNBIASED TRAINING (NVIDIA GPU)
echo ====================================================================
cd /d "%~dp0"

where nvidia-smi >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [OK] NVIDIA GPU detected:
    nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader
) else (
    echo [INFO] nvidia-smi not in standard path or checking CUDA runtime...
)

if exist "venv\Scripts\python.exe" (
    echo Using virtual environment Python: venv\Scripts\python.exe
    venv\Scripts\python.exe train.py --epochs 30 --batch-size 16
) else (
    echo Using system Python: python
    python train.py --epochs 30 --batch-size 16
)

echo ====================================================================
echo  Training completed! Check buffalo_model.pth and metrics.json
echo ====================================================================
pause
