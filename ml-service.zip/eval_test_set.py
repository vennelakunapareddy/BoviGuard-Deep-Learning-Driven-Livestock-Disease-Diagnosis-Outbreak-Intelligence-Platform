import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms, datasets
from torch.utils.data import DataLoader
from sklearn.metrics import classification_report, confusion_matrix
import os

ckpt = torch.load("buffalo_model.pth", map_location="cpu", weights_only=False)
classes = ckpt.get("classes", ['Foot_and_Mouth_Disease', 'Healthy_Buffalo', 'Lumpy_Skin_Disease', 'Mastitis'])

model = models.efficientnet_b0(weights=None)
in_features = model.classifier[1].in_features
model.classifier = nn.Sequential(
    nn.Dropout(p=0.2),
    nn.Linear(in_features, 512),
    nn.BatchNorm1d(512),
    nn.SiLU(),
    nn.Dropout(p=0.15),
    nn.Linear(512, 4),
)
model.load_state_dict(ckpt["model_state_dict"])
model.eval()

img_size = ckpt.get("image_size", (240, 240))
norm_mean = ckpt.get("norm_mean", [0.485, 0.456, 0.406])
norm_std = ckpt.get("norm_std", [0.229, 0.224, 0.225])

eval_transform = transforms.Compose([
    transforms.Resize(img_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=norm_mean, std=norm_std),
])

test_ds = datasets.ImageFolder("buffalo_dataset/test", transform=eval_transform)
test_loader = DataLoader(test_ds, batch_size=10, shuffle=False)

print("Dataset classes detected by ImageFolder:", test_ds.classes)
print("Dataset class_to_idx:", test_ds.class_to_idx)

all_preds, all_labels = [], []
with torch.no_grad():
    for inputs, labels in test_loader:
        out1 = model(inputs)
        out2 = model(torch.flip(inputs, dims=[3]))
        outputs = 0.60 * out1 + 0.40 * out2
        preds = torch.argmax(outputs, dim=1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

print("\nCLASSIFICATION REPORT ON TEST SET:")
print(classification_report(all_labels, all_preds, target_names=classes, digits=4))
print("CONFUSION MATRIX:")
print(confusion_matrix(all_labels, all_preds))
