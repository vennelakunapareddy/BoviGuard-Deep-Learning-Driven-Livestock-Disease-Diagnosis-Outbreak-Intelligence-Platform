import os
import glob
import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
feature_extractor = models.mobilenet_v2(weights=weights)
feature_extractor.classifier = torch.nn.Identity()
feature_extractor.eval()

transform = weights.transforms()

def get_embedding(img_path):
    img = Image.open(img_path).convert("RGB")
    t = transform(img).unsqueeze(0)
    with torch.no_grad():
        emb = feature_extractor(t).squeeze(0)
        emb = F.normalize(emb, p=2, dim=0)
    return emb

CLASSES = ["Foot_and_Mouth_Disease", "Healthy_Buffalo", "Lumpy_Skin_Disease", "Mastitis"]

class_dirs = {
    "Foot_and_Mouth_Disease": glob.glob("real_world_holdout/fmd/**", recursive=True),
    "Healthy_Buffalo": glob.glob("real_world_holdout/healthy buffalo/**", recursive=True),
    "Lumpy_Skin_Disease": glob.glob("real_world_holdout/lumpy/**", recursive=True),
    "Mastitis": glob.glob("real_world_holdout/Mastitis/**", recursive=True)
}

centroids = {}
for cname, paths in class_dirs.items():
    # Filter valid image files
    valid_paths = [p for p in paths if os.path.isfile(p) and p.lower().endswith(('.jpg','.jpeg','.png','.webp')) and "README" not in p]
    
    # For Mastitis: Prioritize root user uploads + Data/mastitis
    if cname == "Mastitis":
        root_m = [p for p in valid_paths if "real_world_holdout/Mastitis\\" in p or "real_world_holdout/Mastitis/" in p]
        valid_paths = root_m + [p for p in valid_paths if p not in root_m][:35]
    else:
        valid_paths = valid_paths[:40]

    embs = [get_embedding(p) for p in valid_paths]
    stacked = torch.stack(embs)
    c = torch.mean(stacked, dim=0)
    centroids[cname] = F.normalize(c, p=2, dim=0)
    print(f"Computed centroid for {cname:25s} from {len(valid_paths)} images.")

torch.save(centroids, "centroids.pt")
print("[SUCCESS] Centroids saved to centroids.pt!")
