import os
import glob
from pathlib import Path

base = Path("real_world_holdout")
classes = {
    "Foot_and_Mouth_Disease": base / "fmd",
    "Healthy_Buffalo": base / "healthy buffalo",
    "Lumpy_Skin_Disease": base / "lumpy",
    "Mastitis": base / "Mastitis"
}

exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

for cname, p in classes.items():
    imgs = [f for f in p.rglob("*") if f.is_file() and f.suffix.lower() in exts]
    print(f"{cname:25s}: {len(imgs):4d} valid images")
    # Show subdirectories
    subdirs = set(f.parent.relative_to(p) for f in imgs)
    for s in sorted(subdirs)[:5]:
        s_imgs = [f for f in imgs if f.parent.relative_to(p) == s]
        print(f"    - Subfolder '{str(s)}': {len(s_imgs)} images")
