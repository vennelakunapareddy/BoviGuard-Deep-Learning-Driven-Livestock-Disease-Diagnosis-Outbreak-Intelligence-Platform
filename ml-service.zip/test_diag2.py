import os
import glob
from PIL import Image
from model import BuffaloDiseaseModel

m = BuffaloDiseaseModel()

print("--- TESTING MASTITIS ROOT & USER IMAGES ---")
root_imgs = [os.path.join("real_world_holdout/Mastitis", f) for f in os.listdir("real_world_holdout/Mastitis") if f.lower().endswith(('.jpg', '.png'))]
for p in root_imgs:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:40s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | Probs: {res['probabilities']}")

print("\n--- TESTING MASTITIS DATA/MASTITIS IMAGES ---")
data_imgs = glob.glob("real_world_holdout/Mastitis/Data/mastitis/*")
for p in data_imgs[:10]:
    res = m.predict_detailed(Image.open(p))
    fname = os.path.basename(p)
    print(f"File: {fname:40s} -> Predicted: {res['prediction']:30s} (conf: {res['confidenceScore']}%) | Probs: {res['probabilities']}")
