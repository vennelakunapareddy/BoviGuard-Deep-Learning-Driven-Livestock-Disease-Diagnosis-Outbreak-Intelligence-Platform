import os
from pathlib import Path
from PIL import Image

holdout = Path("real_world_holdout")
for d in sorted(holdout.iterdir()):
    if not d.is_dir():
        continue
    imgs = [p for p in d.rglob("*") if p.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]]
    valid = []
    corrupted = []
    for p in imgs:
        try:
            with Image.open(p) as im:
                im.verify()
            valid.append(p)
        except Exception as e:
            corrupted.append((p, str(e)))
    print(f"Directory: {d.name} -> Found: {len(imgs)} images, Valid: {len(valid)}, Corrupted: {len(corrupted)}")
    if corrupted:
        print(f"  Corrupted: {corrupted[:3]}")
