import torch
from torchvision import models, transforms
from PIL import Image

ckpt = torch.load("buffalo_model.pth", map_location="cpu", weights_only=False)
classes = ckpt.get("classes")

model = models.efficientnet_b0(weights=None)
in_features = model.classifier[1].in_features
model.classifier = torch.nn.Sequential(
    torch.nn.Dropout(p=0.2),
    torch.nn.Linear(in_features, 512),
    torch.nn.BatchNorm1d(512),
    torch.nn.SiLU(),
    torch.nn.Dropout(p=0.15),
    torch.nn.Linear(512, 4),
)
model.load_state_dict(ckpt["model_state_dict"])
model.eval()

eval_transform = transforms.Compose([
    transforms.Resize((240, 240)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

img = Image.open("crop_udder_user.png").convert("RGB")
w, h = img.size

# Crop specifically to the udder & teats
udder_only = img.crop((int(w * 0.2), int(h * 0.1), int(w * 0.8), int(h * 0.9)))
udder_only.save("udder_only.png")

t = eval_transform(udder_only).unsqueeze(0)
with torch.no_grad():
    out = model(t)
    probs = torch.softmax(out, dim=-1).squeeze(0)

print("Udder-only crop prediction:")
for idx, c in enumerate(classes):
    print(f"  {c}: {probs[idx]*100:.2f}%")
