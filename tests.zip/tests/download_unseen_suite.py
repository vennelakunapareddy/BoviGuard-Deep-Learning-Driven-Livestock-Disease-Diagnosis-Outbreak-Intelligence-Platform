import os
import urllib.request
from PIL import Image, ImageDraw
import numpy as np

headers = {'User-Agent': 'Mozilla/5.0'}

# 1. Unseen Healthy Water Buffalo (Grazing in field)
url_healthy_buffalo = "https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?w=500&q=80"
# 2. Unseen Dairy Cow (Holstein black & white cow)
url_cow = "https://images.unsplash.com/photo-1546445317-29f4545e9d53?w=500&q=80"
# 3. Unseen Goat
url_goat = "https://images.unsplash.com/photo-1524024973431-2ad916746881?w=500&q=80"
# 4. Unseen Mastitis external case
url_mastitis_ext = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Mastitis_in_cow_udder.jpg/440px-Mastitis_in_cow_udder.jpg"

downloads = [
    ("unseen_healthy_buffalo.jpg", url_healthy_buffalo),
    ("unseen_cow.jpg", url_cow),
    ("unseen_goat.jpg", url_goat),
]

for name, url in downloads:
    if not os.path.exists(name):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=12) as response, open(name, 'wb') as f:
                f.write(response.read())
            print(f"[OK] Downloaded {name}")
        except Exception as e:
            print(f"[FAIL] {name}: {e}")
    else:
        print(f"[EXISTS] {name}")

# Generate Random Abstract Texture (Wallpaper / Brick / Noise)
if not os.path.exists("random_texture.jpg"):
    arr = np.zeros((400, 400, 3), dtype=np.uint8)
    for i in range(400):
        for j in range(400):
            arr[i, j] = [(i * 7) % 256, (j * 11) % 256, ((i + j) * 13) % 256]
    img = Image.fromarray(arr)
    img.save("random_texture.jpg", quality=90)
    print("[OK] Created random_texture.jpg")

# Generate Corrupted / Blank / Low-contrast Image
if not os.path.exists("corrupted_blur.jpg"):
    img = Image.new("RGB", (300, 300), color=(128, 128, 128))
    draw = ImageDraw.Draw(img)
    draw.rectangle([100, 100, 200, 200], fill=(130, 130, 130))
    img.save("corrupted_blur.jpg")
    print("[OK] Created corrupted_blur.jpg")
