import os
import sys
import torch
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "ml-service"))
from model import BuffaloDiseaseModel
from PIL import Image

disease_model = BuffaloDiseaseModel()
test_dir = Path("ml-service/buffalo_dataset/test")

print("=" * 80)
print(f"RUNNING EVALUATION ACROSS ALL INDIVIDUAL TEST IMAGES IN {test_dir}")
print("=" * 80)

summary = {}

for class_dir in sorted(test_dir.iterdir()):
    if not class_dir.is_dir():
        continue
    expected_class = class_dir.name
    files = sorted(list(class_dir.glob("*.*")))
    correct = 0
    total = len(files)
    print(f"\n--- Class: {expected_class} ({total} images) ---")

    for f in files:
        img = Image.open(f).convert("RGB")
        # Run model inference
        t1 = disease_model.transform(img).unsqueeze(0).to(disease_model.device)
        t2 = disease_model.transform(img.transpose(Image.FLIP_LEFT_RIGHT)).unsqueeze(0).to(disease_model.device)
        with torch.no_grad():
            out1 = disease_model.model(t1)
            out2 = disease_model.model(t2)
            outputs = 0.60 * out1 + 0.40 * out2
            probs = torch.softmax(outputs, dim=-1).squeeze(0).cpu().numpy()

        pred_idx = int(torch.argmax(torch.tensor(probs)))
        pred_class = disease_model.class_names[pred_idx]
        is_ok = (pred_class == expected_class)
        if is_ok:
            correct += 1
        mark = "OK" if is_ok else "MISCLASSIFIED"

        prob_str = " | ".join([f"{disease_model.class_names[i]}: {probs[i]*100:.1f}%" for i in range(4)])
        if not is_ok:
            print(f"  [{mark}] {f.name} -> Predicted: {pred_class} (Expected: {expected_class})")
            print(f"         Probs: {prob_str}")

    acc = (correct / total * 100) if total > 0 else 0
    print(f"  Total Correct: {correct}/{total} ({acc:.2f}%)")
    summary[expected_class] = (correct, total, acc)

print("\n" + "=" * 80)
print("TEST SET ACCURACY BREAKDOWN:")
for cls, (cor, tot, acc) in summary.items():
    print(f"  - {cls:26s}: {cor:2d}/{tot:2d} ({acc:.2f}%)")
print("=" * 80)
