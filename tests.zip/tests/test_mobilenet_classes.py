import torch
import torchvision.models as models
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transforms = weights.transforms()

test_files = [
    "test_dog.jpg",
    "test_hen.jpg",
    "test_cat.jpg",
    "test_car.jpg",
    "test_human.jpg"
]

print("=" * 80)
print("TESTING MOBILENETV2 PREDICTIONS ON NON-BUFFALO IMAGES")
print("=" * 80)

for f in test_files:
    img = Image.open(f).convert("RGB")
    t = transforms(img).unsqueeze(0)
    with torch.no_grad():
        probs = torch.softmax(model(t), dim=-1).squeeze(0)
    top5_p, top5_idx = torch.topk(probs, 5)
    print(f"\n>> Image: {f}")
    for p, idx in zip(top5_p, top5_idx):
        idx = int(idx)
        print(f"   [{idx:03d}] {categories[idx]}: {float(p)*100:.2f}%")
