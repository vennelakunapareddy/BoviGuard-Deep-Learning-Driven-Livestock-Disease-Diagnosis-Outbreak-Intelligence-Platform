import torch
import torchvision.models as models
from PIL import Image
import os

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transforms = weights.transforms()

# Define category index sets
CANINE_INDICES = set(range(151, 276))  # 151 to 275: dogs, wolves, coyotes, dingoes
FELINE_INDICES = set(range(281, 294))  # 281 to 293: domestic & wild cats
BIRD_INDICES = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147))) # Birds & Poultry (cock, hen, etc.)
BOVINE_INDICES = {345, 346, 347, 697}  # ox, water buffalo, bison, oxcart

test_images = [
    ("test_dog.jpg", "Real Dog"),
    ("test_hen.jpg", "Real Hen"),
    ("test_cat.jpg", "Real Cat"),
    ("test_car.jpg", "Real Car"),
    ("test_human.jpg", "Real Human"),
    ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg", "Buffalo Healthy 1"),
    ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0002.jpg", "Buffalo Healthy 2"),
    ("ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.png", "Buffalo LSD 1"),
    ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg", "Buffalo Mastitis 1"),
    ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg", "Buffalo FMD 1"),
    ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0004.jpg", "Buffalo FMD 4"),
]

print("=" * 80)
print("ANALYZING CATEGORY PROBABILITIES FOR REJECTION LOGIC")
print("=" * 80)

for path, desc in test_images:
    if not os.path.exists(path):
        continue
    img = Image.open(path).convert("RGB")
    t = transforms(img).unsqueeze(0)
    with torch.no_grad():
        probs = torch.softmax(model(t), dim=-1).squeeze(0)
    
    top1_idx = int(torch.argmax(probs))
    top1_prob = float(probs[top1_idx]) * 100
    top1_cat = categories[top1_idx]
    
    canine_prob = float(sum(probs[idx] for idx in CANINE_INDICES)) * 100
    feline_prob = float(sum(probs[idx] for idx in FELINE_INDICES)) * 100
    bird_prob = float(sum(probs[idx] for idx in BIRD_INDICES)) * 100
    bovine_prob = float(sum(probs[idx] for idx in BOVINE_INDICES)) * 100
    
    print(f">> {desc} ({os.path.basename(path)}):")
    print(f"   Top-1: [{top1_idx}] {top1_cat} = {top1_prob:.2f}%")
    print(f"   Total Canine: {canine_prob:.2f}% | Total Bird/Hen: {bird_prob:.2f}% | Total Feline: {feline_prob:.2f}% | Total Bovine: {bovine_prob:.2f}%")
