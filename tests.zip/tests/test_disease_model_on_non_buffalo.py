import os
import sys
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "ml-service"))
from model import BuffaloDiseaseModel
from PIL import Image

disease_model = BuffaloDiseaseModel()
print(f"Loaded: {disease_model.loaded}, Classes: {disease_model.class_names}")

for p in ['test_dog.jpg', 'test_hen.jpg', 'test_cat.jpg', 'test_car.jpg']:
    if os.path.exists(p):
        img = Image.open(p).convert('RGB')
        t = disease_model.transform(img).unsqueeze(0).to(disease_model.device)
        with torch.no_grad():
            out = disease_model.model(t)
            probs = torch.softmax(out, dim=-1).squeeze(0)
        pred_idx = int(torch.argmax(probs))
        pred_class = disease_model.class_names[pred_idx]
        print(f">> {p} -> {pred_class} ({float(probs[pred_idx])*100:.1f}%) | Raw Logits: {[round(float(v), 2) for v in out.squeeze(0)]} | Probs: {[round(float(v), 4) for v in probs]}")
