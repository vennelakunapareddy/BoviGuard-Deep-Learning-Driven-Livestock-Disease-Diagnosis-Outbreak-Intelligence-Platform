import requests
import json
import time

time.sleep(3)

print("--- 1. Testing FastAPI ML Service (Port 5000) ---")
try:
    r_ml = requests.get('http://127.0.0.1:5000/health', timeout=5)
    print("FastAPI Health:", r_ml.status_code, r_ml.json())
except Exception as e:
    print("FastAPI Health Failed:", e)

print("\n--- 2. Testing Express Backend (Port 3000) ---")
try:
    r_be = requests.get('http://127.0.0.1:3000/api/health', timeout=5)
    print("Express Health:", r_be.status_code, r_be.text)
except Exception as e:
    print("Express Health Failed:", e)

print("\n--- 3. Testing Frontend (Port 5173) ---")
try:
    r_fe = requests.get('http://127.0.0.1:5173', timeout=5)
    print("Frontend Health:", r_fe.status_code)
except Exception as e:
    print("Frontend Health Failed:", e)
