# BoviGuard Testing & Verification Suite

This folder centralizes all test images, out-of-distribution (OOD) benchmark samples, API diagnostic tools, and end-to-end inference verification scripts.

---

## 🖼️ Included Test Images

| File | Category | Expected Behavior |
|------|----------|-------------------|
| `unseen_healthy_buffalo.jpg` | Bovine (Healthy) | Accepted as Buffalo -> Healthy Buffalo |
| `unseen_cow.jpg` | Bovine (Cow) | Accepted as Bovine |
| `test_dog.jpg` | Domestic Dog | Rejected by OOD Gate (Canine detection) |
| `test_cat.jpg` | Domestic Cat | Rejected by OOD Gate (Feline detection) |
| `test_hen.jpg` | Bird / Poultry | Rejected by OOD Gate (Bird detection) |
| `test_car.jpg` | Vehicle | Rejected by OOD Gate (Vehicle detection) |
| `test_human.jpg` | Person | Rejected by OOD Gate (Human detection) |
| `unseen_goat.jpg` | Small Ruminant | Rejected / Distinguished |
| `corrupted_blur.jpg` | Quality Test | Rejected (Low quality / excessive blur) |
| `random_texture.jpg` | Non-animal Texture | Rejected by OOD Gate |

---

## 🧪 Test Scripts

1. **`run_final_verification_suite.py`**:
   - Executes multi-case end-to-end tests against the live API (`http://localhost:3000/api/cases/predict`).
   - Run: `python run_final_verification_suite.py`

2. **`test_rejection_suite.py`**:
   - Tests the Out-of-Distribution rejection logic directly using MobileNetV2.
   - Run: `python test_rejection_suite.py`

3. **`run_full_api_audit.py`**:
   - Audits all REST endpoints for health, case registration, and cluster detection.
   - Run: `python run_full_api_audit.py`

4. **`test_confidence_distinction.py`**:
   - Evaluates confidence threshold separation between authentic lesions and non-target patterns.
