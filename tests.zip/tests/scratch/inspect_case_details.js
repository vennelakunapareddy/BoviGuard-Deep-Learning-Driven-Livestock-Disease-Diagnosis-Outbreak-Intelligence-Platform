const mongoose = require('mongoose');

async function inspectFull() {
  await mongoose.connect('mongodb://127.0.0.1:27017/animal-health');
  const Case = mongoose.model('Case', new mongoose.Schema({}, { strict: false }));
  const c5 = await Case.findOne({ caseId: 'BUF-2026-0005' }).lean();
  const c6 = await Case.findOne({ caseId: 'BUF-2026-0006' }).lean();
  console.log('Case 5:', JSON.stringify(c5, null, 2));
  console.log('Case 6:', JSON.stringify(c6, null, 2));
  process.exit(0);
}

inspectFull();
