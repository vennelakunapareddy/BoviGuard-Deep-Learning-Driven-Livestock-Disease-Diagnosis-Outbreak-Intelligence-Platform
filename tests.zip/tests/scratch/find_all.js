const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    list.forEach(file => {
      let fullPath = path.join(dir, file);
      if (file === 'node_modules' || file === '.git' || file === '.venv') return;
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          results = results.concat(walk(fullPath));
        } else {
          results.push(fullPath);
        }
      } catch (e) {}
    });
  } catch (e) {}
  return results;
}

const root = path.resolve(__dirname, '..', '..', '..', '..');
console.log('Scanning from root:', root);
const allFiles = walk(root);
console.log('Total files found:', allFiles.length);

const terms = ['brucell', 'traumatic', 'cutaneous', 'wound'];
allFiles.forEach(f => {
  try {
    const content = fs.readFileSync(f, 'utf8');
    terms.forEach(term => {
      if (new RegExp(term, 'i').test(content)) {
        content.split('\n').forEach((line, idx) => {
          if (new RegExp(term, 'i').test(line)) {
            console.log(`${f}:${idx + 1} [${term}] -> ${line.trim().substring(0, 150)}`);
          }
        });
      }
    });
  } catch (e) {}
});
