import torch
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image
from pathlib import Path

weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
detector = ssdlite320_mobilenet_v3_large(weights=weights).eval()
coco_classes = weights.meta["categories"]
transform = weights.transforms()

paths = [
    Path('test_human.jpg'),
    Path('ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg'),
    Path('ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0002.jpg'),
    Path('ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg')
]

for p in paths:
    if not p.exists():
        continue
    img = Image.open(p).convert('RGB')
    w, h = img.size
    img_area = w * h
    t = transform(img).unsqueeze(0)
    with torch.no_grad():
        preds = detector(t)[0]
    scores = preds['scores']
    labels = preds['labels']
    boxes = preds['boxes']
    mask = scores > 0.35
    print("=" * 60)
    print(f"Image: {p.name} (size: {w}x{h})")
    for b, l, s in zip(boxes[mask], labels[mask], scores[mask]):
        cat = coco_classes[int(l)]
        box_area = float((b[2] - b[0]) * (b[3] - b[1]))
        area_pct = (box_area / img_area) * 100
        print(f"  {cat}: score={float(s)*100:.1f}%, box_area={area_pct:.1f}% of image")
