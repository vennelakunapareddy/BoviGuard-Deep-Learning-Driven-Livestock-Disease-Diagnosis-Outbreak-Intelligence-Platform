const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    list.forEach(file => {
      let fullPath = path.join(dir, file);
      if (file === 'node_modules' || file === '.git' || file === '.venv' || file === 'dist') return;
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          results = results.concat(walk(fullPath));
        } else if (/\.(js|jsx|json|py|md|html|txt|ts|tsx)$/.test(file)) {
          results.push(fullPath);
        }
      } catch (e) {}
    });
  } catch (e) {}
  return results;
}

const terms = process.argv.slice(2);
if (terms.length === 0) {
  console.log('No search terms provided');
  process.exit(1);
}

const files = walk('.');
console.log(`Scanning ${files.length} files for terms: ${terms.join(', ')}`);

files.forEach(f => {
  try {
    const content = fs.readFileSync(f, 'utf8');
    terms.forEach(t => {
      const reg = new RegExp(t, 'i');
      if (reg.test(content)) {
        content.split('\n').forEach((line, idx) => {
          if (reg.test(line)) {
            console.log(`${f}:${idx + 1} [${t}] -> ${line.trim()}`);
          }
        });
      }
    });
  } catch (e) {}
});
