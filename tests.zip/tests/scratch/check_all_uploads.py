import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image
from test_full_classifier import classify_uploaded_image

uploads_dir = r"backend\uploads"
files = [f for f in os.listdir(uploads_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

results_count = {}
for f in files:
    p = os.path.join(uploads_dir, f)
    try:
        im = Image.open(p).convert("RGB")
        res = classify_uploaded_image(im)
        etype = res["entityType"]
        results_count[etype] = results_count.get(etype, 0) + 1
        if etype != "Buffalo":
            print(f"Non-Buffalo in uploads: {f} -> {etype}: {res['predictedSubject']} ({res['confidenceScore']}%)")
    except Exception:
        pass

print("\nFull breakdown of all uploaded images:")
for k, v in results_count.items():
    print(f"  {k}: {v}")
