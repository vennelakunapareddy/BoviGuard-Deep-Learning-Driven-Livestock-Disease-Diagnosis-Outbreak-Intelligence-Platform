import torch
from PIL import Image
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights

w = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
m = ssdlite320_mobilenet_v3_large(weights=w).eval()
t = w.transforms()(Image.open('unseen_goat.jpg')).unsqueeze(0)
p = m(t)[0]
print([(w.meta['categories'][l], round(float(s), 3)) for l, s in zip(p['labels'], p['scores']) if s > 0.2])
