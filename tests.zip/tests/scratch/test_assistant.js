const axios = require('axios');

async function testAssistant() {
  const testCases = [
    {
      desc: 'English: CMT Test Question',
      query: 'How do I perform a California Mastitis Test (CMT) on my buffalo and what do the scores mean?',
      lang: 'en-IN'
    },
    {
      desc: 'Telugu: FMD Care & Symptoms Question',
      query: 'నా గేదె నోటిలో బొబ్బలు వచ్చి తీవ్రంగా సొంగ కారుతోంది, కాళ్ళలో పుండ్లు ఉన్నాయి. ఏం చేయాలి?',
      lang: 'te-IN'
    },
    {
      desc: 'Hindi: Mastitis Care & Precaution Question',
      query: 'भैंस के थन में सूजन और खून वाला दूध आ रहा है, क्या सावधानी बरतें और कैसे ठीक करें?',
      lang: 'hi-IN'
    },
    {
      desc: 'English: Acute Bloat First Aid',
      query: 'My buffalo has severe bloat on the left side and is groaning in pain, what immediate first aid should I do?',
      lang: 'en-IN'
    },
    {
      desc: 'Telugu: Vaccination Schedule Question',
      query: 'గేదెలకు ఏ ఏ సమయాల్లో ఏ టీకాలు వేయించాలి?',
      lang: 'te-IN'
    }
  ];

  for (const tc of testCases) {
    console.log(`\n========================================`);
    console.log(`TEST: ${tc.desc}`);
    console.log(`QUERY: ${tc.query}`);
    try {
      const res = await axios.post('http://127.0.0.1:3000/api/assistant', {
        transcript: tc.query,
        language: tc.lang
      });
      console.log(`RESPONSE:\n${res.data.reply}`);
    } catch (err) {
      console.error('FAILED:', err.response?.data || err.message);
    }
  }
}

testAssistant();
