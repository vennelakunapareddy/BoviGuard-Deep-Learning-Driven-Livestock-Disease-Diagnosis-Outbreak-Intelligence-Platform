const mongoose = require('mongoose');
const fs = require('fs');

async function migrate() {
  await mongoose.connect('mongodb://127.0.0.1:27017/animal-health');
  console.log('Connected to MongoDB');
  const Case = mongoose.model('Case', new mongoose.Schema({}, { strict: false }));

  // Update Case 5 (was Bovine Brucellosis) -> Clinical Mastitis
  const res5 = await Case.updateOne(
    { caseId: 'BUF-2026-0005' },
    {
      $set: {
        diseasePrediction: 'Clinical Mastitis',
        immediateAction: 'Collect milk sample for California Mastitis Test (CMT) and consult veterinarian for targeted intramammary therapy.',
        severity: 'Medium',
        riskPercentage: 65,
        symptoms: ['Clinical Mastitis / Swollen Udder', 'Reduced Milk', 'Hot / Painful Teats']
      }
    }
  );
  console.log('Migrated BUF-2026-0005:', res5);

  // Update Case 6 (was Traumatic Cutaneous Wound / Lesion) -> Multiple Disease Diagnosis
  const res6 = await Case.updateOne(
    { caseId: 'BUF-2026-0006' },
    {
      $set: {
        diseasePrediction: 'Multiple Disease Diagnosis',
        immediateAction: 'Isolate animal in quarantine shed and arrange differential veterinary laboratory testing.',
        severity: 'High',
        riskPercentage: 75,
        symptoms: ['Skin Abrasion / Lesion', 'Crusty Skin Patches', 'Rapid Weight Loss / Dullness']
      }
    }
  );
  console.log('Migrated BUF-2026-0006:', res6);

  // Check any other cases in DB with old disease names
  const allCases = await Case.find({}).lean();
  for (const c of allCases) {
    let changed = false;
    let newName = c.diseasePrediction;
    if (/brucell/i.test(c.diseasePrediction)) {
      newName = 'Clinical Mastitis';
      changed = true;
    } else if (/wound|cutaneous/i.test(c.diseasePrediction)) {
      newName = 'Multiple Disease Diagnosis';
      changed = true;
    }
    if (changed) {
      await Case.updateOne({ _id: c._id }, { $set: { diseasePrediction: newName } });
      console.log(`Updated case ${c.caseId || c._id} to ${newName}`);
    }
  }

  // Also check backend/data/issues.json if it exists
  const issuesFile = 'backend/data/issues.json';
  if (fs.existsSync(issuesFile)) {
    try {
      const data = JSON.parse(fs.readFileSync(issuesFile, 'utf8'));
      let modified = false;
      data.forEach(item => {
        if (/brucell/i.test(item.diseasePrediction)) {
          item.diseasePrediction = 'Clinical Mastitis';
          modified = true;
        } else if (/wound|cutaneous/i.test(item.diseasePrediction)) {
          item.diseasePrediction = 'Multiple Disease Diagnosis';
          modified = true;
        }
      });
      if (modified) {
        fs.writeFileSync(issuesFile, JSON.stringify(data, null, 2), 'utf8');
        console.log('Updated backend/data/issues.json');
      }
    } catch (e) {
      console.error('Error updating issues.json:', e);
    }
  }

  const updatedCases = await Case.find({}).lean();
  console.log('Current updated cases in MongoDB:');
  updatedCases.forEach(c => {
    console.log(`- ${c.caseId}: ${c.diseasePrediction} (Severity: ${c.severity})`);
  });

  process.exit(0);
}

migrate();
