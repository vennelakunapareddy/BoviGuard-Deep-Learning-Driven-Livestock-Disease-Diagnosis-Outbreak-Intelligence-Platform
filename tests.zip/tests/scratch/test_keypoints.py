import torch
from torchvision.models.detection import keypointrcnn_resnet50_fpn, KeypointRCNN_ResNet50_FPN_Weights
from PIL import Image
from pathlib import Path

print("Loading Keypoint R-CNN weights...")
try:
    weights = KeypointRCNN_ResNet50_FPN_Weights.DEFAULT
    model = keypointrcnn_resnet50_fpn(weights=weights).eval()
    print("Keypoint R-CNN loaded!")
    transform = weights.transforms()

    paths = [
        Path('test_human.jpg'),
        Path('ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg'),
        Path('ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0002.jpg'),
        Path('test_dog.jpg')
    ]

    for p in paths:
        if not p.exists():
            continue
        img = Image.open(p).convert('RGB')
        t = transform(img).unsqueeze(0)
        with torch.no_grad():
            preds = model(t)[0]
        scores = preds['scores']
        keypoints = preds['keypoints']
        # check high confidence person with facial keypoints (0: nose, 1: l_eye, 2: r_eye)
        mask = scores > 0.60
        num_persons = int(mask.sum())
        print(f"\nImage {p.name}: persons detected = {num_persons}")
        for i, (kp, s) in enumerate(zip(keypoints[mask], scores[mask])):
            nose_vis = float(kp[0, 2])
            leye_vis = float(kp[1, 2])
            reye_vis = float(kp[2, 2])
            print(f"  Person #{i+1} (score={float(s):.2f}): nose_vis={nose_vis:.1f}, leye_vis={leye_vis:.1f}, reye_vis={reye_vis:.1f}")
except Exception as e:
    import traceback
    traceback.print_exc()
