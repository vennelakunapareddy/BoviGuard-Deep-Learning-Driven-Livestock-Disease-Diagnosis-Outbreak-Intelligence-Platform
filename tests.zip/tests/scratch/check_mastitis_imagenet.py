import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import torch
import torchvision.models as models
from PIL import Image

sys.path.insert(0, os.path.abspath('ml-service'))
weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transforms = weights.transforms()

val_dir = r"ml-service\buffalo_dataset\val\Mastitis"
files = [f for f in os.listdir(val_dir) if f.lower().endswith(('.jpg', '.png', '.jpeg'))]
img = Image.open(os.path.join(val_dir, files[0])).convert("RGB")
batch = transforms(img).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(batch), dim=1)[0]

top10_prob, top10_idx = torch.topk(probs, 10)
print("Top 10 ImageNet classes for Mastitis photo:")
for p, idx in zip(top10_prob, top10_idx):
    print(f"  {idx.item()}: {categories[idx.item()]} ({p.item()*100:.2f}%)")
