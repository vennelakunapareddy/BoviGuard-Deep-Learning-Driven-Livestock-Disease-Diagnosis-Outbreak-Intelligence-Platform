import os
import cv2
import numpy as np

val_dir = r"ml-service\buffalo_dataset\val"
for c in os.listdir(val_dir):
    c_dir = os.path.join(val_dir, c)
    if not os.path.isdir(c_dir): continue
    files = [f for f in os.listdir(c_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    if not files: continue
    
    img = cv2.imread(os.path.join(c_dir, files[0]))
    if img is None: continue
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    
    white_bg_mask = (v > 180) & (s < 40)
    white_ratio = np.count_nonzero(white_bg_mask) / white_bg_mask.size
    
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(thresh)
    
    char_count = 0
    for i in range(1, num_labels):
        w = stats[i, cv2.CC_STAT_WIDTH]
        h_box = stats[i, cv2.CC_STAT_HEIGHT]
        area = stats[i, cv2.CC_STAT_AREA]
        if 3 < w < 80 and 5 < h_box < 80 and 10 < area < 2000:
            char_count += 1
            
    print(f"[{c[:20]:<20}] Mean S: {np.mean(s):.1f}, Mean V: {np.mean(v):.1f}, White: {white_ratio*100:.1f}%, CharCount: {char_count}")
