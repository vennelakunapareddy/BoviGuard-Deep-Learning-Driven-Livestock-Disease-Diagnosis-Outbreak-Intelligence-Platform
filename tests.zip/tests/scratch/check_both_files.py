import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image

for f in ["buffalo-1789550936919-422292939.png", "buffalo-1789550961871-319771322.png"]:
    p = os.path.join(r"backend\uploads", f)
    im = Image.open(p)
    print(f"{f}: size={im.size}, mode={im.mode}")
