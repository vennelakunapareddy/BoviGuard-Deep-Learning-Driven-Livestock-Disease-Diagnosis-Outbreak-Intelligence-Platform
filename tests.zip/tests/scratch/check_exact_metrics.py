import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import cv2
import numpy as np
from PIL import Image

f = r"backend\uploads\buffalo-1789550936919-422292939.png"
np_img = np.array(Image.open(f).convert("RGB"))
hsv = cv2.cvtColor(np_img, cv2.COLOR_RGB2HSV)
h, s, v = cv2.split(hsv)

mean_s = float(np.mean(s))
mean_v = float(np.mean(v))
print(f"Mean Saturation: {mean_s:.2f}, Mean Value: {mean_v:.2f}")

white_bg_mask = (v > 175) & (s < 45)
white_ratio = float(np.count_nonzero(white_bg_mask)) / float(white_bg_mask.size)
print(f"White ratio (>175, <45): {white_ratio*100:.2f}%")

light_bg_mask = (v > 150) & (s < 60)
light_ratio = float(np.count_nonzero(light_bg_mask)) / float(light_bg_mask.size)
print(f"Light ratio (>150, <60): {light_ratio*100:.2f}%")

dark_stroke_mask = (v < 115)
dark_ratio = float(np.count_nonzero(dark_stroke_mask)) / float(dark_stroke_mask.size)
print(f"Dark ratio (<115): {dark_ratio*100:.2f}%")

# Let's inspect percentiles of brightness:
print(f"V percentiles - 10%: {np.percentile(v, 10):.1f}, 50%: {np.percentile(v, 50):.1f}, 90%: {np.percentile(v, 90):.1f}")
print(f"S percentiles - 10%: {np.percentile(s, 10):.1f}, 50%: {np.percentile(s, 50):.1f}, 90%: {np.percentile(s, 90):.1f}")
