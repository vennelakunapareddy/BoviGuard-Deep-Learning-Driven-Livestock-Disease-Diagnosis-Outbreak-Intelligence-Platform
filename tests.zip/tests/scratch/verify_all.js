const http = require('http');

function testUrl(url) {
  return new Promise((resolve) => {
    http.get(url, (res) => {
      resolve({ url, status: res.statusCode });
    }).on('error', (err) => {
      resolve({ url, error: err.message });
    });
  });
}

async function run() {
  console.log('Testing services:');
  const r1 = await testUrl('http://127.0.0.1:5000/docs');
  console.log('ML Service (5000):', r1);
  const r2 = await testUrl('http://127.0.0.1:3000/api/cases');
  console.log('Backend (3000):', r2);
  const r3 = await testUrl('http://127.0.0.1:5173');
  console.log('Frontend Vite (5173):', r3);
}

run();
