import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image
from test_full_classifier import classify_uploaded_image

uploads_dir = r"backend\uploads"
files = [f for f in os.listdir(uploads_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
print(f"Testing {len(files)} files in backend/uploads:")

results_count = {}
sample_findings = []

for f in files[:40]: # test first 40
    p = os.path.join(uploads_dir, f)
    try:
        im = Image.open(p).convert("RGB")
        res = classify_uploaded_image(im)
        etype = res["entityType"]
        results_count[etype] = results_count.get(etype, 0) + 1
        sample_findings.append((f, etype, res["predictedSubject"], res["confidenceScore"]))
    except Exception as e:
        pass

print("\nSummary of entity types in backend/uploads:")
for k, v in results_count.items():
    print(f"  {k}: {v}")

print("\nSample predictions:")
for s in sample_findings[:15]:
    print(f"  {s[0][:25]} -> {s[1]}: {s[2]} ({s[3]}%)")
