const { execSync } = require('child_process');

try {
  const netstat = execSync('C:\\Windows\\System32\\netstat.exe -ano', { encoding: 'utf8' });
  const lines = netstat.trim().split('\n');
  lines.forEach(line => {
    if (line.includes(':3000') && line.includes('LISTENING')) {
      const parts = line.trim().split(/\s+/);
      const pid = parts[parts.length - 1];
      console.log(`Killing process on port 3000 (PID: ${pid})...`);
      try {
        execSync(`C:\\Windows\\System32\\taskkill.exe /F /PID ${pid}`);
        console.log(`Successfully killed PID ${pid}`);
      } catch (e) {
        console.error(`Failed to kill PID ${pid}:`, e.message);
      }
    }
  });
} catch (e) {
  console.log('No process found on port 3000:', e.message);
}
