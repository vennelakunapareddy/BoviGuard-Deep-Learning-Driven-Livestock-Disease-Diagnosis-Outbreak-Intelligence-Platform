import hashlib

p = 'ml-service/buffalo_model.pth'
h = hashlib.sha256(open(p, 'rb').read()).hexdigest().upper()
expected = 'BF97CC673C1037BCEED0F84D776A4BB11FFD2B3A4C7CB4FE61ED17989A53757A'
print("CHECKPOINT PATH:   ", p)
print("CHECKPOINT SHA256: ", h)
print("EXPECTED SHA256:   ", expected)
print("INTEGRITY VERIFIED:", h == expected)
