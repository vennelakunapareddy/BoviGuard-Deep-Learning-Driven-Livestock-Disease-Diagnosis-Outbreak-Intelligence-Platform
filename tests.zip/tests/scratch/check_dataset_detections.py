import torch
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image
from pathlib import Path

weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
detector = ssdlite320_mobilenet_v3_large(weights=weights).eval()
coco_classes = weights.meta["categories"]
transform = weights.transforms()

test_dir = Path("ml-service/buffalo_dataset/test")
for class_folder in sorted(test_dir.iterdir()):
    if not class_folder.is_dir():
        continue
    print(f"\n--- {class_folder.name} ---")
    for img_path in sorted(class_folder.glob("*.jpg"))[:5]:
        img = Image.open(img_path).convert('RGB')
        t = transform(img).unsqueeze(0)
        with torch.no_grad():
            preds = detector(t)[0]
        scores = preds['scores']
        labels = preds['labels']
        mask = scores > 0.40
        det = [(coco_classes[int(l)], round(float(s)*100, 1)) for l, s in zip(labels[mask], scores[mask])]
        print(f"  {img_path.name:<32}: {det}")
