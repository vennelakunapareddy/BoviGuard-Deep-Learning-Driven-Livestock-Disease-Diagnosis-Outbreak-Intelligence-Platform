import requests
import json

BASE_URL = "http://localhost:3000/api/cases/predict"
TEST_IMG = "ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg"
MASTITIS_IMG = "ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg"

print("="*60)
print("TEST 1: MANDATORY SYMPTOMS VALIDATION (WITHOUT SYMPTOMS)")
print("="*60)
with open(TEST_IMG, "rb") as f:
    resp = requests.post(BASE_URL, files={"image": f})
print("Status Code:", resp.status_code)
print("Response:", resp.json())
assert resp.status_code == 400
assert "symptoms" in resp.json().get("message", "").lower()
print(">>> PASS: Rejected without symptoms as required!\n")

print("="*60)
print("TEST 2: FMD IMAGE WITH NON-FMD SYMPTOMS -> MULTIPLE DISEASE DIAGNOSIS")
print("="*60)
with open(TEST_IMG, "rb") as f:
    resp = requests.post(BASE_URL, files={"image": f}, data={"symptoms": "High fever, mild lethargy"})
print("Status Code:", resp.status_code)
data = resp.json()
print("Disease:", data.get("disease"))
print("Disease Key:", data.get("diseaseKey"))
print("Is FMD Mismatch:", data.get("isFmdSymptomMismatch"))
print("Sample Directive:", data.get("sampleDirective"))
print("Awareness Stop Spread:", data.get("awareness", {}).get("stopSpread")[:80] + "...")
print("Veterinary Guidance:", data.get("veterinaryGuidance"))
assert data.get("diseaseKey") == "Multiple_Disease_Diagnosis" or "Multiple" in data.get("disease")
assert "medicine" not in data or data.get("medicine") is None or "1962" in str(data.get("veterinaryGuidance"))
print(">>> PASS: FMD symptom mismatch correctly converts to Multiple Disease Diagnosis!\n")

print("="*60)
print("TEST 3: FMD IMAGE WITH CORROBORATING FMD SYMPTOMS")
print("="*60)
with open(TEST_IMG, "rb") as f:
    resp = requests.post(BASE_URL, files={"image": f}, data={"symptoms": "Blisters on Mouth / Tongue / Lips, Excessive Salivation (Drooling), Hoof Lesions"})
print("Status Code:", resp.status_code)
data = resp.json()
print("Disease:", data.get("disease"))
print("Disease Key:", data.get("diseaseKey"))
print("Sample Directive:", data.get("sampleDirective"))
assert data.get("diseaseKey") == "Foot_and_Mouth_Disease"
print(">>> PASS: FMD correctly corroborated!\n")

print("="*60)
print("TEST 4: MASTITIS PREDICTION & MILK SAMPLE DIRECTIVE")
print("="*60)
with open(MASTITIS_IMG, "rb") as f:
    resp = requests.post(BASE_URL, files={"image": f}, data={"symptoms": "Hard/Swollen Udder, Reduced Milk, Fever"})
print("Status Code:", resp.status_code)
data = resp.json()
print("Disease:", data.get("disease"))
print("Sample Directive Instruction:", data.get("sampleDirective", {}).get("instruction"))
print("Awareness Prevent Future:", data.get("awareness", {}).get("preventFuture")[:80] + "...")
assert "milk" in data.get("sampleDirective", {}).get("instruction", "").lower()
print(">>> PASS: Mastitis milk sample directive verified!\n")

print("ALL TESTS PASSED WITH 100% SUCCESS!")
