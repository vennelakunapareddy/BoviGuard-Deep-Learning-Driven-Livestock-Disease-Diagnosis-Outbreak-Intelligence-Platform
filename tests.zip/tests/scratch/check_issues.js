const fs = require('fs');
const issues = JSON.parse(fs.readFileSync('backend/data/issues.json', 'utf8'));

const predictions = new Set();
issues.forEach((issue, idx) => {
  predictions.add(issue.diseasePrediction);
  if (/wound|brucell|infect/i.test(issue.diseasePrediction || '')) {
    console.log(`Issue #${idx} ID ${issue.id || issue._id}: diseasePrediction = "${issue.diseasePrediction}"`);
  }
});

console.log('Distinct disease predictions in issues.json:');
console.log(Array.from(predictions));
