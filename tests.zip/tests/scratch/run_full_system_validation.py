import os
import sys
import requests
from pathlib import Path

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

test_suite = [
    # Non-Buffalo Rejections
    ("test_human.jpg", "Human Face / Webcam Selfie", "rejected"),
    ("test_dog.jpg", "Domestic Dog Photo", "rejected"),
    ("test_hen.jpg", "Hen / Poultry Photo", "rejected"),
    ("test_cat.jpg", "Domestic Cat Photo", "rejected"),
    ("test_car.jpg", "Automobile / Vehicle", "rejected"),
    ("corrupted_blur.jpg", "Low-Contrast / Blurred Frame", "uncertain_evidence"),
    
    # Real-World User Downloaded Images
    ("c:/Users/venne/Downloads/fmd.jpg", "User Download FMD Buffalo", "confident"),
    ("c:/Users/venne/Downloads/lumppy.jpg", "User Download LSD Buffalo", "confident"),
    ("c:/Users/venne/Downloads/Lumpy-skin-disease_d.jpg", "User Download LSD Buffalo 2", "confident"),
    
    # Unseen Bovine Images
    ("unseen_healthy_buffalo.jpg", "Unseen Water Buffalo (Field)", "confident"),
    ("unseen_cow.jpg", "Unseen Dairy Cow", "confident"),
    
    # Dataset Test Set Images
    ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg", "Healthy Buffalo (with Handler)", "confident"),
    ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg", "FMD Clinical Lesion", "confident"),
    ("ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.png", "LSD Clinical Nodules", "confident"),
    ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg", "Mastitis (Udder with Vet Hand)", "confident"),
    ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0002.jpg", "Mastitis (Udder Macro)", "confident"),
]

print("=" * 105)
print(f"{'Test Case':<32} | {'Expected':<12} | {'ML (5000) Status':<18} | {'Backend (3000) Status':<18} | {'Prediction / Detected'}")
print("=" * 105)

all_passed = True

for path_str, label, expected_status in test_suite:
    path = Path(path_str)
    if not path.exists():
        print(f"File missing: {path_str}")
        continue
    
    # 1. Test FastAPI ML Service
    try:
        with open(path, "rb") as f:
            ml_res = requests.post("http://127.0.0.1:5000/predict", files={"image": f}, timeout=10)
        ml_data = ml_res.json()
        ml_status = ml_data.get("status")
        ml_is_buf = ml_data.get("is_buffalo")
        ml_entity = ml_data.get("predictedSubject") or ml_data.get("prediction")
        ml_conf = ml_data.get("confidenceScore", 0)
    except Exception as e:
        ml_status = f"ERR: {e}"
        ml_entity = "N/A"
        ml_conf = 0
    
    # 2. Test Express Backend
    try:
        with open(path, "rb") as f:
            be_res = requests.post("http://127.0.0.1:3000/api/cases/predict", files={"image": f}, timeout=10)
        be_data = be_res.json()
        be_status = be_data.get("status")
        be_is_buf = be_data.get("isBuffalo")
        be_entity = be_data.get("predictedSubject") or be_data.get("prediction")
        be_conf = be_data.get("confidenceScore", 0)
    except Exception as e:
        be_status = f"ERR: {e}"
        be_entity = "N/A"
        be_conf = 0

    match = (ml_status == expected_status) and (be_status == expected_status)
    if not match:
        all_passed = False
    
    mark = "PASS" if match else "FAIL"
    pred_str = f"{be_entity} ({be_conf}%)" if be_conf > 0 else f"{be_entity}"
    print(f"[{mark}] {label:<25} | {expected_status:<12} | {str(ml_status):<18} | {str(be_status):<18} | {pred_str}")

print("=" * 105)
if all_passed:
    print("ALL TESTS PASSED WITH 100% PRECISION ACROSS BOTH PORTS (5000 & 3000)!")
else:
    print("SOME TESTS DID NOT MATCH EXPECTED STATUS.")
print("=" * 105)
