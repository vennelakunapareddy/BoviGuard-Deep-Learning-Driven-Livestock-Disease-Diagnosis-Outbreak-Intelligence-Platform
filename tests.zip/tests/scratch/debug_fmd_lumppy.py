import torch
from PIL import Image
from torchvision import models
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights

det_w = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
det = ssdlite320_mobilenet_v3_large(weights=det_w).eval()
cls_w = models.MobileNet_V2_Weights.DEFAULT
cls = models.mobilenet_v2(weights=cls_w).eval()

for p in ['c:/Users/venne/Downloads/fmd.jpg', 'c:/Users/venne/Downloads/lumppy.jpg']:
    img = Image.open(p).convert('RGB')
    
    # Detector
    dt = det_w.transforms()(img).unsqueeze(0)
    res = det(dt)[0]
    boxes, labels, scores = res['boxes'], res['labels'], res['scores']
    detected = [(det_w.meta['categories'][int(l)], round(float(s), 3)) for l, s in zip(labels, scores) if s > 0.3]
    
    # Classifier
    ct = cls_w.transforms()(img).unsqueeze(0)
    out = cls(ct)
    probs, idxs = torch.topk(torch.softmax(out, dim=-1), 5)
    top_cls = [(cls_w.meta['categories'][int(i)], round(float(p)*100, 2)) for p, i in zip(probs[0], idxs[0])]
    
    print("=" * 60)
    print("IMAGE:", p)
    print("  SSDLite detections:", detected)
    print("  ImageNet top-5:", top_cls)
