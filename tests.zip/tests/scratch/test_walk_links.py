import os
from pathlib import Path

root = r"c:\Users\venne\Downloads\buffalo health"

count = 0
for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
    for f in filenames:
        count += 1

print(f"Total files discovered with followlinks=True: {count}")
