import os
from pathlib import Path

root = Path(r"c:\Users\venne\Downloads\buffalo health")

for p in root.rglob("*"):
    try:
        if p.is_symlink():
            print("SYMLINK:", p, "-->", os.readlink(p))
        elif os.path.islink(p):
            print("LINK/JUNCTION:", p, "-->", os.readlink(p))
    except Exception as e:
        print("ERROR on", p, ":", e)
