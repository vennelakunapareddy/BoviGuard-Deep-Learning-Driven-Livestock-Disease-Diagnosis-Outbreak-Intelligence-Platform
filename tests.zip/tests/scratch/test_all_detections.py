import torch
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image
from pathlib import Path

weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
detector = ssdlite320_mobilenet_v3_large(weights=weights).eval()
coco_classes = weights.meta["categories"]
transform = weights.transforms()

test_images = [
    'test_dog.jpg',
    'test_human.jpg',
    'test_hen.jpg',
    'test_cat.jpg',
    'test_car.jpg',
    'unseen_healthy_buffalo.jpg',
    'unseen_cow.jpg',
    'unseen_goat.jpg',
    'corrupted_blur.jpg',
    'random_texture.jpg',
    'ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg',
    'ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0002.jpg',
    'ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg',
    'ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0002.jpg',
    'ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg',
    'ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.jpg',
]

print("=" * 70)
print(f"{'Image':<35} | {'Top Detections (score > 0.30)'}")
print("=" * 70)

for p in test_images:
    path = Path(p)
    if not path.exists():
        continue
    img = Image.open(path).convert('RGB')
    t = transform(img).unsqueeze(0)
    with torch.no_grad():
        preds = detector(t)[0]
    scores = preds['scores']
    labels = preds['labels']
    mask = scores > 0.30
    det = [(coco_classes[int(l)], round(float(s) * 100, 1)) for l, s in zip(labels[mask], scores[mask])]
    print(f"{path.name:<35} | {det}")
