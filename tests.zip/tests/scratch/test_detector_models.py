import torch
import torchvision
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image

print("--- Testing Torchvision SSDLite320 Object Detector ---")
try:
    weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
    detector = ssdlite320_mobilenet_v3_large(weights=weights).eval()
    coco_classes = weights.meta["categories"]
    print(f"SSDLite detector loaded successfully! Total COCO classes: {len(coco_classes)}")
    print(f"Indices: person={coco_classes.index('person')}, dog={coco_classes.index('dog')}, cat={coco_classes.index('cat')}, bird={coco_classes.index('bird')}, cow={coco_classes.index('cow')}")

    # Test on test_dog.jpg and test_human.jpg
    transform = weights.transforms()
    for img_name in ['test_dog.jpg', 'test_human.jpg', 'test_hen.jpg', 'unseen_cow.jpg']:
        img = Image.open(img_name).convert('RGB')
        t = transform(img).unsqueeze(0)
        with torch.no_grad():
            preds = detector(t)[0]
        boxes = preds['boxes']
        labels = preds['labels']
        scores = preds['scores']
        high_conf = scores > 0.35
        detected = [(coco_classes[int(l)], round(float(s), 3)) for l, s in zip(labels[high_conf], scores[high_conf])]
        print(f"\nImage {img_name}:")
        print(f"  Detections: {detected}")
except Exception as e:
    import traceback
    traceback.print_exc()
