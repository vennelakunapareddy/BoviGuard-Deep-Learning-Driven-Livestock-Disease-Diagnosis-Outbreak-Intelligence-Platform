import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import torch
import torchvision.models as models
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transforms = weights.transforms()

f = r"backend\uploads\buffalo-1789550961871-319771322.png"
im = Image.open(f).convert("RGB")
batch = transforms(im).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(batch), dim=1)[0]

top10_prob, top10_idx = torch.topk(probs, 10)
print("ImageNet Top 10 for buffalo-1789550961871-319771322.png:")
for p, idx in zip(top10_prob, top10_idx):
    print(f"  {idx.item()}: {categories[idx.item()]} ({p.item()*100:.2f}%)")
