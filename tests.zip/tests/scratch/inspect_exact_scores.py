import torch
from PIL import Image
from torchvision import models
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights

det_w = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
det = ssdlite320_mobilenet_v3_large(weights=det_w).eval()
cls_w = models.MobileNet_V2_Weights.DEFAULT
cls = models.mobilenet_v2(weights=cls_w).eval()

test_files = [
    ("test_human.jpg", "Human Face / Selfie"),
    ("test_dog.jpg", "Dog"),
    ("test_hen.jpg", "Hen"),
    ("test_cat.jpg", "Cat"),
    ("test_car.jpg", "Car"),
    ("c:/Users/venne/Downloads/fmd.jpg", "User FMD"),
    ("c:/Users/venne/Downloads/lumppy.jpg", "User LSD 1"),
    ("c:/Users/venne/Downloads/Lumpy-skin-disease_d.jpg", "User LSD 2"),
]

for p, name in test_files:
    img = Image.open(p).convert('RGB')
    dt = det_w.transforms()(img).unsqueeze(0)
    res = det(dt)[0]
    det_list = [(det_w.meta['categories'][int(l)], round(float(s), 3)) for l, s in zip(res['labels'], res['scores']) if s > 0.35]
    
    ct = cls_w.transforms()(img).unsqueeze(0)
    out = cls(ct)
    probs, idxs = torch.topk(torch.softmax(out, dim=-1), 3)
    cls_list = [(cls_w.meta['categories'][int(i)], round(float(p)*100, 1)) for p, i in zip(probs[0], idxs[0])]
    
    print(f"{name:<22} | SSD: {det_list} | ImageNet: {cls_list}")
