const mongoose = require('mongoose');

async function inspect() {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/animal-health');
    console.log('Connected to MongoDB');
    const Case = mongoose.model('Case', new mongoose.Schema({}, { strict: false }));
    const cases = await Case.find({}).lean();
    console.log(`Found ${cases.length} cases in MongoDB:`);
    cases.forEach(c => {
      console.log(`- ID: ${c.caseId || c._id} | Tag: ${c.tagNumber} | Disease: "${c.diseasePrediction}" | Area: ${c.area}`);
    });
    process.exit(0);
  } catch (err) {
    console.error('MongoDB error:', err.message);
    process.exit(1);
  }
}

inspect();
