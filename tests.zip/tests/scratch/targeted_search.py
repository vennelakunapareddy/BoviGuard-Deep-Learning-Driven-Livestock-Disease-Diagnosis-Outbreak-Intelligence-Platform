import os
import re

pattern = re.compile(r'6-class|6 class|6\.0-pure|dermatophytosis|traumatic cutaneous', re.IGNORECASE)
found = []
for sub in ['backend', os.path.join('frontend-v2', 'src'), 'ml-service']:
    for root, dirs, files in os.walk(sub):
        for f in files:
            if f.endswith(('.js', '.jsx', '.py', '.json')):
                p = os.path.join(root, f)
                try:
                    with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                        for i, line in enumerate(fp, 1):
                            if pattern.search(line):
                                found.append(f"{p}:{i}: {line.strip()[:100]}")
                except Exception as e:
                    pass

for item in found:
    print(item)
print(f"Total occurrences: {len(found)}")
