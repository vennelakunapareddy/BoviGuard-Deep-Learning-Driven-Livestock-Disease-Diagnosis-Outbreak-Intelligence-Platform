import os
from pathlib import Path

root = Path(r"c:\Users\venne\Downloads\buffalo health\animal-health")

def get_dir_size(p):
    total = 0
    count = 0
    try:
        for entry in os.scandir(p):
            try:
                if entry.is_file(follow_symlinks=True):
                    total += entry.stat(follow_symlinks=True).st_size
                    count += 1
                elif entry.is_dir(follow_symlinks=True):
                    s, c = get_dir_size(entry.path)
                    total += s
                    count += c
            except Exception:
                pass
    except Exception:
        pass
    return total, count

for item in sorted(root.iterdir()):
    if item.is_dir():
        sz, cnt = get_dir_size(item)
        print(f"{item.name:<25}: {sz / (1024*1024):>8.2f} MB ({cnt} files)")
    else:
        print(f"{item.name:<25}: {item.stat().st_size / 1024:>8.2f} KB (file)")
