const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    list.forEach(file => {
      let fullPath = path.join(dir, file);
      if (file === 'node_modules' || file === '.git' || file === 'dist') return;
      if (fs.statSync(fullPath).isDirectory()) {
        results = results.concat(walk(fullPath));
      } else if (file.endsWith('.jsx')) {
        results.push(fullPath);
      }
    });
  } catch (e) {}
  return results;
}

walk('frontend-v2/src').forEach(f => {
  const lines = fs.readFileSync(f, 'utf8').split('\n');
  lines.forEach((l, idx) => {
    if (l.includes('<option')) {
      console.log(`${f}:${idx + 1} -> ${l.trim()}`);
    }
  });
});
