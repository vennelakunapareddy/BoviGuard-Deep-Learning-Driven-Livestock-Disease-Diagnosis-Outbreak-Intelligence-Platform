import sys
from PIL import Image
sys.path.insert(0, 'ml-service')
from model import BuffaloDiseaseModel

m = BuffaloDiseaseModel()
for p in ['c:/Users/venne/Downloads/fmd.jpg', 'c:/Users/venne/Downloads/lumppy.jpg', 'c:/Users/venne/Downloads/Lumpy-skin-disease_d.jpg']:
    try:
        img = Image.open(p)
        res = m.predict_detailed(img)
        print("RESULT FOR", p, ":", res["prediction"], f"({res['confidenceScore']}%)", "Status:", res["status"])
    except Exception as e:
        print("Error on", p, ":", e)
