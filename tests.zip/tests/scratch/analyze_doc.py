import cv2
import numpy as np
from PIL import Image, ImageStat

img_path = r"scratch\doc_crop.png"
img = cv2.imread(img_path)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

# 1. Background brightness and saturation
h, s, v = cv2.split(hsv)
mean_s = np.mean(s)
mean_v = np.mean(v)
print(f"Mean Saturation: {mean_s:.2f}, Mean Value/Brightness: {mean_v:.2f}")

# 2. White pixel ratio (>200 brightness and low saturation)
white_bg_mask = (v > 180) & (s < 40)
white_ratio = np.count_nonzero(white_bg_mask) / white_bg_mask.size
print(f"White background ratio: {white_ratio*100:.2f}%")

# 3. Dark stroke / text pixel ratio (<100 brightness)
dark_stroke_mask = (v < 110)
dark_ratio = np.count_nonzero(dark_stroke_mask) / dark_stroke_mask.size
print(f"Dark text stroke ratio: {dark_ratio*100:.2f}%")

# 4. Horizontal edge density (text lines produce strong horizontal edge patterns)
sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
edge_mag = np.sqrt(sobel_x**2 + sobel_y**2)
mean_edge = np.mean(edge_mag)
print(f"Mean Sobel Edge Magnitude: {mean_edge:.2f}")

# 5. Connected components (text has many small connected components)
_, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(thresh)
print(f"Number of connected components (potential letters/words): {num_labels}")

# Count components that look like text characters (small width, height, aspect ratio)
char_count = 0
for i in range(1, num_labels):
    w = stats[i, cv2.CC_STAT_WIDTH]
    h_box = stats[i, cv2.CC_STAT_HEIGHT]
    area = stats[i, cv2.CC_STAT_AREA]
    if 3 < w < 80 and 5 < h_box < 80 and 10 < area < 2000:
        char_count += 1
print(f"Text character candidate count: {char_count}")
