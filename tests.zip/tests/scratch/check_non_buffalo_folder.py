import os
import sys
import torch
from PIL import Image

sys.path.insert(0, os.path.abspath('ml-service'))
import app

# Let's inspect test_non_buffalo folder if any images exist
test_dir = r"ml-service\test_non_buffalo"
if os.path.exists(test_dir):
    print("Files in test_non_buffalo:", os.listdir(test_dir))
    for f in os.listdir(test_dir):
        if f.lower().endswith(('.jpg', '.png', '.jpeg')):
            p = os.path.join(test_dir, f)
            img = Image.open(p).convert('RGB')
            is_valid, msg = app.is_valid_buffalo_image(img)
            print(f"File {f}: is_valid={is_valid}, msg={msg}")
else:
    print("test_non_buffalo folder not found")
