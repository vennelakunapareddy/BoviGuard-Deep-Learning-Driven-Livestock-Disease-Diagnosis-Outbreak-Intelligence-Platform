import torch
from torchvision import models
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta['categories']
transform = weights.transforms()

img = Image.open('random_texture.jpg').convert('RGB')
t = transform(img).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(t), dim=-1).squeeze(0)
top5_p, top5_idx = torch.topk(probs, 5)
print("random_texture.jpg Top 5 ImageNet:")
for i in range(5):
    print(f"  {categories[top5_idx[i]]}: {float(top5_p[i])*100:.2f}% (idx={int(top5_idx[i])})")
