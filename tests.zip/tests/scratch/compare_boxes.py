import torch
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image

weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
detector = ssdlite320_mobilenet_v3_large(weights=weights).eval()
coco_classes = weights.meta["categories"]
transform = weights.transforms()

for name in ['test_human.jpg', 'ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg']:
    img = Image.open(name).convert('RGB')
    t = transform(img).unsqueeze(0)
    with torch.no_grad():
        preds = detector(t)[0]
    scores = preds['scores']
    labels = preds['labels']
    boxes = preds['boxes']
    mask = scores > 0.40
    print(f"\nImage: {name} (size: {img.size})")
    for b, l, s in zip(boxes[mask], labels[mask], scores[mask]):
        print(f"  {coco_classes[int(l)]}: score={float(s):.4f}, box={[round(float(x), 1) for x in b]}")
