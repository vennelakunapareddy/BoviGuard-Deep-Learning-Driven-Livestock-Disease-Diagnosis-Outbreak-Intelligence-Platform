import os
import sys
import torch
import torchvision.models as models
import torchvision.transforms as transforms

weights = models.MobileNet_V2_Weights.DEFAULT
categories = weights.meta["categories"]

# 1. Dogs: 151 to 268
dog_classes = {i: categories[i] for i in range(151, 269)}
print("Total dog classes in ImageNet:", len(dog_classes))
print("Sample dogs:", list(dog_classes.values())[:5])

# 2. Cats: 281 to 285 (+ 286 to 293)
cat_classes = {i: categories[i] for i in range(281, 294)}
print("Total cat classes in ImageNet:", len(cat_classes))
print("Sample cats:", list(cat_classes.values())[:5])

# 3. Bovids:
bovid_classes = {i: categories[i] for i, c in enumerate(categories) if any(k in c.lower() for k in ["buffalo", "bison", "ox", "cow"])}
print("Bovid classes:", bovid_classes)

# 4. Document / text keywords
doc_classes = {i: categories[i] for i, c in enumerate(categories) if any(k in c.lower() for k in ["book", "paper", "menu", "page", "web site", "website", "envelope", "comic book", "crossword"])}
print("Doc classes:", doc_classes)
