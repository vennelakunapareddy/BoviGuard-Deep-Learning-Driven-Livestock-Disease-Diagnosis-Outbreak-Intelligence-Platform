import torch
from torchvision import models
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image
from pathlib import Path

det_weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
detector = ssdlite320_mobilenet_v3_large(weights=det_weights).eval()
coco_classes = det_weights.meta["categories"]
det_transform = det_weights.transforms()

cls_weights = models.MobileNet_V2_Weights.DEFAULT
classifier = models.mobilenet_v2(weights=cls_weights).eval()
imagenet_classes = cls_weights.meta["categories"]
cls_transform = cls_weights.transforms()

lsd_dir = Path("ml-service/buffalo_dataset/test/Lumpy_Skin_Disease")
for p in sorted(list(lsd_dir.glob("*.png")) + list(lsd_dir.glob("*.jpg")))[:5]:
    img = Image.open(p).convert('RGB')
    t_det = det_transform(img).unsqueeze(0)
    t_cls = cls_transform(img).unsqueeze(0)
    with torch.no_grad():
        preds = detector(t_det)[0]
        logits = classifier(t_cls)
        probs = torch.softmax(logits, dim=-1).squeeze(0)
    det_s = preds['scores']
    det_l = preds['labels']
    mask = det_s > 0.35
    det_list = [(coco_classes[int(l)], round(float(s)*100, 1)) for l, s in zip(det_l[mask], det_s[mask])]
    top3_p, top3_idx = torch.topk(probs, 3)
    cls_list = [(imagenet_classes[int(i)], round(float(p)*100, 1)) for i, p in zip(top3_idx, top3_p)]
    print(f"{p.name:<32} | SSDLite: {det_list} | ImageNet: {cls_list}")
