import torch
from torchvision import models
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
transform = weights.transforms()

CANINE_INDICES = set(range(151, 276))

img = Image.open('ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0002.jpg').convert('RGB')
t = transform(img).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(t), dim=-1).squeeze(0)
print('Total canine on FMD test 0002:', sum(float(probs[i]) for i in CANINE_INDICES) * 100)

dog_img = Image.open('test_dog.jpg').convert('RGB')
t_dog = transform(dog_img).unsqueeze(0)
with torch.no_grad():
    probs_dog = torch.softmax(model(t_dog), dim=-1).squeeze(0)
print('Total canine on test_dog.jpg:', sum(float(probs_dog[i]) for i in CANINE_INDICES) * 100)
