import os
import requests
import json
from pathlib import Path

BACKEND_URL = "http://127.0.0.1:3000/api/cases/predict"

def test_image(img_path, category, expected_behavior):
    if not os.path.exists(img_path):
        return {"file": os.path.basename(img_path), "status": "MISSING_FILE"}

    with open(img_path, "rb") as f:
        files = {"image": (os.path.basename(img_path), f, "image/jpeg")}
        data = {"animalType": "Buffalo"}
        try:
            r = requests.post(BACKEND_URL, files=files, data=data, timeout=20)
            res = r.json()
            is_buffalo = res.get("isBuffalo", res.get("is_buffalo", False))
            status = res.get("status", "unknown")
            prediction = res.get("diseasePrediction") or res.get("prediction")
            conf = res.get("confidenceScore", res.get("confidence", 0))
            subject = res.get("predictedSubject")
            msg = res.get("message", "")
            return {
                "file": os.path.basename(img_path),
                "category": category,
                "expected": expected_behavior,
                "http_status": r.status_code,
                "is_buffalo": is_buffalo,
                "gate_status": status,
                "prediction": prediction,
                "confidence": conf,
                "subject": subject,
                "message": msg[:60]
            }
        except Exception as e:
            return {"file": os.path.basename(img_path), "status": f"ERROR: {e}"}

def run_suite():
    print("=" * 80)
    print("      COMPREHENSIVE 17-CASE INFERENCE PIPELINE REGRESSION SUITE")
    print(f"      Target: {BACKEND_URL}")
    print("=" * 80)

    # Find sample dataset test images
    test_dir = Path("ml-service/buffalo_dataset/test")
    fmd_samples = list((test_dir / "Foot_and_Mouth_Disease").glob("*.jpg")) + list((test_dir / "Foot_and_Mouth_Disease").glob("*.png"))
    healthy_samples = list((test_dir / "Healthy_Buffalo").glob("*.jpg")) + list((test_dir / "Healthy_Buffalo").glob("*.png"))
    lsd_samples = list((test_dir / "Lumpy_Skin_Disease").glob("*.jpg")) + list((test_dir / "Lumpy_Skin_Disease").glob("*.png"))
    mastitis_samples = list((test_dir / "Mastitis").glob("*.jpg")) + list((test_dir / "Mastitis").glob("*.png"))

    cases = [
        # --- 1. Non-Buffalo Rejections ---
        ("test_dog.jpg", "Non-Buffalo", "REJECT (Dog)"),
        ("test_hen.jpg", "Non-Buffalo", "REJECT (Hen/Poultry)"),
        ("test_cat.jpg", "Non-Buffalo", "REJECT (Cat)"),
        ("test_car.jpg", "Non-Buffalo", "REJECT (Vehicle)"),
        ("test_human.jpg", "Non-Buffalo", "REJECT (Human)"),
        ("unseen_goat.jpg", "Non-Buffalo", "REJECT (Other Mammal)"),

        # --- 2. Low-Evidence Frame ---
        ("corrupted_blur.jpg", "Low-Evidence", "REJECT (Low contrast/blur)"),

        # --- 3. Dataset Test Split Buffalo Cases ---
        (str(fmd_samples[0]) if fmd_samples else "fmd.jpg", "Dataset Test (FMD)", "ACCEPT -> FMD"),
        (str(fmd_samples[1]) if len(fmd_samples) > 1 else "fmd.jpg", "Dataset Test (FMD)", "ACCEPT -> FMD"),
        (str(healthy_samples[0]) if healthy_samples else "", "Dataset Test (Healthy)", "ACCEPT -> Healthy"),
        (str(healthy_samples[1]) if len(healthy_samples) > 1 else "", "Dataset Test (Healthy)", "ACCEPT -> Healthy"),
        (str(lsd_samples[0]) if lsd_samples else "lumppy.jpg", "Dataset Test (LSD)", "ACCEPT -> LSD"),
        (str(lsd_samples[1]) if len(lsd_samples) > 1 else "lumppy.jpg", "Dataset Test (LSD)", "ACCEPT -> LSD"),
        (str(mastitis_samples[0]) if mastitis_samples else "", "Dataset Test (Mastitis)", "ACCEPT -> Mastitis"),
        (str(mastitis_samples[1]) if len(mastitis_samples) > 1 else "", "Dataset Test (Mastitis)", "ACCEPT -> Mastitis"),

        # --- 4. Unseen Real-World Animals ---
        ("unseen_healthy_buffalo.jpg", "Unseen Buffalo", "ACCEPT -> Evaluate Real-world"),
        ("unseen_cow.jpg", "Unseen Bovine", "Bovine behavior evaluation"),
    ]

    results = []
    for img_path, cat, exp in cases:
        if not img_path:
            continue
        res = test_image(img_path, cat, exp)
        results.append(res)
        gate_icon = "PASS" if res.get("is_buffalo") else "REJECT"
        pred_str = f"{res.get('prediction')} ({res.get('confidence')}%)" if res.get("is_buffalo") else f"Subject: {res.get('subject')}"
        print(f"[{gate_icon:6}] {res.get('file', '')[:25]:<25} | {cat:<22} | {res.get('gate_status', ''):<15} | {pred_str}")

    print("\n" + "=" * 80)
    print("                     EVALUATION SUMMARY")
    print("=" * 80)
    rejections = [r for r in results if not r.get("is_buffalo")]
    accepts = [r for r in results if r.get("is_buffalo")]
    print(f"Total Cases Tested:      {len(results)}")
    print(f"Total Rejected by Gate:  {len(rejections)} (Protected from false disease diagnosis)")
    print(f"Total Accepted by Gate:  {len(accepts)} (Passed to 4-class disease model)")

    # Save results json
    with open("scratch/regression_suite_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("Results saved to scratch/regression_suite_results.json")

if __name__ == "__main__":
    run_suite()
