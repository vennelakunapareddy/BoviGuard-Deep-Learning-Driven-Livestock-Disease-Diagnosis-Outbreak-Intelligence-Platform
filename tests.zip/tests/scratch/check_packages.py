import sys

for pkg in ['ultralytics', 'torchvision', 'cv2', 'PIL', 'timm', 'torch']:
    try:
        mod = __import__(pkg)
        print(f"{pkg}: {getattr(mod, '__version__', 'installed')}")
    except ImportError:
        print(f"{pkg}: NOT installed")

# Also check torchvision detection models
try:
    from torchvision.models import detection
    print("torchvision.models.detection is available!")
    print("Available detection models in torchvision:", [m for m in dir(detection) if not m.startswith('_') and 'weights' not in m.lower()])
except Exception as e:
    print("detection error:", e)
