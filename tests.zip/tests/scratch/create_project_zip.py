import os
import sys
import time
import zipfile
from pathlib import Path

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

source_dir = r"c:\Users\venne\Downloads\buffalo health"
output_zip = r"c:\Users\venne\Downloads\buffalo_health_complete.zip"

print("=" * 70)
print(f"Starting ZIP creation from: {source_dir}")
print(f"Target archive:            {output_zip}")
print("Following all NTFS junctions and directory symlinks...")
print("=" * 70)

start_time = time.time()
file_count = 0
total_bytes = 0
skipped_files = []

# Collect all files first to show progress
all_files = []
for dirpath, dirnames, filenames in os.walk(source_dir, followlinks=True):
    for f in filenames:
        fp = os.path.join(dirpath, f)
        # Avoid including the output zip if it happens to be in the search path
        if os.path.abspath(fp) == os.path.abspath(output_zip):
            continue
        all_files.append(fp)

total_to_zip = len(all_files)
print(f"Total files identified across all subtrees & junctions: {total_to_zip}")

with zipfile.ZipFile(output_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zf:
    for idx, fp in enumerate(all_files, 1):
        try:
            arcname = os.path.relpath(fp, os.path.dirname(source_dir))
            zf.write(fp, arcname)
            file_count += 1
            total_bytes += os.path.getsize(fp)
            if idx % 2000 == 0 or idx == total_to_zip:
                elapsed = time.time() - start_time
                print(f"  Progress: {idx}/{total_to_zip} files ({(idx/total_to_zip)*100:.1f}%) in {elapsed:.1f}s")
        except Exception as e:
            skipped_files.append((fp, str(e)))

elapsed_total = time.time() - start_time
zip_size = os.path.getsize(output_zip)

print("=" * 70)
print(f"ZIP CREATION COMPLETED SUCCESSFULLY in {elapsed_total:.1f}s!")
print(f"Total files compressed: {file_count}")
print(f"Total uncompressed size: {total_bytes / (1024*1024):.2f} MB")
print(f"Final archive size:      {zip_size / (1024*1024):.2f} MB")
print(f"Archive location:        {output_zip}")
if skipped_files:
    print(f"Warning: {len(skipped_files)} files could not be read:")
    for sf, err in skipped_files[:10]:
        print(f"  - {sf}: {err}")
else:
    print("Zero files missed. 100% of files included.")
print("=" * 70)
