import torch
from torchvision import models
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image, ImageStat
from pathlib import Path

class RobustBuffaloValidationGate:
    def __init__(self, device):
        self.device = device
        # 1. COCO Object Detector (SSDLite320)
        det_weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
        self.detector = ssdlite320_mobilenet_v3_large(weights=det_weights).to(self.device).eval()
        self.coco_classes = det_weights.meta["categories"]
        self.det_transform = det_weights.transforms()

        # 2. ImageNet Classifier (MobileNet-V2)
        cls_weights = models.MobileNet_V2_Weights.DEFAULT
        self.classifier = models.mobilenet_v2(weights=cls_weights).to(self.device).eval()
        self.imagenet_classes = cls_weights.meta["categories"]
        self.cls_transform = cls_weights.transforms()

        # ImageNet index sets
        self.bovine_indices = {345, 346, 347, 697}
        self.canine_indices = set(range(151, 276))
        self.feline_indices = set(range(281, 294))
        self.bird_indices = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147)))
        self.other_mammal_indices = set(list(range(294, 345)) + list(range(348, 385)))
        self.vehicle_indices = {403, 407, 436, 475, 479, 511, 627, 654, 670, 671, 751, 817, 864, 867, 895, 468, 555, 665, 705, 734, 779, 829}
        self.document_indices = {916, 620, 664, 782, 487, 921, 446, 508, 526, 722, 687, 728}
        self.building_indices = {497, 498, 538, 598, 652, 663, 678, 698, 706, 449, 749, 876}
        self.human_keywords = ["suit", "jersey", "t-shirt", "sweatshirt", "gown", "sunglasses", "wig", "mask", "military uniform", "cloak", "scuba diver", "neck brace"]

    def inspect(self, pil_img: Image.Image) -> dict:
        w, h = pil_img.size
        img_area = w * h

        # -------------------------------------------------------------
        # STEP 1: Image Quality / Variance Check
        # -------------------------------------------------------------
        stat = ImageStat.Stat(pil_img)
        var = sum(stat.var) / len(stat.var)
        mean_b = sum(stat.mean) / len(stat.mean)
        if var < 12.0 or mean_b < 10 or mean_b > 248:
            return {
                "outcome": "C_UNCERTAIN",
                "is_buffalo": False,
                "status": "uncertain_evidence",
                "entity": "Blank / Low-Contrast Frame",
                "icon": "⚠️",
                "message": "Buffalo validation uncertain: Insufficient visual evidence (blank, dark, or blurry frame). Please provide a clearer photo."
            }

        # -------------------------------------------------------------
        # STEP 2: COCO Object Detection
        # -------------------------------------------------------------
        det_t = self.det_transform(pil_img).unsqueeze(0).to(self.device)
        with torch.no_grad():
            preds = self.detector(det_t)[0]

        det_scores = preds['scores']
        det_labels = preds['labels']
        det_boxes = preds['boxes']

        # Extract confident detections
        detected_objects = []
        for b, l, s in zip(det_boxes, det_labels, det_scores):
            score_val = float(s)
            if score_val < 0.35:
                continue
            cat_name = self.coco_classes[int(l)]
            box_area = float((b[2] - b[0]) * (b[3] - b[1]))
            area_pct = (box_area / img_area) * 100
            detected_objects.append({
                "label": cat_name,
                "score": score_val,
                "area_pct": area_pct
            })

        has_bovine_obj = any(o["label"] == "cow" for o in detected_objects)
        person_objs = [o for o in detected_objects if o["label"] == "person"]
        dog_objs = [o for o in detected_objects if o["label"] == "dog"]
        cat_objs = [o for o in detected_objects if o["label"] == "cat"]
        bird_objs = [o for o in detected_objects if o["label"] == "bird"]
        vehicle_objs = [o for o in detected_objects if o["label"] in {"car", "truck", "bus", "motorcycle", "bicycle"}]

        # -------------------------------------------------------------
        # STEP 3: ImageNet Classification Check (Fine-Grained Context)
        # -------------------------------------------------------------
        cls_t = self.cls_transform(pil_img).unsqueeze(0).to(self.device)
        with torch.no_grad():
            cls_logits = self.classifier(cls_t)
            cls_probs = torch.softmax(cls_logits, dim=-1).squeeze(0)

        top5_p, top5_idx = torch.topk(cls_probs, 5)
        top5_indices = [int(idx.item()) for idx in top5_idx]
        top1_idx = top5_indices[0]
        top1_cat = self.imagenet_classes[top1_idx].lower()
        top1_prob = float(top5_p[0]) * 100

        has_bovine_cls = any(idx in self.bovine_indices for idx in top5_indices)
        has_human_attire = any(k in top1_cat for k in self.human_keywords) or any(any(k in self.imagenet_classes[idx].lower() for k in self.human_keywords) for idx in top5_indices[:3])

        # 2A. REJECT HUMAN / SELFIE / FACE / PERSON WITHOUT BUFFALO
        # If person is detected with very high confidence (> 0.92) AND (human attire is recognized OR person score > 0.97) without bovine
        if person_objs and not has_bovine_obj and not has_bovine_cls:
            top_person = max(person_objs, key=lambda x: x["score"])
            if (top_person["score"] > 0.92 and has_human_attire) or top_person["score"] > 0.97:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Human / Person",
                    "icon": "👤",
                    "message": "Prediction failed: Human detected in the image. Please point camera at a buffalo."
                }

        # 2B. REJECT DOG
        if dog_objs and not has_bovine_obj and not has_bovine_cls:
            top_dog = max(dog_objs, key=lambda x: x["score"])
            if top_dog["score"] > 0.50:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Domestic Dog",
                    "icon": "🐶",
                    "message": "Prediction failed: Domestic dog detected. This system only diagnoses water buffaloes."
                }

        # 2C. REJECT BIRD / POULTRY / HEN
        if bird_objs and not has_bovine_obj and not has_bovine_cls:
            top_bird = max(bird_objs, key=lambda x: x["score"])
            if top_bird["score"] > 0.50:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Bird / Poultry",
                    "icon": "🐔",
                    "message": "Prediction failed: Bird/poultry detected. This system only diagnoses water buffaloes."
                }

        # 2D. REJECT FELINE / CAT
        if cat_objs and not has_bovine_obj and not has_bovine_cls:
            top_cat = max(cat_objs, key=lambda x: x["score"])
            if top_cat["score"] > 0.50:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Feline / Cat",
                    "icon": "🐱",
                    "message": "Prediction failed: Feline/cat detected. This system only diagnoses water buffaloes."
                }

        # 2E. REJECT VEHICLE
        if vehicle_objs and not has_bovine_obj and not has_bovine_cls:
            top_veh = max(vehicle_objs, key=lambda x: x["score"])
            if top_veh["score"] > 0.50:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Vehicle ({top_veh['label']})",
                    "icon": "🚗",
                    "message": "Prediction failed: Vehicle detected in the image."
                }

        # 3A. Direct Bovine Confirmation
        if has_bovine_obj or has_bovine_cls:
            return {
                "outcome": "A_ACCEPTED",
                "is_buffalo": True,
                "status": "confident",
                "entity": "Water Buffalo / Bovine",
                "icon": "🐃"
            }

        # 3B. ImageNet Non-Buffalo Checks
        total_canine = sum(float(cls_probs[i]) for i in self.canine_indices) * 100
        total_bird = sum(float(cls_probs[i]) for i in self.bird_indices) * 100
        total_feline = sum(float(cls_probs[i]) for i in self.feline_indices) * 100

        if (top1_idx in self.canine_indices and top1_prob > 12.0) or total_canine > 45.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Domestic Dog ({self.imagenet_classes[top1_idx]})",
                "icon": "🐶",
                "message": f"Prediction failed: Domestic dog detected ({self.imagenet_classes[top1_idx]})."
            }

        if (top1_idx in self.bird_indices and top1_prob > 15.0) or total_bird > 25.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Bird / Poultry ({self.imagenet_classes[top1_idx]})",
                "icon": "🐔",
                "message": f"Prediction failed: Bird/poultry detected ({self.imagenet_classes[top1_idx]})."
            }

        if (top1_idx in self.feline_indices and top1_prob > 6.0) or total_feline > 25.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Feline / Cat ({self.imagenet_classes[top1_idx]})",
                "icon": "🐱",
                "message": f"Prediction failed: Feline detected ({self.imagenet_classes[top1_idx]})."
            }

        # Documents & Digital Screens
        doc_keywords = ["web site", "menu", "envelope", "screen", "monitor", "laptop", "cellular telephone", 
                        "crossword", "rule", "paper", "comic book", "book jacket", "binder", "packet", "oscilloscope"]
        if (top1_idx in self.document_indices and top1_prob > 15.0) or (any(k in top1_cat for k in doc_keywords) and top1_prob > 15.0):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Digital Screen / Document ({self.imagenet_classes[top1_idx]})",
                "icon": "💻",
                "message": "Prediction failed: Document / screen detected in the image."
            }

        # Vehicles
        veh_keywords = ["car", "automobile", "sports car", "truck", "cab", "van", "jeep", "bus", "bicycle", "motorcycle", "airplane", "boat"]
        if (top1_idx in self.vehicle_indices and top1_prob > 15.0) or (any(k in top1_cat for k in veh_keywords) and top1_prob > 15.0):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Vehicle ({self.imagenet_classes[top1_idx]})",
                "icon": "🚗",
                "message": "Prediction failed: Vehicle detected in the image."
            }

        # Buildings
        bldg_keywords = ["palace", "castle", "monastery", "church", "mosque", "tile roof", "bell cote", "beacon", "bridge", "house"]
        if (top1_idx in self.building_indices and top1_prob > 15.0) or (any(k in top1_cat for k in bldg_keywords) and top1_prob > 15.0):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Building / Architecture ({self.imagenet_classes[top1_idx]})",
                "icon": "🏛️",
                "message": "Prediction failed: Building/architecture detected in the image."
            }

        # Humans / Clothing
        if any(k in top1_cat for k in self.human_keywords) and top1_prob > 3.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Human / Person ({self.imagenet_classes[top1_idx]})",
                "icon": "👤",
                "message": "Prediction failed: Human detected in the image."
            }

        # -------------------------------------------------------------
        # STEP 4: Macro Lesion Candidate vs Uncertain Image
        # -------------------------------------------------------------
        incompatible_objects = ["frisbee", "clock", "shoe", "bottle", "cup", "keyboard", "mouse", "toaster", "refrigerator"]
        if any(k in top1_cat for k in incompatible_objects) and top1_prob > 15.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Object ({self.imagenet_classes[top1_idx]})",
                "icon": "📦",
                "message": f"Prediction failed: Incompatible object detected ({self.imagenet_classes[top1_idx]})."
            }

        # Close-up skin / lesion candidate
        return {
            "outcome": "A_ACCEPTED",
            "is_buffalo": True,
            "status": "confident",
            "entity": "Buffalo Lesion / Cutaneous Area",
            "icon": "🔬"
        }

if __name__ == "__main__":
    gate = RobustBuffaloValidationGate(torch.device("cpu"))
    test_cases = [
        ("test_human.jpg", "Human Face/Selfie"),
        ("test_dog.jpg", "Dog"),
        ("test_hen.jpg", "Hen/Poultry"),
        ("test_cat.jpg", "Cat"),
        ("test_car.jpg", "Car"),
        ("corrupted_blur.jpg", "Blur / Corrupt"),
        ("unseen_healthy_buffalo.jpg", "Unseen Buffalo"),
        ("unseen_cow.jpg", "Unseen Cow"),
        ("unseen_goat.jpg", "Unseen Goat"),
        ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg", "Mastitis (Vet holding)"),
        ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0002.jpg", "Mastitis (Macro Udder)"),
        ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg", "FMD (Mouth)"),
        ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0002.jpg", "FMD (Vet holding)"),
        ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg", "Healthy (Farmer + Buffalo)"),
        ("ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.jpg", "LSD (Nodules)"),
    ]

    print("=" * 80)
    print(f"{'Image':<35} | {'Category':<22} | {'Outcome':<12} | {'Entity'}")
    print("=" * 80)
    for p, cat in test_cases:
        path = Path(p)
        if not path.exists():
            continue
        img = Image.open(path).convert('RGB')
        res = gate.inspect(img)
        print(f"{path.name:<35} | {cat:<22} | {res['outcome']:<12} | {res.get('entity', '')}")
