import cv2

try:
    print("Testing FaceDetectorYN...")
    detector = cv2.FaceDetectorYN.create("", "", (320, 320))
    print("Created successfully!")
except Exception as e:
    print("FaceDetectorYN error:", e)
