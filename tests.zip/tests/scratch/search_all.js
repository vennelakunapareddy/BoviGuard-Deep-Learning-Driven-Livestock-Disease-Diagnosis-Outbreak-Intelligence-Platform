const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  fs.readdirSync(dir).forEach(file => {
    let fullPath = path.join(dir, file);
    if (file === 'node_modules' || file === '.git' || file === 'dist' || file === 'scratch') return;
    if (fs.statSync(fullPath).isDirectory()) {
      results = results.concat(walk(fullPath));
    } else if (/\.(js|jsx|json|py|md|html)$/.test(file)) {
      results.push(fullPath);
    }
  });
  return results;
}

const files = walk('.');
const terms = ['brucell', 'traumatic', 'cutaneous'];

console.log(`Scanning ${files.length} files...`);

files.forEach(f => {
  const content = fs.readFileSync(f, 'utf8');
  terms.forEach(t => {
    const regex = new RegExp(t, 'i');
    if (regex.test(content)) {
      content.split('\n').forEach((line, idx) => {
        if (regex.test(line)) {
          console.log(`${f}:${idx + 1} [${t}] -> ${line.trim()}`);
        }
      });
    }
  });
});
