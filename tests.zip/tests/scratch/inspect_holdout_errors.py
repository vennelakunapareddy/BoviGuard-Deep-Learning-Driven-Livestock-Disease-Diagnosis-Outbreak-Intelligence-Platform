import os
import sys
from pathlib import Path
from PIL import Image

# Ensure ml-service is on path
project_root = Path(r"c:\Users\venne\Downloads\buffalo health\animal-health")
ml_service_dir = project_root / "ml-service"
sys.path.insert(0, str(ml_service_dir))

from model import BuffaloDiseaseModel, CLASS_NAMES

def evaluate_holdout():
    holdout_dir = ml_service_dir / "real_world_holdout"
    if not holdout_dir.exists():
        print(f"Error: Holdout directory not found at {holdout_dir}")
        return

    print("==========================================================")
    print("  EVALUATING BALANCED REAL-WORLD HOLDOUT SET (100 IMAGES) ")
    print("           EXACTLY 10 IMAGES PER CLASS (UNBIASED)         ")
    print("==========================================================")
    
    model = BuffaloDiseaseModel(model_path=str(ml_service_dir / "buffalo_model.pth"))
    print(f"Current Model Tau: {model.tau}")
    print(f"Model 1 Loaded: {model.m1_loaded}")
    print(f"Model 2 Loaded: {model.m2_loaded}")

    total_images = 0
    top1_correct = 0
    top2_correct = 0
    top3_correct = 0

    per_class_stats = {cls_name: {"total": 0, "top1": 0, "top2": 0} for cls_name in CLASS_NAMES}
    errors = []

    for class_name in CLASS_NAMES:
        class_folder = holdout_dir / class_name
        if not class_folder.exists():
            continue

        images = [f for f in sorted(os.listdir(class_folder)) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')) and "gradcam" not in f.lower()]
        for img_name in images:
            img_path = class_folder / img_name
            total_images += 1
            per_class_stats[class_name]["total"] += 1

            try:
                with Image.open(img_path) as pil_img:
                    rgb_img = pil_img.convert("RGB")
                    top_pred, top_conf, topk, all_probs, trained = model.predict(rgb_img, filename=img_name)

                # Get top predictions as keys
                top_keys = [item.get("disease_key") for item in topk]
                
                is_top1 = (top_keys[0] == class_name)
                is_top2 = (class_name in top_keys[:2])
                is_top3 = (class_name in top_keys[:3])

                if is_top1:
                    top1_correct += 1
                    per_class_stats[class_name]["top1"] += 1
                if is_top2:
                    top2_correct += 1
                    per_class_stats[class_name]["top2"] += 1
                if is_top3:
                    top3_correct += 1

                if not is_top1:
                    errors.append({
                        "file": f"{class_name}/{img_name}",
                        "true": class_name,
                        "pred_top1": top_keys[0],
                        "conf_top1": top_conf,
                        "pred_top2": top_keys[1] if len(top_keys) > 1 else None,
                        "conf_top2": topk[1]["confidence"] if len(topk) > 1 else 0.0
                    })
            except Exception as e:
                print(f"Error processing {img_path}: {e}")

    top1_acc = (top1_correct / total_images) * 100 if total_images else 0
    top2_acc = (top2_correct / total_images) * 100 if total_images else 0
    top3_acc = (top3_correct / total_images) * 100 if total_images else 0

    print("\n--- PER-CLASS BREAKDOWN ---")
    for cls_name in CLASS_NAMES:
        stats = per_class_stats[cls_name]
        tot = stats["total"]
        t1 = stats["top1"]
        t2 = stats["top2"]
        t1_pct = (t1 / tot) * 100 if tot else 0
        t2_pct = (t2 / tot) * 100 if tot else 0
        print(f"[{cls_name:<26}] Total: {tot:>2} | Top-1: {t1:>2}/{tot:>2} ({t1_pct:>5.1f}%) | Top-2: {t2:>2}/{tot:>2} ({t2_pct:>5.1f}%)")

    print("\n==========================================================")
    print(f"TOTAL HOLDOUT IMAGES: {total_images}")
    print(f"TOP-1 ACCURACY:       {top1_acc:.2f}% ({top1_correct}/{total_images})")
    print(f"TOP-2 ACCURACY:       {top2_acc:.2f}% ({top2_correct}/{total_images})")
    print(f"TOP-3 ACCURACY:       {top3_acc:.2f}% ({top3_correct}/{total_images})")
    print("==========================================================")

    if errors:
        print(f"\n--- SAMPLE ERRORS ({len(errors)} total) ---")
        for err in errors[:10]:
            print(f"File: {err['file']} | True: {err['true']} -> Pred: {err['pred_top1']} ({err['conf_top1']}%) | Top-2: {err['pred_top2']} ({err['conf_top2']}%)")

if __name__ == "__main__":
    evaluate_holdout()
