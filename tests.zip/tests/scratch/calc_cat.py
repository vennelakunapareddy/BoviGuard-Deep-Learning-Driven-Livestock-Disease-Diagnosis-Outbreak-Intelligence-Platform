import torch
from torchvision import models
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta['categories']
transform = weights.transforms()

FELINE_INDICES = set(range(281, 294))

cat_img = Image.open('test_cat.jpg').convert('RGB')
t_cat = transform(cat_img).unsqueeze(0)
with torch.no_grad():
    probs_cat = torch.softmax(model(t_cat), dim=-1).squeeze(0)

top1_p, top1_idx = torch.topk(probs_cat, 1)
print(f"test_cat.jpg: top1={categories[top1_idx]} ({float(top1_p)*100:.2f}%), total_feline={sum(float(probs_cat[i]) for i in FELINE_INDICES)*100:.2f}%")
