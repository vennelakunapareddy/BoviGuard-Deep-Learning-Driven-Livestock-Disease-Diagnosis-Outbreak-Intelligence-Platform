import os
from pathlib import Path

root = Path(r"c:\Users\venne\Downloads\buffalo health\animal-health\ml-service")

for item in sorted(root.iterdir()):
    if item.is_dir():
        total = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
        count = sum(1 for f in item.rglob('*') if f.is_file())
        print(f"{item.name:<25}: {total / (1024*1024):>8.2f} MB ({count} files)")
    else:
        print(f"{item.name:<25}: {item.stat().st_size / (1024*1024):>8.2f} MB (file)")
