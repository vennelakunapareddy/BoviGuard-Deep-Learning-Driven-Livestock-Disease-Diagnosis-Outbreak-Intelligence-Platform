import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image
from test_detector_logic import detect_document_cv

f = r"backend\uploads\buffalo-1789550961871-319771322.png"
im = Image.open(f).convert("RGB")
is_doc, conf = detect_document_cv(im)
print(f"detect_document_cv on 319771322.png: is_doc={is_doc}, conf={conf}")
