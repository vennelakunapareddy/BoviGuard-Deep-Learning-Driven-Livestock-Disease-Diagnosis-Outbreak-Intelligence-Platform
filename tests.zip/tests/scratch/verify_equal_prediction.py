import os
import sys
import torch
from PIL import Image

# Ensure ml-service is on path
current_dir = os.path.dirname(os.path.abspath(__file__))
ml_service_dir = os.path.join(current_dir, '..', 'ml-service')
if not os.path.exists(ml_service_dir):
    ml_service_dir = os.path.join(current_dir, 'ml-service')
if not os.path.exists(ml_service_dir):
    ml_service_dir = current_dir

sys.path.insert(0, os.path.abspath(ml_service_dir))
from model import BuffaloDiseaseModel, CLASS_NAMES, CLASS_DISPLAY

def verify_predictions():
    print("=" * 80)
    print("SOTA POST-HOC LOGIT ADJUSTMENT (Menon et al., ICLR 2021) VERIFICATION")
    print("=" * 80)
    print("Initializing BuffaloDiseaseModel...")
    model = BuffaloDiseaseModel()
    
    val_dir = os.path.join(ml_service_dir, 'buffalo_dataset', 'val')
    if not os.path.exists(val_dir):
        val_dir = os.path.join(current_dir, 'buffalo_dataset', 'val')

    print(f"Loading holdout validation dataset from: {val_dir}")
    print(f"Logit Adjustment tau: {model.tau}")
    print(f"Platt Temperature:   {model.temperature}")
    print("-" * 80)

    results = []
    
    for class_name in CLASS_NAMES:
        class_folder = os.path.join(val_dir, class_name)
        if not os.path.isdir(class_folder):
            print(f"Warning: Directory not found for class: {class_name}")
            continue
            
        images = [f for f in os.listdir(class_folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        if not images:
            print(f"Warning: No images found for class: {class_name}")
            continue
            
        # Select 1 representative holdout image
        test_img_path = os.path.join(class_folder, images[0])
        img = Image.open(test_img_path).convert('RGB')
        
        # 1. Unadjusted Prediction (tau = 0.0, raw biased prior)
        top_pred_raw, top_conf_raw, topk_raw, _, _ = model.predict(img, tau=0.0)
        
        # 2. Logit-Adjusted Prediction (tau = 0.85, balanced prior)
        top_pred_adj, top_conf_adj, topk_adj, all_probs, _ = model.predict(img, tau=model.tau)
        
        # Check match
        gt_display = CLASS_DISPLAY.get(class_name, class_name)
        match_raw = "MATCH" if topk_raw[0]['disease_key'] == class_name else "FAIL"
        match_adj = "MATCH" if topk_adj[0]['disease_key'] == class_name else "FAIL"
        
        results.append({
            "class": class_name,
            "filename": images[0],
            "raw_pred": topk_raw[0]['disease_key'],
            "raw_conf": top_conf_raw,
            "adj_pred": topk_adj[0]['disease_key'],
            "adj_conf": top_conf_adj,
            "match_adj": match_adj,
            "top3": topk_adj
        })
        
        print(f"\n[Ground Truth]: {class_name} ({images[0]})")
        print(f"  * Raw Prior (tau=0.0):       Predicted -> {topk_raw[0]['disease_key']} ({top_conf_raw}%) [{match_raw}]")
        print(f"  * Logit-Adjusted (tau={model.tau}): Predicted -> {topk_adj[0]['disease_key']} ({top_conf_adj}%) [{match_adj}]")
        print("    Top-3 Predictions:")
        for rank, p in enumerate(topk_adj, 1):
            print(f"      {rank}. {p['disease_key']:<25} : {p['confidence']:.2f}%")

    print("\n" + "=" * 80)
    print("SUMMARY COMPARISON TABLE: UNADJUSTED (BIASED) vs LOGIT-ADJUSTED (BALANCED)")
    print("=" * 80)
    print(f"{'Class':<26} | {'Raw Pred (tau=0.0)':<22} | {'Adjusted Pred (tau=0.85)':<26} | {'Status'}")
    print("-" * 86)
    adj_correct = 0
    raw_correct = 0
    for r in results:
        is_raw_ok = r['raw_pred'] == r['class']
        is_adj_ok = r['adj_pred'] == r['class']
        if is_raw_ok: raw_correct += 1
        if is_adj_ok: adj_correct += 1
        status = "CORRECT" if is_adj_ok else "MISCLASSIFIED"
        print(f"{r['class']:<26} | {r['raw_pred']} ({r['raw_conf']}%)".ljust(51) + f" | {r['adj_pred']} ({r['adj_conf']}%)".ljust(29) + f" | {status}")

    print("-" * 86)
    print(f"Raw Accuracy (Prior Biased):       {raw_correct}/{len(results)} ({raw_correct/len(results)*100:.1f}%)")
    print(f"Logit-Adjusted Accuracy (tau=0.85): {adj_correct}/{len(results)} ({adj_correct/len(results)*100:.1f}%)")
    print("=" * 80)

if __name__ == '__main__':
    verify_predictions()
