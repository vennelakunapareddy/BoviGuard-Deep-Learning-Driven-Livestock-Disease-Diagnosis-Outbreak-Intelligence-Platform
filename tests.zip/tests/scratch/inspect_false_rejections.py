import torch
from torchvision import models
from PIL import Image
from pathlib import Path

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta['categories']
transform = weights.transforms()

paths = [
    Path('ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0002.jpg'),
    Path('ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0002.jpg')
]

for p in paths:
    if p.exists():
        img = Image.open(p).convert('RGB')
        t = transform(img).unsqueeze(0)
        with torch.no_grad():
            probs = torch.softmax(model(t), dim=-1).squeeze(0)
        top5_p, top5_idx = torch.topk(probs, 5)
        print("=" * 50)
        print(f"File: {p.name}")
        for i in range(5):
            print(f"  {categories[top5_idx[i]]}: {float(top5_p[i])*100:.2f}% (idx={int(top5_idx[i])})")
