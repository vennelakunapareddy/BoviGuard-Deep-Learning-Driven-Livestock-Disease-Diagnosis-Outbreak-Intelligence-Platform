import torch
from PIL import Image
from torchvision import models
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights

det_w = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
detector = ssdlite320_mobilenet_v3_large(weights=det_w).eval()
cls_w = models.MobileNet_V2_Weights.DEFAULT
classifier = models.mobilenet_v2(weights=cls_w).eval()

BOVINE_CATEGORIES = {345, 346, 347, 697}
canine_indices = set(range(151, 276))
feline_indices = set(range(281, 294))
bird_indices = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147)))
vehicle_indices = {403, 407, 436, 475, 479, 511, 627, 654, 670, 671, 751, 817, 864, 867, 895, 468, 555, 665, 705, 734, 779, 829}
document_indices = {916, 620, 664, 782, 487, 921, 446, 508, 526, 722, 687, 728}
building_indices = {497, 498, 538, 598, 652, 663, 678, 698, 706, 449, 749, 876}
human_keywords = ["suit", "jersey", "t-shirt", "sweatshirt", "gown", "sunglasses", "wig", "mask", "military uniform", "cloak", "scuba diver", "neck brace"]

def check_img(pil_img):
    dt = det_w.transforms()(pil_img).unsqueeze(0)
    with torch.no_grad():
        preds = detector(dt)[0]
    
    det_scores = preds['scores']
    det_labels = preds['labels']
    detected_objects = []
    for l, s in zip(det_labels, det_scores):
        if float(s) < 0.35:
            continue
        detected_objects.append({
            "label": det_w.meta["categories"][int(l)],
            "score": float(s)
        })

    has_bovine_obj = any(o["label"] == "cow" for o in detected_objects)
    person_objs = [o for o in detected_objects if o["label"] == "person"]
    dog_objs = [o for o in detected_objects if o["label"] == "dog"]
    cat_objs = [o for o in detected_objects if o["label"] == "cat"]
    bird_objs = [o for o in detected_objects if o["label"] == "bird"]
    vehicle_objs = [o for o in detected_objects if o["label"] in {"car", "truck", "bus", "motorcycle", "bicycle"}]

    ct = cls_w.transforms()(pil_img).unsqueeze(0)
    with torch.no_grad():
        cls_logits = classifier(ct)
        cls_probs = torch.softmax(cls_logits, dim=-1).squeeze(0)

    top5_p, top5_idx = torch.topk(cls_probs, 5)
    top5_indices = [int(idx.item()) for idx in top5_idx]
    top1_idx = top5_indices[0]
    top1_cat = cls_w.meta["categories"][top1_idx].lower()
    top1_prob = float(top5_p[0]) * 100

    has_bovine_cls = any(idx in BOVINE_CATEGORIES for idx in top5_indices)
    has_human_attire = any(k in top1_cat for k in human_keywords) or any(any(k in cls_w.meta["categories"][idx].lower() for k in human_keywords) for idx in top5_indices[:3])
    has_canine_cls = any(idx in canine_indices for idx in top5_indices)
    has_bird_cls = any(idx in bird_indices for idx in top5_indices)
    has_feline_cls = any(idx in feline_indices for idx in top5_indices)

    total_canine = sum(float(cls_probs[i]) for i in canine_indices) * 100
    total_bird = sum(float(cls_probs[i]) for i in bird_indices) * 100
    total_feline = sum(float(cls_probs[i]) for i in feline_indices) * 100

    # 1. Human Detection (Face, Selfie, Handler alone without bovine)
    if person_objs and not has_bovine_obj and not has_bovine_cls:
        top_person = max(person_objs, key=lambda x: x["score"])
        if (top_person["score"] > 0.90 and has_human_attire) or top_person["score"] > 0.96:
            return "REJECTED_HUMAN"

    # 2. Dog Detection
    if dog_objs and not has_bovine_obj and not has_bovine_cls:
        top_dog = max(dog_objs, key=lambda x: x["score"])
        if top_dog["score"] > 0.85 or (top_dog["score"] > 0.40 and (has_canine_cls or total_canine > 20.0)):
            return "REJECTED_DOG"

    # 3. Bird / Poultry Detection
    if bird_objs and not has_bovine_obj and not has_bovine_cls:
        top_bird = max(bird_objs, key=lambda x: x["score"])
        if top_bird["score"] > 0.85 or (top_bird["score"] > 0.40 and (has_bird_cls or total_bird > 20.0)):
            return "REJECTED_BIRD"

    # 4. Cat Detection
    if cat_objs and not has_bovine_obj and not has_bovine_cls:
        top_cat = max(cat_objs, key=lambda x: x["score"])
        if top_cat["score"] > 0.85 or (top_cat["score"] > 0.40 and (has_feline_cls or total_feline > 20.0)):
            return "REJECTED_CAT"

    # 5. Vehicle Detection
    if vehicle_objs and not has_bovine_obj and not has_bovine_cls:
        top_veh = max(vehicle_objs, key=lambda x: x["score"])
        if top_veh["score"] > 0.80:
            return "REJECTED_VEHICLE"

    # 6. Direct Bovine Confirmation
    if has_bovine_obj or has_bovine_cls:
        return "ACCEPTED_BOVINE"

    # 7. ImageNet fine-grained checks
    if (top1_idx in canine_indices and top1_prob > 12.0) or total_canine > 40.0:
        return "REJECTED_DOG"
    if (top1_idx in bird_indices and top1_prob > 15.0) or total_bird > 25.0:
        return "REJECTED_BIRD"
    if (top1_idx in feline_indices and top1_prob > 6.0) or total_feline > 25.0:
        return "REJECTED_CAT"
    if any(k in top1_cat for k in human_keywords) and top1_prob > 3.0:
        return "REJECTED_HUMAN"

    return "ACCEPTED_LESION_OR_BUFFALO"

test_files = [
    ("test_human.jpg", "Human Face / Selfie"),
    ("test_dog.jpg", "Dog"),
    ("test_hen.jpg", "Hen"),
    ("test_cat.jpg", "Cat"),
    ("test_car.jpg", "Car"),
    ("c:/Users/venne/Downloads/fmd.jpg", "User FMD"),
    ("c:/Users/venne/Downloads/lumppy.jpg", "User LSD 1"),
    ("c:/Users/venne/Downloads/Lumpy-skin-disease_d.jpg", "User LSD 2"),
    ("unseen_healthy_buffalo.jpg", "Unseen Buffalo"),
    ("unseen_cow.jpg", "Unseen Cow"),
    ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg", "Healthy (Farmer + Buffalo)"),
    ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg", "Mastitis (Vet Hand)"),
    ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0002.jpg", "Mastitis (Udder Macro)"),
    ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg", "FMD (Mouth)"),
]

print("=" * 70)
for p, name in test_files:
    img = Image.open(p).convert('RGB')
    res = check_img(img)
    print(f"{name:<28} | {res}")
print("=" * 70)
