import urllib.request
import os
from PIL import Image

scratch_dir = r"scratch"
os.makedirs(scratch_dir, exist_ok=True)

# Test images from Wikimedia Commons
test_urls = {
    "dog_golden.jpg": "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Basset_Hound_bi-color.jpg/320px-Basset_Hound_bi-color.jpg",
    "cat_tabby.jpg": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Cat03.jpg/320px-Cat03.jpg",
    "human_portrait.jpg": "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Shakespeare.jpg/320px-Shakespeare.jpg"
}

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

for fname, url in test_urls.items():
    p = os.path.join(scratch_dir, fname)
    if not os.path.exists(p):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp, open(p, 'wb') as f:
                f.write(resp.read())
            print(f"Downloaded {fname}")
        except Exception as e:
            print(f"Failed to download {fname}: {e}")
    else:
        print(f"Already exists: {fname}")
