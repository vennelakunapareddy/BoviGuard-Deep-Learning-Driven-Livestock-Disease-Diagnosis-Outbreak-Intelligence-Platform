import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image
from test_detector_logic import classify_entity, detect_document_cv

exact_file = r"backend\uploads\buffalo-1789550936919-422292939.png"
im = Image.open(exact_file).convert("RGB")
is_doc, conf = detect_document_cv(im)
print(f"detect_document_cv on exact upload: is_doc={is_doc}, conf={conf}")

res = classify_entity(im)
print("classify_entity on exact upload:")
for k, v in res.items():
    print(f"  {k}: {v}")
