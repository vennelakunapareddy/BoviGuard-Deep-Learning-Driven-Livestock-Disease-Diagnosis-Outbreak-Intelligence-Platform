import cv2

print("OpenCV version:", cv2.__version__)
print("Has face in cv2:", [x for x in dir(cv2) if 'face' in x.lower() or 'cascade' in x.lower() or 'detect' in x.lower()])
