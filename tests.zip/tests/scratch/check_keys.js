console.log('GEMINI_API_KEY:', process.env.GEMINI_API_KEY ? 'Present (' + process.env.GEMINI_API_KEY.substring(0, 6) + '...)' : 'Not set');
console.log('LLM_API_KEY:', process.env.LLM_API_KEY ? 'Present' : 'Not set');
console.log('GOOGLE_API_KEY:', process.env.GOOGLE_API_KEY ? 'Present' : 'Not set');
