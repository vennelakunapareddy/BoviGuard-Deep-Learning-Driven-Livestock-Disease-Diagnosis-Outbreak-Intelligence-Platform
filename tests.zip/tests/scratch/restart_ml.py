import os
import subprocess

netstat_exe = r"C:\Windows\System32\netstat.exe"
taskkill_exe = r"C:\Windows\System32\taskkill.exe"

out = subprocess.check_output(f'"{netstat_exe}" -ano', shell=True).decode('utf-8', errors='ignore')
for line in out.splitlines():
    if ':5000 ' in line and 'LISTENING' in line:
        pid = line.strip().split()[-1]
        print('Killing PID on 5000:', pid)
        subprocess.call(f'"{taskkill_exe}" /F /PID {pid}', shell=True)
