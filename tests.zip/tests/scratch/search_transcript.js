const fs = require('fs');
const transcript = 'C:/Users/venne/.gemini/antigravity/brain/1b8c0956-f215-489b-8386-2f6130f7f777/.system_generated/logs/transcript.jsonl';
if (fs.existsSync(transcript)) {
  const lines = fs.readFileSync(transcript, 'utf8').split('\n');
  lines.forEach((l, idx) => {
    if (/brucell/i.test(l)) {
      console.log(`Line ${idx}: ${l.substring(0, 300)}`);
    }
  });
} else {
  console.log('Transcript not found');
}
