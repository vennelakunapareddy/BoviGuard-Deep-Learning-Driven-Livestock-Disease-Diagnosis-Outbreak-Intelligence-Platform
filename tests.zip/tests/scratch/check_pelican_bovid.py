import sys, os
sys.path.insert(0, os.path.abspath('ml-service'))
import app
print("Is 144 in app.BOVID_INDICES?", 144 in app.BOVID_INDICES)
print("app.bovid_prob on pelican:")
import torch, torchvision.models as models
from PIL import Image
weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
transforms = weights.transforms()
f = r"backend\uploads\1779031795064-134015607776913242.jpg"
im = Image.open(f).convert("RGB")
batch = transforms(im).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(batch), dim=1)[0]
bovid_prob = sum(probs[i].item() for i in app.BOVID_INDICES)
print("bovid_prob:", bovid_prob)
is_valid, msg, info = app.is_valid_buffalo_image(im)
print("is_valid:", is_valid, "msg:", msg, "info:", info)
