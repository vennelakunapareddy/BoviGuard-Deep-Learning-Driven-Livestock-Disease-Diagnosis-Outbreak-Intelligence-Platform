const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    list.forEach(file => {
      let fullPath = path.join(dir, file);
      if (file === 'node_modules' || file === '.git' || file === '.venv') return;
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          results = results.concat(walk(fullPath));
        } else {
          // ignore large binaries like weights or zip or images
          if (!/\.(pth|pt|onnx|h5|zip|jpg|jpeg|png|gif|mp4|avi)$/i.test(file)) {
            results.push(fullPath);
          }
        }
      } catch (e) {}
    });
  } catch (e) {}
  return results;
}

const files = walk('.');
console.log(`Checking ${files.length} non-binary files for brucell...`);

let found = 0;
files.forEach(f => {
  try {
    const content = fs.readFileSync(f, 'utf8');
    if (/brucell/i.test(content)) {
      found++;
      console.log(`FOUND in: ${f}`);
      content.split('\n').forEach((l, i) => {
        if (/brucell/i.test(l)) {
          console.log(`  Line ${i+1}: ${l.trim().substring(0, 150)}`);
        }
      });
    }
  } catch (e) {}
});

console.log(`Total files with brucell: ${found}`);
