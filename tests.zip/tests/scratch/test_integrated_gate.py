import io
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms
from torchvision.models.detection import ssdlite320_mobilenet_v3_large, SSDLite320_MobileNet_V3_Large_Weights
from PIL import Image, ImageStat
import numpy as np

# ImageNet Bovine Synset Categories (345: ox, 346: water buffalo, 347: bison, 697: oxcart)
BOVINE_CATEGORIES = {345, 346, 347, 697}

class RobustBuffaloValidationGate:
    """
    Dual-Stage Robust Buffalo Validation Gate:
    Stage 1A: Statistical frame quality & contrast check (rejects blank, black, overexposed, extreme blur).
    Stage 1B: SSDLite320 Object Detector (COCO 91 classes) for macroscopic animals, humans, vehicles.
    Stage 1C: MobileNet-V2 Classifier (ImageNet 1k) for fine-grained synsets (dog breeds, felines, poultry, human attire, screens, buildings).
    """
    def __init__(self, device):
        self.device = device
        self.ready = False
        try:
            # 1. COCO Object Detector (SSDLite320)
            det_weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
            self.detector = ssdlite320_mobilenet_v3_large(weights=det_weights).to(self.device).eval()
            self.coco_classes = det_weights.meta["categories"]
            self.det_transform = det_weights.transforms()

            # 2. ImageNet Classifier (MobileNet-V2)
            cls_weights = models.MobileNet_V2_Weights.DEFAULT
            self.classifier = models.mobilenet_v2(weights=cls_weights).to(self.device).eval()
            self.imagenet_classes = cls_weights.meta["categories"]
            self.cls_transform = cls_weights.transforms()

            # ImageNet category sets
            self.bovine_indices = BOVINE_CATEGORIES
            self.canine_indices = set(range(151, 276))  # 118 domestic dog breeds + wolves
            self.feline_indices = set(range(281, 294))  # Felines
            self.bird_indices = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147)))  # Poultry & birds
            self.other_mammal_indices = set(list(range(294, 345)) + list(range(348, 385)))  # Non-bovine mammals (horse, pig, sheep, goat, etc.)
            self.vehicle_indices = {403, 407, 436, 475, 479, 511, 627, 654, 670, 671, 751, 817, 864, 867, 895, 468, 555, 665, 705, 734, 779, 829}
            self.document_indices = {916, 620, 664, 782, 487, 921, 446, 508, 526, 722, 687, 728}
            self.building_indices = {497, 498, 538, 598, 652, 663, 678, 698, 706, 449, 749, 876}
            self.human_keywords = ["suit", "jersey", "t-shirt", "sweatshirt", "gown", "sunglasses", "wig", "mask", "military uniform", "cloak", "scuba diver", "neck brace"]

            self.ready = True
        except Exception as e:
            print(f"Warning: RobustBuffaloValidationGate init error: {e}")
            self.ready = False

    def inspect(self, pil_img: Image.Image) -> dict:
        w, h = pil_img.size
        img_area = w * h

        # -------------------------------------------------------------
        # STEP 1: Image Quality / Variance Check
        # -------------------------------------------------------------
        stat = ImageStat.Stat(pil_img)
        var = sum(stat.var) / len(stat.var)
        mean_b = sum(stat.mean) / len(stat.mean)
        if var < 12.0 or mean_b < 10 or mean_b > 248:
            return {
                "outcome": "C_UNCERTAIN",
                "is_buffalo": False,
                "status": "uncertain_evidence",
                "entity": "Blank / Low-Contrast Frame",
                "icon": "⚠️",
                "message": "Buffalo validation uncertain: Insufficient visual evidence (blank, dark, or blurry frame). Please provide a clearer photo."
            }

        if not self.ready:
            return {
                "outcome": "A_ACCEPTED",
                "is_buffalo": True,
                "status": "confident",
                "entity": "Water Buffalo / Bovine",
                "icon": "🐃"
            }

        # -------------------------------------------------------------
        # STEP 2: SSDLite320 Object Detection (COCO 91 categories)
        # -------------------------------------------------------------
        try:
            det_t = self.det_transform(pil_img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                preds = self.detector(det_t)[0]

            det_scores = preds['scores']
            det_labels = preds['labels']
            det_boxes = preds['boxes']

            detected_objects = []
            for b, l, s in zip(det_boxes, det_labels, det_scores):
                score_val = float(s)
                if score_val < 0.35:
                    continue
                cat_name = self.coco_classes[int(l)]
                box_area = float((b[2] - b[0]) * (b[3] - b[1]))
                area_pct = (box_area / img_area) * 100
                detected_objects.append({
                    "label": cat_name,
                    "score": score_val,
                    "area_pct": area_pct
                })

            has_bovine_obj = any(o["label"] == "cow" for o in detected_objects)
            person_objs = [o for o in detected_objects if o["label"] == "person"]
            dog_objs = [o for o in detected_objects if o["label"] == "dog"]
            cat_objs = [o for o in detected_objects if o["label"] == "cat"]
            bird_objs = [o for o in detected_objects if o["label"] == "bird"]
            sheep_objs = [o for o in detected_objects if o["label"] in {"sheep", "horse", "elephant", "bear", "zebra", "giraffe"}]
            vehicle_objs = [o for o in detected_objects if o["label"] in {"car", "truck", "bus", "motorcycle", "bicycle"}]

        except Exception as e:
            print(f"Detector error: {e}")
            has_bovine_obj = False
            person_objs, dog_objs, cat_objs, bird_objs, sheep_objs, vehicle_objs = [], [], [], [], [], []

        # -------------------------------------------------------------
        # STEP 3: ImageNet Classification Check (Fine-Grained Context)
        # -------------------------------------------------------------
        try:
            cls_t = self.cls_transform(pil_img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                cls_logits = self.classifier(cls_t)
                cls_probs = torch.softmax(cls_logits, dim=-1).squeeze(0)

            top5_p, top5_idx = torch.topk(cls_probs, 5)
            top5_indices = [int(idx.item()) for idx in top5_idx]
            top1_idx = top5_indices[0]
            top1_cat = self.imagenet_classes[top1_idx].lower()
            top1_prob = float(top5_p[0]) * 100

            has_bovine_cls = any(idx in self.bovine_indices for idx in top5_indices)
            has_human_attire = any(k in top1_cat for k in self.human_keywords) or any(any(k in self.imagenet_classes[idx].lower() for k in self.human_keywords) for idx in top5_indices[:3])

            total_canine = sum(float(cls_probs[i]) for i in self.canine_indices) * 100
            total_bird = sum(float(cls_probs[i]) for i in self.bird_indices) * 100
            total_feline = sum(float(cls_probs[i]) for i in self.feline_indices) * 100

        except Exception as e:
            print(f"Classifier error: {e}")
            has_bovine_cls = False
            has_human_attire = False
            top1_cat = ""
            top1_prob = 0.0
            top1_idx = -1
            total_canine, total_bird, total_feline = 0.0, 0.0, 0.0

        # -------------------------------------------------------------
        # STEP 4: Rule-Based Hierarchical Decision Engine
        # -------------------------------------------------------------

        # 4A. Human Detection (Face, Selfie, Handler alone without bovine)
        if person_objs and not has_bovine_obj and not has_bovine_cls:
            top_person = max(person_objs, key=lambda x: x["score"])
            if (top_person["score"] > 0.90 and has_human_attire) or top_person["score"] > 0.96:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Human / Person",
                    "icon": "👤",
                    "message": "Prediction failed: Human detected in the image. Please point camera at a buffalo."
                }

        # 4B. Canine Detection (Dogs)
        if dog_objs and not has_bovine_obj and not has_bovine_cls:
            top_dog = max(dog_objs, key=lambda x: x["score"])
            if top_dog["score"] > 0.40:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Domestic Dog",
                    "icon": "🐶",
                    "message": "Prediction failed: Domestic dog detected. This system only diagnoses water buffaloes."
                }

        # 4C. Bird / Poultry / Hen
        if bird_objs and not has_bovine_obj and not has_bovine_cls:
            top_bird = max(bird_objs, key=lambda x: x["score"])
            if top_bird["score"] > 0.40:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Bird / Poultry",
                    "icon": "🐔",
                    "message": "Prediction failed: Bird/poultry detected. This system only diagnoses water buffaloes."
                }

        # 4D. Feline / Cat
        if cat_objs and not has_bovine_obj and not has_bovine_cls:
            top_cat = max(cat_objs, key=lambda x: x["score"])
            if top_cat["score"] > 0.40:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": "Feline / Cat",
                    "icon": "🐱",
                    "message": "Prediction failed: Feline/cat detected. This system only diagnoses water buffaloes."
                }

        # 4E. Non-bovine Mammals from Object Detector (sheep, horse, etc.)
        if sheep_objs and not has_bovine_obj and not has_bovine_cls:
            top_other = max(sheep_objs, key=lambda x: x["score"])
            if top_other["score"] > 0.45:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Non-Buffalo Animal ({top_other['label'].capitalize()})",
                    "icon": "🐑",
                    "message": f"Prediction failed: Non-buffalo animal ({top_other['label']}) detected. This system only diagnoses water buffaloes."
                }

        # 4F. Vehicles
        if vehicle_objs and not has_bovine_obj and not has_bovine_cls:
            top_veh = max(vehicle_objs, key=lambda x: x["score"])
            if top_veh["score"] > 0.40:
                return {
                    "outcome": "B_REJECTED",
                    "is_buffalo": False,
                    "status": "rejected",
                    "entity": f"Vehicle ({top_veh['label']})",
                    "icon": "🚗",
                    "message": "Prediction failed: Vehicle detected in the image."
                }

        # 4G. Direct Bovine Confirmation (Full body, head, or herd)
        if has_bovine_obj or has_bovine_cls:
            return {
                "outcome": "A_ACCEPTED",
                "is_buffalo": True,
                "status": "confident",
                "entity": "Water Buffalo / Bovine",
                "icon": "🐃"
            }

        # 4H. ImageNet Fine-Grained Non-Buffalo Checks
        if (top1_idx in self.canine_indices and top1_prob > 12.0) or total_canine > 40.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Domestic Dog ({self.imagenet_classes[top1_idx]})",
                "icon": "🐶",
                "message": f"Prediction failed: Domestic dog detected ({self.imagenet_classes[top1_idx]})."
            }

        if (top1_idx in self.bird_indices and top1_prob > 15.0) or total_bird > 25.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Bird / Poultry ({self.imagenet_classes[top1_idx]})",
                "icon": "🐔",
                "message": f"Prediction failed: Bird/poultry detected ({self.imagenet_classes[top1_idx]})."
            }

        if (top1_idx in self.feline_indices and top1_prob > 6.0) or total_feline > 25.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Feline / Cat ({self.imagenet_classes[top1_idx]})",
                "icon": "🐱",
                "message": f"Prediction failed: Feline detected ({self.imagenet_classes[top1_idx]})."
            }

        doc_keywords = ["web site", "menu", "envelope", "screen", "monitor", "laptop", "cellular telephone", 
                        "crossword", "rule", "paper", "comic book", "book jacket", "binder", "packet", "oscilloscope"]
        if (top1_idx in self.document_indices and top1_prob > 15.0) or (any(k in top1_cat for k in doc_keywords) and top1_prob > 15.0):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Digital Screen / Document ({self.imagenet_classes[top1_idx]})",
                "icon": "💻",
                "message": "Prediction failed: Document / screen detected in the image."
            }

        veh_keywords = ["car", "automobile", "sports car", "truck", "cab", "van", "jeep", "bus", "bicycle", "motorcycle", "airplane", "boat"]
        if (top1_idx in self.vehicle_indices and top1_prob > 15.0) or (any(k in top1_cat for k in veh_keywords) and top1_prob > 15.0):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Vehicle ({self.imagenet_classes[top1_idx]})",
                "icon": "🚗",
                "message": "Prediction failed: Vehicle detected in the image."
            }

        bldg_keywords = ["palace", "castle", "monastery", "church", "mosque", "tile roof", "bell cote", "beacon", "bridge", "house"]
        if (top1_idx in self.building_indices and top1_prob > 15.0) or (any(k in top1_cat for k in bldg_keywords) and top1_prob > 15.0):
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Building / Architecture ({self.imagenet_classes[top1_idx]})",
                "icon": "🏛️",
                "message": "Prediction failed: Building/architecture detected in the image."
            }

        if top1_idx in self.other_mammal_indices and top1_prob > 15.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Non-Buffalo Animal ({self.imagenet_classes[top1_idx]})",
                "icon": "🐴",
                "message": f"Prediction failed: Non-buffalo mammal ({self.imagenet_classes[top1_idx]}) detected."
            }

        if any(k in top1_cat for k in self.human_keywords) and top1_prob > 3.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Human / Person ({self.imagenet_classes[top1_idx]})",
                "icon": "👤",
                "message": "Prediction failed: Human detected in the image."
            }

        incompatible_objects = ["frisbee", "clock", "shoe", "bottle", "cup", "keyboard", "mouse", "toaster", "refrigerator"]
        if any(k in top1_cat for k in incompatible_objects) and top1_prob > 15.0:
            return {
                "outcome": "B_REJECTED",
                "is_buffalo": False,
                "status": "rejected",
                "entity": f"Object ({self.imagenet_classes[top1_idx]})",
                "icon": "📦",
                "message": f"Prediction failed: Incompatible object detected ({self.imagenet_classes[top1_idx]})."
            }

        # 4I. Close-up buffalo skin / lesion candidate
        return {
            "outcome": "A_ACCEPTED",
            "is_buffalo": True,
            "status": "confident",
            "entity": "Buffalo Lesion / Cutaneous Area",
            "icon": "🔬"
        }

NonBuffaloDetector = RobustBuffaloValidationGate

if __name__ == "__main__":
    gate = RobustBuffaloValidationGate(torch.device("cpu"))
    print("RobustBuffaloValidationGate initialized successfully!")
