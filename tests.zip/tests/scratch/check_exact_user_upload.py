import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image

f = r"backend\uploads\buffalo-1789550936919-422292939.png"
im = Image.open(f)
print("Dimensions:", im.size)
print("Format:", im.format)
print("Mode:", im.mode)
