const axios = require('axios');

async function test() {
  try {
    const res = await axios.post('http://127.0.0.1:3000/api/assistant', {
      transcript: 'नमस्ते, मुझे मदद चाहिए',
      language: 'hi-IN'
    });
    console.log('Hindi Assistant Response:');
    console.log(res.data.reply);
  } catch (e) {
    console.error('Error:', e.message);
  }
}

test();
