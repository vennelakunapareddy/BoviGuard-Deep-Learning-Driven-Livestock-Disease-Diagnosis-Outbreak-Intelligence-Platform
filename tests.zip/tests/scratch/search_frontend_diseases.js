const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    list.forEach(file => {
      let fullPath = path.join(dir, file);
      if (file === 'node_modules' || file === '.git' || file === 'dist') return;
      if (fs.statSync(fullPath).isDirectory()) {
        results = results.concat(walk(fullPath));
      } else if (/\.(jsx|js|json)$/.test(file)) {
        results.push(fullPath);
      }
    });
  } catch (e) {}
  return results;
}

const terms = ['brucell', 'traumatic', 'wound', 'cutaneous', 'skin infection'];
const files = walk('frontend-v2/src');

files.forEach(f => {
  try {
    const content = fs.readFileSync(f, 'utf8');
    terms.forEach(t => {
      const reg = new RegExp(t, 'i');
      if (reg.test(content)) {
        content.split('\n').forEach((line, idx) => {
          if (reg.test(line)) {
            console.log(`${f}:${idx + 1} [${t}] -> ${line.trim()}`);
          }
        });
      }
    });
  } catch (e) {}
});
