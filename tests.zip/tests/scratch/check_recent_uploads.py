import os
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
from PIL import Image

uploads_dir = r"backend\uploads"
files = sorted(os.listdir(uploads_dir), key=lambda x: os.path.getmtime(os.path.join(uploads_dir, x)), reverse=True)
print(f"Total uploaded files in backend/uploads: {len(files)}")
print("Most recent 10 uploads:")
for f in files[:10]:
    p = os.path.join(uploads_dir, f)
    size = os.path.getsize(p)
    try:
        im = Image.open(p)
        print(f"  {f} : {size} bytes, dimensions={im.size}, format={im.format}")
    except Exception as e:
        print(f"  {f} : error {e}")
