import os, sys
from PIL import Image
import torch, torchvision.models as models

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transforms = weights.transforms()

f = r"backend\uploads\1779031795064-134015607776913242.jpg"
im = Image.open(f).convert("RGB")
batch = transforms(im).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(batch), dim=1)[0]
top5_prob, top5_idx = torch.topk(probs, 5)
for p, idx in zip(top5_prob, top5_idx):
    print(f"{idx.item()}: {categories[idx.item()]} ({p.item()*100:.2f}%)")
