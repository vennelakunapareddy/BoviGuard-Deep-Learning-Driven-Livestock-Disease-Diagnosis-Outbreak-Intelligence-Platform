import os
import sys
import torch
from PIL import Image

sys.path.insert(0, os.path.abspath('ml-service'))
import app

img_path = r"C:\Users\venne\.gemini\antigravity\brain\14c4b76e-be5c-40d9-a3a9-ad8ef9baa55b\.user_uploaded\media_1789550975998.png"
full_screenshot = Image.open(img_path).convert('RGB')

doc_crop = full_screenshot.crop((280, 150, 620, 360)).convert('RGB')
doc_crop.save(r"scratch\doc_crop.png")

print("Doc crop size:", doc_crop.size)

# Test ImageNet model predictions
batch = app.imagenet_preprocess(doc_crop).unsqueeze(0)
with torch.no_grad():
    logits = app.imagenet_model(batch)
    probs = torch.softmax(logits, dim=1)[0]

top10_prob, top10_idx = torch.topk(probs, 10)
print("\nImageNet Top 10 Predictions on Document Crop:")
for p, idx in zip(top10_prob, top10_idx):
    print(f"  {idx.item()}: {app.imagenet_categories[idx.item()]} ({p.item()*100:.2f}%)")

# Test is_valid_buffalo_image
is_valid, msg = app.is_valid_buffalo_image(doc_crop)
print(f"\nis_valid_buffalo_image result: {is_valid}")
print(f"Message: {msg}")
