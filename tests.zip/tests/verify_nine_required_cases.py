import os
import sys
import json
import requests

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

URL = "http://localhost:3000/api/cases/predict"

cases = [
    {
        "id": "CASE-1",
        "description": "Healthy Buffalo",
        "path": "ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg",
        "expected_animal": "Buffalo",
        "expected_disease": "Healthy Buffalo"
    },
    {
        "id": "CASE-2",
        "description": "Buffalo with visible Lumpy Skin Disease",
        "path": "ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.png",
        "expected_animal": "Buffalo",
        "expected_disease": "Lumpy Skin Disease (LSD)"
    },
    {
        "id": "CASE-3",
        "description": "Buffalo with visible Clinical Mastitis signs",
        "path": "ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg",
        "expected_animal": "Buffalo",
        "expected_disease": "Clinical Mastitis"
    },
    {
        "id": "CASE-4",
        "description": "Buffalo with visible FMD signs",
        "path": "ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg",
        "expected_animal": "Buffalo",
        "expected_disease": "Foot-and-Mouth Disease (FMD)"
    },
    {
        "id": "CASE-5",
        "description": "Dog (Domestic)",
        "path": "test_dog.jpg",
        "expected_animal": "Non-Buffalo",
        "expected_disease": "REJECT"
    },
    {
        "id": "CASE-6",
        "description": "Hen (Poultry)",
        "path": "test_hen.jpg",
        "expected_animal": "Non-Buffalo",
        "expected_disease": "REJECT"
    },
    {
        "id": "CASE-7",
        "description": "Cat (Feline)",
        "path": "test_cat.jpg",
        "expected_animal": "Non-Buffalo",
        "expected_disease": "REJECT"
    },
    {
        "id": "CASE-8",
        "description": "Human",
        "path": "test_human.jpg",
        "expected_animal": "Non-Buffalo",
        "expected_disease": "REJECT"
    },
    {
        "id": "CASE-9",
        "description": "Random Object (Sports Car)",
        "path": "test_car.jpg",
        "expected_animal": "Non-Buffalo",
        "expected_disease": "REJECT"
    }
]

print("=" * 80)
print("PHASE 4 & 5 MANDATORY VERIFICATION: 9 TEST CASES")
print("TARGET: POST http://localhost:3000/api/cases/predict")
print("=" * 80)

results = []

for c in cases:
    print(f"\n================================================================================")
    print(f">> {c['id']}: {c['description']}")
    print(f"   Path: {c['path']}")
    print(f"   Expected: {c['expected_animal']} -> {c['expected_disease']}")
    
    with open(c['path'], "rb") as f:
        files = {"image": (os.path.basename(c['path']), f, "image/jpeg")}
        data = {"animalType": "Buffalo"}
        res = requests.post(URL, files=files, data=data, timeout=30)
    
    print(f"   HTTP Status: {res.status_code}")
    d = res.json()
    
    is_buf = d.get("isBuffalo")
    status = d.get("status")
    
    if not is_buf:
        print(f"   Buffalo Validation Result: REJECTED (Non-Buffalo)")
        print(f"   Entity Identified:         {d.get('predictedSubject')}")
        print(f"   Rejection Message:         {d.get('message')}")
        print(f"   Disease Model Bypassed:    YES (No disease prediction returned)")
        is_correct = (c["expected_animal"] == "Non-Buffalo")
    else:
        print(f"   Buffalo Validation Result: BUFFALO DETECTED")
        print(f"   Disease Prediction:        {d.get('diseasePrediction')}")
        print(f"   Predicted Index:           {d.get('predicted_index')}")
        print(f"   Confidence Score:          {d.get('confidenceScore')}%")
        print(f"   Raw Output Logits:         {d.get('raw_logits')}")
        print(f"   4 Class Probabilities:")
        for p in d.get("allProbabilities", []):
            print(f"     - Class {p.get('class_index')} [{p.get('disease')}]: {p.get('confidence')}% (Prob={p.get('probability')})")
        is_correct = (c["expected_animal"] == "Buffalo" and d.get("diseasePrediction") == c["expected_disease"])

    print(f"   Result Evaluation:         {'CORRECT [PASS]' if is_correct else 'INCORRECT [FAIL]'}")
    results.append({
        "id": c["id"],
        "desc": c["description"],
        "is_correct": is_correct,
        "response": d
    })

print("\n" + "=" * 80)
total_correct = sum(1 for r in results if r["is_correct"])
print(f"VERIFICATION SUMMARY: {total_correct}/{len(results)} CASES PASSED")
print("=" * 80)
