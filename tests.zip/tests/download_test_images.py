import urllib.request
import os

images = {
    "test_dog.jpg": "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&q=80",
    "test_hen.jpg": "https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=400&q=80",
    "test_cat.jpg": "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&q=80",
    "test_car.jpg": "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400&q=80",
    "test_human.jpg": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&q=80"
}

headers = {'User-Agent': 'Mozilla/5.0'}

for name, url in images.items():
    if not os.path.exists(name):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response, open(name, 'wb') as out_file:
                out_file.write(response.read())
            print(f"[OK] Downloaded {name}")
        except Exception as e:
            print(f"[FAIL] {name}: {e}")
    else:
        print(f"[EXISTS] {name}")
