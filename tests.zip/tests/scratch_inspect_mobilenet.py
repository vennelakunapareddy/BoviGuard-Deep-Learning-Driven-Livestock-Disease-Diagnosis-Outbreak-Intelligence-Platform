import os
import torch
import torchvision.models as models
from PIL import Image

weights = models.MobileNet_V2_Weights.DEFAULT
m = models.mobilenet_v2(weights=weights).eval()
cats = weights.meta['categories']
tf = weights.transforms()

print("=" * 80)
print("INSPECTING MOBILENETV2 PREDICTIONS ACROSS BUFFALO TEST DATASET")
print("=" * 80)

# Check all test images
for folder in ['Healthy_Buffalo', 'Lumpy_Skin_Disease', 'Mastitis', 'Foot_and_Mouth_Disease']:
    dirpath = os.path.join('ml-service/buffalo_dataset/test', folder)
    if os.path.exists(dirpath):
        imgs = [os.path.join(dirpath, f) for f in os.listdir(dirpath)[:4]]
        for p in imgs:
            img = Image.open(p).convert('RGB')
            t = tf(img).unsqueeze(0)
            with torch.no_grad():
                probs = torch.softmax(m(t), dim=-1).squeeze(0)
            top5_p, top5_idx = torch.topk(probs, 5)
            res = [f"{cats[int(i)]} ({float(p)*100:.1f}%)" for i, p in zip(top5_idx, top5_p)]
            bov_indices = [int(i) for i in top5_idx if int(i) in {345, 346, 347, 697}]
            print(f"{folder} [{os.path.basename(p)}]:")
            print(f"   Top-5: {res}")
            print(f"   Bovine in top 5: {bov_indices}")
