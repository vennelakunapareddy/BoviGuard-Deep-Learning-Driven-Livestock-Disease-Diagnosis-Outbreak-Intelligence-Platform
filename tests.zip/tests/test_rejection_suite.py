import os
import sys
import torch
import torchvision.models as models
from PIL import Image

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

weights = models.MobileNet_V2_Weights.DEFAULT
model = models.mobilenet_v2(weights=weights).eval()
categories = weights.meta["categories"]
transforms = weights.transforms()

CANINE_INDICES = set(range(151, 276))
FELINE_INDICES = set(range(281, 294))
BIRD_INDICES = set(list(range(7, 25)) + list(range(80, 101)) + list(range(127, 147)))
OTHER_MAMMAL_INDICES = set(list(range(294, 345)) + list(range(348, 385)))
BOVINE_INDICES = {345, 346, 347, 697}
VEHICLE_INDICES = {403, 407, 436, 475, 479, 511, 627, 654, 670, 671, 751, 817, 864, 867, 895, 468, 555, 665, 705, 734, 779, 829}
DOCUMENT_SCREEN_INDICES = {916, 620, 664, 782, 487, 921, 446, 508, 526, 722, 687, 728}
BUILDING_INDICES = {497, 498, 538, 598, 652, 663, 678, 698, 706, 449, 749, 876}

def evaluate_image(path):
    img = Image.open(path).convert("RGB")
    t = transforms(img).unsqueeze(0)
    with torch.no_grad():
        probs = torch.softmax(model(t), dim=-1).squeeze(0)

    top5_p, top5_idx = torch.topk(probs, 5)
    top5_indices = [int(idx.item()) for idx in top5_idx]
    top1_idx = top5_indices[0]
    top1_cat = categories[top1_idx].lower()
    top1_prob = float(top5_p[0]) * 100

    has_bovine = any(idx in BOVINE_INDICES for idx in top5_indices)
    if has_bovine:
        return {"is_buffalo": True, "reason": f"Bovine detected in top-5 ({[categories[i] for i in top5_indices if i in BOVINE_INDICES]})"}

    total_canine = sum(float(probs[i]) for i in CANINE_INDICES) * 100
    total_bird = sum(float(probs[i]) for i in BIRD_INDICES) * 100
    total_feline = sum(float(probs[i]) for i in FELINE_INDICES) * 100

    # 1. Birds & Poultry (Hen, Cock, Chicken, Duck, etc.)
    if top1_idx in BIRD_INDICES or total_bird > 25.0:
        return {"is_buffalo": False, "entity": f"Bird / Poultry ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 2. Canines (Dogs)
    if (top1_idx in CANINE_INDICES and top1_prob > 12.0) or total_canine > 40.0:
        return {"is_buffalo": False, "entity": f"Domestic Dog ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 3. Felines (Cats)
    if top1_idx in FELINE_INDICES or total_feline > 15.0:
        return {"is_buffalo": False, "entity": f"Feline / Cat ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 4. Documents & Screens
    doc_words = ["web site", "screen", "monitor", "laptop", "cellular telephone", "menu", "envelope", "crossword", "paper", "packet", "comic book", "binder"]
    if top1_idx in DOCUMENT_SCREEN_INDICES or any(k in top1_cat for k in doc_words):
        return {"is_buffalo": False, "entity": f"Digital Screen / Document ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 5. Vehicles
    veh_words = ["car", "automobile", "sports car", "truck", "cab", "van", "jeep", "bus", "bicycle", "motorcycle", "airplane", "boat"]
    if top1_idx in VEHICLE_INDICES or any(k in top1_cat for k in veh_words):
        return {"is_buffalo": False, "entity": f"Vehicle ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 6. Buildings
    bldg_words = ["palace", "castle", "monastery", "church", "mosque", "tile roof", "bell cote", "beacon", "bridge", "house"]
    if top1_idx in BUILDING_INDICES or any(k in top1_cat for k in bldg_words):
        return {"is_buffalo": False, "entity": f"Building / Architecture ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 7. Other Mammals (Horse, Zebra, Pig, Sheep, Goat, Camel)
    if top1_idx in OTHER_MAMMAL_INDICES and top1_prob > 15.0:
        return {"is_buffalo": False, "entity": f"Non-Buffalo Animal ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 8. Humans & Clothing
    human_words = ["suit", "jersey", "t-shirt", "sweatshirt", "gown", "sunglasses", "wig", "mask", "military uniform", "cloak", "scuba diver"]
    if any(k in top1_cat for k in human_words):
        return {"is_buffalo": False, "entity": f"Human / Person ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    # 9. Plants & Flowers
    plant_words = ["flower", "daisy", "rose", "mushroom", "pomegranate", "corn", "ear", "pot", "honeycomb"]
    if any(k in top1_cat for k in plant_words) and top1_prob > 12.0:
        return {"is_buffalo": False, "entity": f"Plant / Object ({categories[top1_idx]})", "msg": f"detected {categories[top1_idx]}"}

    return {"is_buffalo": True, "reason": "Passed all non-buffalo rejection criteria (lesion/buffalo tissue)"}

suite = [
    # Non-Buffaloes (MUST REJECT)
    ("test_dog.jpg", False, "Dog"),
    ("test_hen.jpg", False, "Hen"),
    ("test_cat.jpg", False, "Cat"),
    ("test_car.jpg", False, "Car"),
    ("test_human.jpg", False, "Human"),
    (r"C:\Users\venne\Downloads\ap eapcet.jpg", False, "Certificate Document"),
    ("ml-service/venv/Lib/site-packages/sklearn/datasets/images/china.jpg", False, "Palace Architecture"),
    ("ml-service/venv/Lib/site-packages/sklearn/datasets/images/flower.jpg", False, "Flower"),
    # Buffalo Images (MUST ACCEPT)
    ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg", True, "Healthy Buffalo 1"),
    ("ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0002.jpg", True, "Healthy Buffalo 2"),
    ("ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.png", True, "LSD Lesion 1"),
    ("ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg", True, "Mastitis Teat 1"),
    ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg", True, "FMD Lesion 1"),
    ("ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0004.jpg", True, "FMD Lesion 4"),
    (r"C:\Users\venne\Downloads\lumppy.jpg", True, "LSD User Upload"),
    (r"C:\Users\venne\Downloads\fmd.jpg", True, "FMD User Upload"),
]

print("=" * 80)
print("TESTING ACCURACY OF REJECTION LOGIC ACROSS ENTIRE TEST MATRIX")
print("=" * 80)

def resolve_path(p):
    if os.path.isabs(p) and os.path.exists(p):
        return p
    if os.path.exists(p):
        return p
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    local_p = os.path.join(cur_dir, p)
    if os.path.exists(local_p):
        return local_p
    root_p = os.path.join(cur_dir, "..", p)
    if os.path.exists(root_p):
        return root_p
    return p

passed = 0
for raw_path, expected_buffalo, label in suite:
    path = resolve_path(raw_path)
    if not os.path.exists(path):
        continue
    res = evaluate_image(path)
    ok = (res["is_buffalo"] == expected_buffalo)
    status_str = "PASS" if ok else "FAIL"
    if ok:
        passed += 1
    print(f"[{status_str}] {label:20s} Expected: {'BUFFALO' if expected_buffalo else 'REJECT'} | Got: {'BUFFALO' if res['is_buffalo'] else 'REJECT'} ({res.get('entity') or res.get('reason')})")

print(f"\nTOTAL RESULT: {passed}/{len(suite)} tests passed!")
