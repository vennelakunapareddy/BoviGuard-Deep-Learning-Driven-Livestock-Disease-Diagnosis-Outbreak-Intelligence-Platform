import os
import requests
import json

URL = "http://localhost:3000/api/cases/predict"

test_suite = [
    # 1. Non-Buffalo: C++ Programming Screenshot uploaded by user
    {
        "path": r"C:/Users/venne/.gemini/antigravity/brain/cc40e0f5-6ad5-4500-8e03-4f77ae9d2db8/.user_uploaded/media_1790866329001.png",
        "description": "User Uploaded C++ Code Screenshot (Non-Buffalo)",
        "expected_buffalo": False
    },
    # 2. Non-Buffalo: China Temple (Architecture)
    {
        "path": "ml-service/venv/Lib/site-packages/sklearn/datasets/images/china.jpg",
        "description": "China Temple / Architecture (Non-Buffalo)",
        "expected_buffalo": False
    },
    # 3. Non-Buffalo: Flower (Plant)
    {
        "path": "ml-service/venv/Lib/site-packages/sklearn/datasets/images/flower.jpg",
        "description": "Flower / Botany (Non-Buffalo)",
        "expected_buffalo": False
    },
    # 4. Healthy Buffalo: Real buffalo from dataset
    {
        "path": "ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg",
        "description": "Real Healthy Buffalo Photo",
        "expected_buffalo": True
    },
    # 5. Lumpy Skin Disease: Real buffalo lesion photo from dataset
    {
        "path": "ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.png",
        "description": "Real Buffalo Lumpy Skin Disease Lesions",
        "expected_buffalo": True
    },
    # 6. Clinical Mastitis: Real buffalo teat/udder photo from dataset
    {
        "path": "ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg",
        "description": "Real Buffalo Clinical Mastitis Udder/Teats",
        "expected_buffalo": True
    },
    # 7. Foot-and-Mouth Disease: Real buffalo oral/hoof photo from dataset
    {
        "path": "ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg",
        "description": "Real Buffalo Foot-and-Mouth Disease Lesions",
        "expected_buffalo": True
    }
]

print("=" * 80)
print("COMPREHENSIVE END-TO-END AUDIT ON REAL API: http://localhost:3000/api/cases/predict")
print("=" * 80)

audit_results = []

for item in test_suite:
    p = item["path"]
    desc = item["description"]
    print(f"\n>> TESTING: {desc}")
    print(f"   File Path: {p}")

    if not os.path.exists(p):
        print(f"   [SKIPPED] File not found: {p}")
        continue

    try:
        with open(p, "rb") as f:
            files = {"image": (os.path.basename(p), f, "image/jpeg")}
            data = {"animalType": "Buffalo"}
            res = requests.post(URL, files=files, data=data, timeout=30)

        print(f"   HTTP Status: {res.status_code}")
        resp_json = res.json()

        is_buffalo = resp_json.get("isBuffalo")
        print(f"   isBuffalo:   {is_buffalo}")

        if not is_buffalo:
            print(f"   Rejection:   {resp_json.get('message')}")
            print(f"   Entity:      {resp_json.get('predictedSubject')}")
            print(f"   Status:      {resp_json.get('status')}")
        else:
            print(f"   Prediction:  {resp_json.get('diseasePrediction')} (Index {resp_json.get('predicted_index')})")
            print(f"   Confidence:  {resp_json.get('confidenceScore')}%")
            print(f"   Raw Logits:  {resp_json.get('raw_logits')}")
            print(f"   Probabilities:")
            for prob_item in resp_json.get("allProbabilities", []):
                print(f"     - Class {prob_item.get('class_index')} [{prob_item.get('disease')} / {prob_item.get('class_key')}]: {prob_item.get('confidence')}% (Prob={prob_item.get('probability')})")

        audit_results.append({
            "description": desc,
            "path": p,
            "status_code": res.status_code,
            "is_buffalo": is_buffalo,
            "api_response": resp_json
        })

    except Exception as e:
        print(f"   [ERROR]: {e}")

print("\n" + "=" * 80)
print(f"AUDIT COMPLETE: Tested {len(audit_results)} cases successfully against port 3000.")
print("=" * 80)
