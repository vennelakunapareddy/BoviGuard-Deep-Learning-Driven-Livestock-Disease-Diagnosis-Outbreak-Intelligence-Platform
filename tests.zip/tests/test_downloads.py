import requests
import json

paths = [
    r'C:\Users\venne\Downloads\ap eapcet.jpg',
    r'C:\Users\venne\Downloads\fmd.jpg',
    r'C:\Users\venne\Downloads\lumppy.jpg',
    r'C:\Users\venne\Downloads\Lumpy-skin-disease_d.jpg'
]

print("=" * 80)
print("TESTING REAL DOWNLOADED USER IMAGES AGAINST http://localhost:3000/api/cases/predict")
print("=" * 80)

for p in paths:
    print(f"\n>> Testing: {p}")
    try:
        with open(p, 'rb') as f:
            r = requests.post(
                'http://localhost:3000/api/cases/predict',
                files={'image': ('image.jpg', f, 'image/jpeg')},
                data={'animalType': 'Buffalo'},
                timeout=15
            )
        d = r.json()
        print(f"   HTTP Status: {r.status_code}")
        print(f"   isBuffalo:   {d.get('isBuffalo')}")
        if not d.get('isBuffalo'):
            print(f"   Rejection:   {d.get('message')}")
            print(f"   Subject:     {d.get('predictedSubject')}")
        else:
            print(f"   Prediction:  {d.get('diseasePrediction')} (Index {d.get('predicted_index')})")
            print(f"   Confidence:  {d.get('confidenceScore')}%")
            print(f"   Raw Logits:  {d.get('raw_logits')}")
            print(f"   All Probs:   {json.dumps(d.get('allProbabilities'), indent=2)}")
    except Exception as e:
        print(f"   Error: {e}")
