import os
import sys
import json
import requests

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

URL = "http://localhost:3000/api/cases/predict"

test_cases = [
    # 1. Healthy Buffalo
    {
        "name": "TEST 1: Healthy Buffalo Image",
        "path": "ml-service/buffalo_dataset/test/Healthy_Buffalo/Healthy_Buffalo_test_0001.jpg",
        "expected_buffalo": True,
        "expected_disease": "Healthy Buffalo"
    },
    # 2. Lumpy Skin Disease
    {
        "name": "TEST 2: Lumpy Skin Disease Image",
        "path": "ml-service/buffalo_dataset/test/Lumpy_Skin_Disease/Lumpy_Skin_Disease_test_0001.png",
        "expected_buffalo": True,
        "expected_disease": "Lumpy Skin Disease (LSD)"
    },
    # 3. Clinical Mastitis
    {
        "name": "TEST 3: Clinical Mastitis Image",
        "path": "ml-service/buffalo_dataset/test/Mastitis/Mastitis_test_0001.jpg",
        "expected_buffalo": True,
        "expected_disease": "Clinical Mastitis"
    },
    # 4. Foot-and-Mouth Disease
    {
        "name": "TEST 4: FMD Buffalo Image",
        "path": "ml-service/buffalo_dataset/test/Foot_and_Mouth_Disease/Foot_and_Mouth_Disease_test_0001.jpg",
        "expected_buffalo": True,
        "expected_disease": "Foot-and-Mouth Disease (FMD)"
    },
    # 5. Dog Image
    {
        "name": "TEST 5: Dog Image",
        "path": "test_dog.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 6. Hen Image
    {
        "name": "TEST 6: Hen Image",
        "path": "test_hen.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 7. Cat Image
    {
        "name": "TEST 7: Cat Image",
        "path": "test_cat.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 8. Human Image
    {
        "name": "TEST 8: Human Image",
        "path": "test_human.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 9. Random Object: Car
    {
        "name": "TEST 9: Car (Vehicle)",
        "path": "test_car.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 10. Random Object: Architecture
    {
        "name": "TEST 10: Architecture (Palace)",
        "path": "ml-service/venv/Lib/site-packages/sklearn/datasets/images/china.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 11. Random Object: Flower
    {
        "name": "TEST 11: Flower (Plant)",
        "path": "ml-service/venv/Lib/site-packages/sklearn/datasets/images/flower.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    },
    # 12. Random Object: Document
    {
        "name": "TEST 12: Certificate / Document",
        "path": r"C:\Users\venne\Downloads\ap eapcet.jpg",
        "expected_buffalo": False,
        "expected_disease": None
    }
]

print("=" * 80)
print("FINAL END-TO-END INFERENCE VERIFICATION SUITE")
print("TARGET ENDPOINT: POST http://localhost:3000/api/cases/predict")
print("=" * 80)

passed = 0
total = 0

def resolve_path(p):
    if os.path.isabs(p) and os.path.exists(p):
        return p
    if os.path.exists(p):
        return p
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    local_p = os.path.join(cur_dir, p)
    if os.path.exists(local_p):
        return local_p
    root_p = os.path.join(cur_dir, "..", p)
    if os.path.exists(root_p):
        return root_p
    return p

for item in test_cases:
    path = resolve_path(item["path"])
    name = item["name"]
    expected_buf = item["expected_buffalo"]
    expected_dis = item["expected_disease"]

    if not os.path.exists(path):
        print(f"\n[SKIP] {name}: File not found ({path})")
        continue

    total += 1
    print(f"\n>> {name}")
    print(f"   File: {path}")

    try:
        with open(path, "rb") as f:
            files = {"image": (os.path.basename(path), f, "image/jpeg")}
            data = {"animalType": "Buffalo"}
            resp = requests.post(URL, files=files, data=data, timeout=30)

        if resp.status_code != 200:
            print(f"   [FAIL] HTTP Status: {resp.status_code}")
            continue

        res = resp.json()
        is_buffalo = res.get("isBuffalo")

        if expected_buf:
            # Expected Buffalo
            actual_disease = res.get("diseasePrediction")
            conf = res.get("confidenceScore")
            probs = res.get("allProbabilities", [])
            num_probs = len(probs)
            logits = res.get("raw_logits")

            ok = (is_buffalo == True) and (actual_disease == expected_dis) and (num_probs == 4)
            status_tag = "[PASS]" if ok else "[FAIL]"
            if ok:
                passed += 1

            print(f"   {status_tag} Buffalo Detected: {is_buffalo}")
            print(f"   {status_tag} Disease: {actual_disease} (Expected: {expected_dis})")
            print(f"   {status_tag} Confidence: {conf}%")
            print(f"   {status_tag} Raw Logits: {logits}")
            print(f"   {status_tag} 4-Class Probability Breakdown ({num_probs} classes):")
            for p_item in probs:
                print(f"       - Index {p_item.get('class_index')} [{p_item.get('disease')}]: {p_item.get('confidence')}%")
        else:
            # Expected Rejection
            status = res.get("status")
            msg = res.get("message")
            entity = res.get("predictedSubject")

            ok = (is_buffalo == False) and (status == "rejected")
            status_tag = "[PASS]" if ok else "[FAIL]"
            if ok:
                passed += 1

            print(f"   {status_tag} Buffalo Detected: {is_buffalo} (Expected: False)")
            print(f"   {status_tag} Status: {status}")
            print(f"   {status_tag} Rejection Message: {msg}")
            print(f"   {status_tag} Identified Non-Buffalo Entity: {entity}")

    except Exception as e:
        print(f"   [ERROR]: {e}")

print("\n" + "=" * 80)
print(f"FINAL SUITE SCORE: {passed}/{total} TESTS PASSED PERFECTLY")
print("=" * 80)
