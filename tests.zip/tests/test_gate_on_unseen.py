import os
import sys
import torch
import torchvision.models as models
from PIL import Image

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

sys.path.insert(0, "ml-service")
from model import NonBuffaloDetector, BuffaloDiseaseModel

disease_model = BuffaloDiseaseModel()
detector = disease_model.entity_detector

test_imgs = [
    ("unseen_healthy_buffalo.jpg", "Unseen Healthy Buffalo"),
    ("unseen_cow.jpg", "Unseen Dairy Cow"),
    ("unseen_goat.jpg", "Unseen Goat"),
    ("random_texture.jpg", "Random Synthetic Texture"),
    ("corrupted_blur.jpg", "Corrupted / Low Contrast Frame"),
    ("c:/Users/venne/Downloads/fmd.jpg", "Unseen FMD Buffalo (User Download)"),
    ("c:/Users/venne/Downloads/lumppy.jpg", "Unseen LSD Buffalo (User Download)"),
]

print("=" * 80)
print("TESTING DETECTOR ON UNSEEN IMAGES")
print("=" * 80)

for p, desc in test_imgs:
    if not os.path.exists(p):
        print(f"Skipping {p} (not found)")
        continue
    img = Image.open(p).convert("RGB")
    res = detector.inspect(img)
    print(f">> {desc} ({p}):")
    print(f"   Result: {res}")
