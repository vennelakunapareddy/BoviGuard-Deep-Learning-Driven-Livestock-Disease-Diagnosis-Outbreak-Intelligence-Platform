import os
import sys

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "ml-service"))
from model import NonBuffaloDetector, BuffaloDiseaseModel
from PIL import Image

disease_model = BuffaloDiseaseModel()
detector = disease_model.entity_detector

for p in ['test_dog.jpg', 'test_hen.jpg', 'test_cat.jpg', 'test_car.jpg', 'test_human.jpg']:
    if os.path.exists(p):
        img = Image.open(p).convert('RGB')
        res = detector.inspect(img)
        print(f">> {p} -> {res}")
